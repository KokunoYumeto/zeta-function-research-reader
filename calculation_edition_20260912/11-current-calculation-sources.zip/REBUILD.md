# Rebuilding the calculation readers

The two PDFs collect complete authored notes at the immutable revision recorded
in `final_snapshot.json`. That manifest hashes the included repository files;
each reader manifest records its exact selected notes and formulas.

The source tree deliberately includes the new calculation and formalization
workbenches rather than duplicating the earlier six PDFs and their source ZIP.
The earlier exact edition remains available at
<https://zenodo.org/records/22678086>, with the complete source download
`07-complete-mathematical-sources.zip`. Source-note links in the new reader use
immutable GitHub revisions, including when they point outside this focused ZIP.

## PDF build

Install Python 3, Pandoc and a XeLaTeX distribution containing the packages used
in the generated TeX. Fonts: DejaVu Serif, DejaVu Sans, DejaVu Sans Mono,
DejaVu Math TeX Gyre and Latin Modern Math. No standalone fonts are distributed.
The build also uses `microtype`, `fvextra`, `adjustbox`, `xurl`, `mathtools`,
`ucharclasses`, `newunicodechar` and `tocloft`.

From `reader-build`:

```sh
python build_readers.py --root ../repository --commit 512fb1a6aa0922318aff49081c01674cf30ec906
```

Both source editions are hashed before rendering. Delimited formulas are
checked unchanged. The builder records its few presentation-only conversions
of ASCII formulas, permits paths and revision hashes to wrap, and preserves
the complete selected note bodies. Generated TeX and Markdown are also included
so they can be compiled directly or inspected independently of the builder.
PDF container timestamps may differ on rebuilding; source hashes, not a promise
of bit-for-bit PDF reproducibility across TeX systems, identify the edition.

## Formal and finite computations

Each workbench retains its complete test code and reproduction instructions.
Start with its README and validation record. The formal package is in
`repository/formal/splitzero`; its Lean toolchain, Mathlib revision, recovery
source manifest and GitHub workflow definitions are retained.

`prepare.py` retrieves the original `SplitZero.lean` implementation from its
immutable public source URL and refuses any Git-blob hash mismatch. Mathlib
and Lean are pinned external dependencies; their build caches are not bundled.
The workflow and note document the successful version-specific formal runs.
Running a finite checker does not replace a Lean run or establish the analytic
claims that the notes explicitly leave outside formalization.

## Rights

Read the preserved `repository/RIGHTS.md` and the individual workbench notices.
No blanket license over third-party source results is added by this collection.
Primary books and papers, private conversations and the local literature corpus
are not included. The notes cite those sources at their stated locators.
