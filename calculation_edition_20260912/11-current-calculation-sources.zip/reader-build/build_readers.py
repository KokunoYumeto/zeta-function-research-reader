"""Typeset complete authored calculation notes; no remote mutations.

The only source changes are presentation-level: source links are made absolute,
note titles receive edition metadata, and source prose Unicode hyphens become
ASCII hyphens. Mathematical source bodies and formula tokens are checked before
and after the renderer. Final mode reads one exact integrated repository tree.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
INTAKE = HERE.parent
REPO = "https://github.com/KokunoYumeto/zeta-function-research-reader"
PANDOC = shutil.which("pandoc") or "pandoc"
ENGINE = shutil.which("xelatex") or "xelatex"

SPLIT = [
    (0, "RESEARCH_PROGRAMMES.md"),
    (0, "formal/splitzero/MATHEMATICAL_NOTE.md"),
    (0, "formal/splitzero/DERIVED_MATHEMATICS.md"),
    (0, "formal/splitzero/SYNCHRONIZATION.md"),
    (3, "workbenches/split-support-rees-trace/RESEARCH_NOTE.md"),
    (3, "workbenches/split-support-rees-trace/ORIGIN_JET_LADDER.md"),
    (3, "workbenches/split-support-rees-trace/ACTUAL_ADELIC_COMPARISON.md"),
    (3, "workbenches/split-support-rees-trace/ORIGINAL_QUOTIENT_PROPAGATION.md"),
    (8, "workbenches/tau-base-cohomology/TAU_BASE_MODEL.md"),
    (8, "workbenches/tau-base-cohomology/FINITE_OPERATOR_COMPARISON.md"),
    (8, "workbenches/tau-base-cohomology/LOCALIZATION_INTERFACE.md"),
    (9, "workbenches/tau-chain-descent/RESEARCH_NOTE.md"),
    (10, "workbenches/tau-global-retraction/RESEARCH_NOTE.md"),
    (0, "workbenches/tau-global-retraction/MEYER_SOURCE_COMPARISON.md"),
    (11, "workbenches/tau-homotopy-control/RESEARCH_NOTE.md"),
    (13, "workbenches/tau-orthogonal-boundary-control/RESEARCH_NOTE.md"),
    (12, "formal/splitzero/TAU_RECOVERY_MATHEMATICS.md"),
    (0, "INTEGRATION_REVIEW_20260912.md"),
]
FLOW = [
    (2, "workbenches/unified-flow/HARTLE_HAWKING.md"),
    (2, "workbenches/unified-flow/CHECKS.md"),
    (2, "workbenches/unified-flow/CONTRIBUTIONS.md"),
]

SPLIT_INTRO = r"""# How to read these calculations

This volume follows the Split-Zero programme from its scalar algebra into an
explicit arithmetic comparison complex. The central question is how much of
the geometry behind Deligne's *Weil II* method can be carried through actual
maps for the Riemann zeta function. It is a record of that attempt: full
calculations, written proofs, corrections and formalization notes are retained,
including results that remain useful without proving a global purity or
positivity statement.

Here **Split-Zero** means the semiring $G(R)=R\sqcup\{\tau\}$. Its supported
zero $e=0_R$ records a zero value at an existing support; $\tau$ records absence
and is the semiring's additive identity and absorbing scalar. The amplitude
map $p:G(R)\to R$ sends both to $0_R$. Keeping its support coordinate makes the
information that $p$ forgets explicit. The first three chapters describe the
maps, support fibres, quotient and homology constructions, and the checked
algebraic corrections.

The arithmetic map used later is the theta summation operator $\Theta:V\to B$
between the test-function spaces specified in the source notes. Its quotient
$Q=B/\Theta(V)$ is studied through finite polynomial operators, chain maps and
representatives. The notes identify finite comparison complexes involving
$g=2\xi$, where

\[
\xi(s)=\tfrac12s(s-1)\pi^{-s/2}\Gamma(s/2)\zeta(s).
\]

Thus the zeta connection is in the displayed comparison maps and the divisor
of the completed zeta function, not merely in a resemblance of terminology.
A **Rees module** retains filtration levels as powers of a parameter. Its
quotient measures the failure of a filtered comparison to be strict: the
filtration inherited from the source can differ from the one inherited from
the target. The Rees calculations keep that difference and then compute the
associated arithmetic trace. **Homology** here means kernels modulo images
in the specified complexes; the notes give the actual differentials rather
than using the word as a generic bridge.

The tau-base chapters construct a pointed coefficient interface, finite
operator kernels, localization maps and chain descent. The subsequent chapters
construct a global retraction, classify the comparison homotopies and compute
rank-two boundary control. The last chapter explains which algebraic and
topological statements the recovered Lean package implements and which
analytic arguments remain written mathematics.

Deligne's *Weil II* is a source of methods involving weights and duality for
cohomology over finite fields. Here the number-field arithmetic comparison is
being constructed and tested explicitly; this volume does not assert that all
the finite-field hypotheses have already been transferred. The actual Weil
quadratic form, spectral positivity, and any conclusion about RH require the
precise objects and estimates stated in the notes. A formal proof of one map
identity is not relabelled a proof of those further conclusions.

## Navigation and status

The table of contents follows the mathematical dependency order. Each chapter
begins with an immutable source link and revision. The complete selected source
note follows it, including its references and limitations; the introduction is
additional reader context, not a substitute for any proof. File paths in those
links identify the source module and allow the notation, computations and
formal files to be retrieved together.

The notes retain their own chronological statements. In particular the early
structural note's description of what was not yet implemented is followed by
the later derived construction; the formal tau note retains its pre-run text
alongside the dated successful-build record. Those historical sentences are
not a retraction of the subsequent verified work. The integrated source review
at the end records the version-specific corrections and checks.

The earlier six research readers remain a separate frozen edition. This new
calculation volume does not silently revise their pages. Repository checkers
and Lean workflow records are validation evidence for their stated source
versions and targets, not independent peer review or novelty certificates.

"""

FLOW_INTRO = r"""# A specified black-hole calculation

The **Unified Flow** workbench tests proposed relations among physical clocks,
thermal states, detector response, entropy, spectral transforms and geometric
flow. Its first worked system is an eternal Schwarzschild black hole in a
Hartle-Hawking thermal state. Each probe, unit, clock and operator is retained:
the goal is to compute the maps between them, not to declare all flows equal.

The full source calculation follows. It distinguishes a four-dimensional
scalar scattering problem, a conformal two-dimensional detector, a Dirac shell
probe and an interacting sigma-model probe. The detector's energy scale,
thermal clock, entropy variation and spectral-zeta transform are computed for
their specified models. These are related calculations within the wider
research workbench, not a claim of solving quantum gravity or RH.

The subsequent chapters retain the computational checks and contributor/source
history. Source literature is cited rather than bundled into this edition.

"""

# Presentation-only conversion of three source formulas that were written as
# undelimited ASCII prose. Exact original spellings are retained in this table;
# no equation, sign, coefficient or exponent is changed.
ASCII_FORMULAS = {
    "F'^2+s^2(F'F'''-F''^2)/4+O(s^4)": r"\({F'}^2+s^2(F'F'''-{F''}^2)/4+O(s^4)\)",
    "s^2F'^2[1+s^2F'''/(12F')+O(s^4)]": r"\(s^2{F'}^2[1+s^2F'''/(12F')+O(s^4)]\)",
    "d^(n+1)d^n": r"\(d^{n+1}d^n\)",
}

HEADER = r"""\usepackage{microtype}
\usepackage{fvextra}
\usepackage{adjustbox}
\usepackage{xurl}
\usepackage{mathtools}
\usepackage[Mathematics]{ucharclasses}
\newfontfamily\fallbackmath{DejaVu Math TeX Gyre}
\setTransitionsForMathematics{\begingroup\fallbackmath}{\endgroup}
\usepackage{newunicodechar}
\usepackage{tocloft}
\setlength{\cftchapnumwidth}{2.6em}
\newunicodechar{≅}{\ensuremath{\cong}}
\newunicodechar{⊲}{\ensuremath{\lhd}}
\newunicodechar{⋆}{\ensuremath{\star}}
\DefineVerbatimEnvironment{Highlighting}{Verbatim}{commandchars=\\\{\},breaklines,breakanywhere,fontsize=\small}
\fvset{breaklines=true,breakanywhere=true}
\setlength{\emergencystretch}{3em}
\setcounter{tocdepth}{1}
\setcounter{secnumdepth}{0}
\let\oldDisplayOpen\[
\let\oldDisplayClose\]
\renewcommand{\[}{\begin{center}\begin{adjustbox}{max width=\linewidth}\(\displaystyle}
\renewcommand{\]}{\)\end{adjustbox}\end{center}}
\renewcommand{\tag}[1]{\qquad\text{(#1)}}
\AtBeginDocument{\hypersetup{breaklinks=true}}
"""

def digest(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def source(pr, rel, final_root, commit):
    if final_root:
        return final_root / rel, commit
    if pr:
        data = json.loads((INTAKE / f"pr_{pr}" / "pr.json").read_text(encoding="utf-8"))
        return INTAKE / f"pr_{pr}" / "files" / rel, data["head"]["sha"]
    request = json.loads((INTAKE / "request.json").read_text(encoding="utf-8"))
    return INTAKE / "main_before" / rel, request["main"]

def absolute_links(body, rel, sha):
    from urllib.parse import quote
    from posixpath import normpath, dirname, join
    def repl(m):
        dest = m.group(2)
        if re.match(r"[A-Za-z][A-Za-z0-9+.-]*:", dest) or dest.startswith("#"):
            return m.group(0)
        mapped = normpath(join(dirname(rel), dest))
        if mapped.startswith("../"):
            raise ValueError("Relative link escapes repository: " + dest)
        return m.group(1) + REPO + "/blob/" + sha + "/" + quote(mapped, safe="/#") + m.group(3)
    return re.sub(r"(\]\()([^\s)]+)(\))", repl, body)

def math_tokens(body):
    # Display and inline backslash/dollar mathematics, excluding fenced code.
    plain = re.sub(r"```[^\n]*\n[\s\S]*?```", "", body)
    return re.findall(r"\\\[([\s\S]*?)\\\]|\\\(([\s\S]*?)\\\)|\$\$([\s\S]*?)\$\$|(?<!\$)\$([^$\n]+)\$", plain)

def build(name, title, intro, selection, args):
    work = HERE / "tmp" / "pdfs" / name
    out = HERE / "output" / "pdf"
    work.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    pieces = [intro]
    records = []
    snapshot = None
    if args.root:
        snapshot = json.loads((INTAKE / "final_snapshot.json").read_text(encoding="utf-8"))
        if snapshot["commit"] != args.commit:
            raise ValueError("Integrated source commit differs from final snapshot receipt")
    for pr, rel in selection:
        file, sha = source(pr, rel, args.root, args.commit)
        raw = file.read_bytes()
        if snapshot:
            expected = snapshot["files"][rel]
            if len(raw) != expected["bytes"] or digest(raw) != expected["sha256"]:
                raise ValueError("Integrated source hash/length mismatch: " + rel)
        body = raw.decode("utf-8-sig").replace("\r\n", "\n")
        if re.search(r"[A-Z]:[\\/](?:Users|user|tmp|w|Documents)|/[U]sers/", body):
            raise ValueError("Private-path/name screening failed for " + rel)
        formatted = absolute_links(body, rel, sha)
        if math_tokens(formatted) != math_tokens(body):
            raise ValueError("Formula text changed for " + rel)
        ascii_formula_counts = {key: formatted.count(key) for key in ASCII_FORMULAS if key in formatted}
        for key, value in ASCII_FORMULAS.items():
            formatted = formatted.replace(key, value)
        # Avoid nonbreaking or Unicode dash glyphs in prose, per PDF skill.
        formatted = formatted.replace("\u2011", "-")
        lines = formatted.splitlines()
        if not lines or not lines[0].startswith("# "):
            raise ValueError("Missing source title " + rel)
        url = REPO + "/blob/" + sha + "/" + rel
        metadata = ["", f"[Complete source note]({url}). Module: `{rel}`.", "",
                    f"Revision: [{sha}]({REPO}/commit/{sha}). Complete selected note.", ""]
        pieces.append("\n\\clearpage\n\n" + "\n".join([lines[0]] + metadata + lines[1:]) + "\n")
        records.append({"source_path": rel, "source_commit": sha, "url": url,
                        "bytes": len(raw), "sha256": digest(raw), "pr": pr or None,
                        "formula_delimited_count": len(math_tokens(body)),
                        "ascii_formula_typesetting": ascii_formula_counts,
                        "complete_source_note_included": True})
    md = "\n".join(pieces)
    (work / "reader.md").write_text(md, encoding="utf-8")
    (work / "header.tex").write_text(HEADER, encoding="utf-8")
    # Render to TeX first so complete generated formula content is inspectable.
    tex = work / "reader.tex"
    cmd = [PANDOC, str(work / "reader.md"), "--from=markdown+tex_math_dollars+tex_math_single_backslash+tex_math_double_backslash+raw_tex+autolink_bare_uris-smart-superscript-subscript",
           "--to=latex", "--standalone", "--toc", "--toc-depth=1", "--top-level-division=chapter",
           "--lua-filter=" + str(HERE / "reader_presentation.lua"),
           "--number-sections", "--include-in-header=" + str(work / "header.tex"),
           "-V", "documentclass=report", "-V", "fontsize=11pt", "-V", "papersize=a4", "-V", "geometry:margin=23mm",
           "-V", "mainfont=DejaVu Serif", "-V", "sansfont=DejaVu Sans",
           "-V", "monofont=DejaVu Sans Mono", "-V", "mathfont=Latin Modern Math",
           "-V", "colorlinks=true", "-V", "linkcolor=blue", "-V", "urlcolor=blue",
           "-M", "title=" + title, "-M", "subtitle=Complete calculation notes and source-linked proof records",
           "-M", "date=12 September 2026", "-o", str(tex)]
    result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    (work / "pandoc.log").write_text(result.stdout + result.stderr, encoding="utf-8")
    if result.returncode:
        raise RuntimeError(result.stderr)
    rendered = tex.read_text(encoding="utf-8")
    # Permit long literal paths, identifiers and immutable revision hashes to
    # wrap without changing their visible characters.
    def wrap_code(m):
        code = m.group(1).replace(r"\_", "_")
        if re.fullmatch(r"[A-Za-z0-9_./:\-]+", code) and len(code) > 22:
            return r"\nolinkurl{" + code + "}"
        original = m.group(1)
        original = re.sub(r"([+*=])", r"\1\\allowbreak{}", original)
        return r"\texttt{" + original + "}"
    rendered = re.sub(r"\\texttt\{([^{}]*)\}", wrap_code, rendered)
    rendered = rendered.replace(r"\_", r"\_\allowbreak{}")
    tex.write_text(rendered, encoding="utf-8")
    for passno in range(1, 3):
        result = subprocess.run([ENGINE, "-interaction=nonstopmode", "-halt-on-error", "-no-shell-escape", "reader.tex"],
                                cwd=work, capture_output=True, text=True, encoding="utf-8", errors="replace")
        (work / f"xelatex-pass{passno}.log").write_text(result.stdout + result.stderr, encoding="utf-8")
        if result.returncode:
            raise RuntimeError("XeLaTeX failed; inspect " + str(work / f"xelatex-pass{passno}.log"))
    pdf = out / (name + ".pdf")
    pdf.write_bytes((work / "reader.pdf").read_bytes())
    # Portable source package contains the generated TeX/Markdown, exact selected
    # note bytes, source manifest and this builder; later assembled by parent.
    manifest = {"utc": datetime.now(timezone.utc).isoformat(), "status": "typeset_pending_visual_review",
                "title": title, "final_integrated_commit": args.commit,
                "provisional": not bool(args.root), "sources": records,
                "source_note_count": len(records), "formula_delimited_count": sum(x["formula_delimited_count"] for x in records),
                "pdf": {"name": pdf.name, "bytes": pdf.stat().st_size, "sha256": digest(pdf.read_bytes())},
                "math_text_unchanged": True, "remote_mutations": False,
                "frozen_20260909_readers_modified": False}
    write_json(HERE / (name + "-manifest.json"), manifest)
    print(json.dumps({"name": name, "notes": len(records), "formulas": manifest["formula_delimited_count"], "pdf": str(pdf)}))

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--root", type=Path)
    p.add_argument("--commit")
    p.add_argument("--only", choices=["split", "flow", "both"], default="both")
    args = p.parse_args()
    if bool(args.root) != bool(args.commit):
        p.error("--root and --commit must be supplied together")
    if args.only in ("split", "both"):
        build("08-splitzero-arithmetic-calculations", "Split-Zero, arithmetic comparison and homology", SPLIT_INTRO, SPLIT, args)
    if args.only in ("flow", "both"):
        build("09-unified-flow-calculations", "Unified Flow: clocks, entropy and spectral probes", FLOW_INTRO, FLOW, args)
