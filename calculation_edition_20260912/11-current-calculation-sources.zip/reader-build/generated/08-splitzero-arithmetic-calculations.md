# How to read these calculations

This volume follows the Split-Zero programme from its scalar algebra into an
explicit arithmetic comparison complex. The central question is how much of
the geometry behind Deligne's *Weil II* method can be carried through actual
maps for the Riemann zeta function. It is a record of that attempt: full
calculations, written proofs, corrections and formalization notes are retained,
including results that remain useful without proving a global purity or
positivity statement.

Here **Split-Zero** means the semiring $G(R)=R\sqcup\{\tau\}$. Its supported
zero $e=0_R$ records a zero value at an existing support; $\tau$ records absence
and is the semiring's additive identity and absorbing scalar. The amplitude
map $p:G(R)\to R$ sends both to $0_R$. Keeping its support coordinate makes the
information that $p$ forgets explicit. The first three chapters describe the
maps, support fibres, quotient and homology constructions, and the checked
algebraic corrections.

The arithmetic map used later is the theta summation operator $\Theta:V\to B$
between the test-function spaces specified in the source notes. Its quotient
$Q=B/\Theta(V)$ is studied through finite polynomial operators, chain maps and
representatives. The notes identify finite comparison complexes involving
$g=2\xi$, where

\[
\xi(s)=\tfrac12s(s-1)\pi^{-s/2}\Gamma(s/2)\zeta(s).
\]

Thus the zeta connection is in the displayed comparison maps and the divisor
of the completed zeta function, not merely in a resemblance of terminology.
A **Rees module** retains filtration levels as powers of a parameter. Its
quotient measures the failure of a filtered comparison to be strict: the
filtration inherited from the source can differ from the one inherited from
the target. The Rees calculations keep that difference and then compute the
associated arithmetic trace. **Homology** here means kernels modulo images
in the specified complexes; the notes give the actual differentials rather
than using the word as a generic bridge.

The tau-base chapters construct a pointed coefficient interface, finite
operator kernels, localization maps and chain descent. The subsequent chapters
construct a global retraction, classify the comparison homotopies and compute
rank-two boundary control. The last chapter explains which algebraic and
topological statements the recovered Lean package implements and which
analytic arguments remain written mathematics.

Deligne's *Weil II* is a source of methods involving weights and duality for
cohomology over finite fields. Here the number-field arithmetic comparison is
being constructed and tested explicitly; this volume does not assert that all
the finite-field hypotheses have already been transferred. The actual Weil
quadratic form, spectral positivity, and any conclusion about RH require the
precise objects and estimates stated in the notes. A formal proof of one map
identity is not relabelled a proof of those further conclusions.

## Navigation and status

The table of contents follows the mathematical dependency order. Each chapter
begins with an immutable source link and revision. The complete selected source
note follows it, including its references and limitations; the introduction is
additional reader context, not a substitute for any proof. File paths in those
links identify the source module and allow the notation, computations and
formal files to be retrieved together.

The notes retain their own chronological statements. In particular the early
structural note's description of what was not yet implemented is followed by
the later derived construction; the formal tau note retains its pre-run text
alongside the dated successful-build record. Those historical sentences are
not a retraction of the subsequent verified work. The integrated source review
at the end records the version-specific corrections and checks.

The earlier six research readers remain a separate frozen edition. This new
calculation volume does not silently revise their pages. Repository checkers
and Lean workflow records are validation evidence for their stated source
versions and targets, not independent peer review or novelty certificates.



\clearpage

# Research programmes: the new calculations and how to read them

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/RESEARCH_PROGRAMMES.md). Module: `RESEARCH_PROGRAMMES.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


The September 12 work develops the repository's **SplitZero arithmetic geometry through cohomology, duality, and weight-control calculations inspired by Deligne's Weil II**. The aim is to understand the Riemann zeta function through explicit geometric and analytic maps, and ultimately to obtain information about its zeros. This is a collection of genuine constructions and calculations, not a claim that the finite-field weight theorem already applies to the Riemann zeta function.

The new work lives in the linked workbenches below. It is **not yet a chapter of the September 9 frozen reader**. The [earlier six-reader edition](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/zenodo_collection_20260909_main411) remains available unchanged. [Machine-readable programme map](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/WORKBENCHES.json) records source versions, dependencies and the kind of checking each contribution received.

## The objects that connect the calculations

**SplitZero coefficients.** Starting with a ring R, the construction G(R) keeps the ordinary ring zero e=0_R and adjoins a different zero tau for external absence. A zero vector in a particular support fibre remains in that fibre; it does not become an absent object. The [formalized reconstruction and quotient maps](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/formal/splitzero/DERIVED_MATHEMATICS.md) explain exactly how this convention passes through modules and homology. The F1-style base is the pointed multiplicative monoid {tau,1}; the [four-point chart and structural maps](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-base-cohomology/TAU_BASE_MODEL.md) retain the coefficients in each chart fibre. The analytic application takes R=C. These specified objects are not being substituted for a finite field.

**The theta complex.** Its source V consists of even Schwartz functions phi on the real line with phi(0)=0 and integral phi=0. Its target B is the specified space of smooth functions on the positive real axis that decrease rapidly at both endpoints. The map

$$\Theta\phi(x)=\sum_{n\in\mathbb Z\setminus\{0\}}\phi(nx)$$

gives the two-term complex [V -> B] and its degree-one cohomology Q=B/Theta(V). Here cohomology means functions in B modulo the actual theta relations. Scaling acts through D=-x d/dx. With the Mellin transform MF(s)=integral F(x)x^s dx/x, the [computed image ideal](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/split-support-rees-trace/ACTUAL_ADELIC_COMPARISON.md) is generated by g(s)=2xi(s), where

$$\xi(s)=\tfrac12s(s-1)\pi^{-s/2}\Gamma(s/2)\zeta(s).$$

**Finite packets and retained derivatives.** A packet is a finite collection of spectral points, with their multiplicities. If h(t) is the polynomial recording those points and orders, E_h=C[t]/(h) retains all derivatives up to the specified orders, not just function values. The [finite comparison](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-base-cohomology/FINITE_OPERATOR_COMPARISON.md) explicitly connects these polynomial coordinates to the original infinite quotient Q.

**Why Weil II enters.** Deligne's machinery motivates the sequence: construct cohomology and its action, identify the arithmetic information it carries, calculate duality, then control weights (the real parts of the corresponding spectral parameters). The new work computes several of these maps and reduces one control problem to concrete small-rank matrices. It has not obtained a uniform weight bound or an RH conclusion. The [source and comparison boundaries](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/formal/splitzero/DERIVED_MATHEMATICS.md) remain attached to the programme.

## Reading order and what each stage achieved

| Stage | Why this calculation was attempted | What is now written or checked |
|---|---|---|
| [SplitZero reconstruction and homology](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/splitzero-derived) | Make support-preserving coefficients, quotients and induced homology maps executable mathematics. | Lean modules for reconstruction, internal quotients, homology kernels and balanced finite jets, with the exact source audit described in the formalization notes. |
| [Rees defects and actual adelic comparison](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/split-support-rees-trace) | Measure information lost by a comparison map, then connect that calculation to the theta trace instead of only to a model example. | Defect lengths, residue duality, graded traces, the theta image ideal, and finite spectral-jet maps. Written derivations plus finite algebraic regression tests. |
| [Tau-base cohomology](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-base-cohomology) | Extract finite spectral information from the original infinite theta quotient without replacing the quotient. | Explicit differential inverses, kernel and quotient comparisons, spectral projectors, and arithmetic torsion extraction. The complementary meromorphic kernel is retained. |
| [Chain descent](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-chain-descent) | Explain the failure of a chosen spectral representative to commute exactly with scaling. | Its exact extension class, rank-one scaling defect, synchronized homotopies and finite arithmetic traces. A homotopy is a map whose differential accounts for the difference between two chain maps. |
| [Global theta retraction](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-global-retraction) | Recover a source function continuously from its theta image and split the full complex. | A written construction using Mobius inversion, two cutoffs and a strict-contraction inverse; continuous quotient, dual and tensor formulas. Finite regressions do not certify its analytic estimates. |
| [Homotopies and source-constrained control](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-homotopy-control) | Determine which choices change the control problem and which merely change its description. | Changing a homotopy parameter leaves the fixed control matrix unchanged; changing the representative by a theta boundary gives an explicit new Gram matrix and control form. |
| [Formal tau recovery](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-formal-recovery) | Check the algebraic and quotient-topological interfaces used by those arguments. | Seven additional Lean modules, including both homotopy equations and inverse laws; the exact successful source run is linked in the module notes. This does not certify the analytic theta estimates. |
| [Orthogonal boundaries and rank-two control](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-orthogonal-boundary-control) | Choose representatives from actual theta derivatives and calculate the remaining relative control. | Rank-two control and rank-one Gram updates, an explicit quotient-kernel coordinate, a theta-moment tail estimate and the retained Hilbert/jet graph. Both Gram and control matrices shrink, so the relative estimate, not absolute smallness alone, is the remaining target. |

These are successive parts of the same programme. The full notes preserve equations, inverses, kernels, signs, local units, support labels and unsuccessful routes. Each workbench has its own reproduction instructions. A merged research note is available work, not an automatic promotion of every assertion to an independently certified theorem.

## Other connected programmes

- [CUE, Mellin and finite phase space](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/CUE_RESEARCH_MAP.md): a source map into the existing random-unitary-matrix calculations, identifying already proved results and specific unconstructed connections. This is navigation, not another discovery of those results.
- [Unified Flow: specified black-hole probes](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/unified-flow): a Schwarzschild/Hartle-Hawking calculation relating thermal clocks, detector response, a surface Dirac spectrum, entropy, spectral zeta and an O(3) geometric-flow probe. Its Mellin entropy formula gives an explicit zeta connection. The four-dimensional scattering density and moving-detector response remain unevaluated.

## Contributing without losing the research history

Start from the full note and its exact version. Briefly record the question, why the approach was chosen, the maps or estimates attempted, what succeeded, corrections, and what is still unfinished. Keep source citations and the distinction between written proof, finite regression, numerical evidence and Lean verification. [Web sessions and local agents can both contribute](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/POLYCLANK_PARTICIPATION.md).


\clearpage

# SplitZero: maps, support fibres, ideals, and exact corrections

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/formal/splitzero/MATHEMATICAL_NOTE.md). Module: `formal/splitzero/MATHEMATICAL_NOTE.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


12 September 2026. The construction and existing manuscript results are attributed to the owner's research programme. This note gives proofs for the bounded structural package; it does not assert global priority or a completed analytic programme. Validation is tied to exact source hashes in `VALIDATION.json`.

## Conventions

For a commutative ring R, write G(R) for a supported copy of R together with one extra point tau. Supported elements add and multiply as in R. The point tau is the additive identity and multiplicative absorber. Write e for supported 0_R. Thus e is not tau, e+e=e, e*r=e for every supported r, and 1+e=1. None of the following statements requires R to be nontrivial.

## 1. Exact universal morphisms

Let p:G(R)->R send tau to 0 and supported r to r. Composition with p gives a bijection

Hom_ring(R,A) ≅ Hom_semiring(G(R),A)

for every commutative ring A. Indeed, for a semiring homomorphism h, the equation e+e=e implies h(e)+h(e)=h(e), hence h(e)=0 by cancellation. Therefore r↦h(r) is a unital ring map and factors h through p. Uniqueness follows from surjectivity of p. In particular, no semiring map G(R)->A to a ring is injective: it identifies e and tau.

Let B be the Boolean semiring. The support character chi:G(R)->B sends tau to 0 and every supported r to 1. It is unique: e=1+(-1) gives h(e)=1 for every unital semiring map h to B; then re=e gives h(r)=1. The map (p,chi):G(R)->R×B is injective with image exactly {(0,0)} union (R×{1}). The second coordinate distinguishes absence from a supported zero; the first distinguishes supported amplitudes.

Every ring map f:R->S lifts to G(f), fixing tau and acting by f on supported elements. Conversely, if H:G(R)->G(S) is a semiring map, p_S H factors through p_R as a unique ring map f. The support coordinate of H equals chi_R by uniqueness of the Boolean character. Thus H and G(f) have equal amplitude and support and are equal by joint injectivity. Consequently

Hom_semiring(G(R),G(S)) ≅ Hom_ring(R,S).

This identifies the morphisms without asserting G(R)≅R. In Lean the exact statements are `ringHomEquiv`, `coordinates_injective`, `coordinates_image`, and `splitHomEquiv`.

## 2. Intrinsic support and fibre modules

For any G(R)-semimodule M, put s(m)=e*m. The scalar identities imply

s(m+n)=s(m)+s(n),  s(s(m))=s(m),  m+s(m)=m,  s(m)+s(m)=s(m).

Conversely suppose y+y=y. Put v=(-1_R)*y. Since e=1_R+(-1_R), s(y)=y+v. Therefore y+s(y)=(y+y)+v=y+v=s(y), while absorption gives y+s(y)=y. Hence s(y)=y. Thus the support set L={l:s(l)=l} is exactly the additive-idempotent locus. Addition gives its join, l≤k iff l+k=k, and its least element is 0_M.

For l∈L, define M_l={m:s(m)=l}. This is an actual R-module: addition is inherited, its zero is l, inverse is m↦(-1_R)*m, and r acts as supported r. The essential identities are

s(m+n)=l+l=l,  m+l=m,  m+(-1_R)*m=l,  e*r=e.

For l≤k, T_lk(m)=m+k lies in M_k. It is additive because k+k=k. Every supported scalar fixes k, since r*k=r*(e*k)=(r*e)*k=e*k=k; hence T_lk is R-linear. Also T_ll=id and T_kn T_lk=T_ln by absorption and k+n=n.

A G(R)-linear map F commutes with s. Its support restriction preserves zero and joins by F(0)=0 and F(l+k)=F(l)+F(k); its fibre restriction is R-linear. Naturality is the literal equation F(m+k)=F(m)+F(k). Lean implements the fibre restrictions as `LinearMap`s and checks transport identity, composition and this naturality square.

Finally m↦(s(m),m) is a bijection with the disjoint union of the intrinsic fibres. If u=s(m)+s(n)=s(m+n), the reconstructed sum is

(m+u)+(n+u)=m+n+u=m+n.

The Lean package supplies the forward fibre construction and reconstruction for an existing semimodule. It does not yet construct the semimodule associated with every arbitrary abstract diagram or the complete categorical equivalence with natural isomorphisms. These are separate remaining implementation steps; the manuscript already proves the equivalence on paper.

## 3. Complete ideal classification

For I⊲R let I^G=p^(-1)(I)=I union {tau}. This contains e, so it is not the zero semiring ideal {tau}. Conversely, if J⊲G(R) differs from {tau}, choose a supported r∈J. Multiplication by e gives e∈J. Therefore J intersect R contains 0_R and is closed under addition and multiplication by arbitrary R-elements, hence is a ring ideal. The two constructions are mutually inverse and preserve inclusion. Thus

Ideal(R) ≅ {J∈Ideal(G(R)): J≠{tau}}

as ordered sets. Equivalently every J is either {tau} or uniquely I^G. The whole ideal poset has one additional bottom element below (0_R)^G={tau,e}. Lean constructs `nonzeroIdealOrderIso`, not merely a conditional theorem assuming the classification.

### Empty joins

The isomorphism preserves joins computed in the non-bottom ideal poset. In the ambient Ideal(G(R)), however, the empty join is {tau}, whereas the lift of the empty join from Ideal(R) is {tau,e}. Hence ambient empty joins are not preserved. Nonempty ambient joins are preserved because their supremum contains a lifted ideal and therefore e; it is still in the non-bottom subposet.

## 4. Correcting the monoid-semiring presentation

The printed presentation in chapter 14 takes the ordinary free monoid semiring N[M_R], where M_R is the multiplicative monoid of G(R), modulo

[a]+[b]=[a+b] for supported a,b,
[x]+[tau]=[x] for multiplicative generators x.

These relations do not imply [tau]=0. Evaluate every multiplicative generator at 1 in the Boolean semiring. This is unital and multiplicative; every displayed relation becomes 1+1=1, but [tau] maps to 1≠0. The free monoid-semiring universal property therefore gives a model of the relations in which the missing equation fails.

The repair is to add [tau]=0, or explicitly use a free construction already identifying the absorber with semiring zero. With the extra relation, the proposed inverse G(R)->Q preserves zero: tau maps to 0 and supported r to [r]. It preserves addition by the supported relation and the zero law, and multiplication and one by the monoid presentation. This inverse and evaluation Q->G(R) are identities on generators, hence mutual inverses.

The Lean file checks the multiplicative-generator countermodel and the corrected semiring-lift universal property. It does not construct the entire free monoid-semiring congruence quotient. No existing frozen reader text is silently rewritten.

## 5. Scope within the Zeta programme

Chapter 14 already gives the semimodule/linear-join-diagram result and ideal classification. PR #3's Rees continuation explicitly begins above that common support. The present work supplies reusable algebraic structure for that continuation; it does not certify its analytic, arithmetic-trace, purity or positivity claims. No RH statement is asserted.

The source acknowledges classical semiring/semimodule terminology and strong semilattices of groups. No exhaustive priority comparison has been completed. Attribution of this construction to the owner's programme, a new Lean implementation, and a claim of new mathematics are distinct assertions.

## Source records

KokunoYumeto. (2026a). *Split-zero support and shifted Dedekind sheets* [Research manuscript, chapter 14]. In *Riemann Zeta Function: Research Reader*. Commit 42d00e359b16d52ca71568ce5e3db5341949d929; blob 49318a578b96462384000afa16794cfd5fe492c1. https://github.com/KokunoYumeto/zeta-function-research-reader/blob/42d00e359b16d52ca71568ce5e3db5341949d929/satellites/14_globalization_cue_split_zero_and_shifted_sheets.tex

KokunoYumeto. (2026b). *Split support, Rees defects, and the completed arithmetic trace* [Draft research note, PR #3]. Commit 37b2cc9b9baee3ffe25a7649314adb025302509f. https://github.com/KokunoYumeto/zeta-function-research-reader/pull/3

KokunoYumeto. (2026c). *SplitZero.lean* [Lean source]. Blob ff991f7383922e71cdf0e4a3bc85e89e18f808ef. https://github.com/KokunoYumeto/modern-latex-manuscripts/blob/f7ff59b176c7dc3941babd4cb9272dffc653070d/formalization/lean/classical_candidates_20260626/split_support_sidecar/SplitZero.lean


\clearpage

# SplitZero: reconstruction, internal homology, and balanced finite jets

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/formal/splitzero/DERIVED_MATHEMATICS.md). Module: `formal/splitzero/DERIVED_MATHEMATICS.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Owner-directed formalization continuation, 12 September 2026.

## Scope and provenance

This contribution extends `formal/splitzero` on the owner's Zeta workbench. Its base is the synchronization PR #5, commit `236f0a8370477991e2d0cf334ad1ebfe4f3f8b17`, itself based on the structural PR #4. The original scalar core and all five preceding extension sources remain unchanged. There is no Sneed-side submission or integration in this continuation.

The mathematical source is the owner's SplitZero programme, including the supplied continuation's internal homology and balanced-Mellin sections. The implementation below distinguishes source-derived structure, ordinary reusable algebra, and the new explicit comparison example. It makes no global priority claim and does not treat the number of Lean declarations as a number of mathematical discoveries. No private conversation or source-literature corpus is republished.

The exact build certificate for a revision is the completed `SplitZero derived constructions` workflow on that commit, including direct source checks and its generated `AuditDerived.lean`. The PR records the accepted execution revision and run. A failed earlier development run is not a certificate for later source.

## 1. Reverse reconstruction, with actual scalar action

Let R be a commutative ring, L a join-semilattice with bottom, and let D consist of R-modules V_i with linear transition maps

    rho_ij : V_i -> V_j  (i <= j),
    rho_ii = id,  rho_jk rho_ij = rho_ik.

No finiteness, field, injectivity, or nontriviality assumption is imposed. Construct

    Total(D) = disjoint union of V_i over i in L.

The global zero is (bottom,0), and

    (i,x) + (j,y) = (i join j, rho_i,i-join-j(x) + rho_j,i-join-j(y)).
    tau . (i,x) = (bottom,0).
    ofR(r) . (i,x) = (i,r x).

`LinearDiagram.totalAddCommMonoid` and `LinearDiagram.totalModule` construct the actual instances and prove every law. For associativity, transport both sides to i join j join k. Linearity and transition composition reduce both to the same three-term sum. The scalar laws follow in the supported case from the R-module laws and in the absent cases from the chosen global zero. The supported-zero scalar sends (i,x) to (i,0).

The bottom fibre is allowed to be nonzero. Specializing it to the zero module recovers the source's carrier consisting of one absent point and the non-bottom fibres. This is an explicit generalization, not an assumption that the bottom fibre in every later dual diagram vanishes. Opposite-index duality itself is not constructed here.

Fixed-index natural families of linear maps produce actual `G(R)`-linear maps between reconstructed totals. Identity and composition are proved. More substantially, `Recovery.recoverEquiv` reconstructs the intrinsic support fibres of **any** existing `G(R)`-semimodule M and gives a full `G(R)`-linear equivalence back to M:

    (l,x) |-> x,        m |-> (e m,m).

Its addition proof uses the original absorption identity m + e m = m. It is not merely a bijection of carriers. A bundled equivalence of the two full categories, including arbitrary changes of support index and both natural inverse comparisons, is a separate library interface not claimed by this implementation.

## 2. The internal quotient is characterized by a universal property

Let B_i be transition-stable submodules of V_i. The quotient diagram has fibres V_i/B_i and the genuinely induced quotient transition maps. The projection

    q : Total(D) -> Total(D/B),  q(i,x) = (i,[x])

is a surjective `G(R)`-linear map. The code proves the exact equality criterion

    q(i,x)=q(i,y)  iff  x-y is in B_i.

Different labels cannot become equal under q. In particular a relation maps to its own fibre zero.

The main point is stronger than that observation. Let N be **any** `G(R)`-semimodule, not assumed additively cancellative, and let f:Total(D)->N be split-linear. If

    f(i,b)=f(i,0)  for every b in B_i,

then there exists a unique split-linear g:Total(D/B)->N with g q=f. The proof does not subtract elements in N. If x-y is in B_i, use the identity y+(x-y)=x inside V_i and then apply additivity of f. This proves constancy on q-fibres. Surjectivity constructs the descended function; linearity and uniqueness follow by lifting representatives.

`Relations.coequalizer_universal` states this against the actual inclusion of the relation diagram and its supported-zero companion. Thus the universal property is proved against arbitrary semimodule targets, not only against a selected class of fixed-support maps. The implementation gives the complete unbundled universal property; it does not merely define the desired quotient and label it a coequalizer.

## 3. Actual homology and the exact transported-class kernel

At a degree i of a cochain complex, use the window

    C^(i-1) --dPrev--> C^i --dNext--> C^(i+1),  dNext dPrev=0.

`Window.boundaryToCycles` constructs the incoming map into ker(dNext). Boundaries are its actual linear range, and H is the module quotient of cycles by that range. `Window.ofCochain` imports these data at every integer degree of a Mathlib `CochainComplex`; `ChainMap.ofCochain` imports an actual cochain map without replacing its differentials.

For a chain map f:C->D, the code constructs

    f_Z : Z(C) -> Z(D),
    H(f) : Z(C)/B(C) -> Z(D)/B(D).

It proves identity, composition, and

    H(f)([z])=0  iff  there exists y with dPrev_D(y)=f_i(z).

Define the module of killed representatives and its original relation submodule:

    Krep = {z in Z(C) : f_Z(z) is in B(D)},
    Bold = B(C), viewed as a submodule of Krep.

There is a constructed linear equivalence

    Krep/Bold  ~=  ker H(f).

Forward map: the class of z goes to the kernel element [z]. It is well-defined because Bold consists exactly of original source boundaries. It is injective because equality of source classes is exactly a difference in Bold. It is surjective because every kernel class has a cycle representative whose image is a boundary. This is `ChainMap.homologyKernelEquiv`, obtained from a general quotient-kernel equivalence proved in the same file.

The calculation retains actions as well. Given chain endomorphisms a of C and b of D satisfying f a=b f, `homology_intertwines` proves H(f) H(a)=H(b) H(f). `kernelAction` constructs the restriction of H(a) to ker H(f). Thus passing to the comparison kernel does not discard a compatible operator or require asserting that the kernel is zero.

## 4. Internal homology on the complete support diagram

For coherent support-indexed chain windows, the code constructs the diagrams of preceding terms, middle terms, following terms, cycles, boundaries, and homology. Let R_L denote the reverse reconstruction.

The differential identity is typed as

    R_L(dNext) R_L(dPrev) = z_L : R_L(C^(i-1)) -> R_L(C^(i+1)),
    z_L(l,x)=(l,0).

The source and target degrees are explicit. A theorem shows that z_L differs from the constant global-zero map whenever L has a non-bottom element. Cycles satisfy the actual equalizer equation d(x)=e.d(x).

The internal homology projection

    q : R_L(Z(C)) -> R_L(H(C))

is the coequalizer of the **original incoming differential into cycles** and its supported-zero companion. `homology_coequalizes` and `homology_coequalizer` establish both parts of that universal property against every split-linear target. This is not an assumed homology compatibility of reconstruction.

For every transition i<=j,

    rho^H_ij([z])=0  iff  rho_ij(z) is a boundary at j.

If z is not a boundary at i, its retained class (i,[z]) is not (i,0), regardless of whether that transition kills it. The quotient-kernel equivalence of section 3 computes all such classes as a module, not just a yes/no predicate.

## 5. A concrete comparison that detects more than the support labels

Fix any nontrivial commutative ring k. In the displayed degree let

    C: k --0--> k --0--> k,
    D: k --a |-> (a,0)--> k^2 --0--> k.

Use zero maps in the outside degrees. The two middle chain maps are

    f(a)=(a,0),            g(a)=(0,a).

The code proves that the source class [1] is nonzero. Its f-image is the **nonzero vector** (1,0), but that vector is a boundary in D, so H(f)([1])=0. In fact H(f)=0 on every source class. The g-image (0,1) cannot be a boundary, because every boundary has second coordinate zero. Hence H(g)([1]) is nonzero and H(f) is not H(g).

The ordinary calculation gives H(C)=k and H(D)=k (the latter through second-coordinate projection). These identifications explain the example; the Lean acceptance tests directly prove the nonzero source class, the nonzero chain image, the zero induced map, the surviving class, and the distinction of induced maps rather than relying on a dimension computation.

Consequently the source and target complexes, individual fibre homology, and terminal homology can be identical while the transition kernel differs. This example is parametric over all nontrivial commutative rings, not a finite numerical experiment. Together with the general assembly theorem it supplies an explicit test of the information retained by support-indexed homology. It is an algebraic test case, not a claimed model of the global theta comparison.

## 6. Balanced finite jets, including the original split quotient square

Let k and B be commutative rings and fix a k[t]-algebra structure on B. Let u:k[t]->B denote that map and

    I_(rho,m)=((t-rho)^m),    m>=0.

There is an explicit B-algebra equivalence

    B tensor_(k[t]) (k[t]/I_(rho,m)) ~= B/((u(t)-u(rho))^m).

It maps b tensor [p] to [u(p)b], with inverse [b] to b tensor 1. No flatness assumption is used for this quotient base-change theorem. This is a specialization of the existing Mathlib theorem `Algebra.TensorProduct.quotIdealMapEquivTensorQuot`, not a claim to have independently developed general tensor-product quotient theory.

`splitBaseChange` lifts this equivalence to the original G-construction on both sides and proves the commutative square with reflect. It preserves tau and e separately and is a genuine semiring equivalence, not just an amplitude comparison. Thus every element of the finite-jet quotient has an inverse image before forgetting split support.

For any k[t]-module V and v in V, the exact balancing calculation is

    (1-u(t)) tensor (t.v) - u(t) tensor (v-t.v) = 0.

Expanding gives 1 tensor (t.v)-u(t) tensor v, which vanishes by the tensor balancing relation. This is the algebraic equation of the source's Mellin repair. The choice u(t)=s and t.v=Dv is an application once those analytic module structures and intertwining maps have been constructed. It does not assert that the entire global balanced kernel vanishes, or that analytic scalar extension is flat without proof.

## 7. Where Deligne enters the intended RH route

None of sections 1-6 imports a Deligne purity theorem. They provide the algebraic maps with which a proposed realization can now be specified and its kernel retained.

For this programme, the subsequent dependency diagram should distinguish the following mathematical obligations:

1. Construct the actual operator-balanced theta complex at the relevant support labels, and its action-compatible analytic comparison beta to the spectral sheaf O/(2 xi). Identify its kernel or cone using the same maps; a finite-jet isomorphism is not a global injectivity argument.
2. Construct the geometric compact-support and ordinary complexes, their actual comparison c, their correspondence action, and a compatible realization identifying the required spectral sheaf with the image of H^1(c). Any additional kernel/cone contributions to the trace must be kept or proved to vanish.
3. Establish two-sided weight control on that **same image**. In Deligne's geometric setting the compact-support upper estimate and the duality-derived ordinary-cohomology lower estimate meet on the image. The dualizing operation, degree and Tate twists, tensor-power maps, and hypotheses of the estimates are part of this step, not consequences stipulated in the definition of support.
4. Transport the spectral normalization without changing the arithmetic function. For a dilation parameter a>1, an eigenvalue a^rho has modulus a^(Re rho). A proved weight-one modulus a^(1/2), for the representation identified with every relevant spectral zero, then forces Re rho=1/2. This last calculation does not supply the missing weight estimate; it states the precise final implication of this route.

These are dependencies of the specified route, not a claim that every possible proof of RH must follow it. The newly implemented kernel action is useful in steps 1-2 precisely because it keeps the part killed by a comparison available to the operator and trace calculation.

The supplied Connes-Consani article has an actual quotient-sheaf realization with a specified closure and scaling action. Its Theorem 1.2 realizes **critical zeros**. That theorem alone cannot be substituted for an identification representing all nontrivial zeros in the desired purity argument. This is a concrete source/target distinction for a future comparison map, not a dismissal of the construction.

## 8. Reading record and references

The six supplied S20 chunks were checked against their individual declared hashes and concatenated in order. The resulting archive has 216,580,466 bytes, 312 members, and SHA-256

    e2005bf31e1fcf362765f73c315c855e0f504f24f34d3a0ab188049da522b7c8.

The current top-level `readers/english_standalone.html` and `readers/source_language.html` were used for the selected readings, not the nested zero-accepted salvage corpus. The inspected windows include the tensor-square improvement in 3.2.13, the upper-bound statement in 3.3.1, and the duality/image argument in 3.3.4-3.3.6. This is not an independent audit of every page or of the entire historical proof. The Connes-Consani introduction and Theorem 1.2 were read in the supplied volume, printed pages 83-85 (physical PDF pages 94-96). No copyrighted source corpus is included in this contribution.

Deligne, P. (1980). La conjecture de Weil. II. *Publications Mathematiques de l'IHES, 52*, 137-252. https://doi.org/10.1007/BF02684780

Connes, A., & Consani, C. (2023). Hochschild homology, trace map and zeta-cycles. In A. Connes, C. Consani, B. I. Dundas, M. Khalkhali, & H. Moscovici (Eds.), *Cyclic cohomology at 40: Achievements and future prospects* (Proceedings of Symposia in Pure Mathematics, Vol. 105, pp. 83-102). American Mathematical Society.

Mathlib contributors. (2026). *Mathlib4*, revision `fabf563a7c95a166b8d7b6efca11c8b4dc9d911f`. In particular, `LinearAlgebra/Quotient/{Defs,Basic}.lean`, `RingTheory/TensorProduct/Quotient.lean`, `Algebra/Homology/HomologicalComplex.lean`, and `Algebra/Category/ModuleCat/Basic.lean`.

## 9. Reproduction

From `formal/splitzero` on this branch, with elan and Python installed:

```sh
python3 prepare.py
python3 check_derived.py --prepare
python3 -m unittest -v test_derived_checker.py
lake update
# Verify the resolved Mathlib revision before fetching its cache.
test "$(git -C .lake/packages/mathlib rev-parse HEAD)" = fabf563a7c95a166b8d7b6efca11c8b4dc9d911f
lake exe cache get
lake -KmaxJobs=1 build
for name in SplitZeroReconstruction SplitZeroRecovery SplitZeroHomology SplitZeroInternalQuotient SplitZeroComplex SplitZeroHomologyExample SplitZeroFiniteJets; do
  lake env lean --trust=0 -DwarningAsError=true "$name.lean"
done
lake env lean --trust=0 -DwarningAsError=true AuditDerived.lean > AuditDerived.log
python3 check_derived.py AuditDerived.log
```

The manifest enumerates the selected declarations, including the principal structures, universal properties, equivalences, and example proofs. Missing, duplicate, unexpected, or nonstandard axiom reports fail. Source checks reject unfinished proofs and native-reduction escapes. The Python tests validate this checking machinery; the mathematical certificate is the successful Lean execution. Build-job totals include dependencies and are not theorem counts.


\clearpage

# Actual mixed-double synchronization: a formal bridge to the Rees workbench

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/formal/splitzero/SYNCHRONIZATION.md). Module: `formal/splitzero/SYNCHRONIZATION.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


This is a **non-duplicating continuation of Zeta PR #4**, based on commit
`9c47f76b4e3336ee065b691344271b2d150d75ff`. It keeps that PR's original core,
reflection, fibre modules, ideal classification, coordinate maps and presentation
proofs unchanged. The new module is `SplitZeroSynchronization.lean`.

The source is section 2.1 of `workbenches/split-support-rees-trace/RESEARCH_NOTE.md`
in pending PR #3, inspected at commit
`37b2cc9b9baee3ffe25a7649314adb025302509f`. The source already contains the paper
argument. This contribution formalizes its actual maps; it does not claim a new
discovery, assume the main conclusion, or import its later analytic assertions.

## Objects and result

Let A be any commutative ring, S = G(A), and e the supported arithmetic zero.
The structural zero of S is tau. The source's mixed carrier and multiplication are

    D = S × S,
    (a,b) ⋆ (c,d) = (ac + ofR(-1)bd, ad + bc).

Set E=(1,e). The implemented synchronization is

    r(a,b) = (a + eb, b + ea).

The code proves `r(x)=E⋆x`, `E⋆E=E`, and `r(r(x))=r(x)` for this explicit
operation. These are not hypotheses of the strictness theorem.

The amplitude target is the actual quotient algebra

    B = A[t]/(t²+1),

implemented using Mathlib's `AdjoinRoot`. With p:G(A)->A the collapse map,

    p_D(a,b) = p(a) + t p(b).

The code proves `p_D(r(x))=p_D(x)`. For **every subset F of B**, it then proves

    r(p_D⁻¹(F)) = image(r) ∩ p_D⁻¹(F).

The exported theorem `mul_E_strict` states the same equality using the literal
multiplication-by-E function. Hence every level of an amplitude-pullback
filtration satisfies this exact image equality, without any finiteness,
characteristic-zero, or continuity assumption. The source's filtered vector-space
setting is a specialization.

## Complete proof

There are four support cases. The absent pair `(tau,tau)` is fixed. A pair of
supported elements `(ofR(a),ofR(b))` is fixed because e times a supported element
is e and adding e to a supported element changes no amplitude. The mixed pair
`(tau,ofR(b))` is sent to `(e,ofR(b))`, and `(ofR(a),tau)` to `(ofR(a),e)`.
Both resulting pairs are supported and therefore fixed. This proves idempotence.

Expanding E⋆x gives the displayed synchronization formula because
`ofR(-1)*e=e`. Applying p to either coordinate of r gives
`p(a)+p(e)p(b)=p(a)`, respectively `p(b)+p(e)p(a)=p(b)`, since p(e)=0.
Substitution into the literal quotient-algebra amplitude gives amplitude
preservation.

If x lies in the amplitude-pullback set, amplitude preservation shows r(x) lies
there too, and r(x) is in image(r). Conversely, if y belongs to image(r) and the
pullback set, idempotence gives r(y)=y. The element y itself is then a preimage
inside the pullback set. This proves both inclusions and therefore equality.
No section of p_D is chosen.

## Boundaries

This proves strictness of this particular synchronization operation. It does not
prove strictness of an arbitrary cohomological comparison, construct a Rees
module, verify the full mixed-double semiring axioms, establish the tensor or
symmetric-power defect formulas, or certify a completed zeta/trace claim. The
source's conclusion about zero amplitude Rees defect requires the separate Rees
construction and its strictness-to-vanishing identification; those are not
silently counted as Lean theorems here.

The original structural results in PR #4 are credited to that existing
contribution. A parallel foundation experiment at
`codex/splitzero-lean-foundations-20260912` overlaps them and is not a second
library proposed for integration. The recommended implementation path is the
PR #4 package plus this additive synchronization module.

## Reproduction

Use the existing Lean 4.31.0 / Mathlib `fabf563a7c95a166b8d7b6efca11c8b4dc9d911f`
workspace in this directory. The additional workflow verifies the unchanged
original-core blob, builds all original modules and the new module, checks the
new source with `--trust=0 -DwarningAsError=true`, and checks every named new
source declaration's transitive axiom report against only
`propext`, `Classical.choice`, `Quot.sound`. It also reruns the original selected
28-declaration audit and its checker tests.

```sh
python3 prepare.py
python3 -m unittest -v test_synchronization_checker.py
python3 check_synchronization.py --prepare
lake update
lake exe cache get
lake -KmaxJobs=1 build
lake env lean --trust=0 -DwarningAsError=true SplitZeroSynchronization.lean
lake env lean --trust=0 -DwarningAsError=true AuditSynchronization.lean > AuditSynchronization.log
python3 check_synchronization.py --log AuditSynchronization.log
```

The additional source-name scanner covers the declaration syntax used by this
single module, not arbitrary Lean syntax or all generated constants. Missing,
duplicate, and nonstandard reports fail. The six synthetic tests exercise the
checker rather than proving the mathematics. Execution status is commit-specific
and is recorded in the PR's exact workflow link, not inferred from this note.


\clearpage

# Split support, Rees defects, and the completed arithmetic trace

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/split-support-rees-trace/RESEARCH_NOTE.md). Module: `workbenches/split-support-rees-trace/RESEARCH_NOTE.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Research continuation, 11 September 2026.

## 1. Scope and the connected calculation

This continuation starts from the filtered comparison object of *Split support, adelic filtrations, and the comparison image*, not from a fresh scalar zero-adjunction. The fixed scalar semiring is

\[
S=G(k)=k\sqcup\{\tau\},\qquad e=0_k\in S,\qquad 0_S=\tau.
\]

Here \(k\) is a characteristic-zero coefficient field. A supported zero, the polynomial parameter origin, and a zero of an arithmetic function occur at different positions in the maps below; none is substituted for another.

The construction links five operations:

\[
\begin{aligned}
&\text{a comparison in a split-support module diagram}\\
&\longrightarrow\text{its Rees inclusion and special-fibre module}\\
&\longrightarrow\text{tensor, symmetric-power, and dual defects}\\
&\longrightarrow\text{a graded determinant and its first variation}\\
&\longrightarrow\text{completed arithmetic logarithmic derivatives and test-function traces}.
\end{aligned}
\]

The algebraic statements are proved below. The completed zeta functions and their analytic properties are established arithmetic inputs, not consequences claimed from support alone. The uniform-shift Rees family used in the arithmetic calculation is explicitly constructed here; it has not been identified with the unknown cohomological comparison for the full number-field spectral realization. The calculations do not establish RH, but they provide a scalar trace bridge and an exact amplification invariant for the proposed Weil II-style programme.

The current Zeta repository already proves the split-semimodule/linear-join-diagram equivalence in chapter 14, divisor and jet maps in chapter 15, and packet-grouped logarithmic derivatives in chapter 17. Those results are inputs and are not recounted as new discoveries.

## 2. Work above the existing common support

The source chapter 14 identifies a \(G(k)\)-semimodule with a join-semilattice \(L\), vector spaces \(V_l\), and coherent linear transports

\[
\rho_{l,m}:V_l\longrightarrow V_m\quad(l\le m).
\]

The reconstructed carrier is \(M=\bigsqcup_{l\in L}V_l\), with

\[
x\boxplus y=\rho_{l,l\vee m}x+\rho_{m,l\vee m}y,
\quad e x=0_{V_l},\quad \tau x=0_{V_{0_L}}.
\]

We retain that carrier. Suppose the vector spaces have decreasing, exhaustive, separated, left-continuous filtrations with finitely many jumps, and the transports preserve them. For a compatible family of comparison maps

\[
c_l:(V_l,F_l)\longrightarrow(W_l,G_l),
\]

put \(I_l=\operatorname{im}c_l\). The source-quotient and target-subspace filtrations are

\[
Q_l^aI_l=c_l(F_l^aV_l),\qquad
P_l^aI_l=I_l\cap G_l^aW_l.
\]

The identity of \(I_l\) gives \(Q_l^aI_l\subseteq P_l^aI_l\). A commuting square of filtered comparison maps sends both filtrations into the corresponding ones at the next support label. Hence all the Rees maps and defect quotients below are functorial over this same \(L\). For any finite dimension at a label, the calculation applies there; it does not replace the whole diagram by its top fibre.

### 2.1 A strict map already supplied by mixed support

In the user's mixed double \(D_A=G(A)^2\), retain

\[
(a,b)\star(c,d)=(ac\oplus(-1_A)bd,\ ad\oplus bc),
\]

and the amplitude map

\[
p_D(a,b)=p_A(a)+t p_A(b)\in B=A[t]/(t^2+1).
\]

The synchronization idempotent is \(E=(1,e_A)\). Multiplication by \(E\) gives a retraction

\[
r_E:D_A\longrightarrow ED_A,\qquad x\longmapsto Ex,
\]

with \(p_Dr_E=p_D\) and \(r_E|_{ED_A}=\operatorname{id}\). For every specified amplitude filtration \(F^aB\), define the lifted filtration by inverse image. Then

\[
\boxed{
 r_E(p_D^{-1}F^aB)=ED_A\cap p_D^{-1}F^aB.
}
\]

The inclusion from left to right uses amplitude preservation. For the converse, any point of the right side is its own preimage under the retraction. This proves supported strictness for this actual idempotent operation; it does not require a chosen section of the ordinary amplitude map. Its induced amplitude comparison is the identity of the same filtered \(B\), so its amplitude Rees defect is zero. This addresses synchronization itself, not every subsequent cohomological map.

## 3. The finite comparison module

Fix one label and write \(I\) for the finite-dimensional image, of rank \(r\ge1\). First retain integer filtration jumps, without changing any of their values. Put \(R=k[T]\), with \(\deg T=1\), and

\[
L_Q=\sum_a Q^aI\,T^{-a},\qquad
L_P=\sum_a P^aI\,T^{-a}
\subset I\otimes_k k[T,T^{-1}].
\]

These are finite free graded \(R\)-modules and \(L_Q\subseteq L_P\). Define

\[
\boxed{D_c=L_P/L_Q.}
\]

It is a finite-dimensional \(k\)-space killed by a power of \(T\). Localizing at \(T\) identifies both lattices with the same \(I\otimes k[T,T^{-1}]\). Thus

\[
D_c=0\iff Q^aI=P^aI\text{ for every }a.
\]

If the two filtration-weight lists are \((\lambda_j)\) and \((\mu_j)\), then

\[
\ell(D_c)=\sum_j\mu_j-\sum_j\lambda_j.
\]

This is the determinant-index formula proved in the predecessor. The retained finite support lift is

\[
\widetilde L_Q=M[\mathbb Z]\times_{I[\mathbb Z]}L_Q,
\qquad
\widetilde L_P=M[\mathbb Z]\times_{I[\mathbb Z]}L_P
\]

whenever \(M\to I\) is the specified compatible amplitude carrier. Supported zero coefficients remain present in \(M[\mathbb Z]\). The ordinary quotient \(D_c\) is an amplitude invariant of these maps; it is not a new externally adjoined scalar zero.

## 4. Exact composition, duality, and amplification

### Theorem 4.1: composition and duality

For nested free lattices \(L_0\subseteq L_1\subseteq L_2\), all with the same localization,

\[
0\longrightarrow L_1/L_0\longrightarrow L_2/L_0
\longrightarrow L_2/L_1\longrightarrow0.
\]

The arrows are the inclusion of classes and the quotient map. Thus lengths add exactly. The same is true of endomorphism traces for any operator preserving the three lattices.

For \(D=L_P/L_Q\), dualizing over \(R\) gives

\[
\boxed{
0\longrightarrow L_P^\vee\longrightarrow L_Q^\vee
\longrightarrow\operatorname{Ext}^1_R(D,R)\longrightarrow0.
}
\]

Indeed \(\operatorname{Hom}_R(D,R)=0\) because \(D\) is torsion and \(R\) is a domain, and both free lattices have zero first Ext. The dual defect has the same length.

There is an explicit perfect \(k\)-pairing

\[
D\times(L_Q^\vee/L_P^\vee)\longrightarrow k,
\quad([x],[\phi])\longmapsto [T^{-1}]\,\phi(x).
\]

Evaluation is taken in \(k[T,T^{-1}]/k[T]\); changing either representative adds a polynomial, whose \(T^{-1}\) coefficient is zero. In a Smith block \(T^aR\subset R\), the pairing on bases \(T^j\) and \(T^{-a+i}\), with \(0\le i,j<a\), is the anti-diagonal matrix \(\mathbf1_{i+j=a-1}\), hence is nondegenerate. If an operator restricts to an automorphism of each lattice, its action on the dual is \(\phi\mapsto\phi\circ F^{-1}\), making the pairing invariant. No positive-definiteness assertion is substituted for this bilinear duality.

### Theorem 4.2: every tensor and symmetric power retains the defect

Let the Smith exponents of \(L_Q\subseteq L_P\) be \(a_1,\ldots,a_r\), all nonnegative. For \(m\ge1\), the tensor-power inclusion has Smith exponents

\[
a_{i_1}+\cdots+a_{i_m}\quad(1\le i_j\le r).
\]

Its defect therefore has length

\[
\boxed{\ell D_{\otimes m}=m r^{m-1}\ell D_c.}
\]

The symmetric-power inclusion has one exponent

\[
\alpha_1a_1+\cdots+\alpha_ra_r
\]

for each \(\alpha\in\mathbb N^r\) with \(\sum_i\alpha_i=m\). Consequently, writing \(r_m=\binom{m+r-1}{r-1}\),

\[
\boxed{
\ell D_{\mathrm{Sym}^m}=\binom{m+r-1}{r}\ell D_c,
\qquad
\frac{\ell D_{\mathrm{Sym}^m}}{r_m}=\frac m r\ell D_c.
}
\]

For exterior powers, \(1\le j\le r\),

\[
\boxed{\ell D_{\wedge^j}=\binom{r-1}{j-1}\ell D_c.}
\]

Proof: the invertible changes of basis used in the Smith form induce invertible maps on each displayed functor. For the diagonal inclusion, the tensor, monomial, and wedge bases give exactly the exponents written above. Each \(a_i\) occurs \(m r^{m-1}\) times in the tensor total and \(\binom{r-1}{j-1}\) times in the wedge total. In the symmetric total, symmetry makes each coordinate contribute \(m r_m/r=\binom{m+r-1}{r}\). No factorial-scaled choice of symmetric basis is used.

### Corollary 4.3: a sublinear per-rank estimate forces strictness

Suppose the **same symmetric-power comparison** satisfies

\[
\ell D_{\mathrm{Sym}^m}\le r_m b_m\quad\text{for every }m\ge1,
\qquad b_m/m\longrightarrow0.
\]

Then \(D_c=0\). In fact, the exact formula yields \(\ell D_c/r\le b_m/m\) for every \(m\), and taking the limit forces the nonnegative integer \(\ell D_c\) to vanish. The hypothesis includes bounds of the form \(b_m=C\log r_m+B\).

This is an exact amplification-to-vanishing theorem. Chen--Moriwaki provide logarithmic-rank errors for their own casting comparisons; those errors are not silently reassigned to this different comparison. To use this corollary on a given arithmetic map, its actual symmetric-power defect must receive the stated bound. Here the invariant and its exact growth are calculated, rather than assumed to vanish.

For finite real filtrations, retain the ordered exponent algebra of the predecessor and the actual degree difference \(\Delta=\sum\mu_j-\sum\lambda_j\). Symmetric-power weight sums give the same identity \(\Delta_m=\binom{m+r-1}{r}\Delta\). These are real degree differences, not a claimed finite module length over a dense non-Noetherian monoid algebra.

## 5. A trace can forget the defect while a graded trace recovers it

Let \(F\) preserve the two integer filtrations. Its induced \(R\)-linear operator commutes with \(T\) and acts on \(D_c\). For every positive integer \(n\), define finite Laurent polynomials

\[
\begin{aligned}
A_Q(z,F^n)&=\sum_d z^d\operatorname{Tr}(F^n\mid(L_Q/TL_Q)_d),\\
A_P(z,F^n)&=\sum_d z^d\operatorname{Tr}(F^n\mid(L_P/TL_P)_d),\\
\Theta_D(z,F^n)&=\sum_d z^d\operatorname{Tr}(F^n\mid(D_c)_d).
\end{aligned}
\]

The grading is literally the exponent of \(T\), so a filtration weight \(\lambda\) gives a free generator of degree \(-\lambda\).

### Theorem 5.1: the boundary-character identity

\[
\boxed{A_P(z,F^n)-A_Q(z,F^n)=(1-z)\Theta_D(z,F^n).}
\]

For a finite graded free module, the degreewise trace series is its fibre trace polynomial divided by \(1-z\). This follows either by the sequences for multiplication by \(T\), or by an adapted basis and the upper triangular action on its weight blocks. Applying additivity of trace to \(0\to L_Q\to L_P\to D_c\to0\) proves the identity. This proof also covers nonsemisimple \(F\).

At \(z=1\), the difference is zero for every \(n\). Its derivative retains the full ungraded defect trace:

\[
\boxed{
-\left.z\frac{\partial}{\partial z}(A_P-A_Q)\right|_{z=1}
=\operatorname{Tr}(F^n\mid D_c).
}
\]

For \(F=I\), this is exactly \(\ell D_c\). Higher derivatives retain higher degree moments of \(D_c\); keeping \(\Theta_D\) retains the trace on every graded component.

The derived special-fibre sequence is

\[
0\to\operatorname{Tor}_1^R(D_c,k)\to L_Q/TL_Q
\to L_P/TL_P\to D_c/TD_c\to0.
\]

The cancellation at \(z=1\) is thus explained by the actual kernel and cokernel maps. It is not a claim that these spaces individually vanish.

### Theorem 5.2: determinant form, with its sign

Define, as a formal series in \(u\),

\[
\boxed{
\mathcal B_c(u,z)=
\frac{\prod_d\det(1-u z^d F\mid(L_Q/TL_Q)_d)}
     {\prod_d\det(1-u z^d F\mid(L_P/TL_P)_d)}.
}
\]

Then \(\mathcal B_c(u,1)=1\), but

\[
\boxed{
\left.z\partial_z\log\mathcal B_c(u,z)\right|_{z=1}
=-u\partial_u\log\det(1-uF\mid D_c)^{-1}.
}
\]

Proof: the determinant logarithm gives

\[
\log\mathcal B_c(u,z)=
\sum_{n\ge1}\frac{u^n}{n}
\bigl(A_P(z^n,F^n)-A_Q(z^n,F^n)\bigr).
\]

Insert Theorem 5.1. Differentiating \((1-z^n)\Theta_D(z^n,F^n)\) at \(z=1\) yields \(-n\operatorname{Tr}(F^n|D_c)\), proving the formula. The minus sign is determined by the displayed order of numerator and denominator.

## 6. Put the actual arithmetic norms into the determinant calculation

Take the uniform comparison

\[
L_Q=k[T]\otimes V,\qquad
L_P=T^{-a}k[T]\otimes V,\qquad a\in\mathbb Z_{>0}.
\]

Its defect has length \(a\dim V\). For an operator \(F\) on \(V\),

\[
\mathcal B_{a,F}(u,z)=\frac{\det(1-uF)}{\det(1-u z^{-a}F)}.
\]

Let \(\mathfrak p\) be a finite prime of a number field, \(Q=N\mathfrak p\). Use the exact parameter map

\[
(s,\varepsilon)\longmapsto(u,z)=(Q^{-s},Q^{-\varepsilon}),
\quad Q^{-s}=\exp(-s\log Q),
\]

with the real positive \(\log Q\). If

\[
L_{\mathfrak p}(s,F)=\det(1-Q^{-s}F)^{-1},
\]

then

\[
\boxed{
\mathcal B_{a,F}(Q^{-s},Q^{-\varepsilon})
=\frac{L_{\mathfrak p}(s-a\varepsilon,F)}{L_{\mathfrak p}(s,F)}.
}
\]

Consequently,

\[
\boxed{
\left.\partial_\varepsilon\log\mathcal B_{a,F}\right|_0
=-a\frac{L_{\mathfrak p}'(s,F)}{L_{\mathfrak p}(s,F)}
=a\log Q\sum_{n\ge1}\operatorname{Tr}(F^n)Q^{-ns}.
}
\]

The prime norm produces the factor \(\log Q\); it has not been replaced by an unweighted count.

For an Artin representation, use exactly \(V^{I_{\mathfrak p}}\) and Frobenius on those inertia invariants. Since finite-group invariants in characteristic zero are exact, the same uniform comparison restricts there. Thus no ramified Euler factor is dropped. The construction is compatible with direct sums, and hence with character decompositions and their multiplicities.

### 6.1 A finite arithmetic check including ramification

For \(\mathbb Q(i)/\mathbb Q\), use the permutation representation on the two embeddings. The local determinant is

\[
\begin{cases}
(1-u)^2,&p\equiv1\pmod4,\\
1-u^2,&p\equiv3\pmod4,\\
1-u,&p=2.
\end{cases}
\]

At \(p=2\), inertia invariants have basis \((1,1)\), and the induced Frobenius is the identity. For the inert case the matrix is \(\left(\begin{smallmatrix}0&1\\1&0\end{smallmatrix}\right)\); its odd power traces vanish and its even power traces are two. The prime-two factor is therefore included by the same formula, not inserted afterward without a representation.

## 7. Complete the trace, including all archimedean and discriminant terms

For a number field \(K\), retain its absolute discriminant \(D_K\), real-place count \(r_1\), and complex-place count \(r_2\). Define

\[
\Gamma_{\mathbb R}(s)=\pi^{-s/2}\Gamma(s/2),\qquad
\Gamma_{\mathbb C}(s)=2(2\pi)^{-s}\Gamma(s),
\]

\[
\Lambda_K(s)=|D_K|^{s/2}
\Gamma_{\mathbb R}(s)^{r_1}
\Gamma_{\mathbb C}(s)^{r_2}\zeta_K(s).
\]

These factors are explicit. Form the meromorphic family

\[
\boxed{\mathscr B_{K,a}(s,\varepsilon)
=\frac{\Lambda_K(s-a\varepsilon)}{\Lambda_K(s)}.}
\]

In a zero- and pole-free neighborhood it is holomorphic in \(\varepsilon\) near zero and has value one there. Its finite-prime part is the convergent product of the preceding uniform Rees comparisons when both real parts exceed one. Its continuation is supplied by the established completed Dedekind function.

Let \(\psi=\Gamma'/\Gamma\). The first variation is exactly

\[
\begin{aligned}
J_{K,a}(s)
&:=\left.\partial_\varepsilon\log\mathscr B_{K,a}\right|_0\\
&=-a\left[
\frac12\log|D_K|
+r_1\left(\frac12\psi(s/2)-\frac12\log\pi\right)
+r_2\left(\psi(s)-\log(2\pi)\right)
+\frac{\zeta_K'(s)}{\zeta_K(s)}\right].
\end{aligned}
\]

For \(\Re s>1\), its last term can be written with every prime ideal:

\[
-a\frac{\zeta_K'}{\zeta_K}(s)
=a\sum_{\mathfrak p}\sum_{n\ge1}
\log N\mathfrak p\,(N\mathfrak p)^{-ns}.
\]

The \(\Gamma_{\mathbb C}\) factor 2 cancels between two identical ratio factors; its presence in \(\Lambda_K\) is retained. Nothing in this construction assigns the defect length \(a\) to an actual arithmetic zero. The length indexes the comparison family, while the first variation reads the existing arithmetic divisor.

### 7.1 The higher datum lies over a supported zero

Set \(\mathscr C_{K,a}=\mathscr B_{K,a}-1\). Let \(U\) avoid the divisor of \(\Lambda_K\), and let \(A\) be the algebra of holomorphic germs near \(U\times\{0\}\). The first-jet ring map is

\[
j^1:A\longrightarrow\mathcal O(U)[\eta]/(\eta^2),
\quad f\longmapsto f(s,0)+\eta\partial_\varepsilon f(s,0).
\]

It is multiplicative by the product rule. Applying the same split functor gives

\[
G(A)\xrightarrow{G(j^1)}G(\mathcal O(U)[\eta]/\eta^2)
\xrightarrow{G(\eta\mapsto0)}G(\mathcal O(U)).
\]

For the supported germ \(\mathscr C_{K,a}\), the first arrow gives

\[
\boxed{-a\eta\,\Lambda_K'(s)/\Lambda_K(s),}
\]

and the second gives the supported zero, not \(\tau\). This is a concrete way in which evaluation at the common origin forgets arithmetic information that a retained first jet recovers. The nilpotent coefficient algebra is a higher amplitude object over the same scalar support; its zero ideal is not asserted to be prime in every coefficient ring.

At a zero or pole \(\rho\) of order \(m_\rho\), with pole orders negative,

\[
\operatorname{Res}_{s=\rho}J_{K,a}(s)=-a m_\rho.
\]

This follows by writing \(\Lambda_K(s)=(s-\rho)^{m_\rho}u(s)\), where \(u(\rho)\ne0\). Thus the jet extends meromorphically and recovers location and multiplicity, not just the common zero value.

## 8. Exact passage to an arithmetic test-function trace

Let \(f\in C_c^\infty(\mathbb R_{>0})\),

\[
h(s)=\int_0^\infty f(x)x^{s-1}\,dx,
\qquad f^\sharp(x)=x^{-1}f(x^{-1}).
\]

Then \(h(1-s)=\mathcal M(f^\sharp)(s)\). For any positively oriented contour avoiding the completed divisor,

\[
-\frac1{2\pi i}\int_C h(s)J_{K,a}(s)\,ds
=a\sum_{\rho\text{ inside }C}m_\rho h(\rho).
\]

This is the residue theorem applied to the first jet just constructed. It needs no claim about where the nontrivial zeros lie.

The completed Dedekind function has its two poles at 0 and 1 and satisfies \(\Lambda_K(s)=\Lambda_K(1-s)\). Moving the contour to the two vertical lines \(c\) and \(1-c\), with \(c>1\), gives

\[
\boxed{
\sum_{\rho\text{ nontrivial}}h(\rho)
=h(0)+h(1)-\frac1{2\pi i a}
\int_{c-i\infty}^{c+i\infty}
[h(s)+h(1-s)]J_{K,a}(s)\,ds.
}
\]

The sum counts multiplicity. Mellin transforms of the stated test functions decay faster than every power vertically in a fixed strip. The order-one completed function's paired logarithmic-derivative expansion supplies polynomial bounds along a sequence of horizontal lines avoiding its zeros; these make the horizontal integrals vanish. Equivalently, for \(K=\mathbb Q\), the current repository's normally convergent packet expansion and the standard explicit formula justify the same passage. The sum and vertical integrals converge in these test-function spaces. This is an application of those established analytic facts, not a new proof of them.

Substitute the calculated \(J\). With

\[
\mathcal G_K(f)=\frac1{2\pi i}\int_{c-i\infty}^{c+i\infty}
[h(s)+h(1-s)]
\left[r_1\frac{\Gamma_{\mathbb R}'(s)}{\Gamma_{\mathbb R}(s)}
+r_2\frac{\Gamma_{\mathbb C}'(s)}{\Gamma_{\mathbb C}(s)}\right]ds,
\]

Mellin inversion gives the full identity

\[
\boxed{
\begin{aligned}
\sum_\rho h(\rho)
={}&h(0)+h(1)+\log|D_K|f(1)+\mathcal G_K(f)\\
&-\sum_{\mathfrak p,n\ge1}\log N\mathfrak p
\left[f((N\mathfrak p)^n)+(N\mathfrak p)^{-n}f((N\mathfrak p)^{-n})\right].
\end{aligned}
}
\]

For a compactly supported \(f\), the last sum has only finitely many nonzero terms. Both poles, the discriminant term, every finite prime ideal, and the archimedean integral have been retained. This completes the scalar trace identification for the constructed first variation. It does not identify the constructed uniform-shift comparison with a compact-support-to-ordinary cohomological map for the number field.

For \(K=\mathbb Q\), \(\xi(s)=\tfrac12s(s-1)\Lambda_{\mathbb Q}(s)\). The exact ratio identity is

\[
\frac{\xi(s-a\varepsilon)}{\xi(s)}
=\frac{(s-a\varepsilon)(s-a\varepsilon-1)}{s(s-1)}
\mathscr B_{\mathbb Q,a}(s,\varepsilon).
\]

Its first variation is \(-a\xi'/\xi\). In chapter 17's actual packet coordinates it is

\[
-a\sum_O m_O\frac{P_O'(s)}{P_O(s)}
=-a\sum_O m_O\sum_{\rho\in O}\frac1{s-\rho},
\]

with that chapter's compact-uniform grouping. This is the direct integration point with the existing Zeta workbench, rather than another construction of the same packet decomposition.

## 9. What has been obtained and what is to be tested next

The common support is retained in a diagram of filtered modules. Actual support synchronization is strict. More general comparison defects have exact composition, duality, and all-power growth laws. Their ungraded determinant can be identically one while the grading derivative recovers every defect trace. Coupling that grading to the actual ideal norm reconstructs completed arithmetic logarithmic derivatives and their test-function trace, with no missing finite or infinite place.

There are now two concrete measurements to carry on the same arithmetic comparison: the all-power Rees defect \(D_{\mathrm{Sym}^m}\), and the completed first-variation trace \(J_{K,a}\). The first has a proved linear-per-rank growth law; a genuinely sublinear estimate on that very family forces strictness. The second is already expressed in the existing prime and packet formulas. No bound on the former has been deduced from the latter in this note, and no positivity of the full Weil pairing is asserted.

For the Weil II-directed route, strictness and the two opposite weight bounds remain separate calculations joined by the image map. The work here advances the strictness/trace interface. It does not replace the two-sided purity argument by support uniqueness, nor use a generic NS endpoint assertion as a proof of an arithmetic estimate.

## 10. Source and verification record

The source basis is recorded in README.md with pinned repository paths and hashes. The predecessor's complete LaTeX was read locally. Current Zeta chapters 14, 15, 17, and selected interfaces of 19 were read as TeX; the relevant local archive copies match the pinned Git blob identities. The mathematical input from Chen--Moriwaki is the attached book and the predecessor's retained formulas. The supplied Deligne TeX excerpts were reread, with their pre-existing historical-transcription qualifications retained. No new PDF or OCR extraction was used for this continuation.

The executable checks use exact rational arithmetic and symbolic polynomials, with explicit failures instead of Python assert statements. They exercise support synchronization, composition and Smith indices, tensor/symmetric/exterior multiplicities, dual residue pairings, graded traces, determinant derivatives, ramified and unramified local factors, and jet/divisor identities. They verify finite instances of the displayed general proofs, not RH, the whole Chen--Moriwaki book, Deligne's proof, or the upstream NS manuscript. Novelty and an independent mathematical audit are not claimed.

### References

- Huayi Chen and Atsushi Moriwaki, *Positivity in Arakelov Geometry over Adelic Curves: Hilbert-Samuel Formula and Equidistribution Theorem*, Progress in Mathematics 355, 2024. In particular §§2.5, 3.1, 3.2, 4.1 and 5.5. DOI: 10.1007/978-3-031-61668-6. Related preprint: arXiv:2207.02033.
- Pierre Deligne, *La conjecture de Weil. II*, Publications Mathématiques de l'IHÉS 52 (1980), 137–252. The relevant supplied TeX passages are §§3.3.4–3.3.6 and 6.2.4–6.2.6.
- James W. Cogdell, *On Artin L-functions*, especially the intrinsic inertia-invariant Euler factors, archimedean factors, and additivity/induction discussion. User-supplied text.
- Alain Connes, Caterina Consani and Henri Moscovici, *Zeta Spectral Triples*, arXiv:2511.22755, §3 for the explicit formula and its test-function conventions.
- KokunoYumeto, Zeta research reader, chapters 14, 15 and 17 at commit `42d00e359b16d52ca71568ce5e3db5341949d929`; *Split support, adelic filtrations, and the comparison image*, conversation attachment, 11 September 2026. These are research inputs, not assertions of an independently audited endpoint theorem.


\clearpage

# Origin-jet ladder from actual restricted theta relations

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/split-support-rees-trace/ORIGIN_JET_LADDER.md). Module: `workbenches/split-support-rees-trace/ORIGIN_JET_LADDER.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Companion to ORIGINAL_QUOTIENT_PROPAGATION.md. This calculation starts with explicit source test functions and propagates the original support-preserving quotient. It does not postulate an additional zero of the actual zeta function.

## 1. Actual source operators produce the relation ideals

Retain

\[
D=-x\partial_x,\qquad
\phi_*(x)=(4\pi^2x^4-6\pi x^2)e^{-\pi x^2},\qquad g(s)=2\xi(s).
\]

The existing source identity is M Theta phi_*=g. For every j>=0 define phi_j=D^j phi_*. Each belongs to the actual source V: it is even and Schwartz, has value zero at the real origin, and integration by parts gives integral D phi = integral phi = 0. Differentiating the theta sum and integrating the Mellin integral by parts gives

\[
\boxed{\mathcal M\Theta\phi_j(s)=s^jg(s).}
\tag{1}
\]

The identity first holds in an absolute-convergence half-plane and then extends by the source's entire continuation. All coefficients and signs are retained.

For 0<=m<=N put

\[
W_{m,N}=\operatorname{span}_{\mathbb C}\{\phi_m,\ldots,\phi_N\}.
\]

These are actual finite labels in the existing source diagram. Their image ideals are exactly

\[
\boxed{\mathcal I_{W_{m,N}}=(g(s)s^m).}
\tag{2}
\]

Containment follows from (1), and the generator at j=m gives equality. The ideal is independent of N once N>=m. For fixed N and 0<=m<N, the source inclusion W_{m+1,N} -> W_{m,N} gives the quotient map

\[
\mathcal D_{m+1}=\mathcal O/(gs^{m+1})\longrightarrow
\mathcal D_m=\mathcal O/(gs^m),\qquad[f]\mapsto[f].
\tag{3}
\]

Every finite segment of this inverse system therefore comes from actual source inclusions, not repeated bottom-support adjunction. The inputs are independent: writing phi_j=P_j exp(-pi x^2) gives P_{j+1}=2 pi x^2 P_j-x P_j', with nonzero leading term of degree 4+2(j+1).

## 2. The comparison kernel is exactly the origin jet

At m=0, D_0=O/(g) is the actual completed arithmetic divisor module. The exact sequence is

\[
\boxed{0\to\mathcal O/(s^m)\xrightarrow{k_m}\mathcal D_m
\longrightarrow\mathcal D_0\to0,\qquad k_m([a])=[ga].}
\tag{4}
\]

The kernel is (g)/(gs^m). Multiplication by the nonzero entire g identifies it with O/(s^m), retaining g in the actual map.

The same theta source computes g(0)=1. Let theta(x)=sum_{n!=0} exp(-pi n^2 x^2). Poisson gives theta(x)=x^{-1}-1 plus a term whose derivatives vanish faster than any power at zero. Also Theta phi_*=D(D-1)theta. Hence

\[
\mathcal M\Theta\phi_*(0)=-[(D-1)\theta]_0^\infty=1.
\]

The functional equation gives g(1)=1.

For m>=1, an explicit Chinese-remainder inverse is obtained by letting a_m(s) be the Taylor polynomial of 1/g at zero of degree less than m and putting

\[
b_m(s)=\frac{1-a_m(s)g(s)}{s^m}.
\]

This is entire and a_m g+b_m s^m=1. The inverse of D_m -> D_0 direct-sum O/(s^m) is

\[
([u],[v])\longmapsto[b_m s^m u+a_m g v].
\tag{5}
\]

For m=0, O/(s^0)=0 and the comparison is the identity D_0 -> D_0 direct-sum 0; no Taylor polynomial is needed. Thus the m-step origin module is an exactly computed kernel of the restricted-presentation comparison. It is not being described as an extra nontrivial zero of the unchanged xi function.

## 3. Apply the original split congruence at every stage

At any analytic stalk R use exactly

\[
x\sim_I^{\mathrm{sp}}y\iff(x=y=\tau)
\text{ or }(x,y\in R\text{ and }x-y\in I).
\]

The supported system is

\[
\boxed{G(R/(gs^{m+1}))\longrightarrow G(R/(gs^m))
\longrightarrow G(R/(g)).}
\tag{6}
\]

Every arrow fixes external absence. Its preimage over external absence contains only external absence. The preimage of the supported zero under the last arrow is the supported copy of (g)/(gs^m).

The class of g s^m is nonzero in the origin stalk at level m+1 and becomes the supported zero at level m. It never becomes tau.

Applying G to the actual Chinese-remainder map gives, stalkwise and then with sheafification,

\[
\boxed{G(\mathcal D_m)\cong
G(\mathcal D_0)\times_{\mathbb B}G(\mathcal O/(s^m)).}
\tag{7}
\]

The fibre product uses the same Boolean support character. It does not add a new external scalar zero for the origin factor.

## 4. The Fourier-compatible version retains both endpoints

On the even Schwartz source,

\[
\widehat{D\phi}=(1-D)\widehat\phi.
\]

Therefore Delta=D(1-D) commutes with Fourier transform. Since hat phi_*=phi_*, the tests psi_j=Delta^j phi_* are Fourier-fixed and satisfy

\[
\boxed{\mathcal M\Theta\psi_j(s)=[s(1-s)]^j g(s).}
\tag{8}
\]

For the source label spanned by psi_m,...,psi_N, the ideal is g[s(1-s)]^m. The comparison kernel is

\[
\boxed{\mathcal O/([s(1-s)]^m)
\cong\mathcal O/(s^m)\oplus\mathcal O/((1-s)^m),}
\tag{9}
\]

embedded into O/(g[s(1-s)]^m) by multiplication by the actual g. The endpoint ideals are comaximal and g is a unit at both endpoints. The full split decomposition is the common-support fibre product of these endpoint factors and the actual arithmetic divisor factor.

For the source involution f^dagger(s)=overline(f(1-bar s)), coordinates z_0=s and z_1=s-1 give the endpoint map

\[
\sum_j a_jz_1^j\longmapsto\sum_j(-1)^j\bar a_jz_0^j.
\tag{10}
\]

The factor s(1-s) has not been replaced by s(s-1); such a replacement would introduce (-1)^m into (8).

This calculates the one-endpoint ladder and its symmetry-preserving two-endpoint counterpart inside the actual source test space. It does not equate a jet order with a Krull dimension or supply a spectral positivity bound. Omitted lower source relations produce a supported origin-jet module; reintroducing those relations removes it by the specified quotient map without erasing the common support.

## Source and check boundary

The source theta multiplier and phi_* are read from ACTUAL_ADELIC_COMPARISON.md at blob c23656c2a43e0041d6f7aeb0b80d6e12a6b468d9. The original quotient is the congruence of the globalization note and the general quotient theorem in ORIGINAL_QUOTIENT_PROPAGATION.md. The recursive Gaussian calculation, exact sequence, and explicit CRT maps above are derived in this continuation.

The local companion checker executes 101 exact symbolic comparisons: the Gaussian Mellin-polynomial recursions, the involution, and universal polynomial CRT identities. The polynomial CRT test examples are not claimed to be the Riemann xi function. The general analytic claims are proved above. No RH claim, independent novelty assessment or automatic merge is made.


\clearpage

# Actual adelic comparison: supported sheaves, theta image, and spectral jets

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/split-support-rees-trace/ACTUAL_ADELIC_COMPARISON.md). Module: `workbenches/split-support-rees-trace/ACTUAL_ADELIC_COMPARISON.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Research continuation, 11 September 2026. This appendix replaces the uniform shifted-L-function example as the starting comparison: its input is the supported arithmetic module sheaf, followed by the actual adelic restriction-and-trace map. It does not assert a completed RH proof, a novelty determination, or an identification of unspecified topological cokernels.

## 1. The arithmetic object and its support

Retain one scalar construction `G(R)=R ⨿ {tau}`, with external additive zero `tau` and supported zero `e_R=0_R`. For an R-module L, use the supported module `L^tau`: supported scalar zero sends a supported vector to `0_L`, while scalar tau sends it to external absence.

For an adele a=(a_f,a_infinity), define

\[
L_a=\{r\in\mathbb Q:a_fr\in\widehat{\mathbb Z}\},\qquad
\xi_a(r)=a_fr,\qquad h_a(r)=a_\infty r.
\]

Here h_a is the map denoted tau_a in Connes–Consani, *On the Jacobian of Spec Z*, arXiv:2602.15941v1; it is not the split scalar tau. The source identifies the framed-divisor objects with the adele-class presentation.

For a nonempty arithmetic open U, use the explicit localized module

\[
L_a(U)=\{r\in\mathbb Q:a_pr\in\mathbb Z_p\text{ for every finite }p\in U\}.
\]

For a finite pointed set X, define supported sections by

\[
\widetilde{\mathcal O}(a)(U)(X)=
\{(r_x)\in(L_a(U)^\tau)^{X\setminus\{*\}}:
\infty\in U\Rightarrow\sum_{x\ne *}|h_a(p(r_x))|\le1\}.
\]

Use the terminal object on the empty open. Pointed-set maps sum over fibres with the split addition. The triangle inequality preserves the bound, and scalar multiplication is compatible because

\[
\sum_{x,y}|h_a(p(b_y r_x))|
=(\sum_y|p(b_y)|)(\sum_x|h_a(p(r_x))|).
\]

Restrictions enlarge the localized coefficient modules. Compatible supported tuples glue. This gives the supported arithmetic module sheaf and its arithmetic projection.

For q in Q^times,

\[
L_{qa}=q^{-1}L_a,\qquad\psi_q:L_{qa}\to L_a,\quad r\mapsto qr,
\]

and

\[
\xi_a\psi_q=\xi_{qa},\qquad h_a\psi_q=h_{qa}.
\]

Extending psi_q by tau -> tau gives the supported sheaf isomorphism. The principal-action groupoid, including its arrows, is retained.

On the earlier extended base i:Y -> Y^+=Y ⨿ {sigma}, with sigma=P_tau, this module sheaf extends with Boolean support stalk and support restriction maps. The arithmetic realization is the typed map

\[
i^{-1}\widetilde{\mathcal O}^{+}(a)\longrightarrow\mathcal O(a).
\]

This is not a claim of a continuous map sending the added generic support point to the zero adele. The support observation and the arithmetic realization are retained together.

## 2. The actual restriction-and-trace comparison

For x in C_Q=A_Q^times/Q^times, set H_x=ell^2(p^{-1}(x)), on its orbit of representatives. For a finite crossed-product sum

\[
a=\sum_{q\in\mathbb Q^\times}f_qU_q,\qquad
U_qfU_q^{-1}(y)=f(q^{-1}y),
\]

define

\[
(\rho_x(a)v)(y)=\sum_q f_q(y)v(q^{-1}y).
\]

Substituting twice proves the representation law. A Bruhat–Schwartz coefficient restricted to this orbit is absolutely summable: the finite-adelic support confines the rational parameter to a fractional lattice, and real Schwartz decay makes the sum converge. Each summand is a trace-class diagonal operator times a permutation. Hence

\[
\boxed{\operatorname{Tr}\rho_x(a)=\sum_{y\in p^{-1}(x)}f_1(y).}
\]

For a multiplication coefficient Phi, this is

\[
\Theta\Phi([g])=\sum_{q\in\mathbb Q^\times}\Phi(qg).
\]

This is the actual degree-zero restriction-and-trace map. Theta is linear; it is not asserted to preserve pointwise multiplication. Its full cyclic extension is a source construction, not newly proved here.

For an idele a, put c_a=product_p p^{-v_p(a_p)}. Then L_a=c_a Z and lambda_a=|a_infinity|c_a=|a|_A. The arithmetic bounded-section count is

\[
N_a(r)=1+2\lfloor r/\lambda_a\rfloor.
\]

Its weighted count is

\[
\int_{(0,\infty)}e^{-\pi u r^2}\,d(N_a(r)-1)
=\sum_{v\in L_a\setminus\{0\}}e^{-\pi u|h_a(v)|^2}.
\]

Thus the theta test is an explicit weighted section-count operation on the arithmetic realization of the supported sheaf. The support lift remains above this observation.

## 3. Both endpoint maps and the test-function topology

Let

\[
V=\{\varphi\in\mathcal S(\mathbb R):\varphi(-x)=\varphi(x),\ 
\varphi(0)=0,\ \int_{\mathbb R}\varphi=0\}.
\]

Use Fourier transform with kernel exp(-2 pi i xy). The two endpoint maps are phi -> (phi(0),hat phi(0)). Embed phi into the adelic coefficients as

\[
\Phi_\varphi(x_f,x_\infty)=\mathbf1_{\widehat{\mathbb Z}}(x_f)\varphi(x_\infty).
\]

At g_t=(1_f,t),

\[
\boxed{\Theta\varphi(t)=\sum_{n\in\mathbb Z\setminus\{0\}}\varphi(nt).}
\]

Before imposing the endpoints, Poisson summation reads

\[
\Theta\varphi(t)=t^{-1}\Theta\widehat\varphi(t^{-1})
+t^{-1}\widehat\varphi(0)-\varphi(0).
\]

Both final terms vanish for phi in V. Define the strong-Schwartz Frechet space T by the seminorms

\[
p_{N,j}(F)=\sup_{t>0}(t^N+t^{-N})|(t\partial_t)^jF(t)|,
\quad N,j\ge0.
\]

Theta:V -> T is continuous. At infinity, differentiate and bound the Schwartz sums; at zero use the displayed Poisson identity for hat phi, which satisfies the same two endpoint equations. Mellin transformation

\[
\mathcal MF(s)=\int_0^\infty F(t)t^s\frac{dt}{t}
\]

is entire and continuous into locally uniform convergence with derivatives. Choose N greater than the spectral real parts on each compact set; additional powers of |log t| control derivatives.

## 4. The actual analytic image is computed

For Re(s)>1, absolute convergence gives

\[
\mathcal M\Theta\varphi(s)=2\zeta(s)M_+\varphi(s),\quad
M_+\varphi(s)=\int_0^\infty\varphi(t)t^s\frac{dt}{t}.
\]

Retain

\[
\xi(s)=\tfrac12s(s-1)\pi^{-s/2}\Gamma(s/2)\zeta(s),
\quad
H_\varphi(s)=\frac{2\pi^{s/2}M_+\varphi(s)}{s(s-1)\Gamma(s/2)}.
\]

**Theorem.** H_phi is entire, and M Theta phi = 2 xi H_phi.

**Proof.** Taylor subtraction continues M_+ phi with possible simple poles at negative even integers. The value condition removes the pole at zero. Reciprocal Gamma cancels the negative-even poles; its simple zero at s=0 cancels the explicit denominator s. The integral condition gives M_+phi(1)=0 and cancels s-1. There are no other possible poles. Analytic continuation extends the identity from Re(s)>1. No division by xi at a zero was assumed.

Set D=x d/dx and

\[
\boxed{\varphi_*=D(D+1)e^{-\pi x^2}
=(4\pi^2x^4-6\pi x^2)e^{-\pi x^2}.}
\]

Integration by parts proves phi_* in V and

\[
M_+\varphi_*(s)=\tfrac12s(s-1)\pi^{-s/2}\Gamma(s/2).
\]

Consequently H_phi*=1 and M Theta phi*=2xi. Fourier conjugation D -> -(D+1) proves hat phi*=phi_*.

The Gaussian/Hermite multiplier is already in the source programme; it is not counted as a new discovery. Its consequence for the supported analytic comparison is

\[
\boxed{\mathcal I_\Theta=2\xi\mathcal O_{\mathbb C},}
\]

where I_Theta is the sheaf of ideals generated by all M Theta phi. Containment follows from the factorization; the chosen actual input proves equality. Thus

\[
0\to\mathcal O_{\mathbb C}\xrightarrow{\times2\xi}\mathcal O_{\mathbb C}
\to\mathcal D_\xi\to0,
\qquad\mathcal D_\xi=\mathcal O_{\mathbb C}/(2\xi).
\]

This is analytic sheafification of the actual image. No equality of an unspecified topological closure with an algebraic ideal is asserted.

The exact map to the existing workbench coordinates is

\[
\mathcal F_\mu\mathcal E\varphi(z)
=\tfrac12\mathcal M\Theta\varphi(\tfrac12-iz),
\quad
\mathcal E\varphi(t)=t^{1/2}\sum_{n\ge1}\varphi(nt).
\]

For phi_*, it gives xi(1/2-iz)=Xi(z), by the functional equation. Both the factor 1/2 and the Fourier exponent's sign are retained.

## 5. All support labels survive the comparison

Let L be the join-semilattice of finite-dimensional subspaces W of V, with join W+W' and bottom 0. In sheaf-valued linear diagrams on this fixed L, set

\[
\mathcal A_W=\mathcal O\otimes_{\mathbb C}W,
\qquad
\mathcal B_W=\mathcal O\ (W\ne0),\qquad\mathcal B_0=0,
\]

and

\[
\delta_W(\sum_j a_j\otimes\varphi_j)=\sum_j a_j\mathcal M\Theta\varphi_j.
\]

Use inclusion in the source and identity in the nonzero target for W subset W'. The squares commute. Define H^1_W=coker(delta_W) fibrewise. This is the degree-one cohomology sheaf of the two-term sheaf complex, not a claim that global sheaf cohomology of the arithmetic curve has already been computed.

Reconstruct the fixed-support diagram through chapter 14's equivalence. Then

\[
e\cdot(W,h)=(W,0),\qquad\tau\cdot(W,h)=(0,0).
\]

**Cofinal stabilization theorem.** Whenever W contains phi_*, its image ideal is 2xi O, and H^1_W=D_xi. Transport between two such labels is the identity on that amplitude cokernel. Every W lies in W+C phi_*, proving cofinality. The labelled origins remain distinct in the reconstructed diagram.

Dilation sends W to {phi(a dot):phi in W}; Fourier sends W to hat W. These are automorphisms of the same join-semilattice. Their amplitude intertwiners are the actual Mellin/Poisson identities, not new scalar supports.

## 6. Surjective maps from the actual topological quotient to every finite jet family

Define, using the topology in section 3,

\[
Q_\Theta=\mathscr T/\overline{\Theta V}^{\,\mathscr T}.
\]

For h in C_c^infinity(R_+), multiplicative convolution h*phi preserves V and satisfies Theta(h*phi)=h*Theta(phi), by absolute convergence. It acts continuously on T and its quotient; Mellin turns the action into multiplication by M h.

For a finite set Omega of actual zeros of xi, with multiplicities m_rho, define

\[
\boxed{
J_\Omega:Q_\Theta\to\bigoplus_{\rho\in\Omega}\mathbb C[z_\rho]/(z_\rho^{m_\rho}),
\quad
[F]\mapsto\left(\sum_{j<m_\rho}\frac{(\mathcal MF)^{(j)}(\rho)}{j!}z_\rho^j\right)_\rho.
}
\]

Continuity of Mellin jets and the factor 2xi prove that it kills the closed image.

**Theorem.** J_Omega is surjective; every finite set of jets has a representative in C_c^infinity(R_+).

**Proof.** Choose a nonnegative smooth h supported in (-delta,delta), of integral one, with exp(M delta)-1<1/2 for M=max |rho|. Then H(s)=integral h(y)exp(sy)dy satisfies |H(rho)-1|<1/2. For prescribed jets b_rho, the Chinese remainder theorem supplies a polynomial P of degree less than sum m_rho such that P(s)H(s) equals b_rho modulo (s-rho)^m_rho at every point. Use the Taylor inverse of H at each point. Set F(t)=[P(-d/dy)h(y)] at y=log t. Integration by parts gives M F=P H, with every 1/j! in the displayed Taylor map retained.

This proves finite-jet surjectivity. It does not assert unrestricted infinite-jet surjectivity or silently identify different functional-analytic cokernels.

## 7. The previous lattice calculation now has an actual arithmetic input

At an actual zero rho, set R_rho=O_{C,rho}, z_rho=s-rho and

\[
u_\rho(z_\rho)=2\xi(\rho+z_\rho)/z_\rho^{m_\rho},\quad u_\rho(0)\ne0.
\]

The inclusion is

\[
L_Q=(2\xi)R_\rho\hookrightarrow L_P=R_\rho.
\]

Its quotient is (D_xi)_rho, of length m_rho. Its comparison with the coordinate block is the square with horizontal maps times 2xi and times z_rho^m, right vertical identity, and left vertical multiplication by u_rho. The unit is an explicit isomorphism, not discarded.

With omega_rho=R_rho ds,

\[
\operatorname{Ext}^1_{R_\rho}((\mathcal D_\xi)_\rho,\omega_\rho)
\cong(2\xi)^{-1}\omega_\rho/\omega_\rho.
\]

The perfect pairing is ([f],[eta]) -> Res_rho(f eta). Bases z^i and z^{-j-1} dz give delta_ij. All higher jets are retained. The length counts the actual multiplicity; it is not renamed as a horizontal displacement from the critical line.

## 8. Dilation and the genuine arithmetic trace pairing

For a>0, lambda_a F(t)=F(at) preserves the source image and

\[
\mathcal M\lambda_aF(s)=a^{-s}\mathcal MF(s).
\]

On a rho-jet block it acts by multiplication by

\[
a^{-\rho}\sum_{j<m_\rho}\frac{(-\log a)^j}{j!}z_\rho^j.
\]

The generator for a=exp(t) is multiplication by -s.

Define iota(s)=1-bar s and f^dagger(s)=overline{f(1-bar s)}. Since xi^dagger=xi, this acts on the quotient. Its local coefficient map from the iota(rho)-block to the rho-block is

\[
\sum_j a_jz^j\longmapsto\sum_j(-1)^j\bar a_jz^j.
\]

For finite iota-stable Omega put A_Omega=direct sum R_rho/(2xi). The actual multiplication trace is

\[
\operatorname{tr}_\Omega(f)=\sum_\rho m_\rho f(\rho)
=\sum_\rho\operatorname{Res}_{s=\rho}\left(f(s)\frac{\xi'(s)}{\xi(s)}ds\right).
\]

Define Q_Omega(f,g)=tr_Omega(f^dagger g). Its radical is exactly the nilradical. Reduction retains multiplicities as the weights m_rho; the Ext pairing above retains the discarded Taylor directions. These two explicit pairings have different domains and are connected by the reduction map.

The exact identity is

\[
\boxed{\mathcal Q_\Omega(a^{-s}f,a^{-s}g)=a^{-1}\mathcal Q_\Omega(f,g).}
\]

Proof: (a^{-s})^dagger=a^{-(1-s)}, and their product is a^{-1}.

A fixed point rho=1-bar rho has reduced pairing m_rho bar x y. A two-point orbit has matrix

\[
m_\rho\begin{pmatrix}0&1\\1&0\end{pmatrix}.
\]

Thus the functional equation produces the weight-one duality identity on the actual divisor. Positivity is not assumed in deriving it.

For f,g in C_c^infinity(R_+), let f^sharp(t)=t^{-1}overline{f(t^{-1})}, and k=f^sharp*g with multiplicative convolution. Then

\[
\mathcal M(f^\sharp*g)=(\mathcal Mf)^\dagger\mathcal Mg.
\]

The finite trace pairing through J_Omega is precisely the corresponding finite part of the Weil spectral sum. Arbitrarily rapid vertical Mellin decay and the standard O(T log T) zero count give absolute convergence on exhaustion. The imported explicit formula, with its full terms retained, is

\[
\begin{aligned}
\sum_\rho m_\rho\mathcal Mk(\rho)
={}&\mathcal Mk(0)+\mathcal Mk(1)
-\sum_p\log p\sum_{n\ge1}(k(p^n)+p^{-n}k(p^{-n}))\\
&-(\log4\pi+\gamma)k(1)
-\int_1^\infty\frac{k(x)+x^{-1}k(x^{-1})-2x^{-1}k(1)}{x-x^{-1}}dx.
\end{aligned}
\]

The quadratic-input involution contains conjugation; the linear reflected term inside the explicit formula does not.

## 9. All primitive Dirichlet channels and the abelian Dedekind product

For a nonprincipal primitive character chi of conductor q>1 and parity chi(-1)=(-1)^epsilon, define

\[
\Phi_{\chi,\psi}(x_f,x_\infty)=\mathbf1_{\widehat{\mathbb Z}}(x_f)\chi(x_f\bmod q)\psi(x_\infty),
\]

with psi Schwartz of the indicated parity. Both adelic endpoint maps vanish: chi(0)=0 and the finite average of chi is zero. The trace is Theta_{chi,psi}(t)=sum_{n in Z}chi(n)psi(nt). Projection onto the character uses Haar measure of total mass one on hat Z^times and the factor bar chi; its conductor is retained.

For psi_chi(x)=x^epsilon exp(-pi x^2/q), direct Mellin integration gives

\[
\boxed{
\mathcal M\Theta_{\chi,\psi_\chi}(s)
=\Lambda_\chi(s)
=(q/\pi)^{(s+\varepsilon)/2}\Gamma((s+\varepsilon)/2)L(s,\chi).
}
\]

The two signs of the integer sum cancel the 1/2 of the Gaussian integral. For arbitrary parity-matching psi the multiplier is 2L(s,chi)M_+psi. Taylor continuation and reciprocal Gamma show that its quotient by Lambda_chi is entire. The chosen Gaussian makes the quotient one. Hence the full analytic image ideal is Lambda_chi O. All support-diagram, finite-jet, lattice, and residue maps above apply to these actual channels. The local Euler factor at a conductor prime is 1, by chi(p)=0; no ramified factor is silently omitted.

For a finite abelian extension K/Q use the associated primitive characters, including the principal conductor-one character. Put

\[
C_K=\prod_\chi q_\chi^{\varepsilon_\chi/2},\qquad
\Lambda_K(s)=|D_K|^{s/2}\Gamma_{\mathbb R}(s)^{r_1}\Gamma_{\mathbb C}(s)^{r_2}\zeta_K(s),
\]

where Gamma_R(s)=pi^{-s/2}Gamma(s/2) and Gamma_C(s)=2(2pi)^{-s}Gamma(s). The conductor-discriminant relation and Gamma_R(s)Gamma_R(s+1)=Gamma_C(s) give product_chi Lambda_chi=C_K Lambda_K.

Using phi_* in the principal channel and multiplicatively convolving all the theta traces gives

\[
\boxed{(2\xi(s))\prod_{\chi\ne1}\Lambda_\chi(s)=C_Ks(s-1)\Lambda_K(s).}
\]

For Q(i), C_K=2. This covers every primitive rational finite-order character and every finite abelian extension of Q; an arbitrary nonabelian extension is not asserted by replacing notation.

## 10. Relation to the purity calculation and source scope

The previous local-lattice/Ext machinery now has the actual arithmetic multiplication map as an input. The quotient-to-jet map is constructed and surjective for every finite family. The duality relation is calculated on those same arithmetic fibres. This goes beyond a family whose logarithmic derivative was chosen to reproduce zeta.

The full weight/positivity bound remains to be obtained for this arithmetic object. The Chen–Moriwaki one-place casting estimate does not itself identify its filtration with the spectral real-part filtration above. No such identification has been inserted as an assumption disguised as a definition.

Sources read: the preceding authored sheaf and Rees notes; the mounted original globalization; repository chapter 14 (fixed-support diagrams), chapter 15 (existing divisor/jet construction), chapter 17 (existing packet trace); the Connes sidebar TeX lines 1–85 (actual theta multiplier and topology qualification); supplied arXiv:2602.15941v1 `Jacobian.tex`, selected sections on arithmetic sheaves, framed divisors, and trace geometry. The Jacobian TeX was extracted directly from the supplied archive. No OCR or PDF extraction was used for these readings. Abstract/metadata checks for arXiv:math/0703392 and math/0311468 do not constitute a full reading of their TeX.

The explicit formula is the source formula in Connes–Consani–Moscovici, equations (3.1)–(3.4), with all terms displayed above. Finite-order factorization and conductor-discriminant identities are the source inputs in Cogdell. The new proofs here do not count those source theorems as novel results.

This is a draft calculation, not a merged accepted claim. The fuller conversation package includes editable LaTeX, all proofs, exact tests, and separately labelled high-precision theta diagnostics. Third-party source texts and private transcripts are not included in this PR.


\clearpage

# Original quotient propagation before arithmetic realization

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/split-support-rees-trace/ORIGINAL_QUOTIENT_PROPAGATION.md). Module: `workbenches/split-support-rees-trace/ORIGINAL_QUOTIENT_PROPAGATION.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Research continuation, 11 September 2026. Additive draft contribution; existing notes and accepted claims are unchanged.

This note uses the original globalization congruences, not an ordinary quotient with a support label added afterward. It gives the universal quotient in the original semimodule category, the actual theta relation at every label, and the analytic realization and operator maps on that quotient. The source semimodule equivalence and theta multiplier are existing results, not new novelty claims.

## 1. Original congruences and their factor map

For a commutative ring R retain S=G(R)=R disjoint-union {tau}, with supported e=0_R and external additive identity tau. Supported elements use the ring operations; r+tau=r and r tau=tau.

For an ideal I define

\[
x\sim_I^{\mathrm{sp}}y
\iff (x=y=\tau)\ \text{or}\ (x,y\in R\text{ and }x-y\in I).
\]

The original quotient and its arithmetic observation are

\[
G(R)\xrightarrow{q_I^{\mathrm{sp}}}G(R/I)
\xrightarrow{p_{R/I}}R/I.
\]

The first map keeps tau separate from the supported zero residue. The second identifies them. These are the rho_n and rho'_n constructions of the original integer globalization note. For a ring map h carrying I into I', the induced G(h), G(bar h) and bar h commute with both arrows. Changing coefficient rings by these maps is not iteration of scalar zero-adjunction.

If R/I is finite, the source arithmetic norm is |R/I|, equivalently the cardinality of the supported fibre inside G(R/I), not |G(R/I)|. This retains the original Dedekind counting rule. We allow the zero ring here: G(0) is the two-element Boolean semiring.

## 2. The original-form quotient theorem

Chapter 14 presents an S-semimodule as M=disjoint-union_l M_l over the join-semilattice eM. Each fibre is an R-module; transport from l to l' is addition of the internal zero at l'. Write epsilon_N(y)=ey.

Let f=(phi,f_l):M->N be an S-linear map, with support map phi:L->K. Define

\[
B_k(f)=\sum_{\phi(l)\le k}
\rho^N_{\phi(l),k}(f_l(M_l))\subset N_k.
\]

All sums are finite sums of elements. The transports send B_k into B_k'. Define directly in the original operations

\[
x\approx_f y
\iff ex=ey=k\quad\text{and}\quad x+(-1_R)y\in B_k(f).
\]

**Theorem.** This is a semimodule congruence and

\[
\boxed{\mathsf Q_{\mathrm{sp}}(f)
=\bigsqcup_{k\in K}N_k/B_k(f)
=\operatorname{coeq}_{S\text{-SMod}}(f,\epsilon_Nf).}
\]

The quotient map is (k,y)->(k,[y]). Its support map is the identity of K, and

\[
e(k,[y])=(k,[0]),\qquad\tau(k,[y])=(0_K,[0]).
\]

**Proof.** The relation in each fibre is a module-quotient relation. Adding an element in N_m transports its difference to B_{k join m}; scalar multiplication preserves it, and tau sends both sides to the least-label zero. Thus it is a congruence. It equalizes f and epsilon_N f. Conversely, an S-linear h equalizing these maps kills each f_l(M_l) to its target fibre zero. Naturality kills every transported summand defining B_k. Therefore h factors uniquely through the displayed quotient. Its fibre zeros still recover exactly K. This proves the universal property without choosing representatives.

A commuting square (a,b) from f to f' induces

\[
\overline b(k,[y])=(\psi(k),[b_k(y)]),
\]

where psi is the support map of b. Naturality proves b_k B_k(f) is contained in B_psi(k)(f'). Thus identity and composition laws hold.

For the ideal inclusion I^tau -> G(R), this is exactly G(R/I), the original support-preserving quotient. The ordinary cokernel coequalizes f with the constant global-zero map instead; there is a canonical further quotient from Q_sp(f) to it. For multiplication by two on G(Z), these are respectively G(Z/2) and Z/2, related by p. This identifies the additional relation rather than treating the two quotients as interchangeable.

## 3. Arithmetic reflection and its information loss

The ordinary R-module reflection of N is

\[
\operatorname{Lin}(N)=\varinjlim_{k\in K}N_k,
\qquad (k,y)\mapsto[y].
\]

Any S-linear map to an R-module via S->R kills every support idempotent and has compatible fibre maps, proving this universal property. Since a join-semilattice is filtered,

\[
\operatorname{Lin}(\mathsf Q_{\mathrm{sp}}(f))
\cong\operatorname{coker}(\operatorname{Lin}(f)).
\]

At a fixed label the lost vector submodule is exactly

\[
\ker(N_k\to\operatorname{Lin}(N))
=\bigcup_{k'\ge k}\ker\rho_{k,k'}.
\]

Thus recording the label beside the already-reflected amplitude need not reconstruct N. The transport kernels have to be retained.

For a fixed-support cochain diagram, the original reconstructed equation \(d^{n+1}d^n\) is the fibrewise zero arrow, not the constant least-label map. Its cycles and cohomology are

\[
Z^n_{\mathrm{sp}}=\operatorname{Eq}(d^n,\epsilon d^n)
=\bigsqcup_l\ker d_l^n,
\]

\[
H^n_{\mathrm{sp}}=\bigsqcup_l\ker d_l^n/\operatorname{im}d_l^{n-1},
\]

using the same coequalizer theorem. Acyclic amplitude fibres leave the skeleton, which arithmetic reflection then maps to the ordinary zero module.

## 4. Apply the theorem to the actual theta relations

Retain V, the even Schwartz functions with phi(0)=hat phi(0)=0, Fourier kernel exp(-2 pi i x xi), and the strong-Schwartz space B on R_+ from ACTUAL_ADELIC_COMPARISON.md. Use

\[
\Theta\phi(x)=2\sum_{n\ge1}\phi(nx),\qquad
\mathcal MF(s)=\int_0^\infty F(x)x^s\,dx/x.
\]

The finite sums are original supported sums: a supported zero result is e, not tau. Their compact-local smooth limit is supported; Poisson gives the stronger endpoint bounds. This does not assert that each finite partial sum lies in B.

Use the same source label system as the existing arithmetic appendix: finite-dimensional W subset V, with join W+W'. At W nonzero the source fibre is W and target fibre is B; at the least label both are zero. The actual map is

\[
\widetilde\Theta(W,\phi)=(W,\Theta\phi).
\]

The quotient before projection is

\[
\boxed{
\mathfrak Q_\Theta
=\{\tau\}\sqcup\bigsqcup_{W\ne0}\{W\}\times(B/\Theta W).}
\]

Its exact relation and addition are

\[
(W,F)\sim(W',F')\iff W=W'\text{ and }F-F'\in\Theta W,
\]

\[
(W,[F])+(U,[G])=(W+U,[F+G]).
\]

For W subset W', transport has kernel

\[
\boxed{\ker(B/\Theta W\to B/\Theta W')
=\Theta W'/\Theta W\cong W'/W.}
\]

The last isomorphism follows from injectivity of Theta: on Re s>1 its Mellin multiplier is 2 zeta(s), which is nonzero, and Mellin/Fourier uniqueness then gives phi=0.

In particular, if phi_* is not in W, the class [Theta phi_*]_W is nonzero, but its transport to W+C phi_* is the supported zero at that larger label. It never becomes tau. This computes an actual difference among the quotient fibres; it is not a uniform tensor decoration of B/Theta V.

Arithmetic reflection and Hausdorff realization have exact kernels

\[
0\to\Theta V/\Theta W\to B/\Theta W\to B/\Theta V\to0,
\]

\[
B/\Theta V\twoheadrightarrow B/\overline{\Theta V},
\qquad\ker=\overline{\Theta V}/\Theta V.
\]

## 5. Keep the mixed chart masks

Index by (W,I), where I subset {+,-}, the empty I occurs only at W=0, and nonempty I with W=0 records supported zero-input faces. Join is (W+U,I union J).

Use source fibre direct-sum_{i in I} W_i, with W_+=W and W_-=hat W, and target B for nonempty I. Transports insert supported zero coordinates. The original-form differential is

\[
d_{W,I}=\mathbf1_{+\in I}\Theta\phi_+
-\mathbf1_{-\in I}\Theta\widehat\phi_-.
\]

Its image is Theta W for every nonempty I. The degree-one quotient is B/Theta W at the same (W,I). For phi_-=hat phi_+, its value is the internal zero of the two-slot face. For both absent it is external absence. No mask is inferred from the resulting amplitude.

The plus-chart inclusion on complexes sends phi to (phi,0) and F to F. The coordinate change (phi,psi)->(phi-hat psi,psi) splits off hat W in degree zero, proving the identity on the displayed degree-one quotient. Its supported label map sends the plus face to the two-slot face.

## 6. The Mellin quotient, including its exact kernel

The existing source identity, with all constants retained, is

\[
\mathcal M\Theta\phi=2\xi H_\phi,
\quad
\xi(s)=\tfrac12s(s-1)\pi^{-s/2}\Gamma(s/2)\zeta(s),
\]

\[
H_\phi(s)=\frac{2\pi^{s/2}M_+\phi(s)}{s(s-1)\Gamma(s/2)}.
\]

The source proves H_phi entire and supplies the actual phi_*=(4 pi^2 x^4-6 pi x^2)exp(-pi x^2), with H_phi*=1.

For O=O_C and W nonzero, retain

\[
J_W=(H_\phi:\phi\in W),\qquad I_W=(2\xi)J_W.
\]

Set A_W=O tensor W, B_W=O tensor B, delta_W=1 tensor Theta, alpha_W(h tensor phi)=h H_phi, and beta_W(h tensor F)=h MF. Then

\[
\beta_W\delta_W=(\times2\xi)\alpha_W.
\]

The induced supported map is

\[
\boxed{(W,[b])\longmapsto(W,[\beta_Wb])
\quad\text{in}\quad\bigsqcup_{W\ne0}O/I_W,\qquad\tau\mapsto\tau.}
\]

Its internal kernel at W is exactly

\[
\boxed{\beta_W^{-1}(I_W)/\delta_W A_W
\cong\ker\beta_W/\delta_W(\ker\alpha_W).}
\]

To prove the equality, subtract a delta_W image with the required element of I_W to enter ker beta_W. Its intersection with delta_W A_W is delta_W ker alpha_W, because multiplication by 2xi is injective. Local surjectivity of beta_W follows by choosing F(e^y)=exp(-s_0 y)h(y), with h nonnegative nonzero smooth compactly supported, so MF(s_0)=integral h is nonzero. Thus the map is locally onto.

For W subset W', the target transport has kernel I_W'/I_W. When W contains phi_*, I_W=(2xi); these labels are cofinal. The analytic amplitude stabilizes there, while the original B/Theta W quotients still have the transport kernels in section 4.

All sheaf-level disjoint unions mean sheafification: labels are locally constant on labelled opens, fibre sections glue there, and the empty open has one section. A raw disjoint-union presheaf is not silently used as a sheaf on disconnected opens.

## 7. The original scalar quotient at the actual analytic stalks

At s_0, with R_s0=O_{C,s_0}, the original congruence is unchanged:

\[
\boxed{G(R_{s_0})/\sim^{\mathrm{sp}}_{(2\xi)}
\cong G(R_{s_0}/(2\xi)).}
\]

Its arithmetic observation is p to R_s0/(2xi). Where xi(s_0) is nonzero, that ring is zero but the supported quotient is G(0)=B. The support skeleton has not vanished just because the amplitude sheaf vanishes.

At an actual zero rho of multiplicity m, put z=s-rho and keep

\[
u_\rho(z)=2\xi(\rho+z)/z^m,\qquad u_\rho(0)\ne0.
\]

The presentation square has horizontal maps times 2xi and times z^m, left vertical times u_rho and right vertical identity. Therefore the resulting supported Taylor map sends tau to tau and each supported germ to its class in G(C[z]/z^m). The analytic unit is retained in the square, not silently discarded.

For a finite jet family Z, the existing finite-jet map induces

\[
\widetilde J_Z(W,[F])=(W,J_ZF),
\quad
J_ZF=\left(\sum_{j<m_\rho}(\mathcal MF)^{(j)}(\rho)z_\rho^j/j!\right)_\rho.
\]

Its internal kernel is ker J_Z / Theta W. Finite-jet surjectivity from compactly supported smooth representatives is the interpolation result in the existing arithmetic appendix. Continuity gives the stated further Hausdorff factorization.

Dilation includes its label map:

\[
(W,[F])\mapsto(R_aW,[R_aF]),\quad R_aF(x)=F(ax),
\]

\[
J_ZR_aF|_\rho=a^{-\rho}\sum_{k<m_\rho}(-\log a)^kz_\rho^k/k!\,J_ZF|_\rho.
\]

For D=-x partial_x, the corresponding map has label DW and jet operator multiplication by rho+z_rho. This follows from DTheta=ThetaD and M D=s M. No individual W-invariance is assumed. Fourier acts through W->hat W and F(x)->x^{-1}F(1/x).

The existing finite-jet quotient metric becomes the observation (W,[F])->(W,nu_R(J_ZF)); its zero fibre is the just-calculated internal kernel, not external absence. A trace or pairing is treated the same way, retaining its input label or pair of labels until the explicitly named scalar observation. No positivity bound is inferred from the existence of these quotient maps.

## 8. The original mixed coefficient multiplication

For the original quadratic double D_A=G(A)^2 and a ring map lambda:A->A', the coefficient map D(lambda)(a,b)=(G(lambda)a,G(lambda)b) preserves

\[
(a,b)\star(c,d)=(ac\oplus(-1_A)bd,\ ad\oplus bc).
\]

For residue reduction modulo I, its kernel pair retains each mask and reduces each supported coefficient modulo I, giving exactly D_{A/I}. The square with amplitude maps to A[t]/(t^2+1) commutes with t->t. The synchronization idempotent E=(1,e) maps to E', and D(lambda)(Ex)=E'D(lambda)(x).

These are coefficient-algebra morphisms. Theta and Mellin are the linear arrows specified above, not claimed to preserve this star product. At finite pointed sets, every semimodule quotient map acts coordinatewise and commutes with the original finite fibre sums.

## Checks and integration

Run `python checks/check_original_congruence.py` and the same command with `python -O`. The dependency-free checker independently generates the least finite congruence by closing the generator pairs under addition, scalar multiplication and equivalence, then compares it with the formula of section 2. Six cases execute 5,443 exact pair comparisons, plus the explicit distinction between G(Z/2) and Z/2. Both runs passed and produced identical output. This tests finite examples, not the infinite-dimensional analytic inputs or an RH estimate.

The larger attached continuation has the full proofs, sheaf formulation, all operator and metric maps, and a SymPy checker with 17,712 exact comparisons. The public check is a subset of those congruence cases; the counts must not be added as independent evidence.

Source basis: original globalization congruence theorem; Zeta chapter 14, blob 49318a578b96462384000afa16794cfd5fe492c1; current ACTUAL_ADELIC_COMPARISON.md, blob c23656c2a43e0041d6f7aeb0b80d6e12a6b468d9, read at head 8a5b82a7c234ca5e283035788545ce1a296f8283; and the attached predecessor's actual theta comparison TeX. Only original TeX and authored notes were used for these readings. No full source books or private conversations are copied here. Research direction and split-zero framework remain attributed to the repository owner; these derivations and finite checks were developed in the current ChatGPT session. Draft only; no merge or endpoint theorem is asserted.


\clearpage

# Arithmetic cohomology over the tau-base

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-base-cohomology/TAU_BASE_MODEL.md). Module: `workbenches/tau-base-cohomology/TAU_BASE_MODEL.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Publication edition of the preceding authored tau-base note. This file retains the model, its maps and proofs; `FINITE_OPERATOR_COMPARISON.md` continues its arithmetic realization. These are research derivations, not Lean-verified analytic theorems.

## Scope

The geometric base is the one-point absolute pointed base with absorber tau. The main calculation is the right adjoint to global cohomology on a specified finite-chart realization. A projective resolution computes arithmetic cohomology; a dual injective complex computes its right adjoint. The arithmetic theta map, finite Mellin jets, nilpotent actions, and original e/tau distinction remain attached.

The category is specified below. No assertion is made that this chart model is an arithmetic scheme, that it supplies all prime correspondences, that its right-adjoint object is an involutive Verdier duality on every sheaf, or that it proves a weight estimate. The dual in the adjunction is algebraic. A continuous-dual identification would require its own map.

## 1. The absolute base and the infinite arithmetic quotient

Let

$$\mathbf F_{1,\tau}=\{\tau,1\}$$

be the pointed multiplicative monoid with identity 1 and absorber tau. Its blueprint zero relation identifies the empty sum with tau; no additive equation $1+1=1$ is imposed. Its spectrum $\mathfrak b_\tau$ has the single prime $\{\tau\}$.

For a nonzero commutative ring $R$, retain

$$G(R)=\{\tau\}\sqcup\{r^\bullet:r\in R\},\qquad e_R=0_R^\bullet.$$

Let $B_R$ be the blueprint with this multiplicative carrier and all its original finite additive relations, including $[\tau]=0$. There is the actual blueprint morphism

$$\jmath_R:\mathbf F_{1,\tau}\longrightarrow B_R,
\qquad \tau\mapsto\tau,\quad1\mapsto1_R^\bullet.$$

On spectra it gives

$$a_R:\operatorname{Spec}B_R\longrightarrow\mathfrak b_\tau.$$

Every prime has inverse image $\{\tau\}$. The arithmetic quotient stays attached:

$$p_R:G(R)\longrightarrow R,\quad p_R(\tau)=0_R,
\quad p_R(r^\bullet)=r.$$

For a domain, the original primes and arithmetic inclusion are

$$P_\tau=\{\tau\},\quad P_0=\{\tau,e_R\},\quad
i_R:\operatorname{Spec}R\hookrightarrow\operatorname{Spec}_{\rm sr}G(R),
\quad\mathfrak p\mapsto\mathfrak p\sqcup\{\tau\}.$$

The image is $V(e_R)=\overline{\{P_0\}}$. The source's infinite quotient at $R=\mathbb Z$ is therefore retained without assigning an additional finite ideal norm.

The Boolean observation is another specified map:

$$\chi_R:G(R)\to\mathbb B,\qquad\chi_R(\tau)=0,
\quad\chi_R(r^\bullet)=1.$$

It gives

$$\operatorname{Spec}\mathbb B\xrightarrow{\operatorname{Spec}\chi_R}
\operatorname{Spec}_{\rm sr}G(R)\xrightarrow{a_R}\mathfrak b_\tau.$$

The first arrow lands at $P_\tau$. The source localization is

$$G(R)[e_R^{-1}]\cong\mathbb B.$$

Indeed $e_R^2=e_R$ and invertibility give $e_R=1$, and $e_Rr^\bullet=e_R$ identifies all supported scalars with 1. External absence remains distinct. The structural morphism $a_R$, with $p_R$ retained, is used for the base change; the localization is its named support observation.

The coefficient realization preserves the infinite arithmetic quotient through

$$\begin{array}{ccc}
G(\mathbb Z)&\xrightarrow{G(j)}&G(\mathbb C)\\
p_{\mathbb Z}\downarrow&&\downarrow p_{\mathbb C}\\
\mathbb Z&\xrightarrow{j}&\mathbb C,
\end{array}\qquad j:\mathbb Z\hookrightarrow\mathbb C.$$

Both supported zero and external absence have their own images in this square.

## 2. The actual characteristic-zero chart

Set $E=\mathbb C$. Let $P$ be the four-point poset

$$+<\eta<\sigma,\qquad -<\eta<\sigma,$$

with $+$ and $-$ incomparable and with the upper-set topology. Its proper nonempty opens are

$$\{\sigma\},\quad\{\eta,\sigma\},\quad
\{+,\eta,\sigma\},\quad\{-,\eta,\sigma\}.$$

The structural sheaf has $G(E)$ on every open containing an arithmetic chart point and $\mathbb B$ on $\{\sigma\}$. Restriction to sigma is $\chi_E$, and other nontrivial restrictions are identities. Compatibility at sigma forces an entire local family to be absent or supported. In the supported case ordinary amplitudes glue. This proves the sheaf assertion.

Together with $\jmath_E$, this defines a space with a sheaf of blueprints over $\mathfrak b_\tau$. The structural map to $\operatorname{Spec}_{\rm sr}G(E)$ sends $+,-,\eta$ to $P_0$ and sigma to $P_\tau$. Compose with the map induced by $G(j)$ to $\operatorname{Spec}_{\rm sr}G(\mathbb Z)$. On its arithmetic stalks the map is $G(\mathbb Q)\to G(E)$, and at sigma it is $\mathbb B\to\mathbb B$.

This particular chart has generic arithmetic image. Its finite-prime geometry is not being claimed to cover the closed prime fibres. Prime information in this realization enters through the theta map and its Euler/explicit formula.

Retain the exact coefficient spaces and transforms

$$V=\{\phi\in\mathcal S(\mathbb R):\phi\text{ even},\ \phi(0)=0,
\ \widehat\phi(0)=0\},\qquad
\widehat\phi(\xi)=\int_{\mathbb R}\phi(x)e^{-2\pi i x\xi}\,dx,$$

$$\mathscr B=\{F\in C^\infty(\mathbb R_{>0}):
\sup_{x>0}x^b|(-x\partial_x)^kF(x)|<\infty
\text{ for all }b\in\mathbb Z,\ k\ge0\},$$

$$\Theta\phi(x)=\sum_{n\in\mathbb Z\setminus\{0\}}\phi(nx),
\qquad JF(x)=x^{-1}F(1/x).$$

Poisson gives $J\Theta\psi=\Theta\widehat\psi$. Define the coefficient diagram

$$\mathcal T_+=V,\quad\mathcal T_-=V,\quad
\mathcal T_\eta=\mathscr B,\quad\mathcal T_\sigma=0,
\quad r_+=\Theta,\quad r_-=J\Theta=\Theta\mathcal F.$$

### The full original support diagram

Let $L=\mathcal P(\{+,-\})$. For nonempty $A\in L$, retain a copy of $V$ at a source leg exactly when that leg lies in $A$. At eta retain $\mathscr B$, and at sigma retain the ordinary zero vector space. Set $\mathcal T_\varnothing=0$. For $A\subseteq A'$, the transports are the coordinate inclusions at the source legs and the identity at eta.

The reconstructed sheaf is

$$\widetilde{\mathcal T}=\{\tau\}\sqcup
\bigsqcup_{A\ne\varnothing}\{A\}\times\mathcal T_A.$$

At sigma its stalk is the complete semilattice $L$, with Boolean scalar action. Restrictions there are semilinear along $\chi_E$:

$$e_E(A,v)=(A,0)\longmapsto A,\qquad
\tau\longmapsto\varnothing.$$

In degree zero the reconstructed module is the original two-leg carrier $(V^\tau)^2$. A missing leg and a supported zero in that leg have different masks. The zero coefficient space for a missing leg is always accompanied by this mask; it does not add a support to that leg.

## 3. Compute global cohomology

Use the declared linear-fibre category

$$\mathcal A=\operatorname{Fun}(P,\operatorname{Vect}_E).$$

Its passage to the original supported sheaf is the reconstruction just given, with internal quotients. It is a realization category, not an asserted new etale-sheaf category.

For $x\in P$, define the projective diagram

$$P_x(y)=\begin{cases}E&x\le y,\\0&\text{otherwise},\end{cases}
\qquad\operatorname{Hom}_{\mathcal A}(P_x,F)=F_x.$$

The constant diagram $\mathbf E$ has the exact projective resolution

$$\boxed{0\to P_\eta\xrightarrow{v\mapsto(v,-v)}P_+\oplus P_-
\xrightarrow{(u,v)\mapsto u+v}\mathbf E\to0.}$$

At $+$ and $-$ the last map is the identity. At eta and sigma it is addition with the specified anti-diagonal kernel. The formulas commute with every arrow.

Therefore

$$\boxed{\mathsf A_\tau(F):=R\Gamma(P,F)
\simeq[F_+\oplus F_-\xrightarrow{r_+-r_-}F_\eta],}$$

in degrees zero and one.

There is an actual comparison to restriction at sigma:

$$\operatorname{res}_\sigma:\mathsf A_\tau(F)\to F_\sigma[0].$$

Representatives in degree zero are $(x,y)\mapsto r_{+\sigma}x$ and $(x,y)\mapsto r_{-\sigma}y$. Their difference is $r_{\eta\sigma}(r_+x-r_-y)$. Hence they are chain homotopic with homotopy $r_{\eta\sigma}$, and define the same derived morphism.

For the actual theta sheaf,

$$\mathsf A_\tau(\mathcal T)
=[V\oplus V\xrightarrow{\Theta(\phi-\widehat\psi)}\mathscr B],$$

$$H^0\mathsf A_\tau(\mathcal T)\cong V,
\quad\psi\mapsto(\widehat\psi,\psi),\qquad
H^1\mathsf A_\tau(\mathcal T)=Q:=\mathscr B/\Theta V.$$

Injectivity of theta follows by its Mellin transform on $\Re s>1$, nonvanishing of the Euler product there, and Mellin uniqueness. It uses no assertion about zeros in the critical strip.

The original supported differential is

$$\widetilde d(\phi,\psi)=(A,\Theta p(\phi)-J\Theta p(\psi)),$$

with $A$ the set of present legs; an absent pair maps to tau. Its cohomology uses

$$Z^i_{\rm sp}=\operatorname{Eq}(d,\varepsilon d),\qquad
H^i_{\rm sp}=\operatorname{coeq}(b,\varepsilon b),\qquad
\varepsilon(x)=ex.$$

For every nonempty $A$, the degree-one fibre is $Q$. A single-leg degree-zero fibre is zero, and the joint degree-zero fibre is $V$. Thus

$$\boxed{\widetilde H^1_\tau=\{\tau\}\sqcup
\bigsqcup_{A\ne\varnothing}\{A\}\times Q.}$$

Restriction to sigma sends its classes to the supported zero of their label in the sigma skeleton. Their global cohomology classes remain present in the displayed object.

## 4. Compute the right adjoint on this base

For $x\in P$ and a vector space $W$, define

$$I_x(W)(y)=\begin{cases}W&y\le x,\\0&\text{otherwise},\end{cases}
\qquad\operatorname{Hom}_{\mathcal A}(F,I_x(W))
=\operatorname{Hom}_E(F_x,W).$$

Evaluation is exact and every vector space is injective over $E$, so $I_x(W)$ is injective. Define

$$\boxed{K_\tau(W)=
[I_\eta(W)\xrightarrow{(+\mathrm{res},-\mathrm{res})}I_+(W)\oplus I_-(W)]}$$

in degrees $-1,0$.

For a sheaf $F$ the actual adjunction is

$$\boxed{R\operatorname{Hom}_{\mathcal A}(F,K_\tau(W))
\cong R\operatorname{Hom}_E(\mathsf A_\tau(F),W).}$$

Both sides are the complex

$$\operatorname{Hom}(F_\eta,W)\longrightarrow
\operatorname{Hom}(F_+,W)\oplus\operatorname{Hom}(F_-,W),
\qquad\ell\mapsto(\ell r_+,-\ell r_-).$$

For a bounded complex $W$, totalize with its specified original differential. On the four stalks,

$$K_\tau(W)_+=[W\xrightarrow{1}W],\quad
K_\tau(W)_-=[W\xrightarrow{-1}W],\quad
K_\tau(W)_\eta=W[1],\quad K_\tau(W)_\sigma=0.$$

If $S_\eta W$ denotes the diagram concentrated at eta, this proves

$$\boxed{K_\tau(W)\simeq S_\eta W[1].}$$

The shift places $W$ in degree $-1$ and is derived from the resolution. This is the right adjoint to algebraic $R\Gamma$ on the declared category. It has not been declared to be extraordinary pullback for an unconstructed proper arithmetic morphism or an involutive local Verdier duality.

Apply the calculation fibrewise to the retained support diagrams. Every zero coefficient stalk reconstructs as its labelled zero, including at sigma. The dual transports are

$$\rho_{AB}^{\vee}:\operatorname{Hom}(H_B,W)\to
\operatorname{Hom}(H_A,W),\qquad\ell\mapsto\ell\rho_{AB}.$$

Their index category is $L^{\rm op}$. The reconstruction interface in PR #6 permits a nonzero bottom fibre when that opposite diagram has one; it must not be forced to zero without an additional quotient.

## 5. The characteristic-zero arithmetic action

For $a>0$, retain

$$U_aF(x)=F(x/a),\qquad
\mathcal MF(s)=\int_0^\infty F(x)x^s\frac{dx}{x}.$$

The exact transforms are

$$\mathcal MU_aF(s)=a^s\mathcal MF(s),\qquad
\widehat{U_a\phi}=aU_{1/a}\widehat\phi.$$

Consequently the chain action is

$$\boxed{(\phi,\psi)\mapsto(U_a\phi,aU_{1/a}\psi),
\qquad F\mapsto U_aF.}$$

Direct calculation gives $U_aJ=aJU_{1/a}$ and

$$d(U_a\phi,aU_{1/a}\psi)=U_ad(\phi,\psi).$$

It fixes every original support mask and the support skeleton at sigma. The base remains the same point while its pushforward retains the arithmetic action.

The moment map supplies two actual coefficient lines,

$$\mathcal L_0:E\text{ with action }1,\qquad
\mathcal L_1:E\text{ with action }a,$$

$$m(\phi)=(\phi(0),\int_{\mathbb R}\phi(x)\,dx),
\qquad mU_a=\operatorname{diag}(1,a)m.$$

Using $K_\tau(\mathcal L_1)$ gives the dual action

$$\boxed{(U_a\ell)(v)=a\,\ell(U_a^{-1}v).}$$

The factor $a$ is retained from the second moment representation, not deduced from the cardinality of a base point.

## 6. The finite arithmetic map into the computed dual

Put $g=2\xi$ and let $Z$ be a finite reflection-stable set of actual zeros with multiplicities $m_\rho$. Define

$$A_Z=\bigoplus_{\rho\in Z}\mathcal O_\rho/(g),\qquad
(J_ZF)_\rho=\sum_{j<m_\rho}
\frac{(\mathcal MF)^{(j)}(\rho)}{j!}z_\rho^j.$$

The source identity $\mathcal M\Theta\phi=gH_\phi$, with $H_\phi$ entire, proves that

$$\mathcal T\longrightarrow S_\eta A_Z$$

is a sheaf morphism: use $J_Z$ at eta and zero at the other points. It induces the specified degree-one map $Q\to A_Z$. The finite jet map is onto by independence of $e^{\rho y}y^j/j!$ on every nonempty interval and a compactly supported smooth interpolation construction. The continuation computes its exact operator kernel and a spectral section.

The scaling action is

$$U_a|_\rho=a^\rho\sum_{j<m_\rho}\frac{(\log a)^j}{j!}N_\rho^j,
\qquad N_\rho z^j=z^{j+1}.$$

Retain the reflected germ map

$$f^\dagger(s)=\overline{f(1-\bar s)},\qquad
\sum c_jz_{\iota\rho}^j\mapsto\sum(-1)^j\bar c_jz_\rho^j.$$

The actual perfect finite residue pairing is

$$R_Z(f,h)=\sum_{\rho\in Z}\operatorname{Res}_{\rho}
\frac{f^\dagger(s)h(s)}{g(s)}\,ds.$$

Locally write $g=u(z)z^{m_\rho}$ with its actual unit. The residue pairs $z^i$ with $u(z)z^{m_\rho-1-i}$, proving nondegeneracy with the units retained. Its raw skew-Hermitian orientation is not changed by inserting a phase. Its scaling is

$$R_Z(U_af,U_ah)=aR_Z(f,h).$$

Precomposition with the degree-one jet map gives the actual injective map

$$\boxed{\overline{A_Z}\longrightarrow
H^{-1}R\operatorname{Hom}_{\mathcal A}
(\mathcal T,K_\tau(\mathcal L_1)),}$$

$$\bar f\longmapsto\left([F]\longmapsto
\sum_{\rho\in Z}\operatorname{Res}_{\rho}
\frac{f^\dagger(s)\mathcal MF(s)}{g(s)}\,ds\right).$$

The target is $\operatorname{Hom}_E(Q,\mathcal L_1)$ by the computed adjunction. Well-definedness follows because a theta relation adds the holomorphic residue expression $f^\dagger H_\phi$. Surjectivity of the finite jet map and perfectness prove injectivity. The displayed dual action and scaling identity prove equivariance.

The arithmetic trace contraction uses the specified Jacobian map

$$J_g:A_Z\to A_Z,\qquad[h]\mapsto[g'h],$$

$$\boxed{R_Z(f,J_gh)=
\sum_\rho m_\rho\overline{f(1-\bar\rho)}h(\rho)
=\operatorname{Tr}(M_{f^\dagger h}|A_Z).}$$

At a zero of order $m$, $g'\equiv m u(z)z^{m-1}\pmod{z^m}$. The radical of the trace contraction consists of the jets with zero residue value. The original internal quotient sends them to their supported zero; the residue pairing before contraction retains all jet orders.

All these maps lift at each support label. A vanishing functional is the supported zero functional of its label. The external scalar tau retains its own image. Changes of source labels commute with the maps, and the dual arrows are the stated precomposition maps.

## 7. Tensor powers over the same base

Take products of the declared chart $P$ over the underlying point of $\mathfrak b_\tau$ and external products of coefficient sheaves. The coefficient tensors are over $E$. The topological product with these coefficients is the declared model; no identification with the schematic square of the full arithmetic space is assumed.

The external tensor product of the projective resolution has differential

$$d(x_1\otimes\cdots\otimes x_r)=
\sum_{j=1}^r(-1)^{\sum_{k<j}|x_k|}
 x_1\otimes\cdots\otimes dx_j\otimes\cdots\otimes x_r.$$

Because tensoring over $E$ is exact, this gives the explicit Kunneth map and

$$\boxed{H^r\mathsf A_{\tau,r}(\mathcal T^{\boxtimes r})
\cong Q^{\otimes_E r}.}$$

The numerator is $\mathscr B^{\otimes r}$. Its top boundaries are the sum of subspaces with $\Theta V$ in at least one factor, so the quotient is exactly the displayed one. Other support fibres and their transports remain in the full diagram; this equation is its specified joint-support evaluation.

A tensor relation is quotiented internally at its support label. A tensor containing external absence has its specified absorbing basepoint. Coefficient balancing and support-index products remain the two actual operations, with their reconstruction maps retained.

Dualizing the tensor resolution gives

$$\boxed{K_{\tau,r}(W)\simeq S_{(\eta,\ldots,\eta)}W[r].}$$

The degree $-r$ is calculated by the tensor complex, with the same Koszul signs. The finite spectral quotient of the top cohomology has action

$$a^{\rho_1+\cdots+\rho_r}
\exp\left((\log a)\sum_jN_{\rho_j,j}\right).$$

For a repeated spectral exponent the exact modulus comparison is

$$\boxed{\log\frac{|a^{r\rho}|^2}{a^r}
=r(2\Re\rho-1)\log a\qquad(a>1).}$$

At this stage it is a statement about the finite spectral quotient. The continuation constructs its actual finite invariant section in the original cohomology. No bound on this quantity follows from the tensor identity alone.

## 8. Structural projection, internal null relations, and packet deletion

The structural map sends every geometric point to the base point. The derived pushforward retains coefficient relations and operators. Restriction to sigma is the separate derived morphism calculated in Section 3, and has the support skeleton as its supported target in this model.

For ordinary vector spaces $W,W'$ with single-active-fibre lifts, a $G(E)$-linear map

$$f:W^\tau\to(W')^\tau$$

that sends one supported vector to tau sends every supported vector to tau. Indeed $f(0_W^\bullet)=f(ev)=ef(v)=\tau$. For every supported $w$, $ef(w)=f(ew)=\tau$. In this specified target only tau has e-multiple equal to tau. This assertion is not made for a general semimodule with nonzero bottom group fibre.

For a reflection-stable finite set $Z=C\sqcup B$, the actual packet deletion is

$$A_Z\twoheadrightarrow A_C,\qquad\ker=A_B.$$

Its removed convolution trace is

$$\operatorname{Tr}(H_h|A_Z)-\operatorname{Tr}(H_h|A_C)
=\sum_{\rho\in B}m_\rho\mathcal Mh(\rho).$$

Finite Mellin interpolation makes this nonzero for some admissible compactly supported smooth $h$ whenever $B$ is nonempty. The cone of $A_Z[-1]\to A_C[-1]$ has $H^0=A_B$. That is the explicit cohomological contribution of this deletion.

An internal quotient by a subspace $N$ instead uses

$$q_N^{\rm sp}:W^\tau\to(W/N)^\tau,\qquad
n^\bullet\mapsto0_{W/N}^\bullet,\quad\tau\mapsto\tau.$$

This is the map used throughout the programme. A proved null relation becomes a supported zero while its quotient kernel remains recorded.

## 9. Output and remaining geometry

The calculated model supplies

$$\widetilde{\mathcal T}\text{ over }\mathfrak b_\tau
\xrightarrow{\mathsf A_\tau}\widetilde H^1_\tau
\xrightarrow{J_Z}A_Z^\tau,$$

with the right-adjoint object $K_\tau(\mathcal L_1)$, the cohomological residue map into that adjoint, its Jacobian trace contraction, and the tensor-power morphisms. It is a characteristic-zero scaling calculation.

The structural square retains $G(\mathbb Z)\to\mathbb Z$. The generic chart image is explicit. A global prime-sensitive geometric realization with its full Lefschetz theorem and the two-sided weight estimates is not established by the finite chart topology. The continuation calculates a further analytic comparison without treating that remaining geometric step as proved.

## Sources and validation scope

- Owner's `globalization_note.tex`: localizations, stalks, contracted monoid algebra and blueprint remark; the supplied structural formalization supplies the explicit `[tau]=0` presentation correction.
- Existing actual-theta comparison in the workbench: source test spaces, theta/Mellin maps, complete multiplier and finite jets. The earlier generated notes are retained research inputs, not a blanket independent audit.
- Selected supplied French Weil II TeX, sections 3.3 and 6.2.1-6.2.7: the comparison-image and duality architecture. Reading these windows is not verification of the whole source corpus. Historical transcription qualifications remain.
- O. Lorscheid, *The geometry of blueprints. Part I*, arXiv:1103.1745, for the declared blueprint framework, not for the new finite-chart calculations.
- PR #6 at `5f6ee6575550d8a20c6fc3990359cb4f67855f80` for the original reconstruction and internal-homology interfaces. This publication retains its generalized bottom-fibre treatment.

`check_tau_base.py` executes finite regressions for the projective resolution, adjoint complex, support differential, action compatibility, tensor signs and trace deletion. These checks are not analytic proof certificates or a verification of Deligne's theorem or RH. The preceding source's spectral statements were about finite quotients; `FINITE_OPERATOR_COMPARISON.md` now constructs their explicit sections and finite invariant subspaces.


\clearpage

# Exact finite operator quotients of the tau-base theta cohomology

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-base-cohomology/FINITE_OPERATOR_COMPARISON.md). Module: `workbenches/tau-base-cohomology/FINITE_OPERATOR_COMPARISON.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Owner-directed continuation, 12 September 2026. Mathematical derivation and research draft; no new analytic theorem below is claimed to have been checked by Lean.

## 0. Inputs, provenance, and the new result

This note continues `TAU_BASE_MODEL.md`, rather than moving the programme back to a finite-field variety. Its arithmetic coefficient object is the original split semiring

$$G(R)=\{\tau\}\sqcup\{r^\bullet:r\in R\},\qquad e=0_R^\bullet.$$

The geometric base remains the one-point absolute pointed base described there. The quotient

$$p_{\mathbb Z}:G(\mathbb Z)\longrightarrow\mathbb Z$$

and its square with $G(\mathbb C)\to\mathbb C$ remain part of the marked object. No ideal norm, Euler factor, scaling parameter, Gaussian, or completion factor is changed here.

The supplied derived formalization (PR #6, `5f6ee6575550d8a20c6fc3990359cb4f67855f80`) provides the actual reconstruction, internal quotient, homology-kernel equivalence, and compatible kernel actions. Its finite-jet module supplies the balanced tensor-quotient comparison with the split-reflection square. Those results are reused; this note does not duplicate their Lean implementation.

The new analytic step computes the previously only surjective finite Mellin-jet observation as an exact operator quotient. For every polynomial $h$ whose roots lie in the open critical strip, it constructs

$$Q/h(D)Q\ \xrightarrow{\sim}\ E_h/g_hE_h,\qquad
Q[h(D)]\ \xrightarrow{\sim}\ \ker(g_h:E_h\to E_h),$$

with $E_h=\mathbb C[t]/(h)$ and $g=2\xi$. It then constructs finite spectral projectors on the original $Q$, not only quotients of $Q$, and identifies the torsion subsheaf of the balanced analytic realization with $\mathcal O/(2\xi)$. Their kernels, original supported zeros, nilpotent actions, and trace-producing residue pairing are all retained.

The general existence of spectral realizations of zeta zeros is prior literature (not a novelty claim here): see R. Meyer, *A spectral interpretation for the zeros of the Riemann zeta function*, arXiv:math/0412277. The contribution of this note is the explicit comparison in the specified workbench, together with its original SplitZero quotients and its complete finite kernel calculation.

## 1. The exact arithmetic complex and its operator

Retain

$$V=\{\phi\in\mathcal S(\mathbb R):\phi(-x)=\phi(x),\ \phi(0)=0,\ \int_{\mathbb R}\phi(x)\,dx=0\},$$

$$\mathscr B=\{F\in C^\infty(\mathbb R_{>0}):
\sup_{x>0}x^b|(-x\partial_x)^kF(x)|<\infty\ \text{for all }b\in\mathbb Z,\ k\ge0\}.$$

The source maps, with their original factors, are

$$D=-x\partial_x,\quad
\Theta\phi(x)=\sum_{n\in\mathbb Z\setminus\{0\}}\phi(nx),\quad
\mathcal MF(s)=\int_0^\infty F(x)x^s\frac{dx}{x}.$$

The Fourier transform is $\widehat\phi(\xi)=\int_{\mathbb R}\phi(x)e^{-2\pi i x\xi}\,dx$. Poisson and the two moment conditions put $\Theta V$ in $\mathscr B$. Also $D\Theta=\Theta D$, and $D$ preserves $V$.

Set

$$A=\mathbb C[t],\qquad t\cdot F=DF,\qquad t\cdot\phi=D\phi,$$

$$C_+=[V\xrightarrow{\Theta}\mathscr B]\quad\text{in degrees }0,1,
\qquad Q=\mathscr B/\Theta V.$$

The existing injectivity proof of $\Theta$ gives $H^0(C_+)=0$ and $H^1(C_+)=Q$.

This is the one-leg subcomplex of the actual tau-base chart complex

$$C_{+-}=[V\oplus V\xrightarrow{\Theta\phi-\Theta\widehat\psi}\mathscr B].$$

Its inclusion is $\phi\mapsto(\phi,0)$ in degree zero and the identity in degree one. The quotient complex is the second copy of $V$ in degree zero. The explicit section is $\psi\mapsto(\widehat\psi,\psi)$. The operator on that second copy is $1-D$, because $D\widehat\psi=\widehat{(1-D)\psi}$. Thus the additional joint-support degree-zero cohomology is retained in this split exact sequence; it is not included in $Q$ and then silently discarded.

The actual source multiplier is

$$g(s)=2\xi(s)=s(s-1)\pi^{-s/2}\Gamma(s/2)\zeta(s),$$

$$H_\phi(s)=c(s)M_+\phi(s),\quad
c(s)=\frac{2\pi^{s/2}}{s(s-1)\Gamma(s/2)},\quad
M_+\phi(s)=\int_0^\infty\phi(x)x^s\frac{dx}{x}.$$

On the open strip $\mathscr S=\{0<\Re s<1\}$, $c(s)$ is holomorphic and nowhere zero. The source identity is

$$\mathcal M\Theta\phi=gH_\phi.$$

The specific function

$$\phi_*(x)=(4\pi^2x^4-6\pi x^2)e^{-\pi x^2}$$

has $H_{\phi_*}=1$. Consequently

$$H_{P(D)\phi_*}(s)=P(s),\qquad
\mathcal M\Theta(P(D)\phi_*)=g(s)P(s).$$

These are identities with the stated Gaussian and $g=2\xi$; no rescaling is performed.

## 2. A continuous inverse to the actual Euler differential

For any $\rho\in\mathbb C$, define on the subspace $\{H\in\mathscr B:\mathcal MH(\rho)=0\}$

$$\boxed{S_\rho H(x)=x^{-\rho}\int_x^\infty H(t)t^{\rho-1}\,dt.}$$

All powers use the real logarithm on $x,t>0$. Direct differentiation gives

$$(D-\rho)S_\rho H=H.$$

**Endpoint control.** Write $x=e^y$, $h(y)=H(e^y)$, and $\sigma=\Re\rho$. At $y\ge0$, the displayed tail and a bound $|h(t)|\le C_Ne^{-Nt}$ give

$$|S_\rho H(e^y)|\le\frac{C_N}{N-\sigma}e^{-Ny}\quad(N>\sigma).$$

At $y\le0$, the zero moment changes the same expression into the negative lower tail. A bound $|h(t)|\le C_N'e^{Nt}$ gives

$$|S_\rho H(e^y)|\le\frac{C_N'}{N+\sigma}e^{Ny}\quad(N+\sigma>0).$$

Differentiating uses $(S_\rho H)'_y=-\rho S_\rho H-H(e^y)$, so every derivative has the same family of estimates. This proves membership in $\mathscr B$ and continuity in its stated seminorms. The homogeneous solution $x^{-\rho}$ fails the required rapid decrease unless its coefficient is zero. Thus $D-\rho$ is injective, and

$$\boxed{(D-\rho)\mathscr B=\ker(F\mapsto\mathcal MF(\rho)).}$$

Mellin intertwining gives

$$\mathcal M(S_\rho H)(s)=\frac{\mathcal MH(s)}{s-\rho},$$

with the removable value filled at $s=\rho$.

There is also a source inverse. For $\rho\in\mathscr S$ and $\phi\in V$ with $H_\phi(\rho)=0$, use the same tail for $x>0$ and extend evenly. The nonvanishing of $c(\rho)$ gives $M_+\phi(\rho)=0$. Near zero the formula is

$$S_\rho\phi(x)=-\int_0^1u^{\rho-1}\phi(xu)\,du.$$

Differentiation under this integral proves smoothness at zero in every order. The function is even and its value at zero is zero. The upper-tail formula proves Schwartz decay at infinity. Finally

$$(1-\rho)\int_{\mathbb R}S_\rho\phi(x)\,dx=\int_{\mathbb R}\phi(x)\,dx=0,$$

so the second moment condition is preserved. This proves the source range identity

$$\boxed{(D-\rho)V=\ker(\phi\mapsto H_\phi(\rho))\quad(\rho\in\mathscr S).}$$

At the level of Taylor coefficients $\phi(x)=\sum_{j\ge1}a_{2j}x^{2j}$, the local expression is $-\sum_{j\ge1}a_{2j}x^{2j}/(\rho+2j)$, interpreted to each finite Taylor order with its smooth remainder. All denominators and the minus sign are retained. Endpoints $0,1$ are not included in this source range theorem.

## 3. Every finite operator test, without choosing zeros first

Choose any finite set of distinct centres $\rho_1,\ldots,\rho_r\in\mathscr S$ and positive integers $m_i$. Define the particular polynomial

$$h(t)=\prod_{i=1}^r(t-\rho_i)^{m_i},\quad d=\deg h,\quad E_h=A/(h).$$

This defines the test; it does not presume that any centre is a zeta zero. The Chinese-remainder map is

$$\theta_h:E_h\xrightarrow{\sim}\prod_i\mathbb C[z_i]/(z_i^{m_i}),\qquad
[P(t)]\mapsto[P(\rho_i+z_i)].$$

For a holomorphic germ family $f$ at the centres, $j_hf$ denotes its Taylor jets transported back by $\theta_h^{-1}$. In particular $g_h=j_hg$ retains the original local units of $g$.

Iterate Section 2 through the factors of $h$. Uniqueness makes the inverse independent of their chosen order. This gives the continuous inverse

$$S_h:\ker(j_h\mathcal M)\longrightarrow\mathscr B,
\qquad h(D)S_h=\mathrm{id}.$$

The exact range identities are

$$h(D)\mathscr B=\ker(j_h\mathcal M),\qquad
h(D)V=\ker(j_hH).$$

Surjectivity on the source follows from $H_{P(D)\phi_*}=P$. Surjectivity of the target jet map follows directly from finite Mellin interpolation: on an interval in $y=\log x$, the functions $e^{\rho_i y}y^j/j!$ are linearly independent. For a nonnegative smooth bump $\eta$ positive on a subinterval, the Gram matrix

$$G_{(i,j),(k,l)}=\int\eta(y)e^{(\rho_i+\bar\rho_k)y}\frac{y^{j+l}}{j!l!}\,dy$$

is positive definite. Multiplying its inverse into the prescribed jet vector produces a compactly supported smooth preimage. This is only an interpolation device; it does not define or alter the arithmetic Weil pairing.

Consequently the vertical arrows in

$$\boxed{\begin{array}{ccc}
V/h(D)V&\xrightarrow{\overline\Theta}&\mathscr B/h(D)\mathscr B\\
\alpha_h\downarrow\wr&&\wr\downarrow\beta_h\\
E_h&\xrightarrow{\times g_h}&E_h
\end{array}}$$

are actual $A$-module isomorphisms:

$$\alpha_h[\phi]=j_hH_\phi,\qquad \beta_h[F]=j_h\mathcal MF.$$

An inverse to $\alpha_h$ sends the unique polynomial representative $P$ of degree less than $d$ to $[P(D)\phi_*]$. An inverse to $\beta_h$ is any of the above explicit interpolation lifts, taken modulo $h(D)\mathscr B$; the class is independent of that choice by the range theorem.

## 4. The kernel and quotient of the global arithmetic operator

Both $V$ and $\mathscr B$ are torsion-free $A$-modules: every factor $D-\rho$ is injective, since its homogeneous solution cannot be Schwartz at infinity. Over the PID $A$, they are flat. The bounded complex $C_+$ is therefore a valid flat model for derived tensoring. The displayed isomorphism computes

$$\boxed{C_+\otimes_A^{\mathbf L}E_h\ \simeq\ [E_h\xrightarrow{\times g_h}E_h]}$$

in degrees zero and one. It is the base-change of the actual theta complex, not a newly declared spectral complex with an assigned differential.

The original exact sequence $0\to V\xrightarrow\Theta\mathscr B\to Q\to0$ also gives

$$\boxed{0\to Q[h(D)]\xrightarrow{\kappa_h}E_h
\xrightarrow{\times g_h}E_h\longrightarrow Q/h(D)Q\to0.}$$

Here $Q[h(D)]=\ker(h(D):Q\to Q)$. The maps are explicit:

* Given $[F]\in Q[h(D)]$, uniquely write $h(D)F=\Theta\phi$. Then $\kappa_h[F]=j_hH_\phi$.
* The quotient observation sends $[F]$ to $j_h\mathcal MF$ modulo $g_hE_h$.
* For $P\in\ker(g_h:E_h\to E_h)$, choose its polynomial representative of degree less than $d$ and set

$$\boxed{\partial_h(P)=[S_h\Theta(P(D)\phi_*)]\in Q[h(D)].}$$

The last expression is defined because its theta input has zero jets modulo $h$. Replacing $P$ by $P+hR$ changes the result by $\Theta(R(D)\phi_*)$. Thus it is independent of representatives and is the inverse of $\kappa_h$ onto its kernel. The two injectivity and surjectivity assertions also follow directly by lifting representatives in the preceding exact sequence; no dimension-only argument is needed.

All maps commute with $D$, with $U_aF(x)=F(x/a)$, and with compactly supported multiplicative convolution. On $E_h$, the scaling action is multiplication by $j_h(a^s)$, including its entire finite nilpotent Taylor polynomial.

At one centre, retain $g(\rho+z)=u(z)z^r$, where $u(0)\ne0$ (and $r=0$ is allowed). For test order $m$, the two cohomology modules have dimension $\min(m,r)$. When $r=0$, multiplication by $g_h$ is invertible. The derived amplitude complex is then acyclic, while its reconstructed supported homology still has each labelled internal zero.

The degree-zero term is $Q[h(D)]$; the degree-one term is $Q/h(D)Q$. Their finite alternating traces cancel. The arithmetic packet trace below is the degree-one action, or equivalently its explicitly constructed direct summand in the original $Q$. The canonical truncation triangle retains the degree-zero term rather than relabelling it as zero.

## 5. Exact finite spectral projectors on the original cohomology

Now let $Z$ be any finite set of actual nontrivial zeros and retain their full multiplicities $r_\rho$. Put

$$h_Z(t)=\prod_{\rho\in Z}(t-\rho)^{r_\rho},\quad E_Z=A/(h_Z),\quad
v_Z(s)=g(s)/h_Z(s).$$

The quotient $v_Z$ is entire and its germs are nonzero at every point of $Z$. Hence $v_{Z,h}=j_{h_Z}v_Z$ is an invertible element of $E_Z$. This inverse retains the actual Taylor coefficients of $g/h_Z$; it is not set to one.

Here $g_{h_Z}=0$, and the exact sequence becomes

$$Q[h_Z(D)]\xrightarrow[\kappa_Z]{\sim}E_Z,
\qquad Q/h_Z(D)Q\xrightarrow[\beta_Z]{\sim}E_Z.$$

There is a further map that must be calculated, not assumed: the inclusion of the kernel into $Q$, followed by the quotient. For $P\in E_Z$,

$$\mathcal M\bigl(S_{h_Z}\Theta(P(D)\phi_*)\bigr)
=\frac{gP}{h_Z}=v_ZP.$$

Therefore this kernel-to-quotient comparison is precisely

$$\boxed{\beta_Z\,q_Z\,\partial_Z=M_{v_{Z,h}}:E_Z\xrightarrow{\sim}E_Z.}$$

Define

$$\sigma_Z=\partial_Z\circ M_{v_{Z,h}^{-1}}:E_Z\longrightarrow Q,$$

$$\boxed{\Pi_Z=\sigma_ZJ_Z:Q\longrightarrow Q,\qquad J_Z[F]=j_{h_Z}\mathcal MF.}$$

Then

$$\boxed{J_Z\sigma_Z=\mathrm{id},\quad \Pi_Z^2=\Pi_Z,\quad
\operatorname{im}\Pi_Z=Q[h_Z(D)],\quad \ker\Pi_Z=h_Z(D)Q.}$$

This gives the actual equivariant direct sum

$$\boxed{Q=Q[h_Z(D)]\oplus h_Z(D)Q.}$$

A representative formula is completely determined. For $F\in\mathscr B$, let $P_{Z,F}$ be the unique polynomial of degree less than $\deg h_Z$ representing $v_{Z,h}^{-1}j_{h_Z}\mathcal MF$. Then

$$\boxed{\Pi_Z[F]=[S_{h_Z}\Theta(P_{Z,F}(D)\phi_*)].}$$

For a simple actual zero $\rho$, this specializes to

$$\Pi_{\{\rho\}}[F]=\frac{\mathcal MF(\rho)}{g'(\rho)}
\left[x^{-\rho}\int_x^\infty\Theta\phi_*(t)t^{\rho-1}\,dt\right].$$

The displayed denominator is the actual $g'(\rho)=2\xi'(\rho)$; it is not omitted. The bracketed class is an actual nonzero eigenclass in $Q$, proved by the exact sequence, even though its representative is only an eigenvector modulo the theta relation.

For finite packets the projectors satisfy

$$\Pi_Z\Pi_W=\Pi_{Z\cap W},\qquad
\Pi_{Z\cup W}=\Pi_Z+\Pi_W\quad(Z\cap W=\varnothing).$$

These follow from the direct sums, coprimality of disjoint packet polynomials, and commutation with $D$. Inclusions of finite packets therefore give compatible invariant subspaces and quotient observations. No convergence of an infinite sum of projectors is asserted.

## 6. Carry every projector through the original split quotient

For any vector space $M$ the single-active-fibre lift is $M^\tau=\{\tau\}\sqcup\{m^\bullet:m\in M\}$. For a submodule $N$ use exactly

$$q_N^{\mathrm{sp}}:M^\tau\to(M/N)^\tau,\quad
m^\bullet\mapsto[m]^\bullet,\quad\tau\mapsto\tau.$$

This is the original coequalizer of the relation inclusion and its internal-zero companion. Its universal property is the one implemented in PR #6, including arbitrary noncancellative target semimodules.

Consequently the finite observation has the split-linear equivalence

$$\boxed{(Q/h(D)Q)^\tau\xrightarrow{\sim}G(E_h/g_hE_h),\qquad
[F]^\bullet\mapsto(j_h\mathcal MF\bmod g_hE_h)^\bullet.}$$

The domain is being used as a split semimodule, not as an unconstructed ring. A class in $h(D)Q$ maps to the supported zero, and external absence alone maps to external absence.

Lift the projector as

$$\widetilde\Pi_Z(\lambda,[F])=(\lambda,\Pi_Z[F]).$$

This formula applies to the actual nonempty support faces of the tau-base theta model; their degree-one transports are the stated identities of $Q$. At bottom it is the original zero map of the bottom module. The full reconstruction interface permits a nonzero bottom fibre when a subsequent diagram requires one; it is not silently specialized away on an opposite-index dual diagram.

For disjoint packets,

$$\boxed{\widetilde\Pi_Z\widetilde\Pi_W=\varepsilon,
\qquad\varepsilon(\lambda,x)=(\lambda,0).}$$

This is the supported lift of the zero linear operator, not the constant external-zero map. More uniformly, take $\Pi_\varnothing=0_Q$ and lift it to $\varepsilon$. The scalar representation

$$G(\operatorname{End}_{\mathbb C}Q)\longrightarrow
\operatorname{End}_{G(\mathbb C)}(Q^\tau)$$

sends $f^\bullet$ to its split lift and sends $\tau$ to the constant-\(\tau\) map. It is a unital semiring morphism and sends the supported scalar zero to $\varepsilon$.

### Retain smaller admitted source labels

For a subspace $W\subset V$, first use its specified enlargement $W_D=\mathbb C[D]W$ and keep the map

$$\mathscr B/\Theta W\longrightarrow Q_{W_D}:=\mathscr B/\Theta W_D,
\qquad\ker=\Theta W_D/\Theta W.$$

For a $D$-stable $W$, define the ideal

$$J_{W,h}=\{j_hH_\phi:\phi\in W\}\subseteq E_h.$$

It is an ideal because $H_{P(D)\phi}=P H_\phi$ and every element of $E_h$ has a polynomial representative. The same target range calculation gives

$$\boxed{Q_W/h(D)Q_W\cong E_h/(g_hJ_{W,h}).}$$

Enlarging to $W+\mathbb C[D]\phi_*$ makes $J_{W,h}=E_h$. The exact finite comparison kernel is

$$\boxed{g_hE_h/(g_hJ_{W,h}).}$$

Thus the finite equality for the full arithmetic relation space has a precise smaller-label comparison. It is not asserted for every original $W$ without this kernel.

## 7. The Hausdorff observation and the remaining global kernel

The projectors just constructed have continuous finite-rank representatives on $\mathscr B$: $J_Z$ is continuous, $E_Z$ is finite dimensional, and $S_{h_Z}$ is continuous on its zero-jet domain. They annihilate $\Theta V$, hence also its closure. They therefore descend to

$$Q^{\mathrm H}=\mathscr B/\overline{\Theta V}.$$

The finite observation still has kernel exactly $h_Z(D)Q^{\mathrm H}$. Indeed

$$\ker J_Z=h_Z(D)\mathscr B+\Theta V,$$

and continuity gives $\overline{\Theta V}\subset\ker J_Z$. Hence adding the closure to the right side leaves it unchanged. The same finite section yields a continuous direct sum

$$Q^{\mathrm H}=\sigma_Z(E_Z)\oplus h_Z(D)Q^{\mathrm H}.$$

The algebraic packet $Q[h_Z(D)]$ injects into this Hausdorff quotient: its composite with $J_Z$ is already an isomorphism onto $E_Z$. No conclusion about vanishing of the entire algebraic-to-Hausdorff kernel follows from this finite statement.

Let

$$\mathcal R_\infty=\bigcap_{Z\text{ finite}}\ker\Pi_Z
=\bigcap_{Z\text{ finite}}h_Z(D)Q.$$

The map $Q\to\prod_\rho\mathcal O_\rho/(g)$ has exactly this kernel. Every nonzero polynomial whose roots are in $\mathscr S$ acts bijectively on $\mathcal R_\infty$. To verify this, its kernel on $Q$ lies in the finite packet at its zero centres; its cokernel is supported there as calculated in Section 4. On the complementary summand it is bijective, and its inverse preserves all other commuting finite projectors. This proves injectivity and surjectivity on the intersection.

The continuation retains $\mathcal R_\infty$ and its scaling action. Finite packets do not prove it zero. A topological spectral-synthesis theorem or a global cohomological trace argument must address that specific invariant module rather than infer its disappearance from finite-jet isomorphisms.

### 7.1 The global balanced kernel has a computed local-cohomology complement

Work now on the analytic strip $\mathscr S$, with its sheaf $\mathcal O$ and sheaf $\mathcal K$ of meromorphic functions. Form the sheafified balanced realization

$$\mathcal M_Q=\mathcal O\otimes_AQ,\qquad
\beta:\mathcal M_Q\longrightarrow\mathcal O/(g),\quad
b\otimes[F]\longmapsto[b\,\mathcal MF].$$

Let $\operatorname{tors}_{\mathcal O}(\mathcal M_Q)$ denote its torsion subsheaf: a germ is in it when some nonzero holomorphic germ annihilates it. This is torsion over the specified analytic coefficient ring; its connection to the original split support is the reconstruction of the inclusion and quotient maps below.

**Theorem.** The actual Mellin map restricts to an isomorphism

$$\boxed{\beta|_{\operatorname{tors}}:
\operatorname{tors}_{\mathcal O}(\mathcal M_Q)
\xrightarrow{\sim}\mathcal O/(g).}$$

Moreover, $\mathcal N=\ker\beta$ has a canonical $\mathcal K$-module structure, and the displayed map canonically splits the sequence:

$$\boxed{\mathcal M_Q\cong\mathcal O/(g)\oplus\mathcal N,
\qquad\mathcal K\otimes_{\mathcal O}\mathcal N\cong\mathcal N.}$$

**Proof at every stalk.** Fix $\rho\in\mathscr S$ and set $x=s-\rho$. If $g(\rho)\ne0$, Section 4 with $h=t-\rho$ proves that $D-\rho$ is bijective on $Q$. Consequently $x$ is invertible on $\mathcal M_{Q,\rho}$, and this module is a module over the meromorphic field $\mathcal O_\rho[1/x]$. Its torsion is zero, as is $\mathcal O_\rho/(g)$.

If $r=\operatorname{ord}_\rho g>0$, the finite projector for this one full packet gives

$$Q=Q[(D-\rho)^r]\oplus (D-\rho)^rQ.$$

On the second summand, $(D-\rho)^r$ is bijective: it is injective by the direct-sum intersection, and

$$(D-\rho)^rQ=(D-\rho)^{2r}Q$$

follows by applying $(D-\rho)^r$ to the direct sum. Hence $D-\rho$ itself is bijective there. Tensoring the direct sum with $\mathcal O_\rho$ gives a first summand $\mathcal O_\rho/(x^r)$, on which $\beta$ is the isomorphism calculated in Section 5, and a second summand on which $x$ is invertible. The map $\beta$ kills the second summand because it is in $x^r\mathcal M_{Q,\rho}$, while $x^r$ annihilates its target. Every nonzero germ of $\mathcal O_\rho$ is a unit times a power of $x$, so that second summand is a module over $\mathcal K_\rho$ and is torsion-free.

This proves the stated torsion isomorphism at every stalk. It glues without choosing neighbourhood projectors: both the torsion subsheaf and the restricted map $\beta$ are intrinsic. The inverse of that isomorphism, followed by the torsion inclusion, is the global section of $\beta$. Local inverses to nonzero holomorphic scalars on $\mathcal N$ are unique, so they glue to its $\mathcal K$-module structure. This proves the theorem.

### 7.2 The extraction is an actual local-cohomology map

At the same stalk the principal-ideal local-cohomology complex is the explicit localization complex

$$R\Gamma_{(x)}(\mathcal M_{Q,\rho})
=[\mathcal M_{Q,\rho}\longrightarrow\mathcal M_{Q,\rho}[1/x]],
\quad\text{degrees }0,1.$$

The decomposition just proved computes it:

$$\boxed{R\Gamma_{(x)}(\mathcal M_{Q,\rho})
\xrightarrow{\sim}(\mathcal O_\rho/(g))[0].}$$

The finite torsion summand maps to zero upon localization; the meromorphic summand maps isomorphically to itself. The map to the displayed target is $\beta$ in degree zero and zero in degree one. Thus the supported arithmetic divisor is the actual cohomological image of the localization kernel, not a prescribed deletion of a list of spectral points.

Before analytic extension there is the corresponding operator-localization map

$$Q\longrightarrow A[h_Z^{-1}]\otimes_AQ,$$

with kernel $Q[h_Z(D)]$ and cokernel zero, because $h_Z(D)$ is invertible on its complementary summand. Its supported lift sends that kernel to the internal supported zero, not to external absence.

At every original label $\lambda$, reconstruct the localization complex using

$$d(\lambda,m)=(\lambda,m/1),\qquad
\varepsilon(\lambda,m)=(\lambda,0).$$

Its internal degree-zero cycles are exactly the reconstructed torsion module. Its internal first cohomology is the support skeleton, since the ordinary first cohomology vanishes. The map $p_{\mathbb Z}$ remains in the structural coefficient square throughout; $x$ is the analytic image of the operator $t-\rho$, not a replacement for the scalar $e$ or $\tau$.

The theorem does not assert $\mathcal N=0$. It computes what local cohomology does to it: localization is an isomorphism on that module, so it contributes no cohomology to the stated local-support complex. Its possible contribution to a different global trace functor has not been declared absent.

## 8. The residue duality is now inside an actual derived finite comparison

Assume the centres and their orders in $h$ are stable under $\iota(s)=1-\bar s$. For germs define

$$f^\dagger(s)=\overline{f(1-\bar s)}.$$

The chosen monic polynomial satisfies $h^\dagger=(-1)^d h$. Retain that factor. Define the perfect finite algebra pairing

$$R_h(f,u)=\sum_i\operatorname{Res}_{s=\rho_i}
\frac{f^\dagger(s)u(s)}{h(s)}\,ds.$$

It satisfies $\overline{R_h(u,f)}=(-1)^{d+1}R_h(f,u)$. No phase is inserted to change this sign. Since $g^\dagger=g$, multiplication by $g_h$ is self-adjoint for this pairing. Therefore it induces a perfect pairing

$$\boxed{\overline{\operatorname{coker}g_h}\ \otimes\ \ker g_h
\longrightarrow\mathbb C.}$$

Well-definedness is the identity $R_h(ga,u)=R_h(a,gu)$; nondegeneracy follows by taking the annihilator of the image in the finite perfect algebra pairing. Through Section 4 this pairs the two actual cohomology groups of $C_+\otimes_A^{\mathbf L}E_h$.

For an exact packet $h_Z$, set $v_{Z,h}=j_h(g/h_Z)$ as above and

$$\jmath_Z:A_Z\to\ker g_h=E_Z,\qquad
[f]\mapsto[j_h(h_Z/g)f].$$

Here $A_Z=\prod_{\rho\in Z}\mathcal O_\rho/(g)\cong E_Z$ by the specified local quotient maps; $h_Z/g$ is holomorphic at every centre. The local units are not replaced by one. The exact contraction is

$$\boxed{R_h(f,\jmath_Zk)=
\sum_{\rho\in Z}\operatorname{Res}_{\rho}\frac{f^\dagger k}{g}\,ds=:R_Z(f,k).}$$

Thus the previously constructed arithmetic residue form is the duality pairing of the actual finite operator comparison after the displayed unit morphism.

The Jacobian map is still $J_g[k]=[g'k]$. Its contraction is

$$\boxed{R_h(f,\jmath_ZJ_gk)=R_Z(f,J_gk)
=\sum_{\rho\in Z}r_\rho\overline{f(1-\bar\rho)}k(\rho)
=\operatorname{Tr}(M_{f^\dagger k}|A_Z).}$$

In particular the factor $2$ in $g=2\xi$ is retained in both the denominator and the Jacobian. The trace contraction is invariant under their combined explicitly specified transformation, not by deleting that factor in only one place.

Every map lifts to the original support fibres. Dual support arrows are precomposition maps on the opposite index category. A vanishing pairing value is the supported scalar $e_{\mathbb C}$; an absent argument gives $\tau$.

## 9. Cohomological placement and arithmetic traces

On the tau-base chart use the one-leg sheaf $\mathcal T_+$ and its $A$-action. The bounded projective resolution from `TAU_BASE_MODEL.md` gives the canonical map

$$\mathsf A_\tau(\mathcal T_+\otimes_A^{\mathbf L}E_h)
\xrightarrow{\sim}
\mathsf A_\tau(\mathcal T_+)\otimes_A^{\mathbf L}E_h
\xrightarrow{\sim}[E_h\xrightarrow{g_h}E_h].$$

These isomorphisms use finite evaluation sums and the displayed free/flat resolutions. They are not compact-support base-change assertions for a different arithmetic scheme.

The packet projector is now an actual finite-rank endomorphism of the original $H^1_\tau=Q$ (and of each of its retained support fibres). For an admissible smooth compactly supported multiplicative test $k$,

$$H_kF(x)=\int_0^\infty k(a)F(x/a)\,\frac{da}{a}$$

commutes with the projector. Its ordinary finite-rank trace is

$$\boxed{\operatorname{Tr}(H_k\Pi_Z|Q)
=\sum_{\rho\in Z}r_\rho\mathcal Mk(\rho).}$$

This is a finite-rank trace on the original cohomology, using its explicit finite invariant image. It is stronger than declaring that a surjective finite observation has a trace. Infinite trace summation still requires the specified topology and admissible test class.

On $r$-fold products over the tau-point, the already calculated external tensor map gives $H^r=Q^{\otimes r}$. The operator $\Pi_Z^{\otimes r}$ is a finite projector onto $Q[h_Z]^{\otimes r}$. The full nilpotent scaling action there is

$$a^{\rho_1+\cdots+\rho_r}
\exp\left((\log a)\sum_{j=1}^rN_{\rho_j,j}\right).$$

For a repeated exponent the exact modulus comparison remains

$$\log\frac{|a^{r\rho}|^2}{a^r}=r(2\Re\rho-1)\log a.$$

This supplies actual finite invariant objects on which a Deligne-style tensor estimate would have to act. It does not prove that estimate. The source's opposite weight bounds, its global dualizing theory, and the admissibility of its geometric hypotheses have not been inferred from these finite isomorphisms.

## 10. Status and publication boundary

**Established in this note, with written proofs:** the differential range identities on the stated spaces; the exact finite operator quotient and torsion kernel; the derived finite comparison; the analytic torsion-subsheaf and local-cohomology identification with $\mathcal O/(2\xi)$; finite spectral direct summands with explicit projectors; the original split lifts and smaller-label kernels; the residue/Jacobian contraction on that comparison; and compatible finite-rank arithmetic traces and tensor actions.

**Not claimed:** a global injectivity theorem for the full balanced analytic realization; vanishing of $\mathcal R_\infty$; identification of the entire four-point chart category with an arithmetic curve; a full compact-support/ordinary-cohomology realization satisfying the hypotheses of Weil II; positivity of the unshifted Weil form; RH or GRH. The finite tests are not a Lean or analytic proof certificate.

The prior base note and this continuation are published as additive research material beside PR #6. The original scalar core, formal modules, frozen reader and all existing branches remain unchanged. New derivations are AI-assisted work under the owner's programme; the structural source and its Lean implementation retain their own attribution. No copyrighted source corpus or private conversation is included.

### References and source interfaces

- Owner's SplitZero programme: the original scalar, support fibre and quotient constructions; PR #6 at `5f6ee6575550d8a20c6fc3990359cb4f67855f80`, especially `SplitZeroHomology.lean`, `SplitZeroComplex.lean`, `SplitZeroInternalQuotient.lean`, and `SplitZeroFiniteJets.lean`.
- `TAU_BASE_MODEL.md`: the actual characteristic-zero chart, cohomology, right-adjoint and tensor constructions used here. It remains an authored research model, not an accepted geometric RH realization.
- Deligne, P., *La conjecture de Weil. II* (1980), sections 3.3.4-3.3.6 and 6.2.1-6.2.7. Selected supplied TeX passages were reread for the intended comparison/duality architecture; no source proof is republished or claimed fully audited.
- Meyer, R., *A spectral interpretation for the zeros of the Riemann zeta function*, arXiv:math/0412277. Prior spectral-realization context; no theorem from it is silently used to identify the test spaces here.
- The Stacks Project, Derived tensor product, Tag 06XY. The general bounded-flat-complex construction used in Section 4.


\clearpage

# The global localization complex and its geometric comparison

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-base-cohomology/LOCALIZATION_INTERFACE.md). Module: `workbenches/tau-base-cohomology/LOCALIZATION_INTERFACE.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Continuation of `FINITE_OPERATOR_COMPARISON.md`, Sections 7.1–7.2. These are written deductions in the specified analytic module category, not new Lean-certified declarations.

## 1. Extract the full arithmetic divisor without choosing a finite packet

On the analytic strip \(\mathscr S=\{0<\Re s<1\}\), retain

\[
\mathcal M_Q=\mathcal O\otimes_{\mathbb C[t]}Q,
\qquad \beta:\mathcal M_Q\longrightarrow\mathcal D_g=\mathcal O/(g),
\qquad g=2\xi.
\]

The computed decomposition in the main note is

\[
\mathcal M_Q\cong\mathcal D_g\oplus\mathcal N,
\qquad \mathcal N=\ker\beta,
\qquad \mathcal K\otimes_{\mathcal O}\mathcal N\cong\mathcal N.
\]

The section of beta is the inverse of beta on the intrinsic torsion subsheaf. It therefore commutes with the retained scaling and convolution actions, which are \(\mathcal O\)-linear on this realization. No list of zero locations is input to that section.

Define the explicit localization complex

\[
L_g(\mathcal M_Q)
=[\mathcal M_Q\xrightarrow{\ell_g}\mathcal M_Q[1/g]],
\qquad \ell_g(m)=m/1,
\]

in degrees zero and one. This is the usual principal-ideal, module-theoretic local-cohomology complex over the locally Noetherian analytic coefficient ring. Its terms and cohomology can also be calculated directly from the displayed decomposition, without invoking that general identification.

The first summand is killed by g. Multiplication by g is invertible on the second, since that summand is a module over meromorphic functions. Thus

\[
\mathcal M_Q[1/g]\cong\mathcal N,
\qquad \ell_g(d,n)=n.
\]

The actual chain map

\[
(\beta,0):L_g(\mathcal M_Q)\longrightarrow\mathcal D_g[0]
\]

is consequently a quasi-isomorphism:

\[
\boxed{H^0L_g(\mathcal M_Q)\cong\mathcal O/(2\xi),\qquad
H^1L_g(\mathcal M_Q)=0.}
\]

This is a cohomological extraction from the actual balanced arithmetic quotient. The defining map is localization at the unchanged theta multiplier g, not deletion of a selected spectral packet.

## 2. Propagate the original support through localization

At each retained support label \(\lambda\), reconstruct

\[
\widetilde\ell_g(\lambda,m)=(\lambda,m/1),
\qquad
z_L(\lambda,m)=(\lambda,0).
\]

External tau remains the global zero of the reconstruction. The internal cycles are the equalizer of \(\widetilde\ell_g\) and \(z_L\). Their \(\lambda\)-fibre is the actual torsion module \(\mathcal D_g\). The internal cokernel is the support skeleton because the ordinary localization map is surjective. Its labelled zeros are not all replaced by external tau.

The maps to the ordinary amplitude complex are exactly the source reconstruction/projection maps. For any nonzero bottom fibre required by a later diagram, the same formulas retain that module at bottom. The assertion here about a single external absent element is the original zero-bottom specialization, not an assumption about every possible opposite-index diagram.

The parent coefficient square \(G(\mathbb Z)\to G(\mathbb C)\) over \(\mathbb Z\to\mathbb C\) remains attached. Inverting the analytic function g is not inverting the scalar e. These two operations are related by the maps from the original supported localization complex to its coefficient amplitudes, not identified with one another.

## 3. The exact comparison to geometric support

Let \(j:U=\mathscr S\setminus V(g)\hookrightarrow\mathscr S\) be the open inclusion. There is a canonical derived morphism

\[
u_g:\mathcal M_Q[1/g]\longrightarrow Rj_*j^*\mathcal M_Q.
\]

It is obtained from the adjunction unit of the localized module and the identity
\(j^*(\mathcal M_Q[1/g])\cong j^*\mathcal M_Q\). Its composite with \(\ell_g\) is the adjunction unit of \(\mathcal M_Q\).

Thus there is the exact typed comparison

\[
\begin{array}{ccc}
\mathcal M_Q&\xrightarrow{\ell_g}&\mathcal M_Q[1/g]\\
\Vert&&\downarrow u_g\\
\mathcal M_Q&\longrightarrow&Rj_*j^*\mathcal M_Q.
\end{array}
\]

Taking fibres gives

\[
L_g(\mathcal M_Q)\longrightarrow
\operatorname{Fib}(\mathcal M_Q\to Rj_*j^*\mathcal M_Q).
\]

In particular the module-theoretic extraction and the geometric-support object are connected by an actual morphism. Their possible difference is

\[
\boxed{\operatorname{Cone}\bigl(
L_g(\mathcal M_Q)\to
\operatorname{Fib}(\mathcal M_Q\to Rj_*j^*\mathcal M_Q)
\bigr)
\cong\operatorname{Cone}(u_g)[-1].}
\]

No isomorphism between those two support functors has been assumed. The difference cone, with its inherited arithmetic action, is the specified object for the next geometric comparison. A module over meromorphic functions can have nontrivial extension behaviour as a sheaf on a punctured analytic neighbourhood; the explicit arrow u_g retains that issue instead of inferring geometric acyclicity from invertibility of g alone.

## 4. The endomorphism-ring lift used by the finite projectors

The main note uses the notation \(G(\operatorname{End}_{\mathbb C}Q)\). For precision, this is the following explicit extension of the same formula to an associative, possibly noncommutative, ring B:

\[
G_{\mathrm{ass}}(B)=\{\tau\}\sqcup B^\bullet,
\quad b^\bullet\oplus c^\bullet=(b+c)^\bullet,
\quad b^\bullet c^\bullet=(bc)^\bullet,
\]

with tau the additive identity and multiplicative absorber. Associativity and distributivity follow by the same supported/absent case calculations; multiplicative commutativity is not asserted. For commutative B it is the original G(B).

For B=End(Q), define

\[
\mathcal L:G_{\mathrm{ass}}(B)\to
\operatorname{End}_{G(\mathbb C)}(Q^\tau),
\]

by \(\mathcal L(f^\bullet)(v^\bullet)=f(v)^\bullet\),
\(\mathcal L(f^\bullet)(\tau)=\tau\), and \(\mathcal L(\tau)\) the constant-tau map. Direct evaluation proves preservation of addition, composition, identity, and the external zero. In particular

\[
\mathcal L(0_B^\bullet)=\varepsilon,
\qquad\varepsilon(v^\bullet)=0_Q^\bullet,
\qquad\mathcal L(\tau)(v^\bullet)=\tau.
\]

For disjoint finite packets, \(\Pi_Z\Pi_W=0_B\), so the original supported lifts compose to epsilon. This is the precise associative-semiring interface used there; it is not a claim that the commutative-ring-only source functor already had noncommutative objects in its declared domain.


\clearpage

# Chain-level arithmetic descent over the tau base

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-chain-descent/RESEARCH_NOTE.md). Module: `workbenches/tau-chain-descent/RESEARCH_NOTE.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Owner-directed research continuation, 12 September 2026. Draft proofs for review; no new Lean certification or RH claim.

## 0. Fixed inputs and publication scope

This is an additive continuation of Zeta PR #8 at `25689c5376166df37801229bc275ff5a896007d9`, particularly `workbenches/tau-base-cohomology/FINITE_OPERATOR_COMPARISON.md` (Git blob `68f59d098d60708f8e899bb960abbd1135ebb3b4`). Its sections 1–5 supply the stated analytic range theorem and the finite packet maps. The new result here is their chain-level descent, its actual extension class, and the connection of that class to residue duality and the arithmetic trace.

The source programme retains

$$G(R)=\{\tau\}\sqcup\{r^\bullet:r\in R\},\quad e_R=0_R^\bullet,$$

$$p_R(\tau)=0_R,\qquad p_R(r^\bullet)=r.$$

The absolute pointed base and the coefficient square remain

$$\mathfrak b_\tau=\operatorname{Spec}\mathbf F_{1,\tau},\qquad
\begin{array}{ccc}G(\mathbb Z)&\xrightarrow{G(j)}&G(\mathbb C)\\
p_{\mathbb Z}\downarrow&&\downarrow p_{\mathbb C}\\
\mathbb Z&\xrightarrow{j}&\mathbb C.\end{array}$$

The target of the first vertical map remains the infinite ring of integers. Every new arrow below is a coefficient or cochain construction over this marked base. No base field, ideal norm, Euler factor, or completion constant is changed.

The supplied derived note and PR #6 provide `Recovery.recoverEquiv`, `Relations.coequalizer_universal`, the internal-homology coequalizer, `ChainMap.homologyKernelEquiv`, and `homology_intertwines`. Their algebraic conclusions are used at their stated types. No existing formal module is modified. Analytic inputs from PR #8 remain written research arguments; they are not promoted to Lean theorems.

## 1. The actual arithmetic source and packet

Let

$$V=\{\phi\in\mathcal S(\mathbb R):\phi(-x)=\phi(x),\ \phi(0)=0,\ \int_{\mathbb R}\phi(x)\,dx=0\},$$

$$\mathscr B=\{F\in C^\infty(\mathbb R_{>0}):
\sup_{x>0}x^b|(-x\partial_x)^kF(x)|<\infty\text{ for every }b\in\mathbb Z,k\ge0\}.$$

Retain

$$D=-x\partial_x,\quad \Theta\phi(x)=\sum_{n\in\mathbb Z\setminus\{0\}}\phi(nx),\quad
\mathcal MF(s)=\int_0^\infty F(x)x^s\frac{dx}{x},$$

$$\widehat\phi(\xi)=\int_{\mathbb R}\phi(x)e^{-2\pi i x\xi}\,dx,\qquad
A=\mathbb C[t],\quad t\cdot F=DF.$$

The one-leg tau-chart complex is

$$C_+=[V\xrightarrow{\Theta}\mathscr B],\quad |V|=0,\quad |\mathscr B|=1,\qquad Q=H^1(C_+).$$

The injectivity of theta gives $H^0(C_+)=0$. The two-leg complex is

$$C_{+-}=[V\oplus V\longrightarrow\mathscr B],\qquad
(\phi,\psi)\longmapsto\Theta\phi-\Theta\widehat\psi.$$

Its source operator is $(D,1-D)$; the inclusion $C_+\to C_{+-}$ is $\phi\mapsto(\phi,0)$ and the identity in degree one. It leaves the extra degree-zero copy of $V$ in $C_{+-}$ present.

Use the unchanged arithmetic multiplier

$$g(s)=2\xi(s)=s(s-1)\pi^{-s/2}\Gamma(s/2)\zeta(s).$$

The input function is

$$\phi_*(x)=(4\pi^2x^4-6\pi x^2)e^{-\pi x^2},$$

and the established identities are

$$\mathcal M\Theta\phi=gH_\phi,\qquad H_{\phi_*}=1,\qquad
H_{P(D)\phi_*}(s)=P(s).$$

Fix a nonempty finite packet $Z$ of actual nontrivial zeros, with full orders $m_\rho$. Set

$$h(t)=\prod_{\rho\in Z}(t-\rho)^{m_\rho},\quad d=\deg h,\quad E=A/(h),\quad v(s)=g(s)/h(s).$$

The specific monic polynomial defines this finite test; it does not rescale $g$. Write $j_h$ for the complete Taylor-jet/Chinese-remainder map at these centres, and retain the invertible element

$$v_h=j_hv\in E^\times,\qquad \varepsilon_Z=v_h^{-1}.$$

For $u\in E$, let $R_Z(u)\in\mathbb C[t]_{<d}$ be the unique polynomial representing $\varepsilon_Zu$.

The input range theorem supplies the inverse $S_h^{\mathscr B}$ of $h(D)$ on the zero-jet range, and the analogous source inverse $S_h^V$. For one factor,

$$S_\rho F(x)=x^{-\rho}\int_x^\infty F(y)y^{\rho-1}\,dy.$$

The stated source inverse uses $0<\Re\rho<1$ and the zero moment. Iteration supplies $S_h$. Define the actual maps

$$J:\mathscr B\to E,\quad JF=j_h\mathcal MF,$$

$$s:E\to\mathscr B,\quad s(u)=S_h^{\mathscr B}\Theta(R_Z(u)(D)\phi_*).$$

The inverse is defined because $gR_Z(u)$ has all required zero jets. Directly,

$$\mathcal Ms(u)=vR_Z(u),\quad Js=1_E,\quad J\Theta=0,\quad
h(D)s(u)=\Theta(R_Z(u)(D)\phi_*).\tag{1}$$

These equations fix the representative map, including all derivatives of $g/h$. On $Q$, the existing projector is $\Pi_Z=\bar s\bar J$, with image $Q[h(D)]$ and kernel $h(D)Q$.

## 2. The exact equivariant extension and its class

Define an actual subspace of the original test-function space:

$$\mathscr B_Z=\{F\in\mathscr B:[F]\in Q[h(D)]\}.$$

Then

$$\mathscr B_Z=\Theta V\oplus s(E)\quad\text{as complex vector spaces},$$

with maps

$$(\phi,u)\longmapsto\Theta\phi+s(u),\qquad
F\longmapsto\bigl(\Theta^{-1}(F-sJF),JF\bigr).\tag{2}$$

For the inverse, $F-sJF$ has zero class in $Q$ by the packet projector theorem; injectivity of theta makes its source unique. The intersection is zero by $Js=1$ and $J\Theta=0$.

The original operator $D$ preserves $\mathscr B_Z$, and there is a short exact sequence of $A$-modules

$$\boxed{0\longrightarrow V\xrightarrow{\Theta}\mathscr B_Z\xrightarrow{J}E\longrightarrow0.}\tag{3}$$

The arrows in (3), not just the three modules, specify its extension class. Compute it using the resolution

$$0\longrightarrow A\xrightarrow{\times h}A\longrightarrow E\longrightarrow0.$$

The resulting isomorphism $\operatorname{Ext}^1_A(E,V)\cong V/h(D)V$ sends an extension to $h(D)b$ in the source, where $b$ is any lift of $1\in E$. Fixing this explicit rule fixes its sign. Under the existing map $[\phi]\mapsto j_hH_\phi$, the class of (3) is

$$\boxed{[\mathscr B_Z]=\varepsilon_Z=j_h(h/g)\in E^\times.}\tag{4}$$

Proof: use the lift $s(1)$ and (1). Its source boundary is $R_Z(1)(D)\phi_*$, whose $H$-jet is $\varepsilon_Z$.

In particular, (3) has no $A$-linear section. This also follows immediately from the injectivity of $h(D)$ on $\mathscr B$: an $A$-linear map $E\to\mathscr B$ has image killed by $h(D)$ and is therefore zero. The map $s$ in (2) is the explicit complex-linear section, and the next section computes exactly how it fails to intertwine the arithmetic action. This non-splitting occurs for every nonempty packet, including critical-line packets; it is not an RH-failure criterion.

The general use of extension classes is standard homological algebra (Stacks, Tags 010I and 06XP). Formula (4) calculates the specific extension arising from this theta complex.

## 3. The scaling defect is an original theta boundary

For $P\in A$ and $u\in E$, define

$$q_P(u)=\frac{P(t)R_Z(u)-R_Z(Pu)}{h(t)}\in A,\qquad
k_P(u)=q_P(u)(D)\phi_*\in V.\tag{5}$$

The numerator is divisible by $h$, since both of its residues are $P\varepsilon_Zu$. Using (1) and the injectivity of $h(D)$ on $\mathscr B$ gives

$$\boxed{P(D)s-sM_P=\Theta k_P.}\tag{6}$$

No quotient has yet been applied in (6). The right side is an actual theta function. The composition law is

$$\boxed{k_{PQ}=P(D)k_Q+k_PM_Q.}\tag{7}$$

It follows either by expanding the numerator of (5), or by expanding the commutator in (6) and using injectivity of theta.

For $P=t$, the numerator of (5) has degree at most $d$. Hence

$$\ell_Z(u)=[t^{d-1}]R_Z(u),\quad q_t(u)=\ell_Z(u),\quad
\boxed{Ds(u)-s(tu)=\ell_Z(u)\Theta\phi_*.}\tag{8}$$

Thus, in the exact coordinates (2), the original operator is

$$\boxed{D_{\mathscr B_Z}=
\begin{pmatrix}D_V&\phi_*\ell_Z\\0&M_t\end{pmatrix}.}\tag{9}$$

Its off-diagonal map is rank one and its coefficient is determined by the retained local arithmetic unit. It is not chosen to improve a spectral estimate.

For one simple zero,

$$h=t-\rho,\quad \varepsilon_Z=1/g'(\rho),$$

$$s(1)=\frac1{g'(\rho)}x^{-\rho}\int_x^\infty\Theta\phi_*(y)y^{\rho-1}\,dy,$$

$$\boxed{(D-\rho)s(1)=\frac1{g'(\rho)}\Theta\phi_*.}\tag{10}$$

The coefficient is $1/(2\xi'(\rho))$, with the original factor two retained.

### The full dilation group

For $a>0$, retain $U_aF(x)=F(x/a)$ and $A_a=M_{j_h(a^s)}$ on $E$. Define

$$k_a(u)=S_h^V\bigl(U_a(R_Z(u)(D)\phi_*)-R_Z(A_au)(D)\phi_*\bigr).\tag{11}$$

The source of $S_h^V$ has zero $H$-jets because $a^s\varepsilon_Zu$ and $\varepsilon_ZA_au$ have equal jets. All powers use the real logarithm of $a$. The exact identities are

$$U_as-sA_a=\Theta k_a,\qquad
k_{ab}=U_ak_b+k_aA_b,\qquad k_1=0.\tag{12}$$

The same construction applies to a smooth compactly supported multiplicative test $f$: replace $U_a$ by $H_f=\int f(a)U_a\,da/a$ and $A_a$ by $M_{j_h\mathcal Mf}$. The source integral belongs to $V$; its $H$-jets give the same cancellation. These are actual linear maps, not a choice of a formal matrix on $E$ alone.

## 4. A derived equivariant inclusion with its full homotopy

Put $P_Z=sJ:\mathscr B\to\mathscr B$. It is a finite-rank idempotent, and $P_Z\Theta=0$. Consequently

$$\mathsf p_Z=(0,P_Z):C_+\to C_+\tag{13}$$

is a cochain idempotent. Its image is the two-term complex $[0\to s(E)]$, complex-linearly isomorphic to $E[-1]$.

For the operator $P(D)$ on $C_+$, define a degree-minus-one map with sole component

$$\mathsf H_P^1=k_PJ:\mathscr B\to V.$$

Equation (6) gives

$$\boxed{P(D)\mathsf p_Z-\mathsf p_ZP(D)
=d\mathsf H_P+\mathsf H_Pd.}\tag{14}$$

In degree one this is $\Theta k_PJ$; in degree zero it is zero because $J\Theta=0$. For dilation use $\mathsf H_a^1=k_aJ$. Equation (12) is the coherence law of those homotopies.

There is also a strictly $A$-linear derived presentation. Set

$$C_Z=[V\xrightarrow{\Theta}\mathscr B_Z].$$

In the coordinates (2) its differential is $\phi\mapsto(\phi,0)$ and its action is (9). The maps

$$\iota:C_Z\hookrightarrow C_+,\qquad
\pi:C_Z\to E[-1],\quad\pi^0=0,\ \pi^1=J\tag{15}$$

are strictly $A$-linear cochain maps, and $\pi$ is a quasi-isomorphism. Thus the actual equivariant inclusion is the roof

$$\boxed{E[-1]\xleftarrow[\simeq]{\pi}C_Z\xrightarrow{\iota}C_+.}\tag{16}$$

The complex-linear deformation retraction also has an exact contracting homotopy: on $\mathscr B_Z$, send $\Theta\phi+s(u)$ to $\phi\in V$. Its equation is $1-s\pi=dH+Hd$ (with $s$ interpreted as the degree-one cochain section). This homotopy is not claimed $A$-linear; the $A$-linear replacement is the roof (16).

The strictly $A$-linear map $j:C_+\to E[-1]$ is $J$ in degree one and zero in degree zero. It satisfies $j\iota=\pi$. This gives a split retract in $D(A)$ without falsely asserting an $A$-linear section into $\mathscr B$.

On the two-leg complex use $\mathsf p_Z^0=0$ on $V\oplus V$, $\mathsf p_Z^1=P_Z$, and $\mathsf H_a^1(F)=(k_aJF,0)$. The source dilation is $(U_a,aU_{1/a})$, so (14) holds with its original two-leg differential. The inclusion $C_+\to C_{+-}$ commutes with these cochain projectors. The extra degree-zero cohomology of $C_{+-}$ is killed by this projector; it remains in the complementary complex.

## 5. The mixed-support homotopies require the actual synchronization map

Let $L=\mathcal P(\{+,-\})$ be the original chart-support lattice. Its three active complexes are

$$C_+=[V\xrightarrow{\Theta}\mathscr B],\quad
C_-=[V\xrightarrow{-\Theta\mathcal F}\mathscr B],\quad
C_{+-}=[V\oplus V\xrightarrow{\Theta(\phi-\widehat\psi)}\mathscr B].$$

Here $\mathcal F$ is the specified Fourier transform, with $\mathcal F^2=1$ on even functions. The source inclusions into the joint fibre are $v\mapsto(v,0)$ and $v\mapsto(0,v)$; degree-one transports are identities. The bottom complex is zero in this particular model. The new formalization allows a nonzero bottom fibre in the general reconstruction; no assertion about all diagrams is obtained by specializing this model.

The reconstructed operations are

$$(\lambda,x)+(\mu,y)=
(\lambda\vee\mu,\rho_{\lambda,\lambda\vee\mu}x+\rho_{\mu,\lambda\vee\mu}y),$$

$$e(\lambda,x)=(\lambda,0),\qquad
\tau(\lambda,x)=(\bot,0).\tag{17}$$

The cochain projector $\widetilde{\mathsf p}_Z$ is zero-in-its-fibre in degree zero and $P_Z$ in degree one. It commutes with the support transports. So does the actual action: $U_a$ on the plus source, $aU_{1/a}$ on the minus source, their direct sum on the joint source, and $U_a$ at every active overlap.

The objectwise homotopies are, however, different maps. With $b=k_aJF$, they are

$$\mathsf H_{a,+}^1(F)=b,\qquad
\mathsf H_{a,-}^1(F)=-\widehat b.$$

Their images in the joint source are $(b,0)$ and $(0,-\widehat b)$. The difference is the explicit cycle

$$\boxed{(b,\widehat b)\in\ker d_{+-}=H^0(C_{+-}).}\tag{18}$$

For nonzero $k_a$, there is no label-preserving family of homotopies compatible with both source inclusions: the joint component would have to equal both $(b,0)$ and $(0,-\widehat b)$. This says exactly which naturality square fails. It does not discard the cohomology or the arithmetic action.

The replacement is the programme's actual synchronization. Define the support map

$$r_L(\bot)=\bot,\qquad r_L(\lambda)=\{+,-\}\quad(\lambda\ne\bot).$$

In degree zero use literal multiplication by $E=(1,e)$ on the original two-coordinate support module:

$$\mathfrak r^0(a,b)=(a+eb,b+ea).$$

In degree one define $\mathfrak r^1(\lambda,F)=(r_L\lambda,F)$ for active labels and preserve global zero. An absent source coordinate becomes its supported vector zero, so the source differential has unchanged amplitude. Hence

$$\boxed{d\mathfrak r^0=\mathfrak r^1d,\qquad
\mathfrak r^2=\mathfrak r.}\tag{19}$$

This uses the operation verified in the synchronization attachment, now on the actual complex. The fixed active fibre is exactly $C_{+-}$. On degree-one homology, the map is

$$(\lambda,[F])\longmapsto(\{+,-\},[F]).$$

It has no nonzero amplitude kernel, because all degree-one transports are the identity of $Q$. The original mask is retained through

$$x\longmapsto(\operatorname{supp}(x),\mathfrak r x).$$

This map is injective in each degree of this chart complex: in degree zero the coordinate inclusions are injective, and in degree one the transport is the identity. This injectivity is a proved property of these maps, not an assumption for general diagrams with noninjective transports.

There are now two actual split-linear homotopies with the same support map $r_L$. Define

$$\widetilde{\mathsf H}^{\mathrm{left},1}_a(\lambda,F)
=(\{+,-\},(k_aJF,0)),$$

$$\widetilde{\mathsf H}^{\mathrm{right},1}_a(\lambda,F)
=(\{+,-\},(0,-\mathcal F k_aJF)),$$

and send global zero to global zero. Both satisfy

$$\boxed{\mathfrak r\bigl(\widetilde U_a\widetilde{\mathsf p}_Z
+(-1)^\bullet\widetilde{\mathsf p}_Z\widetilde U_a\bigr)
=\widetilde d\widetilde{\mathsf H}_a+
\widetilde{\mathsf H}_a\widetilde d.}\tag{20}$$

In degree one this is (6); in degree zero it follows from $Jd=0$. The two choices differ by the retained cycle (18). No averaging or removal of that cycle is performed. This is the precise role of synchronization here: it permits a common supported comparison fibre for the homotopy, while the original mask and the difference of homotopies remain recorded.

In the simple-zero case (10), the defect in any source support is the nonzero chain amplitude $\Theta(\phi_*/g'(\rho))$. Its internal homology class is the zero of that support, not external absence.

For every chain comparison $f:C\to C'$, the supplied formalized kernel equivalence remains

$$\{z\in Z(C):f(z)\in B(C')\}/B(C)\xrightarrow{\sim}\ker H(f).$$

Applied to $\pi$ in (15), it computes the zero kernel in degree one from its actual exact sequence. Applied to support synchronization, it yields the degree-one assertion just proved and the separately retained degree-zero data. It is not applied to a different global comparison without carrying that comparison's maps.

For any smaller $D$-stable admitted source $W\subset V$, the map $Q_W\to Q$ has kernel $\Theta V/\Theta W$. A homotopy value may not already lie in $W$. The explicit replacement is enlargement by the actual source values, with this quotient map and its kernel retained. The present chart uses full $V$, where every displayed homotopy is defined.

## 6. The same extension class produces the arithmetic duality factor

Assume $Z$ is stable under $\rho\mapsto1-\bar\rho$. Then

$$f^\dagger(s)=\overline{f(1-\bar s)},\qquad h^\dagger=(-1)^d h.$$

The perfect finite pairing is

$$R_h(f,u)=\sum_{\rho\in Z}\operatorname{Res}_{s=\rho}
\frac{f^\dagger(s)u(s)}{h(s)}\,ds,$$

with exact symmetry $\overline{R_h(u,f)}=(-1)^{d+1}R_h(f,u)$.

Identify $E$ with the actual divisor algebra $A_Z=\prod_{\rho\in Z}\mathcal O_\rho/(g)$ by polynomial evaluation and the complete Chinese-remainder jets. The nonzero local units in $g/h$ make this an isomorphism. The operator represented by the extension class is

$$M_{\varepsilon_Z}:E\to E.$$

Substituting (4) into the residue formula gives

$$\boxed{R_h(f,M_{\varepsilon_Z}u)
=\sum_{\rho\in Z}\operatorname{Res}_{\rho}
\frac{f^\dagger u}{g}\,ds=R_Z(f,u).}\tag{21}$$

This is independent of representatives: changing $\varepsilon_Z$ by $h$ times a germ adds a holomorphic differential. Thus the actual extension class is precisely the unit morphism converting the polynomial-resolution residue form into the arithmetic residue form.

Let $J_g=M_{j_hg'}$. Then

$$\boxed{R_h(f,M_{\varepsilon_Z}J_gu)
=\sum_{\rho\in Z}m_\rho\overline{f(1-\bar\rho)}u(\rho)
=\operatorname{Tr}(M_{f^\dagger u}\mid E).}\tag{22}$$

Locally $g=z^m w(z)$ gives $g'/g=m/z+w'/w$. This proves the formula and retains every multiplicity. The product $\varepsilon_ZJ_g$ carries both factors associated to $g=2\xi$.

The pairing-valued support map sends a zero value to $e_{\mathbb C}$ and an absent argument to $\tau$. Its original input support and relation fibre remain available upstream. Formula (22) is a calculated trace, not a positivity assertion.

### Reflection is strict for this specified section

Define conjugate-linear involutions

$$\mathfrak j_BF(x)=x^{-1}\overline{F(1/x)},\quad
\mathfrak j_V\phi=\overline{\widehat\phi},\quad j_Eu=u^\dagger.$$

They satisfy $\Theta\mathfrak j_V=\mathfrak j_B\Theta$ and $J\mathfrak j_B=j_EJ$. The actual source function is Fourier-fixed: writing $\phi_*=D(D-1)e^{-\pi x^2}$, Fourier sends the two factors to $(1-D)(-D)=D(D-1)$ and fixes the Gaussian. It is real, so $\mathfrak j_V\phi_*=\phi_*$.

Since $\varepsilon_Z^\dagger=(-1)^d\varepsilon_Z$ and reflection preserves polynomial degree,

$$R_Z(j_Eu)=(-1)^d(R_Z(u))^\dagger.$$

Uniqueness of the inverse of $h(D)$ on its range gives

$$\mathfrak j_B S_h^{\mathscr B}=(-1)^d S_h^{\mathscr B}\mathfrak j_B.$$

Both factors $(-1)^d$ are retained in the substitution, and their product is one. Therefore

$$\boxed{\mathfrak j_Bs=sj_E,\qquad
\mathfrak j_BP_Z=P_Z\mathfrak j_B.}\tag{23}$$

This is an actual equality for this section; it would not follow for an arbitrary choice of representatives. Its compatibility with the nonzero dilation homotopy is

$$\boxed{\mathfrak j_V k_a=a k_{1/a}j_E.}\tag{24}$$

Indeed, apply $\mathfrak j_B$ to (12), use $\mathfrak j_BU_a=aU_{1/a}\mathfrak j_B$ and (23), then use injectivity of theta. The split lift is semilinear through $r^\bullet\mapsto\bar r^\bullet$, which fixes both $e$ and $\tau$.

## 7. A finite-rank Lefschetz trace on the actual chain complex

For $f\in C_c^\infty(\mathbb R_{>0})$, let $\mathsf U_f$ be its convolution action on $C_+$. The cochain endomorphism

$$\mathsf p_Z\mathsf U_f=(0,sJH_f)$$

has finite-rank components. Its cochain supertrace is therefore defined without an infinite-dimensional regularization:

$$\boxed{\operatorname{Str}(\mathsf p_Z\mathsf U_f\mid C_+)
=-\operatorname{Tr}(sJH_f\mid\mathscr B)
=-\sum_{\rho\in Z}m_\rho\mathcal Mf(\rho).}\tag{25}$$

The finite-rank identity $\operatorname{Tr}(AB)=\operatorname{Tr}(BA)$ reduces the middle expression to $\operatorname{Tr}(JH_fs\mid E)$; this is multiplication by $j_h\mathcal Mf$. Equation (25) equals the supertrace of the induced operator on homology. On $C_{+-}$ its degree-zero contribution is still zero, since the same cochain projector has zero degree-zero component.

The boundary representatives in (6), (14), and (20) are retained even though their contribution to homology is zero. The finite-rank trace does not delete their complex or assign its zero to external absence.

For the $n$-fold tensor complex over the tau-base product, use the original coefficient tensor over $\mathbb C$ and its differential

$$d(x_1\otimes\cdots\otimes x_n)=
\sum_j(-1)^{\sum_{i<j}|x_i|}
 x_1\otimes\cdots\otimes dx_j\otimes\cdots\otimes x_n.$$

The projector $\mathsf p_Z^{\otimes n}$ has image $E^{\otimes n}[-n]$. For independently specified tests $f_1,\ldots,f_n$,

$$\operatorname{Str}\left(\bigotimes_j(\mathsf p_Z\mathsf U_{f_j})\right)
=(-1)^n\prod_j\sum_{\rho\in Z}m_\rho\mathcal Mf_j(\rho).\tag{26}$$

Let $A=U_a\mathsf p_Z$ and $B=\mathsf p_ZU_a$ as cochain maps. A homotopy for $A^{\otimes n}-B^{\otimes n}$ is

$$\sum_{j=1}^nB^{\otimes(j-1)}\otimes\mathsf H_a\otimes A^{\otimes(n-j)},$$

with the displayed Koszul sign on homogeneous inputs when the degree-minus-one map crosses the preceding factors. The telescoping identity and (14) prove it. The full support mask maps to the product of its input masks; vanishing products of represented amplitudes stay supported.

## 8. What now enters the Weil II programme

The structural base, the infinite quotient, and the actual theta complex are unchanged. The new objects are the extension (3), its unit class (4), its synchronized homotopy (20), its strict equivariant derived roof (16), and the chain trace (25). The arithmetic residue unit in (21) is now supplied by that very extension rather than appended without its source.

Deligne's inspected comparison-image argument (Weil II 3.3.4–3.3.6) requires two weight bounds on the same cohomological image. The inspected derived formulation (6.2.1–6.2.7) retains the dualizing operation, its degree and Tate shifts, and its exchange of direct-image functors. This continuation supplies coherent arithmetic maps and finite trace operations for the tau model; it does not transfer the finite-field hypotheses or assert those two bounds.

The retained error is explicit: it is the original boundary $\Theta k_a$ on representatives, with the nonzero Ext class (4). It is removed at homology by the original supported quotient, not by making its input absent. A geometric comparison can now be tested for compatibility with this class and the residue map (21). A complex-linear section that ignores (6) fails that test.

No infinite sum of packet projectors is asserted to converge. The existing meromorphic/kernel summand from PR #8 remains in its own exact sequence, and a different global trace functor must retain or analyze its contribution. The source's finite-jet isomorphisms and the new finite-rank chain trace do not by themselves set that summand to zero.

## 9. Verification and references

The new finite checker tests polynomial remainder identities, the extension class, rank-one scaling defects, cochain homotopies, dilation cocycles, residue contraction, tensor signs, trace identities, and original support operations. These finite algebraic models are not numerical tests of zeta zeros and not certificates for the analytic range theorem. No Lean execution is claimed for this continuation.

Read source interfaces:

- PR #8 at the pinned revision above, `FINITE_OPERATOR_COMPARISON.md`, sections 1–10; `TAU_BASE_MODEL.md` is its already-published model.
- Owner's `SplitZero_Derived_Mathematics_2026-09-12(1).md`, sections 1–7. In particular its allowance of a nonzero bottom fibre and the exact homology-kernel/action theorems are retained.
- `formal/splitzero/SplitZeroHomology.lean`, lines 175–end, read at the same revision; blob `7b9e5c49a494dd0c751133e0234b3e01048f7b67`.
- Supplied Deligne TeX excerpts: French segment 2, original lines 882–950; segment 3, original lines 675–756. The used equations are the image bounds and duality operations, not every assertion in the historical transcription. No source corpus is republished with this contribution.
- The Stacks Project, Tags 010I and 06XP, for extension classes and their projective-resolution interpretation.
- R. Meyer, *A spectral interpretation for the zeros of the Riemann zeta function*, arXiv:math/0412277, for prior spectral-realization context. No global priority claim is made here.

New calculations are AI-assisted work under the owner's programme. Existing mathematical files, formalizations, licensing, and source attribution remain untouched.


\clearpage

# A global retraction of the original theta complex over the tau base

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-global-retraction/RESEARCH_NOTE.md). Module: `workbenches/tau-global-retraction/RESEARCH_NOTE.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Owner-directed continuation of Zeta PR #9, 12 September 2026. New derivations are submitted as research proofs for review, not as Lean-certified analytic theorems.

## 0. Fixed source, result, and provenance

The base is PR #9 at `8f99b94d306c3b1aaa817d52c57fa6fd298d511c`; its chain-descent note has Git blob `86db838e79d10a8fe7d4376303706c4ea64570a1`. Its source and the owner's derived SplitZero attachment remain the inputs. This continuation constructs an inverse on the entire original theta image, not only on a chosen finite spectral packet.

Retain

$$G(R)=\{\tau\}\sqcup\{r^\bullet:r\in R\},\qquad e_R=0_R^\bullet,$$

$$\mathfrak b_\tau=\operatorname{Spec}\mathbf F_{1,\tau},\qquad
\begin{array}{ccc}G(\mathbb Z)&\xrightarrow{G(j)}&G(\mathbb C)\\
p_{\mathbb Z}\downarrow&&\downarrow p_{\mathbb C}\\
\mathbb Z&\xrightarrow{j}&\mathbb C.\end{array}\tag{1}$$

The first vertical target is still infinite. The geometric base, the original additive laws, and the arithmetic quotient are unchanged. The auxiliary cutoffs below are parameters of an explicit continuous representative map; they do not change an Euler factor, the theta relation space, or the completed zeta function.

**Result.** For every pair of the cutoffs specified in section 3 there is an explicitly constructed continuous complex-linear map

$$\Lambda_{\alpha,\beta}:\mathscr B\longrightarrow V,\qquad
\boxed{\Lambda_{\alpha,\beta}\Theta=\operatorname{id}_V.}\tag{2}$$

Consequently the actual image $\Theta V$ is closed and complemented in the stated strong-Schwartz topology. The original quotient $Q=\mathscr B/\Theta V$ is Hausdorff. The note constructs its global section, the full supported cochain homotopy, the exact change of the finite sections in #9, its continuous dual sequence, and the completed tensor powers. The proof does not assume RH, simplicity of any zero, or vanishing of the separate balanced-Mellin kernel.

Spectral realizations on nuclear Frechet spaces are prior work, notably R. Meyer, arXiv:math/0412277. That paper's abstract was consulted for scope, but no theorem from an unread body of that paper is imported. The proof below is given for the workbench's precise spaces. No global novelty claim is made.

## 1. Spaces and all transforms

Let

$$V=\{\phi\in\mathcal S(\mathbb R):\phi(-x)=\phi(x),\ \phi(0)=0,\ \int_{\mathbb R}\phi(x)\,dx=0\},$$

$$\mathscr B=\{F\in C^\infty(\mathbb R_{>0}):
p_{b,k}(F):=\sup_{x>0}x^b|D^kF(x)|<\infty
\text{ for every }b\in\mathbb Z,\ k\ge0\},\qquad D=-x\partial_x.\tag{3}$$

These seminorms give $\mathscr B$ its Frechet topology; under $x=e^y$ they are the weighted uniform derivative seminorms on smooth functions of $y$. Completeness follows by uniform convergence on compact sets of every derivative, followed by the weighted bounds. $V$ has its closed-subspace Schwartz topology.

The original maps are

$$\Theta\phi(x)=\sum_{n\in\mathbb Z\setminus\{0\}}\phi(nx)
=2\sum_{n\ge1}\phi(nx),$$

$$\mathcal F\phi(\xi)=\int_{\mathbb R}\phi(x)e^{-2\pi i x\xi}\,dx,\qquad
\mathcal F^{-1}u(x)=\int_{\mathbb R}u(\xi)e^{2\pi i x\xi}\,d\xi,$$

$$JF(x)=x^{-1}F(1/x),\qquad
\mathcal MF(s)=\int_0^\infty F(x)x^s\,\frac{dx}{x}.\tag{4}$$

Poisson summation, with both source moments zero, gives

$$\Theta\mathcal F=J\Theta,\qquad J^2=1,\qquad D J=J(1-D).\tag{5}$$

The theta sum and each derivative converge absolutely on closed subsets of $x>0$. At infinity, Schwartz estimates give all $p_{b,k}$ bounds. At zero use (5) and the same estimates on $\widehat\phi$. This proves continuity $\Theta:V\to\mathscr B$. Also $J$ is continuous on $\mathscr B$: $p_{b,k}(JF)$ is bounded by the binomial sum of $p_{1-b,j}(F)$, $0\le j\le k$.

The original complex is $C_+=[V\xrightarrow\Theta\mathscr B]$ in degrees $0,1$, over $A=\mathbb C[t]$ with $t$ acting as $D$. The two-leg tau chart retains $C_{+-}=[V^2\to\mathscr B]$ with differential $\Theta(\phi-\widehat\psi)$ and source action $(D,1-D)$.

## 2. Arithmetic inversion on the two exterior regions

Let $\mu$ be the ordinary Mobius function, characterized by

$$\sum_{d\mid n}\mu(d)=\begin{cases}1,&n=1,\\0,&n>1.\end{cases}$$

For $F\in\mathscr B$ define, for $x\ne0$,

$$\boxed{\mathcal U F(x)=\frac12\sum_{n\ge1}\mu(n)F(n|x|).}\tag{6}$$

The factor $1/2$ is the inverse of the full nonzero-integer theta sum in (4). The map is complex-linear into smooth even functions on $\mathbb R\setminus\{0\}$. It is not asserted to be smooth at zero for arbitrary $F$.

Here are the required estimates. For $j\ge0$, let $P_j(T)=(-1)^jT(T+1)\cdots(T+j-1)$, with $P_0=1$. Then $x^j\partial_x^j=P_j(D)$. If $C_{N,j}(F)$ is the sum of the $p_{N,k}(F)$ weighted by the absolute coefficients of $P_j$, then, for $x>0$ and integer $N>1$,

$$|\partial_x^j\mathcal U F(x)|
\le\frac12\zeta(N)C_{N,j}(F)x^{-N-j}.\tag{7}$$

Indeed each summand is bounded by $C_{N,j}(F)n^{-N}x^{-N-j}/2$. This proves convergence of every derivative uniformly for $|x|\ge\delta>0$, and gives rapid decay there. It also proves continuity of the cut-off exterior maps used below.

For every $\phi\in V$,

$$\boxed{\mathcal U\Theta\phi(x)=\phi(x),\qquad
\mathcal U J\Theta\phi(x)=\widehat\phi(x)\quad(x\ne0).}\tag{8}$$

For the first equality the double series is absolutely convergent for each $x>0$: its absolute value is bounded by $\sum_{k\ge1}d(k)|\phi(kx)|$, which is finite by Schwartz decay. Rearrange by $k=mn$ and use the displayed divisor identity. Evenness handles negative $x$. The second equality follows from (5) and the first equality applied to $\widehat\phi\in V$.

In the split lift, every $\mu(n)$ is the supported integer $\mu(n)^\bullet$, including $\mu(n)=0$. A convergent sum within a specified active fibre begins at that fibre's zero and is taken in that fibre's vector-space topology. Formula (8) thus lifts to a support-preserving equality. A computed cancellation is not external absence.

## 3. The reconstruction operator, with the strict contraction proved

Choose and retain real, even $\alpha,\beta\in C_c^\infty(\mathbb R)$ satisfying $0\le\alpha,\beta\le1$ and equal to $1$ on neighborhoods of zero. Their supports and all values are part of the auxiliary data. Work on $\mathcal H=L^2(\mathbb R,dx)$ with the Fourier convention in (4).

Define bounded operators

$$A_\alpha=M_\alpha,\qquad
B_\beta=\mathcal F^{-1}M_\beta\mathcal F,\qquad
T_{\alpha,\beta}=A_\alpha B_\beta.\tag{9}$$

**Lemma.** $T_{\alpha,\beta}$ is compact and $c_{\alpha,\beta}:=\|T_{\alpha,\beta}\|<1$.

**Proof.** Its kernel is $\alpha(x)\check\beta(x-y)$, whose squared integral is $\|\alpha\|_2^2\|\beta\|_2^2$. Hence it is Hilbert-Schmidt. Both factors are contractions. If the norm were $1$, compactness would supply a unit vector $f$ attaining it. Equality in

$$\|A_\alpha B_\beta f\|\le\|B_\beta f\|\le\|f\|$$

forces $\widehat f$ to be supported where $\beta=1$; there $B_\beta f=f$. The first equality forces $f$ to be supported where $\alpha=1$. Both supports are compact. The inverse Fourier transform of compactly supported $\widehat f\in L^2$ is entire, by differentiation under its finite-interval integral. Its continuous restriction agrees with the compactly supported $f$, so it vanishes on an open real interval and hence identically. This contradicts $\|f\|=1$. Thus $c_{\alpha,\beta}<1$.

Consequently the exact Neumann inverse exists:

$$\boxed{(1-T_{\alpha,\beta})^{-1}=\sum_{k\ge0}T_{\alpha,\beta}^k,
\qquad\|(1-T_{\alpha,\beta})^{-1}\|\le\frac1{1-c_{\alpha,\beta}}.}\tag{10}$$

No uniform bound as the cutoffs vary is claimed. In particular the gap $1-c_{\alpha,\beta}$ is retained, not replaced by a positive universal constant.

The operator $T_{\alpha,\beta}$ maps $L^2$ continuously to the Schwartz space. For each derivative, compact Fourier support and Cauchy-Schwarz bound $\partial^j B_\beta f$ uniformly by a constant times $\|f\|_2$; multiplication by the smooth compactly supported $\alpha$ gives every Schwartz seminorm.

Define the two exterior data and their combination:

$$a_F=(1-\alpha)\mathcal U F,\qquad
b_F=(1-\beta)\mathcal U JF,$$

$$Y_{\alpha,\beta}F=a_F+\alpha\mathcal F^{-1}b_F.\tag{11}$$

The exterior terms are extended by zero near the origin, where their cutoff is identically zero. Estimates (7) prove that both are even Schwartz functions and depend continuously on $F$. Therefore $Y:\mathscr B\to\mathcal S(\mathbb R)^{\mathrm{even}}$ is continuous.

Put

$$\Phi_{\alpha,\beta}F=(1-T_{\alpha,\beta})^{-1}Y_{\alpha,\beta}F.\tag{12}$$

This initially defines an $L^2$ vector, but the identity $\Phi F=YF+T\Phi F$ proves it is Schwartz. If $q$ is any Schwartz seminorm and $q(Tu)\le C_q\|u\|_2$, then

$$q(\Phi F)\le q(YF)+\frac{C_q}{1-c_{\alpha,\beta}}\|YF\|_2.\tag{13}$$

This is an explicit continuity estimate. Both sides are even because the cutoff operators preserve parity.

For $F=\Theta\phi$, equations (8) give

$$Y\Theta\phi=(1-A_\alpha)\phi+A_\alpha(1-B_\beta)\phi
=(1-T_{\alpha,\beta})\phi,$$

hence

$$\boxed{\Phi_{\alpha,\beta}\Theta\phi=\phi.}\tag{14}$$

## 4. Keep both original moment conditions

For arbitrary $F$, (12) need not satisfy the two source moments. The correction is the following specified projection, not an alteration of $V$.

Retain

$$\gamma_0(x)=e^{-\pi x^2},\qquad
\gamma_2(x)=2\pi x^2e^{-\pi x^2}.$$

Their moment columns $(\phi(0),\int\phi)$ are $(1,1)$ and $(0,1)$. Define

$$\mathsf m(\phi)=\bigl(\phi(0),\int_{\mathbb R}\phi\bigr),\qquad
j_0(a,b)=a\gamma_0+(b-a)\gamma_2,$$

$$P_V\phi=\phi-j_0\mathsf m(\phi)
=\phi-\phi(0)\gamma_0-\left(\int\phi-\phi(0)\right)\gamma_2.\tag{15}$$

Then $\mathsf m j_0=1$, $P_V^2=P_V$, $\operatorname{im}P_V=V$, and $P_V|_V=1$. All maps are continuous.

The promised map is

$$\boxed{\Lambda_{\alpha,\beta}=P_V(1-T_{\alpha,\beta})^{-1}Y_{\alpha,\beta}:\mathscr B\to V.}\tag{16}$$

Equation (14) and $P_V|_V=1$ prove (2). The discarded moment vector has the recorded map $\mathsf m\Phi:\mathscr B\to\mathbb C^2$ and the explicit correction $j_0\mathsf m\Phi$. It vanishes on the actual theta image. No endpoint constant was absorbed into the zeta function.

## 5. The full quotient is closed and has a continuous section

Write $\Lambda=\Lambda_{\alpha,\beta}$, and define

$$P_\Theta=\Theta\Lambda,\qquad K=1_{\mathscr B}-\Theta\Lambda.\tag{17}$$

Direct substitution gives

$$P_\Theta^2=P_\Theta,\quad K^2=K,\quad
\ker K=\Theta V,\quad\operatorname{im}K=\ker\Lambda.\tag{18}$$

Since $K$ is continuous, its kernel is closed. Thus $Q=\mathscr B/\Theta V$ with its actual quotient topology is Frechet and Hausdorff. If $q:\mathscr B\to Q$ is the original quotient map, the continuous section is

$$\boxed{s:Q\to\mathscr B,\qquad s[F]=KF,\quad qs=1,\quad\Lambda s=0.}\tag{19}$$

The explicit topological direct-sum isomorphism is

$$\boxed{V\oplus Q\xrightarrow{\sim}\mathscr B,
\quad(\phi,u)\mapsto\Theta\phi+su,
\quad F\mapsto(\Lambda F,qF).}\tag{20}$$

For a convergent sequence $\Theta\phi_n\to F$ in $\mathscr B$, one can check the closedness without any abstract theorem: $\phi_n=\Lambda\Theta\phi_n\to\Lambda F$ in $V$, so $F=\Theta\Lambda F$ by continuity of theta.

This computes the earlier Hausdorff arrow:

$$Q^{\mathrm{alg}}=\mathscr B/\Theta V\longrightarrow
Q^{\mathrm H}=\mathscr B/\overline{\Theta V},\qquad[F]\mapsto[F],\tag{21}$$

as an isomorphism with zero amplitude kernel. It does not say the map from $Q$ into its product of spectral jets is injective. The latter map and the balanced analytic map still have their own named kernels:

$$Q\to\prod_\rho\mathcal O_\rho/(g),\qquad
\mathcal O\otimes_{\mathbb C[t]}Q\xrightarrow{\beta}\mathcal O/(g).$$

No claim that $\mathcal R_\infty$ or $\ker\beta$ vanishes is inferred from (21).

### Smaller admitted relations

For any specified subspace $W\subset V$, retain

$$Q_W=\mathscr B/\Theta W\longrightarrow Q,\qquad
\ker=\Theta V/\Theta W\cong V/W.\tag{22}$$

The isomorphism sends $[\phi]\mapsto[\Theta\phi]$. It is algebraic for arbitrary $W$; when $W$ is closed, (20) makes it a topological isomorphism onto the kernel. The pullback of the global section has the representative relation kernel in (22); the full-source result is not silently asserted with $W$ in place of $V$.

## 6. Perform the original internal quotient and synchronization

On the single-leg map, or a fixed-index diagram of that same map, the split lifts are

$$\widetilde\Theta(\lambda,\phi)=(\lambda,\Theta\phi),\quad
\widetilde\Lambda(\lambda,F)=(\lambda,\Lambda F),\quad
\widetilde K(\lambda,F)=(\lambda,KF).\tag{23}$$

They preserve external bottom and commute with scalar reflection. In particular

$$\widetilde K\widetilde\Theta(\lambda,\phi)=(\lambda,0_{\mathscr B})=z_{V,\mathscr B}(\lambda,\phi).$$

Here $z_{V,\mathscr B}$ is the label-preserving zero map from the source fibre to the target fibre. The mixed chart, whose minus restriction is $-\Theta\mathcal F$, is treated separately by the explicit maps (25)-(28), without changing that restriction. The actual chart has zero bottom fibre; a general nonzero bottom fibre is acted on by its stated linear map, rather than identified with the single global zero.

The supported image projection is idempotent, and the quotient map is exactly the coequalizer of the theta relation inclusion and its supported-zero companion. The implementation's universal property applies against all split-linear targets. A theta boundary is sent to $e_\lambda=(\lambda,0)$; it is not sent to external absence.

For the single-leg complex there is an actual continuous contraction in complexes of locally convex complex vector spaces, after forgetting $A=\mathbb C[t]$-linearity:

$$C_+\ \xrightleftharpoons[s]{q}\ Q[-1],\qquad H^1=\Lambda,$$

$$\boxed{q s=1,\qquad 1_{C_+}-s q=dH+Hd.}\tag{24}$$

In degree zero this is $\Lambda\Theta=1_V$; in degree one it is $\Theta\Lambda=1-K$. In split notation the subtraction means addition of the supported scalar $(-1)^\bullet$ times the second map. It yields the correct labelled zero wherever the amplitude vanishes.

For the two-leg chart set $H_0=V[0]\oplus Q[-1]$ with zero differential, and define

$$p_L^0(\phi,\psi)=\psi,\quad p_L^1=q,\qquad
i^0(\psi)=(\widehat\psi,\psi),\quad i^1=s,$$

$$H_L^1(F)=(\Lambda F,0).\tag{25}$$

Then $p_L i=1$, and $1-i p_L=dH_L+H_Ld$. The degree-zero identity is $(\phi,\psi)-(\widehat\psi,\psi)=(\phi-\widehat\psi,0)$.

The other leg gives

$$p_R^0(\phi,\psi)=\widehat\phi,\quad p_R^1=q,\qquad
H_R^1(F)=(0,-\widehat{\Lambda F}).\tag{26}$$

It obeys $1-i p_R=dH_R+H_Rd$. Their homotopies differ by

$$\boxed{H_L^1F-H_R^1F=(\Lambda F,\widehat{\Lambda F}),}\tag{27}$$

the actual joint degree-zero cycle, which is retained.

On the complete original support diagram, use literal multiplication by $E_{\mathrm{sync}}=(1,e)$ in degree zero and the source's active-label-to-joint map in degree one:

$$\mathfrak r^0(a,b)=(a+eb,b+ea),\qquad
\mathfrak r^1(\lambda,F)=(\{+,-\},F)\quad(\lambda\ne\bot).$$

The absent input remains absent. The original differential obeys $d\mathfrak r=\mathfrak r d$ and $\mathfrak r^2=\mathfrak r$. Consequently (25) lifts to the fully typed equation

$$\boxed{\mathfrak r-\widetilde i\widetilde p_L\mathfrak r
=\widetilde d\,\widetilde H_L+\widetilde H_L\widetilde d,}\tag{28}$$

where $\widetilde H_L(\lambda,F)=(\{+,-\},(\Lambda F,0))$ for each active label. The right-leg equation is analogous with (26). The original mask is recorded with the injection $x\mapsto(\operatorname{supp}x,\mathfrak r x)$ already proved for this chart. Neither synchronization nor the contraction identifies the three supported origins with $\tau$.

## 7. Global scaling defects, and their agreement with the finite extensions

Let $U_aF(x)=F(x/a)$, $a>0$, and denote its induced continuous action on $Q$ by $\overline U_a$. The section (19) gives a global continuous boundary map

$$\boxed{k_a=\Lambda U_a s:Q\to V,\qquad
U_a s-s\overline U_a=\Theta k_a.}\tag{29}$$

The proof applies $K+\Theta\Lambda=1$ to $U_as$, then uses $qU_as=\overline U_a$. Therefore

$$k_{ab}=U_a k_b+k_a\overline U_b,\qquad k_1=0.\tag{30}$$

The same calculation works for $D$ and compactly supported multiplicative convolution, with $k_D=\Lambda D s$. In the explicit coordinates (20),

$$\boxed{U_a|_{\mathscr B}=\begin{pmatrix}U_a|_V&k_a\\0&\overline U_a\end{pmatrix},
\qquad D|_{\mathscr B}=\begin{pmatrix}D|_V&k_D\\0&D_Q\end{pmatrix}.}\tag{31}$$

Thus the topological splitting is not substituted for an equivariant splitting. Equation (29) is the precise comparison between them.

For two cutoff choices, let $s_0,s_1$ be their sections and set $b_{10}=\Lambda_0s_1:Q\to V$. Then

$$s_1-s_0=\Theta b_{10},\qquad
k_a^{(1)}=k_a^{(0)}+U_ab_{10}-b_{10}\overline U_a.\tag{32}$$

All dependence on the chosen representative map is carried by this displayed coboundary. No canonical cutoff or average over choices is declared.

### Restrict back to PR #9 without changing its extension class

Use its existing maps $s_Z:E_Z\to\mathscr B$, $\sigma_Z=q s_Z:E_Z\to Q$, and $J_Z:\mathscr B\to E_Z$. Put $b_Z=\Lambda s_Z$. The new continuous representative of the same finite arithmetic class is

$$s_Z^{\mathrm{new}}=s\sigma_Z=K s_Z=s_Z-\Theta b_Z.\tag{33}$$

If $P(D)s_Z-s_ZM_P=\Theta k_{P,Z}$, direct substitution gives

$$k_{P,Z}^{\mathrm{new}}=k_{P,Z}-P(D)b_Z+b_ZM_P.\tag{34}$$

For $P=h_Z$, this changes the source boundary by $-h_Z(D)b_Z$. It is zero in $V/h_Z(D)V$, so the extension class remains exactly

$$\varepsilon_Z=j_{h_Z}(h_Z/g),\qquad g=2\xi.\tag{35}$$

The polynomial residue form still becomes the arithmetic one by $M_{\varepsilon_Z}$; its Jacobian contraction remains $M_{\varepsilon_Z}M_{j_h g'}$. No unit, derivative, sign, or factor of $2$ is changed.

The two finite cochain projectors differ by the explicit homotopy $-b_ZJ_Z$ in degree minus one. Their finite-rank trace difference is zero because $J_Z\Theta=0$. Hence their cochain Lefschetz trace is the unchanged

$$-\sum_{\rho\in Z}m_\rho\mathcal Mf(\rho).\tag{36}$$

## 8. Continuous duality and completed tensor powers of the full object

Use continuous duals, denoted $E'_b$ with the strong topology. Transpose the actual topological splitting (20). It gives

$$\boxed{0\to Q'_b\xrightarrow{q'}\mathscr B'_b
\xrightarrow{\Theta'}V'_b\to0,\qquad \Theta'\Lambda'=1.}\tag{37}$$

The continuous cochain-dual complex is $[\mathscr B'_b\xrightarrow{\Theta'}V'_b]$ in degrees $-1,0$. Its cohomology is $Q'_b$ in degree $-1$ and zero in degree $0$. The transpose contraction proves this directly; no general exactness theorem for arbitrary locally convex quotients is assumed.

For a finite packet $Z$ stable under $\rho\mapsto1-\overline\rho$, with the full multiplicities retained as in PR #9, the actual finite residue map into that continuous dual is

$$\overline{E_Z}\longrightarrow Q'_b,\qquad
\bar f\longmapsto\bigl(u\mapsto R_Z(f,j_Zu)\bigr),\tag{38}$$

where $j_Zq=J_Z$. Continuity follows from the finite Mellin jets and finite dimensionality of $E_Z$. It is injective by their surjectivity and perfect residue duality. Multiplication by $g'$ then gives the arithmetic finite trace pairing, with its previously calculated radical retained.

Let $\widehat\otimes_\pi$ denote completed projective tensor product. The comparison from the previous algebraic tensor is its canonical completion map. All chain operators in (24) are continuous. Thus their finite tensor products and homotopies extend to the completed products. With $P=sq$ on $C_+$, the homotopy

$$H_n=\sum_{j=1}^n P^{\widehat\otimes(j-1)}\widehat\otimes H
\widehat\otimes1^{\widehat\otimes(n-j)}\tag{39}$$

includes $(-1)^{\sum_{i<j}|x_i|}$ on homogeneous inputs. It satisfies

$$dH_n+H_nd=1-P^{\widehat\otimes n}.$$

Consequently, for the completed external coefficient complex on the same tau-base chart product,

$$\boxed{H^k(C_+^{\widehat\otimes n})=
\begin{cases}Q^{\widehat\otimes n},&k=n,\\0,&k\ne n.\end{cases}}\tag{40}$$

This follows from a split continuous contraction, not from a blanket claim that completed tensor product preserves every exact sequence.

For the joint chart use (25). Its full cohomology in degree $k$ is the direct sum, indexed by subsets $J\subseteq\{1,\ldots,n\}$ with $|J|=k$, of the ordered completed tensors having $Q$ in the slots of $J$ and $V$ in the other slots. In those $V$ slots the scaling action is $aU_{1/a}$, exactly as in the original minus-coordinate representative. The degree-zero contribution is not discarded. Split reconstruction retains each product mask and each internal zero.

## 9. The pairing calculation is now a specified global boundary problem

The section $s:Q\to\mathscr B\subset L^2(dx)$ supplies a positive definite auxiliary form

$$\mathcal H_s(u,v)=\langle su,sv\rangle_{L^2(dx)}.$$

This is not assigned to the arithmetic Weil form. The explicit weight-covariance defect is calculated using (29) and $\langle U_af,U_ag\rangle=a\langle f,g\rangle$:

$$\boxed{\begin{aligned}
\mathcal H_s(\overline U_au,\overline U_av)-a\mathcal H_s(u,v)
={}&-\langle U_asu,\Theta k_av\rangle
-\langle\Theta k_au,U_asv\rangle\\
&+\langle\Theta k_au,\Theta k_av\rangle.
\end{aligned}}\tag{41}$$

The original source boundary and both of its cross-pairings remain. Being a boundary in $Q$ does not assert these pairings are zero in the representative Hilbert space. In a split lift each computed zero is its supported value $e$.

For a reduced eigenline of the actual dilation representation with exponent $\rho$, the left side at $u=v$ is $(a^{2\Re\rho}-a)\mathcal H_s(u,u)$. Formula (41) locates that defect in the full global boundary cocycle, with the original operator retained.

### A concrete comparison explaining which topology must be kept

In fact $\Theta V$ is dense in $L^2(\mathbb R_{>0},dx)$, although it is closed in $\mathscr B$. Here is a proof retaining the map between them. Set $b_*=\Theta\phi_*$ and

$$W:L^2(dx)\xrightarrow{\sim}L^2(dy),\qquad WF(y)=e^{y/2}F(e^y).$$

The Fourier transform in $y$, with kernel $e^{-2\pi i\nu y}$, gives

$$\mathcal F_yWb_*(\nu)=g(1/2-2\pi i\nu).$$

This is nonzero almost everywhere, because $g$ is a nonzero entire function. The span of all translates of $Wb_*$ is dense in $L^2(dy):$ a vector orthogonal to all translates has Fourier transform whose product with $\overline{\mathcal F_yWb_*}$ is an $L^1$ function with zero Fourier transform, hence vanishes almost everywhere. The nonvanishing just stated then makes that vector zero. Since $WU_ab_*=a^{1/2}(Wb_*)(y-\log a)$ and $U_ab_*\in\Theta V$, density follows.

The exact quotient comparison is therefore

$$\boxed{Q=\mathscr B/\Theta V\longrightarrow
L^2(dx)/\overline{\Theta V}^{L^2}=0.}\tag{42}$$

Its kernel is all of $Q$. Its split lift sends every supported input to the supported zero in $G(0)=\mathbb B$, while keeping external absence separate. The constructive replacement is the Frechet quotient and the explicit global section (19), not a claim that the ordinary Hilbert quotient secretly retains those classes.

## 10. Scope of the progress toward the Deligne comparison

The selected supplied Weil II passages 3.3.4-3.3.6 put two bounds on the same compact-to-ordinary image; 6.2 retains the dualizing operation and its shifts. This continuation does not apply those bounds over a new base without their geometric proof. It makes the existing characteristic-zero arithmetic complex globally split in its precise topological category, gives its continuous dual and completed products, and computes the operator defects on those same objects.

The formerly unresolved algebraic-to-Hausdorff kernel is now zero by (16)-(21). The finite extension class and its residue/Jacobian trace are carried by (33)-(36). The full scaling boundary is (29), its dependence on the auxiliary cutoffs is (32), and its metric defect is (41). These are concrete maps available for a global comparison.

Still retained: the common kernel of all finite spectral observations, the meromorphic summand of the balanced analytic realization, and the requirement to identify the correct arithmetic polarization/weight control on the global geometric image. The density map (42) explains why discarding the stronger topology would remove the entire arithmetic cohomology, not why the supported programme should be abandoned.

The reconstruction estimate contains $1-c_{\alpha,\beta}$; no asymptotic uniform estimate for it is proved. No global positivity, RH, GRH, or infinite trace-class theorem is claimed. No theorem from the earlier finite-range work is upgraded to a Lean certificate. The new global retraction proof itself uses only the original theta/Poisson identities, absolute Mobius inversion, the displayed Fourier compactness argument, and the two retained moment maps.

## 11. Verification and references

The written analytic proofs are the evidence for the new analytic statements. The accompanying unittest script tests exact finite identities: divisor cancellation with supported zeros, cutoff-resolvent identities in a finite unitary model, moment corrections, contractions, synchronization masks, operator cocycles, changes of sections, preservation of extension classes, finite trace changes, and completed-tensor algebra before completion. It does not numerically certify a Fourier operator norm, an analytic convergence statement, or a Riemann zero.

Source interfaces read:

- Owner's `SplitZero_Derived_Mathematics_2026-09-12(1).md`, sections 1-7; the source permits nonzero bottom fibres in its general interface.
- PR #9, `workbenches/tau-chain-descent/RESEARCH_NOTE.md`, at the commit above; local bytes match its Git blob.
- PR #8's finite comparison as retained and invoked in #9; the sections using $s_Z$ and $J_Z$ are explicitly dependencies of (33)-(38), not inputs to the proof of (2).
- Supplied Weil II TeX: the actual 3.3.1-3.3.6 excerpt, including its finite-type base and duality assumptions. It was read as TeX, not obtained by OCR. No full source-proof audit is claimed.
- Ralf Meyer, *A spectral interpretation for the zeros of the Riemann zeta function*, arXiv:math/0412277: prior-context abstract only in this continuation. A source-archive retrieval failed; no unread detailed theorem is cited as a premise.

The contribution is AI-assisted under the owner's mathematical direction. Original mathematical files, formal sources, attribution and licenses are unchanged. Only authored exposition, test code and validation records are proposed for public addition; no private transcript or source-literature corpus is published.


\clearpage

# The theta quotient in Meyer's spectral construction

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-global-retraction/MEYER_SOURCE_COMPARISON.md). Module: `workbenches/tau-global-retraction/MEYER_SOURCE_COMPARISON.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


This source comparison was added on 12 September 2026. It supplements, without rewriting, the original note's account of which literature its author consulted.

Ralf Meyer, [*A spectral interpretation for the zeros of the Riemann zeta function*](https://arxiv.org/abs/math/0412277), defines the zeta operator in section 3 by

$$Z\phi(x)=\sum_{n\geq1}\phi(nx).$$

His source $H_\cap$ is the space of even Schwartz functions with $\phi(0)=\widehat\phi(0)=0$. His target $H_-$ is the intersection, over all real $s$, of the multiplicative Schwartz spaces weighted by $x^{-s}$. The precise identifications with [the present note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-global-retraction/RESEARCH_NOTE.md) are

$$V=H_\cap,\qquad \mathscr B=H_-,\qquad \Theta=2Z|_V.$$

The factor 2 comes from pairing the positive and negative terms in the theta sum on even functions. The Fourier kernels with signs $+2\pi i x\xi$ and $-2\pi i x\xi$ agree on these even inputs. Meyer's local Euler operator $x\partial_x$ is the negative of the present $D=-x\partial_x$.

The target topologies also agree, not just their underlying functions. In logarithmic coordinates $x=e^y$, polynomial factors in $y$ are controlled by slightly stronger exponential weights. Conversely every real weight is bounded by neighboring integer weights. The weighted logarithmic Schwartz seminorms and the present integer-weight Euler-derivative seminorms therefore define the same Fréchet space.

Meyer's theorem following the Poisson formula in section 3 (source label `the:Zeta_estimate`) proves that $Z:H_+\to H_\cup$ is a topological embedding with closed range, and $Z\phi\in H_-$ exactly when $\phi\in H_\cap$. Its proof uses the continuous Möbius inverse on the exterior weighted space (label `pro:Z_invertible`), Poisson summation and simultaneous estimates of a function and its Fourier transform. Thus the closed-range assertion for $\Theta:V\to\mathscr B$ is already covered by this literature under the displayed maps.

The present note additionally writes an explicit continuous left inverse $\Lambda:\mathscr B\to V$ and the projection $K=1-\Theta\Lambda$, retaining their scaling defect. Closed range alone does not give that particular projection. This source comparison makes no priority claim about the projection or the later literature.

Source version checked: arXiv TeX `math_0412277.tex`, SHA-256 `ab9bc31f3c105a64fdc6f3b65ad16701dd8bf218fc90df98fe8d7f3c7c58c00e`; definitions at lines 240–279, zeta operator and inverse at 445–503, Poisson/source space and complete closed-range proof at 514–571. The source body and proof, not merely its abstract, were read for this comparison. No source-paper bulk text is reproduced here.


\clearpage

# Homotopy choices and source-preserving arithmetic control

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-homotopy-control/RESEARCH_NOTE.md). Module: `workbenches/tau-homotopy-control/RESEARCH_NOTE.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Owner-directed SplitZero continuation, 12 September 2026. Base: PR #10, d26c283c2a58da57bb5a5a4d4bc8669019f6ebb7. This integration note records the new derivations; the conversation delivery also contains a longer equation-by-equation exposition. No original scalar definitions or formal modules are changed.

## 1. Reviewed theorem and analytic specialization

The supplied other-session proof classifies all homotopies for

$$C=[V\oplus V\xrightarrow d B],\qquad d(v,w)=\Theta(v-\mathcal Fw),\qquad Q=B/\Theta V,$$

where Theta is injective and F is an R-linear automorphism. For a fixed kappa:B->V with kappa Theta=0, every solution of BOTH equations

$$dH=\Theta\kappa,\qquad Hd=0$$

has the unique form

$$H_\alpha(b)=(\kappa b+\alpha qb,\mathcal F^{-1}\alpha qb),\qquad\alpha:Q\to_R V.$$

Proof: writing H=(u,v), injectivity gives u-Fv=kappa. Since d(x,0)=Theta x, Hd=0 gives H Theta=0. Hence Fv factors uniquely through q, and supplies alpha. Conversely substitution proves both equations. The reference solution is H_0=(kappa,0); the family is an affine space under Hom_R(Q,V), relative to that reference.

Let gamma(v)=(v,F^-1 v). Then

$$H_\alpha-H_\beta=\gamma(\alpha-\beta)q.$$

The difference is a map H1(C)->H0(C). There are no degree-minus-two endomorphisms of this two-term coefficient complex. Thus it is a genuine degree-minus-one Hom-complex class, not an erased difference.

The supplied theorem is mathematically correct. Its Lean draft explicitly remains uncompiled, and its earlier failed chart build is not relabelled successful. No Lean or Lake executable is installed in the review environment.

**Superseding status, 12 September 2026.** The preceding execution statements record the original PR #11 review environment. The later [PR #12](https://github.com/KokunoYumeto/zeta-function-research-reader/pull/12), at head `5d2772ea0a16d177ac3e01ff70394b90ba95a232`, passed [run `34686934725`, job `103535438942`](https://github.com/KokunoYumeto/zeta-function-research-reader/actions/runs/34686934725/job/103535438942): seven formal algebra/quotient-topology modules and 87 selected axiom reports, including both cochain equations and the inverse homotopy equivalence. This is a later remote certificate, not a successful rerun of the earlier failed revision or a local Lean execution here. It does not certify the analytic theta construction, the new Gram/control arguments, or RH.

For the actual analytic spaces instantiate R=C. With the quotient topology on Q, the continuous version follows: alpha q=F pr2 H is continuous, so the quotient property makes alpha continuous. Conversely the displayed formula sends continuous alpha to continuous H.

For the polynomial action A0=C[t], Fourier has the exact type

$$\mathcal F:V^{\jmath}\xrightarrow{\sim}V,\qquad t\cdot_{V^\jmath}v=(1-D)v,\qquad\jmath(t)=1-t,$$

because F D=(1-D)F. Thus d is A0-linear from V+V^j to B. A complex-linear homotopy is not automatically A0-linear. The reflected module above is the actual comparison, not a change to the Fourier definition.

## 2. Original split support on every homotopy

Retain the base b_tau and the square G(Z)->G(C) over Z->C. The quotient G(Z)->Z remains infinite. Both lifted coefficient maps preserve tau and the supported scalar e separately.

Use the original support lattice L={bottom,+,-,J}, J={+,-}. Degree-zero fibres are 0,V,V,V+V with the coordinate inclusions. Degree-one active fibres are all B, with identity transports. Their differentials are Theta, -Theta F and d. Retain zero modules in the other degrees; their reconstructed zero map is z(lambda,x)=(lambda,0).

Literal multiplication by E_sync=(1,e) induces

$$r^0(a,b)=(a+eb,b+ea),\qquad r_L(\bot)=\bot,\quad r_L(\lambda)=J\ (\lambda\ne\bot).$$

Every homotopy lifts by

$$\widetilde H_\alpha(\lambda,b)=\bigl(J,(\kappa b+\alpha qb,\mathcal F^{-1}\alpha qb)\bigr),\quad\lambda\ne\bot;\qquad\widetilde H_\alpha(\tau)=\tau.$$

This is split-linear: two active inputs add at their joined label, both outputs add at J, and their amplitudes obey the two displayed linear formulas. A supported scalar zero gives (J,(0,0)); external tau gives the global zero. Therefore

$$\widetilde d\widetilde H_\alpha+\widetilde H_\alpha\widetilde d=r\widetilde\Delta.$$

The difference is (J,gamma(alpha-beta)qb), retaining its degree-zero class. For this chart, the pair (support(x),r(x)) is injective. No such injectivity is assumed for arbitrary diagrams with noninjective transports. For a smaller relation space W, keep Q_W->Q with kernel Theta V/Theta W; q in the formulas means the displayed quotient by the full admitted V.

## 3. Coherence for all dilations

Let S_a=U_a on V, T_a=U_a on B, U_a F(x)=F(x/a), and Tbar_a the quotient action. The actual cochain action is

$$\mathsf T_a^0=(S_a,\mathcal F^{-1}S_a\mathcal F)=(U_a,aU_{1/a}),\qquad\mathsf T_a^1=T_a.$$

It satisfies T_a^0 gamma=gamma S_a and qT_a=Tbar_aq. With the PR #10 section s, take P=(0,sq), and write

$$[\mathsf T_a,P]^1=\Theta\kappa_a,\qquad\kappa_a=k_aq,\qquad T_as-s\overline T_a=\Theta k_a.$$

The commutator product identity gives kappa_ab=S_a kappa_b+kappa_a T_b. The family of homotopies is composition-coherent,

$$H_{ab}=\mathsf T_aH_b+H_a\mathsf T_b,$$

exactly when

$$\boxed{\alpha_{ab}=S_a\alpha_b+\alpha_a\overline T_b.}$$

Proof: the reference family (kappa_a,0) is coherent. Subtract it and use injectivity of gamma and surjectivity of q. No action or boundary is omitted.

For a smoothly parameterized continuous-linear family with L=(d/dt)|_0 alpha_(e^t), the exact formula is

$$\alpha_{e^t}=\int_0^t S_{e^{t-r}}L\overline T_{e^r}\,dr.$$

This is a vectorwise integral in the complete Frechet source, with the original oriented integral for negative t. Differentiating the composition equation gives the formula; splitting the integral proves its converse. In particular alpha_a=S_a b-b Tbar_a has infinitesimal parameter D_V b-bD_Q.

## 4. A homotopy parameter leaves the control form fixed

Fix an actual finite arithmetic packet with full multiplicities,

$$h_Z(t)=\prod_{\rho\in Z}(t-\rho)^{m_\rho},\qquad E_Z=\mathbb C[t]/(h_Z),\qquad A=M_t.$$

Use the existing R:E_Z->B and J_Z:B->E_Z with

$$qR=\sigma_Z,\quad J_ZR=1,\quad J_Z\Theta=0,\quad J_ZD=AJ_Z,\quad DR-RA=\Theta k.$$

The cochain projector P_R=(0,RJ_Z) has commutator (0,Theta kJ_Z), so the reviewed theorem applies with kappa=kJ_Z. The quotient jet Jbar_Z satisfies Jbar_Z sigma_Z=1, hence any alpha_E:E_Z->V extends to alpha_E Jbar_Z on Q. Restriction to R gives

$$\boxed{H_{\alpha_E}R=(k+\alpha_E,\mathcal F^{-1}\alpha_E),\qquad dH_{\alpha_E}R=\Theta k.}$$

Take H=L2(R_+,dx) with the original inner product, conjugate-linear in the first variable. Define

$$G_R=R^*R,\qquad B_R=\Theta k,\qquad W_R=-(R^*B_R+B_R^*R).$$

The composite of actual maps

$$\operatorname{Hom}_{\mathbb C}(E_Z,V)\longrightarrow\operatorname{Hom}(E_Z,V^2)\xrightarrow{d\circ(-)}\operatorname{Hom}(E_Z,H)\xrightarrow{B\mapsto-(R^*B+B^*R)}\operatorname{Herm}(E_Z)$$

is constant at W_R. Its last map is real-linear. The retained H0 ambiguity does not change this boundary contraction.

Integration by parts on the actual source functions gives

$$\boxed{A^*G_R+G_RA-G_R=W_R.}$$

The boundary term [x conjugate(F)H]_0^infinity vanishes by the stated decay. No claim that a theta boundary is orthogonal to a representative is used.

## 5. The actual representative-change family

Every representative of the same inclusion sigma_Z is uniquely

$$R_b=R+\Theta b,\qquad b:E_Z\to_{\mathbb C}V.$$

Indeed q(R'-R)=0 gives values in Theta V, and the PR #10 retraction gives the unique b=Lambda(R'-R). Finite source dimension gives continuity. Global continuous sections have the identical formula with b:Q->V continuous.

The complete changes are

$$k_b=k+D_Vb-bA,$$

$$\delta G_b=R^*\Theta b+(\Theta b)^*R+(\Theta b)^*\Theta b,$$

$$\boxed{W_{R_b}-W_R=A^*\delta G_b+\delta G_bA-\delta G_b.}$$

Their extension-coordinate map is U_b(v,u)=(v+bu,u), and

$$U_b^{-1}\begin{pmatrix}D_V&k\\0&A\end{pmatrix}U_b=\begin{pmatrix}D_V&k+D_Vb-bA\\0&A\end{pmatrix}.$$

Lift that automorphism on the common active fibre (V+E_Z)^tau. For the original masks, first keep the pair (support(x),r(x)); apply the shear on the joint fibre, and recover the original amplitudes by U_b^-1 and the original mask by its recorded component. No inverse to the unrecorded support collapse is asserted.

The projectors obey P_(R_b)-P_R=partial L_b with L_b^1(F)=(bJ_ZF,0). Their finite cochain traces agree because

$$\operatorname{Tr}(\Theta bJ_ZH_f)=\operatorname{Tr}(J_ZH_f\Theta b)=0.$$

The cochain supertrace sign remains -1 in degree one. The arithmetic extension class changes by h_Z(D)b(1), so its class in V/h_Z(D)V remains epsilon_Z=j_h(h_Z/(2xi)). The residue/Jacobian trace form is consequently unchanged.

## 6. Finite actual source ansatz and one master Gram matrix

Retain phi_*=(4pi^2 x^4-6pi x^2)exp(-pi x^2), phi_j=D^j phi_*, and

$$\Phi_m:\mathbb C^{m+1}\to V,\qquad(c_j)\mapsto\sum_{j=0}^m c_j\phi_j.$$

Their actual Mellin identities are M Theta phi_j(s)=2xi(s)s^j. They remain in the original two-moment source and are linearly independent. The source section R_0=s_Z has the exact rank-one defect DR_0-R_0A=Theta phi_* ell_Z, with the unchanged arithmetic remainder functional ell_Z.

Define maps, including the target enlargement,

$$I_m e_j=e_j,\qquad S_m e_j=e_{j+1},\qquad I_m,S_m:\mathbb C^{m+1}\to\mathbb C^{m+2},\qquad D\Phi_m=\Phi_{m+1}S_m.$$

For B in Mat_((m+1) x d)(C), d=dim E_Z, put

$$R_B=R_0+\Theta\Phi_mB,\qquad K_B=e_0\ell_Z+S_mB-I_mBA.$$

Then

$$DR_B-R_BA=\Theta\Phi_{m+1}K_B,\qquad qR_B=\sigma_Z,\qquad J_ZR_B=1.$$

Take the actual column map and its Gram matrix

$$\mathcal T_m:E_Z\oplus\mathbb C^{m+2}\to L^2(\mathbb R_+,dx),\qquad(u,c)\mapsto R_0u+\Theta\Phi_{m+1}c,\qquad M_m=\mathcal T_m^*\mathcal T_m.$$

M_m is positive definite. Applying J_Z to a vanishing combination gives u=0; Mellin then gives c=0. Its entries are the convergent integrals of the displayed arithmetic functions, with the original measure.

Define

$$X_B=\begin{pmatrix}I_d\\I_mB\end{pmatrix},\qquad Y_B=\begin{pmatrix}0\\K_B\end{pmatrix}.$$

The complete control calculation is

$$\boxed{G_B=X_B^*M_mX_B,\qquad W_B=-(X_B^*M_mY_B+Y_B^*M_mX_B)=A^*G_B+G_BA-G_B.}$$

This restricts representative choice to an actual finite family of theta boundaries. It is not an arbitrary positive matrix ansatz, and it is not asserted to exhaust all continuous source corrections. All packet coordinates, multiplicities, local units and finite source-degree changes are retained.

## 7. Error transport, duality, and the remaining estimate

With actual enclosures ||M-Mhat||<=eta_M, ||X-Xhat||<=eta_X, ||Y-Yhat||<=eta_Y, put x=||Xhat||, y=||Yhat||, m0=||Mhat||. Product estimates give

$$\eta_G=\eta_M(x+\eta_X)^2+m_0(2x\eta_X+\eta_X^2),$$

$$\eta_W=2[\eta_M(x+\eta_X)(y+\eta_Y)+m_0(x\eta_Y+y\eta_X+\eta_X\eta_Y)].$$

These include coefficient errors, not just quadrature errors. Exact certificates for Ghat-eta_G I>0 and

$$\epsilon\widehat G\pm\widehat W-(\epsilon\eta_G+\eta_W)I\succeq0$$

imply the actual two-sided control. This is an error-transfer theorem; arithmetic enclosures have not been computed here.

For the residue-duality statements here, retain PR #9, section 6's assumption that Z is stable under rho -> 1-conjugate(rho), with every zero's full multiplicity. This inherited restriction concerns the same-packet duality, not the preceding general Gram construction. The unchanged residue matrix S satisfies S*=-S and A*S+SA=S. Its exact dual transport is

$$G_B^{\mathrm D}=S^*G_B^{-1}S,\qquad W_B^{\mathrm D}=-S^*G_B^{-1}W_BG_B^{-1}S.$$

Thus an upper certificate gives a lower certificate on the same arithmetic packet. The Weil form stays S J_g, with metric comparison G_B^-1 S J_g; no positivity is assigned by choosing G_B.

For tensor degree n, retain A_n=sum_j 1 tensor A tensor 1 and G_(B,n)=G_B^(tensor n). The product control is sum_j G_B tensor W_B tensor G_B. Changing a homotopy by gamma alpha q changes the tensor homotopy by its Koszul-signed insertions; its differential is zero, hence it does not change that control form.

The existing orbit construction on this actual tensor image gives

$$G_{B,n,T}=\int_0^T e^{-nt}e^{tA_n^*}G_{B,n}e^{tA_n}\,dt,$$

$$A_n^*G_{B,n,T}+G_{B,n,T}A_n-nG_{B,n,T}=e^{-nT}e^{TA_n^*}G_{B,n}e^{TA_n}-G_{B,n}.$$

Every occurrence of G_(B,n) now has the explicitly constrained source in section 6.

A nonzero boundary need not have nonzero control. The exact calibration D_amb=diag(1/2+i,1/2+2i), Theta(v)=(v,0), A=1/2+2i, R(u)=(u,u) has boundary Theta(-i), Gram 2, and control zero. It is an algebraic calibration, not a zeta packet. The real-linear map B->-(R*B+B*R) explains which nonzero boundaries can have zero control.

Conversely every eigenvector Av=rho v obeys

$$\frac{v^*W_Bv}{v^*G_Bv}=2\Re\rho-1.$$

This ensures that changing representatives has not changed a spectral coordinate. The analytic target is now to bound the actual matrices from section 6, or their tensor-orbit endpoints, with all packet and tensor dependence retained. No uniform purity estimate, RH, GRH, or global spectral-kernel vanishing is proved here.

## 8. Validation and attribution

The attachment supplies the homotopy-classification theorem and the uncompiled draft. That draft status is historical; see the dated superseding status in section 1. This note verifies its proof and adds the continuous/twisted interface, supported reconstruction, coherent-family condition, and the connection to the actual control matrices. The original owner-directed SplitZero construction remains the source.

The independent checker has sixteen exact unittest methods, including finite parameter families. They passed normally and under python -O with identical successful JSON records. Intentional negative controls failed in both modes. The previous control checker also passed its sixteen methods. These finite checks cover algebraic models and polynomial-times-exponential integral calibrations, not evaluated zeta packets or analytic/Lean certification.

General references: The Stacks Project, Tags 0A8H and 0115 for the Hom-complex differential and homotopy, and 010I and 06XP for extension classes. The formulas above are proved on the specified programme objects; those references are not imported as a number-field weight theorem. Only authored notes, test code and validation records are published; no private transcript, source-literature corpus, or font files are included.


\clearpage

# Orthogonal theta boundaries and rank-two arithmetic control

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-orthogonal-boundary-control/RESEARCH_NOTE.md). Module: `workbenches/tau-orthogonal-boundary-control/RESEARCH_NOTE.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Owner-directed SplitZero continuation, 12 September 2026. Base: PR #11, d37eade4f9e6a82c1a88aeff710a3b851a34eb49. This is an additive research contribution with written proofs for review, not a new Lean certificate for the analytic results. The conversation delivery contains a longer numbered LaTeX/HTML version, the full reading record, and exploratory arithmetic moments.

## 1. Reviewed input and exact types

The supplied other-session theorem is correct: for injective Theta:V->B, an R-linear automorphism F, Q=B/Theta V, and kappa:B->V with kappa Theta=0, all homotopies satisfying BOTH dH=Theta kappa and Hd=0, for d(v,w)=Theta(v-Fw), are

    H_alpha(b)=(kappa b+alpha qb, F^-1 alpha qb),   alpha:Q->R V.

Writing H=(u,v) gives u-Fv=kappa. Since d(x,0)=Theta x, Hd=0 gives H Theta=0; hence Fv descends uniquely to alpha. Substitution proves the converse. The difference is gamma(alpha-beta)q with gamma(v)=(v,F^-1v). The solution set is affine relative to H_0, not generally a vector space with the zero homotopy as origin.

The attachment's uncompiled-draft status has now been superseded by the other session's successful PR #12 at `5d2772ea0a16d177ac3e01ff70394b90ba95a232`. The actual `SplitZeroTauHomotopy.lean`, completed job `103535438942`, and its full log were read. Both cochain equations and the inverse equivalence passed the specified kernel checks. Retraction and quotient-topology interfaces also passed with their explicit hypotheses. This is the other session's formalization; neither the actual analytic theta construction nor the new Gram/control results below are certified by it. No local Lean/Lake execution is claimed. See `COORDINATION_UPDATE.md` for exact scope. PR #11 already supplies the continuous specialization, the Fourier twist over C[t], support-changing lifts, coherent dilations and representative-change formulas. Those are retained inputs, not new results here.

Keep the original tau base and the square G(Z)->G(C) over Z->C, with p:G(Z)->Z still infinite, e=ofR(0), and tau the external scalar zero. No Boolean localization replaces the base quotient. All quotient relations below use the original internal coequalizer and preserve the support label.

Retain V, B and the actual operators of PRs #8-#11:

    V={even Schwartz phi on R: phi(0)=0 and integral(phi)=0};
    B={smooth F on R_+: sup x^b |D^k F(x)|<infinity for all integer b and k>=0};
    D=-x d/dx; Theta phi(x)=2 sum_(n>=1) phi(nx);
    M F(s)=integral_0^infinity F(x)x^s dx/x;
    phi_*=(4 pi^2 x^4-6 pi x^2)exp(-pi x^2);
    phi_j=D^j phi_*; f_j=Theta phi_j=D^j f_0;
    M f_j(s)=s^j g(s), g=2 xi.

The Hilbert observation is H=L2(R_+,dx), conjugate-linear in the first argument. Polynomial packet coordinates are retained, not changed to orthonormal coordinates.

For an actual finite packet with all multiplicities, let E=C[t]/h_Z, A=M_t. The previous analytic constructions supply

    R_0:E->B, J_Z:B->E, qR_0=sigma_Z, J_ZR_0=1, J_ZTheta=0,
    DR_0-R_0 A=f_0 ell_Z.

The exact ell_Z comes from epsilon_Z=j_h(h/(2 xi)); at a simple zero its value on 1 is 1/(2 xi'(rho)). These analytic constructions remain the cited research-proof dependencies, not theorems certified by the finite tests here.

## 2. An actual minimum over the admitted theta relations

For m>=0 define

    W_m=span(phi_0,...,phi_m);
    Phi_m:C^(m+1)->V, c |-> sum c_j phi_j;
    F_m=Theta Phi_m:C^(m+1)->H;
    H_m=F_m* F_m; C_m=F_m* R_0; G_0=R_0*R_0.

The f_j are independent: Mellin sends a relation to g(s)P(s)=0. Thus H_m is positive definite. Here C_m is a cross-Gram matrix E->C^(m+1), not the complex of that name in the endpoint workbench.

Set

    B_m=-H_m^-1 C_m;
    Pi_m=F_m H_m^-1 F_m*;
    R_m=R_0+Theta Phi_m B_m=(1-Pi_m)R_0.

The correction is a finite original theta boundary, so R_m lands in B, qR_m=sigma_Z, and J_ZR_m=1 at every m. Direct multiplication proves

    F_m*R_m=0;
    G_m=R_m*R_m=G_0-C_m*H_m^-1 C_m >0.

Positive definiteness follows from J_ZR_m=1. For any B:E->C^(m+1),

    (R_0+F_m B)*(R_0+F_m B)
      =G_m+(B-B_m)*H_m(B-B_m).

This is the minimum of the Hilbert Gram within the stated source family, not yet a minimum of its relative weight error. Also (1-Pi_m)(R_0+F_m B')=R_m: changing the initial representative by a relation already in W_m leaves the result unchanged.

## 3. The complete control form has rank at most two

Let I_m,S_m:C^(m+1)->C^(m+2) be I_m e_j=e_j and S_m e_j=e_(j+1). Define

    K_m=e_0 ell_Z+S_m B_m-I_m B_m A.

Then

    DR_m-R_m A=F_(m+1)K_m=Theta(Phi_(m+1)K_m).

No boundary component is discarded in this identity. Put b_m=e_m*B_m:E->C, and z_m=R_m*f_(m+1):C->E. Integration by parts on the stated source functions gives

    <DF,H>+<F,DH>=<F,H>,

with vanishing boundary term [x conjugate(F)H]_0^infinity. Hence

    W_m=A*G_m+G_m A-G_m
       =-(R_m*F_(m+1)K_m+K_m*F_(m+1)*R_m)
       =-z_m b_m-b_m*z_m*.

The last equality uses F_m*R_m=0 and the exact last row of K_m, which is b_m. Thus rank(W_m)<=2 for every packet dimension and every finite m. The pairings with the first m+1 theta directions vanish; those supported vectors themselves are retained.

Define the actual scalar quantities

    u_m=z_m*G_m^-1 z_m >=0;
    v_m=b_m G_m^-1 b_m* >=0;
    c_m=b_m G_m^-1 z_m.

The nonzero spectrum of G_m^-1 W_m is the nonzero spectrum of

    -[[c_m,v_m],[u_m,conjugate(c_m)]].

This follows by factoring through the two-column map [z_m,b_m*] and using the equality of nonzero spectra of the two compositions. Its trace is -2 Re(c_m), determinant |c_m|^2-u_m v_m. Therefore the least symmetric control allowance is

    epsilon_m=|Re(c_m)|+sqrt(u_m v_m-(Im(c_m))^2),
    -epsilon_m G_m <= W_m <= epsilon_m G_m.

Cauchy-Schwarz makes the radicand nonnegative. The formula also covers rank one. A reflection-stable full packet has

    trace(G_m^-1 W_m)=2 Re(trace A)-dim E=0,

so Re(c_m)=0. This is an exact trace identity, not a choice of coordinates. For every eigenvector Av=rho v,

    (v*W_m v)/(v*G_m v)=2 Re(rho)-1.

Thus the relative control still detects precisely the original spectral weight.

## 4. The next relation is a rank-one update with its own retained coordinate

Set

    a_(m+1)=(1-Pi_m)f_(m+1)=Theta psi_(m+1),
    psi_(m+1)=phi_(m+1)-Phi_m H_m^-1 F_m*f_(m+1),
    eta_(m+1)=||a_(m+1)||^2 >0.

Then R_m*a_(m+1)=z_m, and orthogonal decomposition gives

    Pi_(m+1)=Pi_m+a_(m+1) eta_(m+1)^-1 a_(m+1)*;
    R_(m+1)=R_m-a_(m+1) eta_(m+1)^-1 z_m*;
    G_(m+1)=G_m-eta_(m+1)^-1 z_m z_m*.

The control update is obtained by applying the same real-linear operator X |-> A*X+XA-X to the last identity.

The original quotient transport is

    Q_Wm=B/Theta W_m -> Q_W(m+1)=B/Theta W_(m+1),
    kernel=Theta W_(m+1)/Theta W_m ~= W_(m+1)/W_m.

That kernel is one-dimensional. The square E->Q_Wm by R_m and E->Q_W(m+1) by R_(m+1) commutes. The new relation becomes the supported zero only through the actual next-level quotient; it is not another scalar adjunction at the bottom.

There is a form on the entire quotient:

    Hcal_m([F],[G])=<(1-Pi_m)F,(1-Pi_m)G>.

It is positive definite since the kernel of 1-Pi_m in B is exactly Theta W_m. Let lambda_(m+1)[F]=<a_(m+1),F>. This is well defined on Q_Wm and

    Hcal_m(x,y)=Hcal_(m+1)(qx,qy)
                +eta_(m+1)^-1 conjugate(lambda(x))lambda(y).

The map (q,lambda):Q_Wm -> Q_W(m+1) plus C is a linear isomorphism. Its inverse is

    ([F],c) |-> [F-a eta^-1<a,F>+a eta^-1 c]_Wm.

Changing F by a relation at level m+1 changes this expression only by a relation at level m. This supplies the exact metric comparison between levels instead of treating the quotient transports as isometries.

Every displayed linear map has its original fixed-support lift. On the full source chain, reconstructed addition uses the join max(m,n) and the above transports. The scalar e sends (m,[F]) to (m,[0]); tau sends it to external absence. The two-leg primitives are (k_m u,0) and (0,-Fourier^-1 k_m u), where k_m=Phi_(m+1)K_m. Synchronization by the original E_sync=(1,e) supplies their common joint support. Their difference remains the H0 cycle (k_m u,Fourier^-1 k_m u). The other session's Hom(Q,H0) freedom leaves their differential and hence W_m unchanged.

## 5. Actual arithmetic moments and their truncation allowance

The matrices H_m come from the original arithmetic functions. Since JF(x)=x^-1 F(1/x) is unitary on L2(dx), Jf_0=f_0 and JD=(1-D)J,

    H_ij=integral_1^infinity [conjugate(f_i)f_j
                 +conjugate(f_i^ref)f_j^ref] dx,
    f_j^ref=(1-D)^j f_0.

This retains both multiplicative ends and permits absolutely convergent Gaussian sums on x>=1. Write

    phi_j(x)=P_j(x)exp(-pi x^2),
    P_0=4 pi^2 x^4-6 pi x^2,
    P_(j+1)=2 pi x^2 P_j-x P_j',
    P_j=sum_r c_(j,r)x^(2r),
    c_(j+1,r)=2 pi c_(j,r-1)-2r c_(j,r).

For f_j^[N](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-orthogonal-boundary-control/x)=2 sum_(n=1)^N P_j(nx)exp(-pi n^2x^2), put

    C_j=sum_r |c_(j,r)|sqrt(Gamma(2r+1/2)/(2 pi^(2r+1/2))).

Then

    ||f_j-f_j^[N]||_L2([1,infinity))
      <= 2 C_j (N+1)^(-1/2) exp(-pi(N+1)^2/2)
         /[1-exp(-pi(2N+3)/2)].

Proof: on x>=1, 2 pi n^2x^2 >= pi n^2+pi n^2x^2. Integrating each monomial's squared bound gives n^-1/2 exp(-pi n^2/2) times the displayed gamma constant. Minkowski and a geometric bound on consecutive n terms give the formula. The reflected derivative retains the absolute binomial sum of these allowances.

The finite integral entries use exactly

    integral_1^infinity x^(2k)exp(-c x^2) dx
      =Gamma(k+1/2,c)/(2 c^(k+1/2)), c=pi(n^2+n'^2).

For truncation tail norms delta_i,delta_j, each inner-product error is bounded by delta_i||f_j^[N]||+||f_i^[N]||delta_j+delta_i delta_j, plus its reflected contribution. Numerical evaluation errors for the finite expression still require their own enclosure. The optional conversation computation is explicitly exploratory, not interval-certified.

The exact consistency check is H_(i+1,j)+H_(i,j+1)=H_ij. Cross-Gram columns F_m*R_0 remain their actual source integrals and are not replaced by arbitrary matrices.

## 6. The same source proves a strong topology comparison

For this actual f_0,

    closure span{D^j f_0:j>=0} in L2(R_+,dx) = H.

Proof. The explicit unitary Mellin-line map sends F to M F(1/2+it) in L2(R,dt/(2 pi)). For general F in H this means the L2 extension of the source Mellin transform, not a claim that the ordinary integral converges. It sends D to 1/2+it and f_j to (1/2+it)^j g(1/2+it). The log-space function h(z)=exp(z/2) f_0(exp z) is holomorphic in |Im z|<pi/4 by its Gaussian series. For |Im z|<=a<pi/4 it decays superexponentially as Re z tends to positive infinity. Poisson gives h(z)=h(-z), so the same holds at the other end. Fourier contour displacement therefore gives |g(1/2+it)|<=C_a exp(-a|t|).

The measure dmu=|g(1/2+it)|^2dt/(2 pi) has a positive exponential moment. If an L2(mu) function is orthogonal to all polynomials, multiplying mu by its conjugate gives a finite complex measure with a smaller positive exponential moment. Its Fourier transform is analytic in a strip and all derivatives at zero vanish. Analyticity and uniqueness of the Fourier transform imply that measure is zero. Thus polynomials are dense in L2(mu). Multiplication by g is unitary from this weighted space onto L2(dt/(2 pi)), because the nonzero analytic function g on the line is nonzero almost everywhere. This proves the assertion without RH.

As a result, for a fixed finite packet,

    R_m -> 0 in Hom(E,H), G_m -> 0 and W_m -> 0,
    while qR_m=sigma_Z and J_ZR_m=1 for every m.

This specifies why unscaled smallness of W_m cannot be used alone as weight control: its denominator G_m is also shrinking. The exact relative formula in section 3 must be retained.

The corrective map is the Hilbert/jet graph:

    closure{(F,J_ZF):F in B} = H plus E;
    closure{(Theta phi,0):phi in V} = H plus 0.

Indeed finite theta polynomials give every (h,0) in the closure, and the sequence (R_m u,u) gives (0,u). For a specified positive metric on E, completion in ||F||_2^2+||J_ZF||_E^2 is this graph closure, and the quotient by the boundary closure is E by [(h,u)]|->u. The added metric is retained supplied data, not an implied positivity theorem for the Weil pairing.

For E nonzero, this closure is a closed linear relation in H plus E, not the graph of an operator H->E: the sequence (R_m u,u)->(0,u) with u nonzero proves that J_Z is not closable on H. The graph-norm completion just described does not replace the original Frechet quotient topology.

Its split observation is

    ((R_m u)^bullet,u^bullet) -> (e_H,u^bullet)

in the product of the stated support-fibre topologies. The arithmetic component survives above a supported Hilbert zero. External absence is (tau,tau).

## 7. Duality, trace and scope

For the residue-duality statements here, retain PR #9, section 6's assumption that Z is stable under rho -> 1-conjugate(rho), with every zero's full multiplicity. This inherited restriction concerns the same-packet duality, not the preceding general Gram construction. The original residue map has matrix S with S*=-S and A*S+SA=S. Its pullback of the dual metric is

    G_m^D=S*G_m^-1 S,
    W_m^D=-S*G_m^-1 W_m G_m^-1 S.

Thus the upper-to-lower comparison is retained on the same arithmetic packet. The Weil pairing stays S J_g, with explicit metric comparison G_m^-1 S J_g. Its positivity is not imposed by choosing a positive Gram matrix.

All representative changes above are original theta boundaries. Their extension class j_h(h/(2 xi)) is unchanged; the induced finite cochain projectors differ by the homotopy (bJ_Z,0). The trace difference is zero because J_ZTheta=0. Degree-one and tensor Koszul signs remain those of the source complex. On a raw tensor metric, the inserted W_m terms give the copied allowance n epsilon_m; tensoring alone does not improve it.

The new results are the actual orthogonal source choice, rank-two boundary formula, exact relative certificate, rank-one source-kernel recurrence, arithmetic moment tail bound, and the full Hilbert/jet topology comparison. No uniform arithmetic purity estimate, global spectral-kernel vanishing, RH or GRH is asserted.

The thirteen finite exact tests check the encoded algebra and declared calibration models, not infinite analytic arguments or actual zeta zeros. The complete cochain-homotopy theorem remains the other session's result, now supported by the independently inspected successful PR #12 run. Its certificate does not extend to the new analytic control results. Existing Lean modules and earlier validation receipts are untouched.

References: live PR #11 at the pinned head; successful PR #12 and source/job references in COORDINATION_UPDATE.md; the supplied Tau_Deligne_Control and Tau_Global_Comparison source notes; the supplied other-session homotopy proof; the previously retained Weil II 3.3.4-3.3.6 and 6.2 duality excerpts. Standard orthogonal-polynomial context is NIST DLMF 18.2; the density argument needed here is proved above for the actual arithmetic measure.


\clearpage

# Tau-base recovery, complete homotopy classification, and global retractions

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/formal/splitzero/TAU_RECOVERY_MATHEMATICS.md). Module: `formal/splitzero/TAU_RECOVERY_MATHEMATICS.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


Owner-directed continuation, 12 September 2026. This note distinguishes recovered formal sources, new formalization of source-derived consequences, and analytic inputs still requiring their own formal implementation. The successful workflow on an exact commit is the build record; until that run completes this note makes no certificate claim.

**Build status added on 12 September 2026.** The preceding sentence records the pre-run state. The later [successful run 34686934725, job 103535438942](https://github.com/KokunoYumeto/zeta-function-research-reader/actions/runs/34686934725/job/103535438942) used exact source head `5d2772ea0a16d177ac3e01ff70394b90ba95a232`. Its seven module hashes and 87 selected axiom reports were independently checked during integration. This is the certificate for those declarations, not for the separate analytic theta construction or an arithmetic weight estimate. The mathematical sources below are unchanged.

## 1. Provenance and unchanged data

The base is the accepted SplitZero package on `main` at `14c69d604044b848d64318751a7bee19edfd9aba`. The original scalar core, earlier theorem modules, dependency pin and old workflows are unchanged. Four tau sources are recovered from the interrupted branch at `621eb8863d6e0421b1ce3a604e5712c14d7b5cc2`, with proof-script repairs where fresh Lean runs exposed incomplete elaboration. Those repairs do not change the mathematical statements.

The new homotopy result develops the two-leg comparison of chain-descent PR #9 (`8f99b94d306c3b1aaa817d52c57fa6fd298d511c`, `workbenches/tau-chain-descent/RESEARCH_NOTE.md`). The retraction and topology files formalize consequences of the specified maps in global-retraction PR #10 (`d26c283c2a58da57bb5a5a4d4bc8669019f6ebb7`). They do not count those written analytic arguments as already checked Lean proofs. The source programme and its construction remain attributed to the owner; ordinary quotient algebra and Mathlib reuse are not new discoveries.

The retained scalar is G(R) with structural zero tau, supported zero e, and the original amplitude map to R. The base F1_tau is the pointed multiplicative monoid {tau,1}, not the Boolean semiring. Its structural maps, unique multiplicative prime, finite-word relations, and commuting arithmetic map are implemented in `SplitZeroTauBase.lean`. This is a specified minimal pointed/preaddition interface, not a completed general blueprint-scheme library.

## 2. The recovered finite chart and dual maps

The chart is the four-point ordered topological space + < eta < sigma and - < eta < sigma. A diagram F retains all four modules and its three generating restriction maps. Its displayed differential is

    d_F(x,y)=r_+(x)-r_-(y).

The code proves that compatible sections are exactly its kernel, and that their eta/sigma values extend uniquely. The two degree windows and the induced chain map are constructed from those actual restrictions.

Opposite-index dual transport is precomposition. The bottom fibre of the opposite diagram is not assumed zero. The code constructs quotient-dual/annihilator equivalences, evaluation and its naturality, the double-dual comparison, and the twisted operator action a times precomposition by U inverse. Evaluation obeys the full twist.

For coefficient W, the two cofree chart terms have exact linear Hom equivalences

    Hom(F,I_eta W) ~= Hom(F_eta,W),
    Hom(F,I_+ W + I_- W) ~= Hom(F_+,W) x Hom(F_-,W).

Their differential corresponds to ell |-> (ell r_+, -ell r_-). The signs are proved in both Hom-comparison squares. Over a field these cofree terms have the proved lifting property across pointwise injective maps. In particular the dual of the actual degree-one quotient is identified with the kernel of this signed dual differential.

The implementation establishes these objects, equations and lifting properties. It does not bundle the entire derived-category adjunction, the projective resolution of the constant sheaf, or a Verdier six-functor formalism.

## 3. Every homotopy of the two-leg comparison

Let R be any commutative ring, Theta:V->B an injective R-linear map, and F:V~=V an R-linear automorphism. In degrees 0,1 put

    C=[V x V --d--> B],   d(v,w)=Theta(v-Fw),   Q=B/Theta(V).

Let kappa:B->V be linear and kappa Theta=0. The prescribed cochain difference is Delta=(0,Theta kappa). A homotopy is exactly a linear H:B->V x V satisfying BOTH

    d H=Theta kappa,     H d=0.

There is an explicit equivalence

    Hom_R(Q,V) ~= {such homotopies},
    alpha |-> H_alpha(b)=(kappa(b)+alpha(qb), F^(-1) alpha(qb)).

Proof: substitution gives d H_alpha=Theta kappa. Both kappa and alpha q vanish on Theta(V), so H_alpha d=0. Conversely write H=(u,v). Injectivity of Theta gives u-Fv=kappa. Since im d=im Theta, the second equation gives H Theta=0; therefore Fv descends uniquely through q to alpha. This gives the stated inverse. The Lean definition `cochainHomotopyEquiv` proves both inverse laws.

The solution set is affine, with difference module Hom_R(Q,V). It is not a linear space with zero as its natural origin when Delta is nonzero. Requiring only the first equation would instead yield parameters Hom_R(B,V); the second equation is essential.

The two source-note choices correspond to alpha=0 and alpha=-kappa_bar. Their difference is (kappa(b),F^(-1)kappa(b)), a cycle. It is nonzero whenever kappa(b) is nonzero. Since there is no degree -1 incoming differential, these cycles represent degree-zero cohomology. The ordinary kernel is canonically V through v |-> (v,F^(-1)v); the Lean acceptance tests prove the explicit nonzero cycle and classify all homotopies directly. The chart adapter identifies the differential with the existing four-point chart, rather than introducing an unrelated complex.

## 4. Construct the global quotient section, not merely a proposed map

Suppose Theta:V->B and Lambda:B->V are linear with Lambda Theta=id. Define

    K=id_B-Theta Lambda,    Q=B/range(Theta),    q:B->Q.

The code proves

    K^2=K, ker K=range Theta, range K=ker Lambda.

Indeed K Theta=0, Lambda K=0, and b=Theta Lambda b+Kb. These identities prove both image/kernel assertions and idempotence without finite-dimensional assumptions.

Since K kills the original range, the quotient universal property constructs

    s:Q->B, s(qb)=Kb.

Then qs=id, Lambda s=0 and the maps

    V x Q -> B, (v,u) |-> Theta v+s u,
    B -> V x Q, b |-> (Lambda b,qb)

are inverse R-linear maps. This is the actual `splitEquiv`. The quotient is the range quotient already used in the homology package, not a quotient postulated to be isomorphic to a selected finite model.

The `fromReconstruction` constructor retains the source's intermediate maps: i:V->W, P:W->V, T,N:W->W, Y:B->W, with P i=id, N(w-Tw)=w, and Y Theta=i-Ti. It constructs Lambda=P N Y and proves Lambda Theta=id. The analytic cutoff, Neumann inverse and moment calculations must supply those input identities at their analytic types. They are not silently provided as axioms.

## 5. Exact operator defect and changes of representatives

Let A_B and A_V intertwine Theta. The code constructs the actual induced operator A_Q on Q and

    k_A=Lambda A_B s : Q->V.

Decompose A_B s(u) through the preceding inverse maps to obtain

    A_B s=Theta k_A+s A_Q.

For composable endomorphisms A,C of the same data, substitution yields

    k_(AC)=A_V k_C+k_A C_Q.

Indeed expand C_B s, apply A_B, use its intertwining with Theta, and apply Lambda. This is a general composition theorem; for a group action it gives the displayed dilation cocycle without assuming its vanishing.

Every other linear section has a unique form s_b=s+Theta b with b:Q->V. The proof applies the decomposition to s'(u); the parameter is Lambda s'. Applying Lambda proves uniqueness. Its defect is exactly

    k_A^b=k_A+A_V b-b A_Q.

The code proves the changed block equation and

    A_B s_b=s_b A_Q  iff  k_A^b=0.

Thus equivariance is an equation to solve for an actual source-valued map. It is not obtained merely by choosing representatives. In particular a continuous splitting is not being relabelled an equivariant splitting.

For ANY finite representative map f:E->B, the identity

    s q f=f-Theta Lambda f

is proved at its actual map type. Applying it to the source's finite section explains the representative correction; proving the analytic Ext/residue interpretation remains separate.

## 6. Keep the actual quotient topology

Give V and B their specified topologies. If B is a Hausdorff topological additive group and Theta,Lambda are continuous, K is continuous. Since range Theta=K^(-1)({0}), the range is closed.

The quotient topology on Q makes q a quotient map. The equality s q=K therefore proves continuity of s. Both maps of the preceding linear equivalence are continuous, yielding the actual `splitHomeomorph`. The quotient is Hausdorff, and the induced A_Q and defect k_A are continuous whenever A_B is continuous.

This argument does not require a Banach norm. In a future analytic instantiation it can use the source's strong-Schwartz topology. It must not be read as a claim that the theta range is closed in an unrelated L2 completion. Nor does a closed range prove injectivity of a different spectral-observation map.

## 7. Carry the retraction through the existing supported objects

Let D,E be the original linear join diagrams and theta:D->E, lambda:E->D actual natural transformations satisfying lambda_i theta_i=id. Define residual_i=id-theta_i lambda_i. Naturality is proved using the original transport equations, so these are actual G(R)-linear maps on reconstructed total semimodules.

The checked identities are

    lambda_total theta_total=id,
    residual_total^2=residual_total,
    residual_total(theta_total x)=e . theta_total x.

The final right side is the supported zero in the SAME fibre. It is not global absence. The theorem is stated against the existing `Hom.total` and original scalar e, not against a newly invented scalar implementation. No injectivity of arbitrary support transports is assumed.

These are fixed-index natural maps. The complete support-changing synchronization homotopy, the general category equivalence with changing index, and the geometric sheaf realization are not claimed by these three identities.

## 8. Exact formal/analytic boundary

The formal package contains seven sources: four recovered tau modules and three additions for homotopies, retractions and topology. Their target manifest enumerates the principal constructions and proof terms for transitive axiom checking. Declaration counts include definitions and infrastructure and are not discovery counts.

Analytic obligations not formalized here include: Mobius/Fourier exterior reconstruction on the original test spaces; compactness and the strict cutoff-operator norm inequality; the actual Neumann inverse in the stated Frechet/Schwartz construction; its analytic seminorm bounds; global spectral synthesis and the other observation kernels; the arithmetic residue/Ext identification; and the common-scale weight estimate. The new Deligne-control archive was not readable through the available file reader, and the local execution sandbox did not open it. No claim to have audited that archive is made.

The source's global-retraction note was read through the supplied rendered text and its published PR record. It supplies the motivation and specified analytic input, not an additional trusted theorem of Lean. The precise output of this continuation is the conditional algebraic/topological theorem package and the recovered finite-chart maps. No positivity, purity, RH or GRH conclusion is assumed in a formal definition.

## 9. Reproduction

In `formal/splitzero` with the existing pinned Lean 4.31.0 environment:

```sh
python3 prepare.py
python3 check_tau_recovery.py --prepare
python3 -m unittest -v test_tau_recovery.py test_derived_checker.py
python3 -O -m unittest -v test_tau_recovery.py test_derived_checker.py
lake update
test "$(git -C .lake/packages/mathlib rev-parse HEAD)" = fabf563a7c95a166b8d7b6efca11c8b4dc9d911f
lake exe cache get
lake -KmaxJobs=2 build
while IFS= read -r name; do
  lake env lean --trust=0 -DwarningAsError=true -o ".lake/build/lib/lean/$name.olean" "$name.lean" || exit 1
done < TAU_RECOVERY_MODULES.txt
lake env lean --trust=0 -DwarningAsError=true AuditTauRecovery.lean >AuditTauRecovery.log
python3 check_tau_recovery.py AuditTauRecovery.log
```

The workflow also reruns the older 73-target derived and 28-target structural audits. Shared parser tests exercise missing, duplicate, unexpected and forbidden axiom reports; new tests cover source/module agreement and proof-escape rejection. Tests are not proof certificates; Lean execution is the mathematical validation. The source manifest prints SHA-256 hashes so the accepted source can be identified exactly. Development failures remain in branch history.

## References and reuse

Owner-directed SplitZero programme. (2026). *Chain-level arithmetic descent over the tau base* (Zeta PR #9, exact revision above).

Owner-directed SplitZero programme. (2026). *Global theta retraction* (Zeta PR #10, exact revision above).

Mathlib contributors. (2026). *Mathlib4* (revision `fabf563a7c95a166b8d7b6efca11c8b4dc9d911f`). Quotient linear maps, product linear equivalences, topological quotient modules, and ordinary Lean tactics are reused under the existing dependency license.


\clearpage

# September 12 calculations: what was checked

[Complete source note](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/INTEGRATION_REVIEW_20260912.md). Module: `INTEGRATION_REVIEW_20260912.md`.

Revision: [512fb1a6aa0922318aff49081c01674cf30ec906](https://github.com/KokunoYumeto/zeta-function-research-reader/commit/512fb1a6aa0922318aff49081c01674cf30ec906). Complete selected note.


This edition joins nine research contributions to the living zeta repository. Their purpose and mathematical objects are explained in [Research programmes](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/RESEARCH_PROGRAMMES.md). The full notes, equations, source citations and executable tests remain separate and readable; the earlier six-reader edition is unchanged.

## Content review and executable evidence

| Contribution | Review and reproducible evidence |
|---|---|
| [CUE research map](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/CUE_RESEARCH_MAP.md), PR #1 | Editorial map read; its eight referenced theorem labels checked against the existing source. This contributes navigation rather than a new theorem. |
| [Unified Flow](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/unified-flow), PR #2 | Complete horizon/probe derivation and checker read; 28 elementary checks passed normally and with optimized Python, with identical output. |
| [Rees and actual quotient calculations](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/split-support-rees-trace), PR #3 | Four complete notes and four checkers read. Normal/optimized runs agreed: 2,085 Rees conditions, 1,452 actual-comparison conditions, 5,443 finite congruence comparisons, and 101 origin-ladder checks. These are finite instances, not counts of proved general theorems. |
| [Tau-base comparison](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-base-cohomology), PR #8 | Complete analytic and algebraic arguments read. Base checker: 79 named records in six suites; finite comparison: ten test methods. Both normal/optimized runs and deliberate-failure controls checked. |
| [Chain descent](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-chain-descent), PR #9 | Complete argument read, including its exact extension unit and reflection-stable residue interface. Twelve test methods passed normally and optimized; failure controls failed as intended. |
| [Global retraction](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-global-retraction), PR #10 | Complete continuous-retraction proof reviewed independently twice; twelve finite methods and failure controls replayed. The infinite-dimensional estimates are supported by the written argument, not certified by those finite tests. See the [Meyer source comparison](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-global-retraction/MEYER_SOURCE_COMPARISON.md). |
| [Homotopy/control](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-homotopy-control), PR #11 | Complete argument and sixteen finite methods reviewed; positive runs agreed normally/optimized and failure controls failed. |
| [Formal tau recovery](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-formal-recovery), PR #12 | Seven Lean sources read, their hashes matched to the successful exact-head build, and 87 selected axiom reports reparsed. Details below. |
| [Orthogonal boundaries](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/workbenches/tau-orthogonal-boundary-control), PR #13 | Complete Gram, rank-two, density and graph argument read; thirteen finite methods replayed normally/optimized, including deliberate-failure controls. |

These reviews are tool-assisted checks, not independent human peer review. The finite symbolic replays used Python 3.13.9 and SymPy 1.13.1 where applicable. The authors' original environment records are preserved rather than overwritten.

## The precise Lean certificate

PR #12 head `5d2772ea0a16d177ac3e01ff70394b90ba95a232` passed [Actions run 34686934725, job 103535438942](https://github.com/KokunoYumeto/zeta-function-research-reader/actions/runs/34686934725/job/103535438942). The seven module sources and the selected axiom reports were independently matched to that run. Those reports use only the recorded standard Lean axioms. The certificate covers the declarations named in the package, not every analytic or arithmetic claim in the surrounding programme.

A one-line Windows test-fixture repair now explicitly writes UTF-8 with LF newlines. The unchanged original harness had two newline-related failures on Windows; the repaired harness passes all 18 tests both normally and optimized. This changes no Lean declaration. The earlier PR #11 report of an uncompiled draft remains historical, with a dated link to the later successful source version.

## Precision corrections included in this edition

- The fixed-N origin ladder states its range $0\leq m<N$; its Taylor-polynomial inverse uses $m\geq1$, with $m=0$ handled by the identity comparison.
- Same-packet residue duality repeats the inherited condition that the packet is stable under $\rho\mapsto1-\overline\rho$, retaining full multiplicities. This does not restrict the preceding general Gram construction.
- The continuous contraction is explicitly in complexes of locally convex complex vector spaces after forgetting $\mathbb C[t]$-linearity. Its actual scaling defect remains displayed.
- Mellin transformation of arbitrary Hilbert-space vectors means its $L^2$ extension. The completed jet graph is a closed linear relation, with its explicit nonclosability witness, not an operator graph over the original Hilbert space.

These changes preserve the equations and proof data. They do not supply the still-missing relative weight estimate. In particular, small absolute Gram and control matrices do not by themselves imply a small relative control norm, positivity of the Weil form, or RH.

## Versions and reproducibility

[WORKBENCHES.json](https://github.com/KokunoYumeto/zeta-function-research-reader/blob/512fb1a6aa0922318aff49081c01674cf30ec906/WORKBENCHES.json) gives the exact contribution heads, merge commits, source paths, dependencies and local reproduction entrypoints. Each workbench retains its author's validation record and citations. The source archive accompanying the calculation reader contains the authored notes and checking code, not the private literature library or session logs.
