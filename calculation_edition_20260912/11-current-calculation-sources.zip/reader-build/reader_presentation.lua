-- Turn literal immutable Git hashes into breakable inline literals. Hyperlink
-- destinations and Math nodes remain untouched.
function Str(el)
  local sha, rest = el.text:match("^([0-9a-f]+)(.*)$")
  if sha and (#sha == 40 or #sha == 64) and (rest == "" or rest:match("^[,.;:)]")) then
    return {pandoc.Code(sha), pandoc.Str(rest)}
  end
  if el.text:match("^[A-Z_]+%.md[.,;:]?$") then
    return pandoc.Code(el.text)
  end
end

-- A source's plain-text product R*B+B*R is not Markdown emphasis.
function Emph(el)
  local value = pandoc.utils.stringify(el)
  if value:match("[+=]") then
    return pandoc.Str("*" .. value .. "*")
  end
end
