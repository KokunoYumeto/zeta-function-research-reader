# The first separated-link connected electric covariance

8 September 2026. Two links which share no elementary face nevertheless
develop a nonzero connected electric covariance through two adjacent faces.
This note calculates that coefficient in the actual full-box vacuum. The
calculation keeps both intermediate spin channels and the disconnected
expectation subtraction. It does not assume a volume-uniform remainder.

## 1. Original Hilbert space and the coefficient to be calculated

Fix \(L\geq2\), vertices \(\{-L,\ldots,L\}^3\), all positive contained
links e, and all contained elementary faces p. Write their complete counts
as \(N=3(2L)(2L+1)^2\) and \(M=3(2L)^2(2L+1)\). Link variables are
\(U_e\in SU(2)\), with the inverse on reverse traversal. The face trace is
\[
 W_{(n;i,j)}=\operatorname{tr}\{U_i(n)U_j(n+\mathbf e_i)
           U_i(n+\mathbf e_j)^{-1}U_j(n)^{-1}\},\qquad i<j.
\]
On product Haar probability space use \(T_a=-i\sigma_a/2\), left
derivatives \(X_{e,a}\), \(E_e=-\sum_aX_{e,a}^2\), and
\[
 H=\kappa\sum_eE_e+b\sum_p(2-W_p),\quad
 \kappa=2g^2/a,\quad b=1/(2g^2a),\quad\xi=b/\kappa=1/(4g^4).
\tag{1}
\]
The fundamental Casimir is \(3/4\). In the original metric
\(-\operatorname{tr}(AB)/2\), the Laplacian is four times the sum-of-squares
Laplacian in these generators, so the electric coefficient in that metric
is \(\kappa/4\). Neither this factor nor the Wilson scalar \(2bM\)
is changed.

The compact connected configuration manifold and bounded smooth potential
give a self-adjoint compact-resolvent operator of domain \(H^2\), form
domain \(H^1\), and unique smooth positive unit ground vector \(\psi_\xi\).
For precision, the modulus inequality supplies a nonnegative form minimizer,
elliptic regularity and the maximum principle make it positive, and the
identity
\(q_{H-\mathcal E}(\psi f)=\kappa\sum_{e,a}\int\psi^2|X_{e,a}f|^2\)
implies uniqueness by division by \(\psi\). Gauge transformations preserve
this vector and every link Casimir. All following vectors are thus physical.

Set \(r_e=\#\{p:e\in\partial p\}\),
\(\gamma_e=\langle\psi,E_e\psi\rangle\),
\(v_e=(E_e-\gamma_e)\psi\), and
\[
 C_{ef}=\langle v_e,v_f\rangle
   =\langle\psi,E_eE_f\psi\rangle-\gamma_e\gamma_f.
\tag{2}
\]
The operators commute for different links. Smoothness makes (2) legitimate
as an operator identity on the vacuum, not only a formal product of forms.

For distinct e,f that share no face, define the integer
\[
 a_{ef}=\#\{(p,q): e\in\partial p,\ f\in\partial q,
                     |\partial p\cap\partial q|=1\}.
\tag{3}
\]
The pair in (3) is ordered by which face contains e and which contains f;
there is no double counting because no face contains both links. All faces
are those of the original open box. The result is
\[
 \boxed{C_{ef}=\frac{127}{219024}\,a_{ef}\xi^4+O_L(\xi^6)
        \quad(e,f\text{ share no face}).}
\tag{4}
\]
In particular the coefficient is positive whenever a two-face channel
exists, even though the energy matrix between these links is exactly zero.
The latter assertion is proved in Section 4.

## 2. The full second vacuum coefficient, including both shared-link channels

Put \(H_0=\sum E_e\) and \(S=\sum W_p\), so
\(H=\kappa(H_0-\xi S)+2bM\). On \(|z|=3/8\) in the full Hilbert
space the resolvent of H_0 has norm at most \(8/3\), since its first
nonzero eigenvalue is \(3/4\). Also \(\|S\|=2M\). Therefore the
bounded perturbation Neumann series converges for
\(|\xi|<3/(16M)\), gives the analytic rank-one bottom projection, and
gives an analytic positive unit eigenvector for real \(\xi\) near zero.
Elliptic regularity applied repeatedly to the eigen-equation upgrades this
to analyticity in each fixed Sobolev space. Its radius and estimates may
depend on L. This suffices for the finite derivative calculations below.

Product Haar integration gives \(\int W_p=0\),
\(\langle W_p,W_q\rangle=\delta_{pq}\), and \(H_0W_p=3W_p\).
Indeed a link in only one of two distinct face boundaries has odd central
parity; for the same face integrate its Haar holonomy and use the fundamental
character squared norm one. Comparing coefficients in the actual equation
\((H_0-\xi S)\psi=e(\xi)\psi\), including its unit-vector condition,
gives
\[
 \psi=1+\xi A_1+\xi^2A_2+O_{H^k,L}(\xi^3),\quad A_1=S/3,
 \quad e(\xi)=-M\xi^2/3+O_L(\xi^3),
\]
\[
 H_0A_2=(S^2-M)/3,\qquad\int A_2=-M/18.
\tag{5}
\]
The inverse in (5) can be resolved entirely. For adjacent distinct faces
p,q sharing g put
\[
 Z_{pq,0}=\int W_pW_q\,dU_g,\qquad
 Z_{pq,1}=W_pW_q-Z_{pq,0}.
\]
After reversing one real trace if needed, their words are
\(\operatorname{tr}(U_gB)\), \(\operatorname{tr}(U_g^{-1}D)\), with
six distinct outer links. The fundamental Haar identity gives
\(Z_{pq,0}=\operatorname{tr}(BD)/2\). The shared-edge spin tensor
\(1/2\otimes1/2\) consists of spins zero and one, while all outer
links have spin \(1/2\). Thus
\[
 H_0Z_{pq,0}=\tfrac92 Z_{pq,0},\quad
 H_0Z_{pq,1}=\tfrac{13}2Z_{pq,1},\quad
 \|Z_{pq,0}\|^2=\tfrac14,\quad\|Z_{pq,1}\|^2=\tfrac34.
\tag{6}
\]
The norms use orthogonal Haar projection on g and total product norm one.
A repeated face has \(W_p^2-1=\chi_1(U_p)\) with free energy8 and norm
one. An edge-disjoint pair has energy6 and norm one, even when the faces
meet at a vertex. Consequently the full coefficient is
\[
 \boxed{A_2=-\frac M{18}+\sum_p\frac{W_p^2-1}{24}
 +\sum_{\{p,q\}\ {\rm edge\!\!-\!\!disjoint}}\frac{W_pW_q}{9}
 +\sum_{\{p,q\}\ {\rm adjacent}}
       \left(\frac4{27}Z_{pq,0}+\frac4{39}Z_{pq,1}\right).}
\tag{7}
\]
All distinct-pair sums in (7) are unordered; the factor two in S² has
already been included. No finite-face subsystem is substituted for H.

Different unordered pairs in (7) have different odd-link parity supports.
If their symmetric boundaries agreed, their symmetric face difference would
be a nonempty closed mod-two collection of at most four squares. A face
in that collection needs another face on each of its four boundary edges;
two distinct elementary squares share at most one edge, so at least four
other squares would be needed, a contradiction. Haar integration on a
link where parity differs makes the cross term zero. Repeated-face terms
are even everywhere, and different repeated-face terms have different
joint link spins. Thus all the displayed components, with their two spin
channels, are mutually orthogonal. This remains true after application of
any link Casimir, which preserves those parity and spin subspaces.

## 3. Exact connected fourth coefficient

Suppose e,f share no face. Then \(E_eE_f1=E_eE_fA_1=0\): each
term in A_1 is a single face and depends on at most one of these links.
Self-adjointness moves \(E_eE_f\) to either of these vectors, so every
term of degree less than four in \(\langle\psi,E_eE_f\psi\rangle\)
vanishes, and its degree-four term is exactly
\[
 \langle A_2,E_eE_fA_2\rangle.
\tag{8}
\]
In particular no third or fourth unknown coefficient of the vacuum is
being omitted from (8): its possible pairing with 1 or A_1 is identically
zero for the stated reason. Similarly
\[
 \gamma_e=\xi^2\langle A_1,E_eA_1\rangle+O_L(\xi^3)
          =\frac{r_e}{12}\xi^2+O_L(\xi^3).
\tag{9}
\]

Only a pair p,q with \(e\in p\), \(f\in q\) contributes to (8).
Repeated faces contribute zero. There are exactly \(r_er_f\) such
distinct unordered pairs when they are labeled as in (3). For an
edge-disjoint pair, both e and f carry fundamental spin, so its contribution
is \((3/4)^2/9^2=1/144\). For an adjacent pair, neither e nor f can
be its shared edge: otherwise the face containing the other link would
contain both e and f. They are therefore both outer fundamental edges in
each of the two channels (6), and the contribution is
\[
 \left(\frac34\right)^2
 \left[\left(\frac4{27}\right)^2\frac14
       +\left(\frac4{39}\right)^2\frac34\right]
       =\frac1{324}+\frac3{676}.
\tag{10}
\]
Equation (9) subtracts \(r_er_f/144\) at degree four in (2). Hence every
edge-disjoint pair cancels its disconnected contribution exactly; every
adjacent pair leaves
\[
 \frac1{324}+\frac3{676}-\frac1{144}
          =\frac{127}{219024}>0.
\tag{11}
\]
This proves the coefficient in (4).

For its stated even error, the center transformation
\(U_{(n,i)}\mapsto(-1)^{\sum_{j<i}n_j}U_{(n,i)}\) changes every face
trace sign, commutes with every E_e and preserves Haar measure. It
intertwines H_0−ξS with H_0+ξS and hence the positive unit vacua at
ξ and−ξ. Both terms in (2) are consequently even analytic functions of
ξ near zero. Their next possible order after four is six. This proves
the error in (4); it does not supply a volume-uniform analytic radius.

## 4. Exact support map and relation to the energy matrix

Define the edge adjacency matrix \(B\) by \(B_{eg}=1\) when e,g are
distinct physical links belonging to a common elementary face, and zero
otherwise. Two distinct links belong to at most one elementary square:
perpendicular incident links determine its two plane directions and base,
while parallel links in a square must be opposite sides and also determine
that square. Thus, for the e,f considered above,
\[
 \boxed{a_{ef}=(B^2)_{ef}.}
\tag{12}
\]
Indeed a pair p,q counted in (3) has a unique shared edge g, which is a
common neighbor of e,f. Conversely a common neighbor g determines the
unique p containing e,g and q containing g,f; these are distinct because
e,f share no face, and their unique shared edge is g. These two maps are
inverse. The covariance coefficient thus has support at graph distance
two, including boundary incidences, and no support beyond distance two
at this order. It makes no all-orders finite-range claim about C.

There are actual such channels in every L≥2. Take
\(e=((0,0,0),1)\) and \(f=((0,2,0),1)\). They share no face, but
the 12 faces based at \((0,0,0)\) and \((0,1,0)\) share the edge
\(((0,1,0),1)\), giving \(a_{ef}\geq1\). All of their vertices
are in the original box, including at L=2.

Put \(\mathcal N_{ef}=\langle v_e,(H-\mathcal E)v_f\rangle\).
Commuting the link operators on the smooth real vacuum gives
\[
 \mathcal N_{ef}=\tfrac12
 \langle\psi,[E_e,[H,E_f]]\psi\rangle.
\tag{13}
\]
To check (13), expand the double commutator, use \(H\psi=\mathcal E\psi\),
commute E_e,E_f, and use the real symmetry of their two matrix elements.
Only potential faces containing f occur in \([H,E_f]\). If e shares
no face with f, E_e commutes with every one of their multiplication and
derivative terms. Thus
\[
 \boxed{\mathcal N_{ef}=0\text{ exactly, at every positive coupling,
 when e,f share no face}.}
\tag{14}
\]
There is no contradiction between (4) and (14): a matrix-valued spectral
measure can have nonzero zeroth moment and zero first moment off diagonal.
Explicitly, for the spectral resolution of A=H−E on the physical space,
\[
 d\Sigma_{ef}(\omega)=\langle v_e,\mathbf1_{d\omega}(A)v_f\rangle,
 \quad C_{ef}=\int d\Sigma_{ef},\quad
 \mathcal N_{ef}=\int\omega\,d\Sigma_{ef}.
\tag{15}
\]
The measure matrix is positive semidefinite on every Borel set because
its quadratic form is the squared norm of a projected linear combination
of the v_e. An individual off-diagonal entry, however, need not be a
nonnegative measure; (15) retains its signs. Smoothness gives the finite
moments used here. These identities are the exact relation between the
nonlocal covariance contribution and the local energy matrix, not an
assumption that one determines the other's support.

Finally \(\xi^4=1/(256g^{16})\). The physical coefficient in (4) is
therefore \(127a_{ef}/(56070144g^{16})\); C has no extra energy factor,
whereas \(\mathcal N\) has one. The scalar energy shift remains in H
and cancels only in H−E. The fixed-box coefficient is a concrete next
input to the extensive denominator calculation; control of all higher
orders and summability at fixed coupling is not inferred from its finite
range at order four.

## 5. The complete fourth-order spectral functional and time correlation

The same calculation can resolve the energy dependence, rather than only
its zeroth moment. Put \(A_\xi=(H-\mathcal E)/\kappa\), and write
\[
 F_{ef,\xi}(h)=\langle v_e,h(A_\xi)v_f\rangle.
\]
For each fixed box, for distinct links sharing no face, and every bounded
continuous real or complex function h which is differentiable at 3,
\[
\boxed{\lim_{\xi\to0}\xi^{-4}F_{ef,\xi}(h)
 =a_{ef}\left[-\frac{59}{275184}h(3)-\frac1{336}h'(3)
             +\frac1{1296}h(9/2)+\frac3{132496}h(13/2)\right].}
\tag{16}
\]
Here the limit is a functional on the specified test functions. In
particular the derivative term must not be omitted or represented as an
ordinary positive spectral atom. Each original matrix-valued spectral
measure is still the exact positive-semidefinite measure (15).

We prove (16), including the relation to the actual first interacting
spectral subspace. Let P project onto the free physical energy-three space
\(\mathcal P=\operatorname{span}\{W_p\}\), and let
\[
 R_3=(I-P)((H_0-3)|_{\mathcal P^\perp})^{-1}(I-P).
\]
The inverse is on the physical space: its constant channel is -1/3.
To verify isolation, a nonzero physical spin network has no degree-one
support vertex. Its support contains a cycle of length at least four in
the bipartite cubic graph, costing at least 3. With fewer than six
nontrivial edges it must be one elementary square: a fifth edge would
have a new degree-one endpoint, or be a forbidden same-bipartition chord
of the four-cycle. The degree-two invariant contractions require equal
spins on that square. Only spin 1/2 has energy below 9/2. A six-edge
rectangular loop realizes energy 9/2. Thus the first physical free band
is exactly P, with the next energy 9/2.

For sufficiently small real \(\xi\), the contour \(|z-3|=3/4\)
defines the actual spectral projection \(P_\xi\), and the exact isometry
\[
 V_\xi=P_\xi P(PP_\xi P|_{\mathcal P})^{-1/2}
       :\mathcal P\longrightarrow\operatorname{ran}P_\xi
\tag{17}
\]
uses its full Gram factor. Indeed the free contour resolvent has norm
at most 4/3. For \(|\xi|\le3/(64M)\), its Neumann factor is at most
1/8, and integrating the resolvent difference gives
\(\|P_\xi-P\|\le1/7\). The displayed inverse square root therefore
exists by its binomial series; idempotence and orthogonality of the real
projection show \(V_\xi^*V_\xi=I\). Its range is smooth, and the
finite-rank resolvent formula and elliptic regularity justify all operator
products and fixed Sobolev derivatives below. It is orthogonal to the
actual vacuum for a smaller interval, for example
\(|\xi|\le3/(128M)\), by the free gaps and the bounded perturbation
estimate \(2M|\xi|\).

Let Q be the unchanged open-face signless adjacency matrix, with diagonal
the actual face degrees and off-diagonal 1 for shared-edge faces. Direct
virtual-channel calculation gives
\[
 V_\xi^*A_\xi V_\xi=3I+\xi^2F+O_L(\xi^4),\qquad
 F=\frac7{15}I-\frac1{21}Q.
\tag{18}
\]
Here is the coefficient calculation rather than an assumption of (18).
Differentiating (17) gives \(V'_0=R_3SP\). The second matrix coefficient
before vacuum subtraction is \(-PSR_3SP\). The vacuum channel gives
+1/3 to every entry; a repeated-face channel gives -1/5 to its diagonal;
an edge-disjoint pair gives -1/3 to its two diagonals and mutual entries;
an adjacent pair gives
\(- (1/4)/(9/2-3)-(3/4)/(13/2-3)=-8/21\)
to that same four-entry pattern. Thus the diagonal is
\(7/15-M/3-d_p/21\), and the off-diagonal is -1/21 exactly for adjacent
faces. The actual vacuum coefficient -M/3 from (5) gives (18).
The central cochain used in Section 3 acts as -I on P; it makes the
matrix in (18) even and accounts for the fourth-order remainder.

The electric vector can be treated with arbitrary fixed real link weights
w, retaining its linear dependence on all of them. Define
\(\Gamma_w=\sum w_eE_e\), \(a_p(w)=\sum_{e\in p}w_e/4\), and
\(v(w)=(\Gamma_w-\langle\Gamma_w\rangle)\psi\). Put
\[
 y_\xi(w)=V_\xi^*v(w),\qquad
 \rho_\xi(w)=(I-P_\xi)v(w).
\]
These are exact orthogonal components, both orthogonal to the actual
vacuum. Coefficient comparison using (7) and \(V'_0=R_3SP\) gives
\[
 y_\xi(w)=\xi x(w)+\xi^3z(w)+O_L(\xi^5),\qquad
 x(w)=\sum_pa_p(w)W_p,
\]
\[
 \rho_\xi(w)=\xi^2r(w)+O_{H^k,L}(\xi^3),
\tag{19}
\]
where, for \(s=a_p(w)+a_q(w)\) and g the shared edge,
\[
 r(w)=\sum_p\frac{2a_p(w)}{15}(W_p^2-1)
       +\sum_{\{p,q\}\ {\rm adjacent}}
       \left[-\frac{2(s+w_g)}9Z_{pq,0}
             +\frac{2(3s+7w_g)}{273}Z_{pq,1}\right].
\tag{20}
\]
For completeness, \(\Gamma_w\) has eigenvalues
\(8a_p\) on the repeated face, \(3s\) on an edge-disjoint pair,
and \(3s-3w_g/2,3s+w_g/2\) on the adjacent zero and one channels.
The shared edge is counted twice as fundamental in 3s; replacing that
by its actual spin accounts for precisely the last two corrections.
In \(\Gamma_w A_2\), the respective coefficients are
\(a_p/3,s/3,(4s-2w_g)/9,(12s+2w_g)/39\).
Subtract the full dressing \(R_3Sx(w)\), whose coefficients are
\(a_p/5,s/3,2s/3,2s/7\). The two constant coefficients are both
\(-\sum_pa_p/3\) and also cancel. This proves (20) with no omitted
channel. The centered projection identity
\(V_\xi^*\psi_\xi=0\) is exact. The same central cochain makes
\(y_\xi(w)\) odd, proving the first expansion (19).

For a single link e use the original weight \(w^{(e)}_g=\delta_{eg}\),
and denote the resulting x,z,r by \(x_e,z_e,r_e^{\rm vec}\).
This superscript distinguishes the vector from the incidence count r_e.
Then \(x_e=\sum_{p\ni e}W_p/4\). If e,f share no face,
\(\langle x_e,x_f\rangle=0\), and (18) gives exactly
\[
 \langle x_e,Fx_f\rangle=-a_{ef}/336.
\tag{21}
\]
Each ordered adjacent pair contributes \(-1/(4\cdot21\cdot4)\).
In the cross spectral measure of \(r_e^{\rm vec},r_f^{\rm vec}\),
only the pairs counted by (3) occur. Repeated-face cross terms vanish.
For every contributing pair, e and f are outer links of different faces,
\(s=1/4\) for each weight, and \(w_g=0\). Thus their zero-channel
coefficients in (20) are both -1/18, and their one-channel coefficients
are both 1/182. Orthogonality and (6) give the complete free cross measure
\[
 \langle r_e^{\rm vec},h(H_0)r_f^{\rm vec}\rangle
 =a_{ef}\left[\frac1{1296}h(9/2)+\frac3{132496}h(13/2)\right].
\tag{22}
\]
No edge-disjoint channel survives in (20).

As \(A_\xi-H_0=-\xi S-e(\xi)I\) tends to zero in operator norm,
its resolvents converge in norm. For bounded continuous h, this implies
convergence of the cross expectations on \(\rho_\xi/\xi^2\) to
(22): first use continuous functions vanishing at infinity and norm
resolvent convergence, then approximate h on a compact interval and
control the discarded tail by the uniformly bounded second spectral
moments. Those moments follow from the \(H^2\) convergence in (19).
Polarization gives the cross statement from the four corresponding
diagonal statements. Hence (22) is the entire fourth-order out-of-band
contribution.

The fourth coefficient of the band mass is obtained without knowing
the third vacuum coefficient: subtract (22) at h=1 from (4). It is
\[
 \langle x_e,z_f\rangle+\langle z_e,x_f\rangle
 =a_{ef}\left(\frac{127}{219024}-\frac1{1296}-\frac3{132496}\right)
 =-\frac{59}{275184}a_{ef}.
\tag{23}
\]
Differentiability of h at 3 and spectral calculus of the finite matrix
(18) give
\(h(V_\xi^*A_\xi V_\xi)=h(3)I+\xi^2h'(3)F+o_L(\xi^2)\).
Combine this with (19), (21), (23), and the exact orthogonal spectral
decomposition into the band and its complement. This proves (16).

In particular the complete dimensionful ground-state time correlation,
with physical \(\kappa>0\) and physical time \(t\ge0\) fixed, is
\[
\boxed{\begin{split}
 \langle v_e,e^{-t(H-\mathcal E)}v_f\rangle
 =a_{ef}\xi^4\biggl[&-\frac{59}{275184}e^{-3\kappa t}
       +\frac{\kappa t}{336}e^{-3\kappa t}\\
       &+\frac1{1296}e^{-9\kappa t/2}
       +\frac3{132496}e^{-13\kappa t/2}\biggr]+O_{L,t,\kappa}(\xi^6).
\end{split}}
\tag{24}
\]
Here \(h(q)=e^{-\kappa tq}\) is used on the nonnegative excitation
spectrum, with any bounded continuous extension below zero, so it belongs
to the test class of (16). The bounded potential perturbation gives
\(e^{-\kappa tK_\xi}\) its norm-convergent Duhamel series: each order
is bounded by \((2M|\xi|\kappa t)^n/n!\). The excitation semigroup
retains the additional analytic scalar \(e^{\kappa t e(\xi)}\).
The vacuum and vectors are analytic in fixed Sobolev norms, and the central
cochain makes the whole expression even.
These facts justify the even remainder in (24), not only a pointwise
little-o limit. For varying physical \(\kappa\), the same proof uses
the explicit parameter \(\tau=\kappa t\) and keeps its dependence;
no estimate uniform in \(\tau\) or L is implied.

At t=0 the bracket is \(127/219024\). Its derivative at t=0 is
exactly zero, because
\[
3\left(-\frac{59}{275184}\right)-\frac1{336}
 +\frac{9}{2\cdot1296}+\frac{39}{2\cdot132496}=0.
\tag{25}
\]
This agrees with the exact identity (14). It exhibits which separated-link
spectral contributions cancel in the first moment: the actual band-mass
correction, the actual band-energy derivative, and both higher spin
channels. The term proportional to t is essential to that cancellation.
Equations (16)--(25) describe the fixed-box fourth coefficient of the
original interacting correlations; they do not exchange a volume limit
with the coupling expansion or assert a continuum spectrum.

## 6. Primary context

The original Hamiltonian framework is J. Kogut and L. Susskind,
*Hamiltonian formulation of Wilson's lattice gauge theories*, Physical
Review D **11** (1975), 395--408,
<https://doi.org/10.1103/PhysRevD.11.395>. Full conventions appear in (1).
For historical linked-cluster calculations in the same spatial dimension,
see A. C. Irving, T. E. Preece and C. J. Hamer, *Cluster expansion approach
to non-abelian lattice gauge theory in (3+1)D (I). SU(2)*, Nuclear Physics B
**270** (1986), 536--552,
<https://doi.org/10.1016/0550-3213(86)90567-5>. This note derives (4)
directly, with no historical novelty assertion or imported coefficient.
