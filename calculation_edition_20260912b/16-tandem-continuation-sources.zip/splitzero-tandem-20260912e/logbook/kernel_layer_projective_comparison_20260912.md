# Original orthogonal shells and the projective-ratio algebra

Date: 12 September 2026. This is the full research record for the new standalone proof fragment `output/split_zero_rh_tandem_2026-09-12/tex/kernel_layer_projective_comparison.tex`.

## Scope and provenance

The parent task requested complete proofs of the original orthogonal-versus-homogeneous shell comparison, a legitimate ratio-algebra embedding, and the finite counterexample to a proposed rank substitution. Existing sealed fragments and the main cumulative source were excluded from editing. This scope was respected. The exact new source delivery was read and audited first in `work/kernel_layer_source_audit_20260912.md`; the original equation numbers and hashes are recorded there.

The source defines orthogonal-shell full jets using the actual monic orthogonal polynomials. The proposed identification with homogeneous-shell ranks was rejected by a complete three-atom positive polynomial model. The resulting continuation retains the full lower-degree coefficients, computes the graph/common quotient relating the unequal images, and proves the ratio subalgebra with all ordered pairs and every nilpotent multiplicity.

## Mathematical results and exact maps

1. The monic splitting and the homogeneous splitting are sections of the same polynomial-filtration quotient. Their exact difference is the complete lower-degree coefficient map. Applying the unchanged arithmetic unit and full jet map gives `A_orth=A_hom+J_<N L_N`. The same associated-graded target map is accompanied by the complete image/kernel exact sequences.
2. With the same source H and kernel spaces K_h,K_o, the paired image is exactly `I_h ×_Q I_o`, with `Q=H/(K_h+K_o)`. Its source is `H/(K_h intersect K_o)`. The proof includes each projection kernel, the universal property of Q, and the criterion for the relation to be the graph of a function.
3. For the original tensor ratio zeta=s_1/s_2, all nonzero centres retained, the minimal polynomial is the product over distinct ratios r of `(Z-r)^M_r`, with `M_r=max_(rho/sigma=r)(m_rho+m_sigma-1)`. The full local top nilpotent power is written with its binomial coefficient, signs, rho and sigma powers. The resulting quotient of the polynomial algebra embeds in the original tensor algebra. It is a subalgebra embedding; multiplication by the arithmetic unit and s_2^N is stated separately as a linear isomorphism onto its image.
4. The actual summed generator acts between adjacent homogeneous-shell images by `A(U s_2^N f(zeta))=U s_2^(N+1)(1+zeta)f(zeta)`. Every factor and shell shift is retained.
5. The local ratio inclusion admits a unital complex-algebra retraction exactly when one local multiplicity is one. The global inclusion in `E_h tensor E_h` admits such a retraction exactly when h is squarefree. The complete proof uses the ratio-one factor, all source idempotents, and the nonvanishing first-order nilpotent coefficient; it assumes neither simplicity of arithmetic zeros nor RH.
6. The three-atom model is computed through both source minima and the actual next relation layer. Its homogeneous/orthogonal ranks are 1/0, derivative layer is zero, original interpolation metrics are G_1=9 and G_2=9/5, and the next relation Gram has eigenvalues 10,4,2. The minimum R_2 and all five orthogonality equations are checked explicitly in the written proof. This is a finite polynomial model, not an arithmetic zero or a substitute measure.

## Independent audit and build

The complete final source was independently read in `work/kernel_layer_projective_fragment_audit_20260912.md`; the independent algebra proof is `work/kernel_layer_projective_independent_audit_20260912.md`. Mathematical findings were resolved. A subsequent display-only edit removes an inline overflow and is recorded in the audit handoff. The final source hash and actual typesetting receipt follow below. No source delivery, old proof fragment, or cumulative main file was modified.

The actual standalone XeLaTeX build succeeds with seven pages and no warnings, overflows, missing-character messages or undefined commands/references. This source-writing lane does not claim visual QA; the cumulative build owner receives the final fragment for that review.

```json
{
  "source": "package:\\tex\\kernel_layer_projective_comparison.tex",
  "source_sha256": "6711C4C1F0E3B2F9606EBFF913BAB1BE9C053801558DC5E3A1011B6EF7AEFE35",
  "pdf": "workspace:\\work\\kernel_layer_projective_build\\projective_wrapper.pdf",
  "pdf_sha256": "0595878AA9B8243342DE6BF9178DAF15C679A8195694A86BCFB9191DB70F2833",
  "pdf_bytes": 124726,
  "pages_from_actual_xelatex_log": 7,
  "log": "workspace:\\work\\kernel_layer_projective_build\\projective_wrapper.log",
  "log_sha256": "67E5CC3736207CC6ABBBE754AFB749EB2AAC54F5790B2A01529D0846E2083D28",
  "warnings_or_overflows_or_missing_glyphs_or_undefined": [],
  "visual_review": "Not performed in this bounded source-writing lane; cumulative build owner receives the new TeX.",
  "scope": "Standalone typesetting validation and complete written mathematical proof; no Lean execution or arithmetic quadrature enclosure.",
  "command": "xelatex -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=work/kernel_layer_projective_build work/kernel_layer_projective_build/projective_wrapper.tex"
}
```

## Complete proof source

```latex
\section{Original orthogonal shells and the exact projective-ratio algebra}
\label{sec:kernel-layer-projective-comparison}

The source's degree shell consists of its original orthogonal product
polynomials.  This section proves its full comparison with the
homogeneous monomial shell, including every lower-degree coefficient.
It also calculates the algebra generated by the ratio of the two
original tensor coordinates.  The arithmetic local unit and all
multiplicities remain in the resulting linear maps.

\subsection{Two sections of the same polynomial filtration}

Retain a complete nonempty arithmetic packet
\[
 h(s)=\prod_{\rho\in Z}(s-\rho)^{m_\rho},\qquad
 d=\deg h,\quad E_h=\mathbb C[s]/(h),\quad
 \upsilon_h=j_h(g/h),\quad g=2\xi.
 \tag{KPC.1}
\]
The complete orders make \(\upsilon_h\) a unit.  For \(k\ge1\),
write \(E^{(k)}=E_h^{\otimes k}\) in its original monomial
tensor coordinates and use the original full-jet map
\[
 J(P)=U_{\upsilon_h^{\otimes k}}
       [P]_{(h(s_1),\ldots,h(s_k))},
 \qquad J:\mathbb C[s_1,\ldots,s_k]\longrightarrow E^{(k)}.
 \tag{KPC.2}
\]
Here \(U_a\) is multiplication by the stated element \(a\).
The integration variables remain \(s_j=1/2+it_j\), with
\[
 d\nu_h(t)=|g(1/2+it)/h(1/2+it)|^2\frac{dt}{2\pi}.
 \tag{KPC.3}
\]
Let \(p_j(s)=\sum_{r=0}^j p_{j,r}s^r\), with
\(p_{j,j}=1\), be the original monic orthogonal polynomials
for this measure.  Retain
\(\kappa_j=\int|p_j(s)|^2d\nu_h>0\).
For a multi-index \(\alpha\), put
\[
 p_\alpha=\prod_{j=1}^k p_{\alpha_j}(s_j),\qquad
 \kappa_\alpha=\prod_{j=1}^k\kappa_{\alpha_j},\qquad
 a_\alpha=J(p_\alpha).
 \tag{KPC.4}
\]
All moment integrals in these definitions use the original density.

For \(N\ge0\), let \(\mathcal P_{\le N}\) be the polynomials
of total degree at most \(N\), let
\(\mathcal P_{\le-1}=0\), and let \(\mathcal H_N\) be the
homogeneous polynomials of degree \(N\).  The highest-degree map
\(\ell_N:\mathcal P_{\le N}\to\mathcal H_N\) has kernel
\(\mathcal P_{\le N-1}\).  It therefore identifies
\(\mathcal H_N\) with the associated-graded space
\(\mathcal P_{\le N}/\mathcal P_{\le N-1}\).
There are two specified sections:
\[
 \begin{split}
 i_N\Bigl(\sum_{|\alpha|=N}c_\alpha s^\alpha\Bigr)
       &=\sum_{|\alpha|=N}c_\alpha s^\alpha,\\
 O_N\Bigl(\sum_{|\alpha|=N}c_\alpha s^\alpha\Bigr)
       &=\sum_{|\alpha|=N}c_\alpha p_\alpha.
 \end{split}                                                    \tag{KPC.5}
\]

\begin{theorem}[The exact lower-degree correction]
Both maps in (KPC.5) are linear sections of \(\ell_N\).
Their difference \(L_N=O_N-i_N\) has target
\(\mathcal P_{\le N-1}\) and is exactly
\[
 L_N\Bigl(\sum_{|\alpha|=N}c_\alpha s^\alpha\Bigr)
 =\sum_{|\gamma|<N}
   \left(\sum_{\substack{|\alpha|=N\\\gamma_j\le\alpha_j\ (1\le j\le k)}}
       c_\alpha\prod_{j=1}^k p_{\alpha_j,\gamma_j}\right)s^\gamma.
 \tag{KPC.6}
\]
The image of \(O_N\) is the orthogonal complement of
\(\mathcal P_{\le N-1}\) in \(\mathcal P_{\le N}\) for
the original product measure, and its basis in (KPC.5) has Gram
\(\operatorname{diag}(\kappa_\alpha)_{|\alpha|=N}\).
Define the two full residue maps on the same \(\mathcal H_N\) by
\[
 A_N^{\rm hom}=J i_N,\qquad A_N^{\rm orth}=J O_N.
\]
Then, with \(J_{<N}=J|_{\mathcal P_{\le N-1}}\),
\[
 \boxed{A_N^{\rm orth}=A_N^{\rm hom}+J_{<N}L_N.}
 \tag{KPC.7}
\]
In particular the original orthogonal-shell columns of
\(A_N^{\rm orth}\) are exactly \(a_\alpha\).
\end{theorem}

\begin{proof}
Expand each factor in \(p_\alpha\).  Its coefficient of
\(s^\gamma\) is \(\prod_jp_{\alpha_j,\gamma_j}\) when
\(\gamma_j\le\alpha_j\) for all \(j\), and is zero
otherwise.  If \(|\alpha|=|\gamma|=N\), these inequalities
force \(\gamma=\alpha\), whose coefficient is one.
This proves both section identities and the complete expression
(KPC.6).  For a monomial \(s^\gamma\) of degree less than
\(N=|\alpha|\), at least one \(\gamma_j<\alpha_j\).
In the product integral for
\(\langle s^\gamma,p_\alpha\rangle\), that factor is zero
by one-variable orthogonality.  All product integrals are justified
by their finite moments and Cauchy--Schwarz.  Distinct product
polynomials are mutually orthogonal, and their norms multiply to
\(\kappa_\alpha\).  Their leading monomials make them
independent.  Their number is
\(\dim\mathcal P_{\le N}-\dim\mathcal P_{\le N-1}\),
so they exhaust the indicated orthogonal complement.
Applying the unchanged linear map \(J\) to
\(O_N=i_N+L_N\) proves (KPC.7).  This application includes
the fixed multiplication by \(\upsilon_h^{\otimes k}\).
For \(N=0\) the sum in (KPC.6) is empty and \(L_0=0\),
so the same proof includes the initial shell.
\end{proof}

The associated-graded target is explicit as well.  Put
\(F_NE^{(k)}=J(\mathcal P_{\le N})\) and \(F_{-1}E^{(k)}=0\).
Projection onto \(F_NE^{(k)}/F_{N-1}E^{(k)}\), composed
with either map in (KPC.7), gives the same surjection
\[
 \overline A_N:\mathcal H_N\twoheadrightarrow
                  F_NE^{(k)}/F_{N-1}E^{(k)}.
 \tag{KPC.8}
\]
Indeed their difference lands in \(F_{N-1}E^{(k)}\), and
\(\mathcal P_{\le N}=i_N\mathcal H_N+
\mathcal P_{\le N-1}\) proves surjectivity.  If
\(Z_N=\ker\overline A_N\) and
\(K_N^a=\ker A_N^a\) for \(a\in\{{\rm hom},{\rm orth}\}\),
then \(K_N^a\subseteq Z_N\) and the exact sequence is
\[
 0\longrightarrow Z_N/K_N^a
  \longrightarrow\mathcal H_N/K_N^a
  \longrightarrow\mathcal H_N/Z_N\longrightarrow0.
 \tag{KPC.9}
\]
The middle space is identified with \(\operatorname{im}A_N^a\)
by \([c]\mapsto A_N^a c\), the last space with the target
of (KPC.8), and the first space with
\(\operatorname{im}A_N^a\cap F_{N-1}E^{(k)}\).
These identifications follow directly from their kernels and are
bijective: for the first image, membership in \(F_{N-1}\)
is exactly the condition \(c\in Z_N\).  Thus equality of
the graded maps retains, rather than removes, the two potentially
different lower-filtration image spaces.  In particular, once
\(N-1\ge k(d-1)\), complete monomial remainders show
\(F_{N-1}E^{(k)}=E^{(k)}\), so (KPC.8) has zero target;
the full maps (KPC.7) still have their stated images and kernels.

\subsection{The full correspondence between the two image spaces}

\begin{theorem}[Common quotient and exact graph correspondence]
Write \(I_h=\operatorname{im}A_N^{\rm hom}\),
\(I_o=\operatorname{im}A_N^{\rm orth}\),
\(K_h=\ker A_N^{\rm hom}\), and
\(K_o=\ker A_N^{\rm orth}\).  Define
\[
 Q_N=\mathcal H_N/(K_h+K_o),\qquad
 \Gamma_N=\{(A_N^{\rm hom}c,A_N^{\rm orth}c):c\in\mathcal H_N\}.
 \tag{KPC.10}
\]
The maps \(q_h:I_h\to Q_N\) and \(q_o:I_o\to Q_N\),
given respectively by \(A_N^{\rm hom}c\mapsto[c]\) and
\(A_N^{\rm orth}c\mapsto[c]\), are well-defined
surjections, with exact sequences
\[
 \begin{split}
 0&\longrightarrow A_N^{\rm hom}(K_o)
       \longrightarrow I_h\xrightarrow{q_h}Q_N\longrightarrow0,\\
 0&\longrightarrow A_N^{\rm orth}(K_h)
       \longrightarrow I_o\xrightarrow{q_o}Q_N\longrightarrow0.
 \end{split}                                                    \tag{KPC.11}
\]
One has the exact vector-space identifications
\[
 \boxed{\Gamma_N=I_h\mathbin{\times}_{Q_N}I_o
       \cong\mathcal H_N/(K_h\cap K_o).}
 \tag{KPC.12}
\]
The projection \(\Gamma_N\to I_h\) has kernel
\(\{0\}\oplus A_N^{\rm orth}(K_h)\); the projection
onto \(I_o\) has kernel
\(A_N^{\rm hom}(K_o)\oplus\{0\}\).
\end{theorem}

\begin{proof}
Changing a representative of an element of \(I_h\) changes
\(c\) by \(K_h\), hence leaves its class modulo
\(K_h+K_o\) unchanged.  The same argument applies to
\(I_o\).  The formulas give surjectivity.  If \(q_h(A_N^{\rm hom}c)=0\),
write \(c=c_h+c_o\) with \(c_h\in K_h,c_o\in K_o\).
Then \(A_N^{\rm hom}c=A_N^{\rm hom}c_o\).  Conversely
every such vector maps to zero.  This proves the first kernel
formula in (KPC.11); interchanging the two maps proves the second.

The paired map from \(\mathcal H_N\) onto \(\Gamma_N\)
has kernel exactly \(K_h\cap K_o\), proving the last
identification in (KPC.12).  Every paired image belongs to the
fibre product.  Conversely, suppose
\((A_N^{\rm hom}c,A_N^{\rm orth}b)\) belongs to the fibre
product.  Then \(c-b=c_h+c_o\) for some
\(c_h\in K_h,c_o\in K_o\).  Put
\(e=c-c_h=b+c_o\).  It has the two desired images,
so the pair belongs to \(\Gamma_N\).  This proves equality
with the full fibre product, not merely an inclusion.  Taking
the kernel of each coordinate projection gives the asserted
remaining formulas.
\end{proof}

The quotient in (KPC.10) also has its precise universal property.
If linear maps \(f_h:I_h\to Z\) and \(f_o:I_o\to Z\)
satisfy \(f_hA_N^{\rm hom}=f_oA_N^{\rm orth}\), their
common composite on \(\mathcal H_N\) vanishes on both
\(K_h\) and \(K_o\), hence on their sum.  It therefore
factors uniquely through \(Q_N\), and that factor gives
both original maps after the surjections in (KPC.11).
Likewise, a linear map \(T:I_h\to I_o\) satisfying
\(TA_N^{\rm hom}=A_N^{\rm orth}\) exists exactly when
\(K_h\subseteq K_o\).  Necessity follows by evaluating
on \(K_h\); under that inclusion the formula
\(T(A_N^{\rm hom}c)=A_N^{\rm orth}c\) is well-defined
and proves sufficiency.  It is an isomorphism exactly when
\(K_h=K_o\).  Thus (KPC.11)--(KPC.12) give the full
typed correspondence even when no such isomorphism exists.

There is also an explicit polynomial deformation of the sections.
For a complex parameter \(z\), define, without division by \(z\),
\[
 p_j^{\langle z\rangle}(s)=\sum_{r=0}^j
                 p_{j,r}z^{j-r}s^r,\qquad
 O_{N,z}(c)=\sum_{|\alpha|=N}c_\alpha
                         \prod_jp_{\alpha_j}^{\langle z\rangle}(s_j).
 \tag{KPC.13}
\]
For \(|\gamma|<N\), its coefficient of \(s^\gamma\) is
exactly the coefficient in (KPC.6) multiplied by
\(z^{N-|\gamma|}\); at degree \(N\) it is \(c_\gamma\).
Hence \(O_{N,0}=i_N\), \(O_{N,1}=O_N\), and
\(\ell_NO_{N,z}=I\) for every \(z\).  The maps
\(JO_{N,z}\) are matrices polynomial in the parameter,
and (KPC.8) is unchanged throughout.  A rank condition
\(\operatorname{rank}JO_{N,z}\le r\) is exactly the
vanishing of every \((r+1)\)-minor.  No constancy of their
rank follows from this deformation.  In particular (KPC.13)
retains every original coefficient at \(z=1\); it does not
replace the original measure or its orthogonal minimum.

\subsection{The algebra generated by the original coordinate ratio}

Now take \(k=2\) and retain \(h(0)\ne0\).  Every original
nontrivial zero in the arithmetic packet has \(0<\operatorname{Re}\rho<1\),
so this domain includes that packet.  Work in the original algebra
\[
 E^{(2)}=\mathbb C[s_1,s_2]/(h(s_1),h(s_2)),\qquad
 \zeta=s_1s_2^{-1}.
 \tag{KPC.14}
\]
The inverse is defined because \(s\) and \(h(s)\) are
coprime; the Euclidean identity for these polynomials supplies
an inverse modulo \(h\).  All ordered pairs of centres and
their multiplicities are retained.

\begin{theorem}[Complete ratio algebra and homogeneous-shell rank]
For every distinct ratio \(r=\rho/\sigma\), put
\[
 M_r=\max_{\rho/\sigma=r}(m_\rho+m_\sigma-1),\qquad
 b=\sum_r M_r,\qquad
 \mu_\zeta(Z)=\prod_r(Z-r)^{M_r}.
 \tag{KPC.15}
\]
Then evaluation at \(\zeta\) has exactly kernel
\((\mu_\zeta)\), and gives the unital algebra embedding
\[
 \mathbb C[Z]/(\mu_\zeta)
       \lhook\joinrel\longrightarrow E^{(2)},
       \qquad [P]\longmapsto P(\zeta).
 \tag{KPC.16}
\]
Its image is the subalgebra \(\mathbb C[\zeta]\).
For every \(N\ge0\), the full arithmetic homogeneous-shell map is
\[
 \sum_{j=0}^N c_j s_1^j s_2^{N-j}
   \longmapsto
    \upsilon_h^{\otimes2}s_2^N\sum_{j=0}^N c_j\zeta^j.
 \tag{KPC.17}
\]
Its kernel consists exactly of the coefficient polynomials
\(\sum_{j=0}^Nc_jZ^j\) divisible by \(\mu_\zeta\), and
\[
 \boxed{\operatorname{rank}A_N^{\rm hom}=\min\{N+1,b\}.}
 \tag{KPC.18}
\]
The arithmetic unit and \(s_2^N\) in (KPC.17) are retained
invertible multiplication maps.  Formula (KPC.18) does not replace
the orthogonal-shell map (KPC.7).
\end{theorem}

\begin{proof}
The factors \((s-\rho)^{m_\rho}\) of \(h\) are pairwise
coprime.  For each factor, a Euclidean identity with the product
of the others gives a polynomial equal to one modulo that factor
and zero modulo all others.  Their residue classes are mutually
orthogonal idempotents and sum to one: each of these assertions
holds modulo every factor, hence modulo their product.
They give the full Chinese-remainder isomorphism, with inverse
obtained by multiplying each component representative by its
idempotent and adding.  Tensoring these explicit maps gives
\[
 E^{(2)}\cong
 \prod_{(\rho,\sigma)}
   \mathbb C[x,y]/(x^{m_\rho},y^{m_\sigma}),\qquad
 x=s_1-\rho,\quad y=s_2-\sigma.
 \tag{KPC.19}
\]
In each component the basis is the full set
\(x^ay^c\), \(0\le a<m_\rho,0\le c<m_\sigma\).
The inverse of \(\sigma+y\) is explicitly
\(\sum_{j=0}^{m_\sigma-1}(-1)^jy^j/\sigma^{j+1}\),
as multiplication and cancellation of consecutive powers verify.

Write \(m=m_\rho\), \(n=m_\sigma\).  In this component
the ratio retains the exact identity
\[
 \zeta-\frac\rho\sigma
       =\frac{\sigma x-\rho y}{\sigma(\sigma+y)}.
 \tag{KPC.20}
\]
Every monomial of total degree \(m+n-1\) vanishes, since
one exponent must reach \(m\) or \(n\).  Thus the
\((m+n-1)\)-st power of (KPC.20) is zero.  Its preceding
power has the exact value
\[
 \left(\zeta-\frac\rho\sigma\right)^{m+n-2}
 =\binom{m+n-2}{m-1}
   \frac{\sigma^{m-1}(-\rho)^{n-1}}
        {\sigma^{2(m+n-2)}}x^{m-1}y^{n-1}\ne0.
 \tag{KPC.21}
\]
Indeed only the displayed monomial survives in the numerator
power; in the inverse-denominator power only its constant
coefficient can multiply that monomial without making it zero.
The displayed coefficient is nonzero over \(\mathbb C\)
because \(\rho,\sigma\ne0\).  For \(m=n=1\) the
preceding power is the zeroth power one, and the first power is
zero, so this case is included.  The local nilpotent index is
therefore exactly \(m+n-1\).

For any nonzero polynomial \(P(Z)\), factor at the local
ratio \(r\) as \(P(Z)=(Z-r)^e B(Z)\) with \(B(r)\ne0\).
The element \(B(\zeta)\) is invertible: after division by
its nonzero constant \(B(r)\), it is one plus a nilpotent
polynomial in \(\zeta-r\), whose finite geometric series
is an inverse.  Hence \(P(\zeta)=0\) in that component
exactly when \(e\ge m+n-1\).  Across all ordered
components, the condition at each coincident ratio is its maximum
exponent, and conditions at distinct ratios are coprime.  This
proves that the global evaluation kernel is precisely
\((\mu_\zeta)\), including the zero polynomial.
It proves (KPC.16) and its stated image.

Each homogeneous monomial satisfies
\(s_1^js_2^{N-j}=s_2^N\zeta^j\) inside the original
algebra.  Applying the original arithmetic unit proves (KPC.17).
Both multiplication factors there are invertible, so its kernel
is exactly the asserted restricted polynomial kernel.  For
\(N<b\), no nonzero polynomial of degree at most \(N\)
is divisible by the monic \(\mu_\zeta\).  For \(N\ge b\),
all such multiples are \(\mu_\zeta\mathbb C[Z]_{\le N-b}\),
which has dimension \(N-b+1\), since multiplication by the
nonzero polynomial is injective.  Subtracting this dimension
from \(N+1\) gives (KPC.18) in both cases.
\end{proof}

In the retained monomial tensor coordinates, set
\(S_1=A_h\otimes I\), \(S_2=I\otimes A_h\),
\(c=[1]\otimes[1]\), and \(Z_{\rm mat}=S_1S_2^{-1}\).
Then (KPC.17) is exactly
\[
 (c_0,\ldots,c_N)\longmapsto
 U_{\upsilon_h^{\otimes2}}S_2^N
                \sum_{j=0}^Nc_jZ_{\rm mat}^j c.
 \tag{KPC.22}
\]
This retains each complete Taylor block under (KPC.19) rather
than replacing either coordinate by its eigenvalue.  Multiplication
by \(\upsilon_h^{\otimes2}s_2^N\) is a linear isomorphism
from \(\mathbb C[\zeta]\) to its displayed image, with
inverse multiplication by \(s_2^{-N}(\upsilon_h^{\otimes2})^{-1}\)
on that image.  The image after this multiplication is not asserted
to be a unital subalgebra.

The original summed generator also has an exact map between
adjacent shells.  Write \(A^{(2)}=M_{s_1+s_2}\) on the
retained algebra and \(U=\upsilon_h^{\otimes2}\).  Then
\[
 A^{(2)}\bigl(U s_2^N f(\zeta)\bigr)
        =U s_2^{N+1}(1+\zeta)f(\zeta).
 \tag{KPC.22a}
\]
This follows from \(s_1+s_2=s_2(1+\zeta)\) and
commutativity of the original multiplication maps.  Multiplication
by \(1+Z\) sends degree at most \(N\) to degree at most
\(N+1\), and sends a multiple of \(\mu_\zeta\) to
another such multiple.  Therefore (KPC.22a) is well-defined
on the complete source quotients in (KPC.17).  It is an
adjacent-shell action; it does not assert that
\(\mathbb C[\zeta]\) alone is invariant under
\(A^{(2)}\).  For example, if the packet has two distinct
centres \(\rho,\sigma\), the diagonal pairs
\((\rho,\rho)\) and \((\sigma,\sigma)\) both have
ratio one, while the constant terms of their summed generators
are \(2\rho\) and \(2\sigma\).  A polynomial in the
ratio has the same constant term at both pairs, so it cannot
equal that summed coordinate.  Formula (KPC.22a) retains the
missing second-coordinate multiplication explicitly.

\begin{theorem}[Exact algebra-retraction criterion]
In the local algebra
\(R_{\rho,\sigma}=\mathbb C[x,y]/(x^m,y^n)\), with
\(\rho,\sigma\ne0\), the ratio-subalgebra inclusion
\(\mathbb C[\zeta]\hookrightarrow R_{\rho,\sigma}\)
admits a unital complex-algebra retraction exactly when
\(\min(m,n)=1\).  In the full original tensor algebra
\(E_h^{\otimes2}\), the inclusion (KPC.16) admits a unital
complex-algebra retraction exactly when \(h\) is squarefree.
\end{theorem}

\begin{proof}
First suppose \(m=1\), so \(x=0\) and
\(\zeta=\rho/(\sigma+y)\).  This element is a unit,
and \(y=\rho\zeta^{-1}-\sigma\).  Its inverse belongs
to the ratio subalgebra: \(\zeta=r+w\), with
\(r=\rho/\sigma\ne0\) and \(w^n=0\), has inverse
\(\sum_{j=0}^{n-1}(-1)^jw^j/r^{j+1}\).
Thus the ratio subalgebra contains y and is the whole local
algebra.  If \(n=1\), then \(y=0\) and
\(x=\sigma\zeta-\rho\), giving the same conclusion.
In both cases the inclusion is an isomorphism and its inverse
is the asserted retraction.

Now suppose \(m,n\ge2\), and put \(L=m+n-1\).
The exact local index proved above identifies the ratio
subalgebra with \(B=\mathbb C[t]/(t^L)\), by
\(t\mapsto\zeta-\rho/\sigma\).
In any putative retraction \(f:R_{\rho,\sigma}\to B\),
the images of x and y have zero constant term because their
powers vanish.  If the coefficient of t in f(x) were a
nonzero number a, the coefficient of \(t^m\) in
\(f(x)^m\) would be \(a^m\ne0\).  Since \(m<L\),
that term survives in B, contradicting \(x^m=0\).
The same argument using \(n<L\) shows that f(y) also
has zero linear coefficient.  The exact expression (KPC.20)
then makes \(f(\zeta-\rho/\sigma)\) have zero linear
coefficient: its numerator lies in \((t^2)\) and its
denominator is a unit.  A retraction would send that element
to t.  This contradiction proves the local converse.

If h is squarefree, (KPC.19) identifies the full tensor
algebra with \(\mathbb C^{Z\times Z}\).  The ratio
subalgebra is the algebra of functions constant on every fibre
of \((\rho,\sigma)\mapsto\rho/\sigma\).
Indeed (KPC.15) has exponent one at each ratio, and ordinary
polynomial interpolation gives every assignment of values on
the distinct ratios.  Choose one ordered pair in each such
fibre.  Restriction of a function to those chosen pairs,
then assigning that value to the entire corresponding fibre,
is a unital algebra map back to this subalgebra.  It is the
identity on the subalgebra, proving existence of a retraction.

Conversely, let \(M=\max_\rho m_\rho\ge2\).
The ratio-one component in (KPC.15) is
\[
 B_1=\mathbb C[t]/(t^{2M-1}),\qquad
        \zeta\longmapsto1+t.
 \tag{KPC.22b}
\]
This is because \(\rho/\sigma=1\) for nonzero centres
exactly when \(\rho=\sigma\), and the maximum of
\(2m_\rho-1\) is \(2M-1\).
Compose a proposed global retraction with projection onto
\(B_1\).  A unital map from the product (KPC.19) into
\(B_1\) selects exactly one local factor.  To justify
that statement, an idempotent of \(B_1\) has constant
term zero or one.  If it is zero, the idempotent lies in
the nilpotent ideal \((t)\), and an idempotent which is
nilpotent is zero, since all its positive powers equal
itself.  If the constant term is one, apply this argument
to one minus the idempotent.  Hence the only idempotents
are zero and one.  The mutually orthogonal source-factor
idempotents sum to one, so exactly one maps to one and
all others map to zero, proving the selection statement.

Suppose the selected factor is indexed by \((\rho,\sigma)\).
Images of its nilpotent coordinates have zero constant term,
so the constant term of its ratio image is \(\rho/\sigma\).
Equation (KPC.22b) forces this ratio to be one; thus
\(\rho=\sigma\), with common multiplicity
\(m=m_\rho\le M<2M-1\).  The relation \(x^m=0\)
again forces the coefficient of t in the image of x to
vanish, since a nonzero coefficient would produce a
nonzero \(t^m\) term in the target.  The same holds for y.
Their ratio minus one therefore has zero linear coefficient
by (KPC.20), contradicting its required image t in
(KPC.22b).  This proves the global converse while retaining
all source-factor idempotents and the original ratio embedding.
\end{proof}

\subsection{A complete finite witness for unequal shell ranks}

The following positive polynomial model tests the proposed passage
from homogeneous rank to the original orthogonal rank.  It is not
a claim that \(1/2\) is an arithmetic zero.  Use the specified
measure
\[
 \nu_{\rm ex}=\delta_{1/2-i}+\delta_{1/2}+\delta_{1/2+i}
 \quad\hbox{on the variable }s,\qquad
 h_{\rm ex}(s)=s-\tfrac12,\qquad \upsilon_{\rm ex}=1.
 \tag{KPC.23}
\]
All three masses are exactly one.  Through degree two the monic
orthogonal polynomials and norms are
\[
 \begin{array}{c|c|c}
 j&p_j(s)&\kappa_j\\\hline
 0&1&3\\
 1&s-\tfrac12&2\\
 2&(s-\tfrac12)^2+\tfrac23&\tfrac23.
 \end{array}
 \tag{KPC.24}
\]
To verify the complete Gram, their three value columns are
\[
 (1,1,1)^T,\qquad (-i,0,i)^T,\qquad(-1/3,2/3,-1/3)^T.
\]
Their pairwise Hermitian inner
products are zero, and their squared norms are respectively
\(3\), \(1+0+1=2\), and
\(1/9+4/9+1/9=2/3\).  Thus the moment form through degree
two is positive definite, as required for the source and next
layer used below.

Take \(k=2\), \(N=1\).  Here \(d=1\) and the
threshold \(N\ge k(d-1)=0\) holds.  The original tensor
residue algebra is \(E^{(2)}_{\rm ex}=\mathbb C\), with
\(s_1=s_2=1/2\), and its full jet map is evaluation at
that ordered pair.  For \(c=c_{10}s_1+c_{01}s_2\),
the two section and image maps are exactly
\[
 \begin{split}
 i_1(c)&=c_{10}s_1+c_{01}s_2,\\
 O_1(c)&=c_{10}(s_1-\tfrac12)+c_{01}(s_2-\tfrac12),\\
 L_1(c)&=-\tfrac12(c_{10}+c_{01}),\\
 A_1^{\rm hom}(c)&=\tfrac12(c_{10}+c_{01}),
       \qquad A_1^{\rm orth}(c)=0.
 \end{split}                                                    \tag{KPC.25}
\]
Thus the lower coefficient in (KPC.7) cancels the entire
homogeneous image.  The ranks are one and zero.  The kernels are
\(K_h=\{(c_{10},c_{01}):c_{10}+c_{01}=0\}\) and
\(K_o=\mathbb C^2\), so the common quotient in (KPC.10)
is zero and the full correspondence is \(\mathbb C\oplus\{0\}\).
The ratio is \(\zeta=1\), its minimal polynomial is
\(Z-1\), and (KPC.18) gives the correct homogeneous rank
\(\min(2,1)=1\).  Equation (KPC.25) proves explicitly
why it gives no equality with the orthogonal rank.

The actual finite minimum and next layer in this model can also
be retained.  In the source with product measure
\(\nu_{\rm ex}^{\otimes2}\), the degree-at-most-one
orthogonal basis is
\(p_0p_0,p_1p_0,p_0p_1\), with norms \(9,6,6\)
and jets \(1,0,0\).  Hence the full interpolation kernel
is \(K_1=1/9\), the metric is \(G_1=9\), and its
minimum is the constant polynomial \(R_1u=u\).
Multiplication by the original sum \(s_1+s_2\) acts on
the packet by \(A=1\).  Consequently
\[
 B_1u=(s_1+s_2-1)u\in\mathcal L_1,
 \qquad C_1=(I-P_{\mathcal L_1})B_1=0,\qquad
 W_1=A^*G_1+G_1A-2G_1=0.
 \tag{KPC.26}
\]
Indeed \(\mathcal L_1\) is spanned by
\(s_1-1/2,s_2-1/2\), the complete degree-one relation
kernel.  Thus the derivative rank zero is verified directly
without presupposing the shell-rank formula.

At the next shell, ordered as \((2,0),(1,1),(0,2)\),
the original jets and norm diagonal are
\[
 U=\begin{pmatrix}2/3&0&2/3\end{pmatrix},\qquad
 D_{\rm next}=\operatorname{diag}(2,4,2).
\]
The actual layer vectors are
\(e_{20}=(s_1-1/2)^2\),
\(e_{11}=(s_1-1/2)(s_2-1/2)\), and
\(e_{02}=(s_2-1/2)^2\).  Each has zero jet and is
orthogonal to \(\mathcal L_1\), either by its product
moments or by the layer construction.  Their Gram is exactly
\[
 H=D_{\rm next}+U^*G_1U
   =\begin{pmatrix}6&0&4\\0&4&0\\4&0&6\end{pmatrix}.
 \tag{KPC.27}
\]
For example the diagonal squared norm of \(e_{20}\) is
\((1+0+1)(1+1+1)=6\), and its pairing with \(e_{02}\)
is \((-1+0-1)^2=4\); the odd cross terms vanish.
The eigenvalues of the outer two-coordinate block are \(10,2\),
and the middle eigenvalue is \(4\), proving positivity.
The next full kernel and metric therefore are
\[
 K_2=\frac19+\frac{(2/3)^2}{2}
                  +\frac{(2/3)^2}{2}=\frac59,
 \qquad G_2=\frac95.
 \tag{KPC.28}
\]
The representative itself is the explicit polynomial
\[
 R_2u=\left[1+\frac35
       \bigl((s_1-\tfrac12)^2+(s_2-\tfrac12)^2\bigr)\right]u.
 \tag{KPC.28a}
\]
For a direct verification, it has jet u.  Its values for u equal
to one are \(-1/5\) at the four product nodes where both
coordinates differ from \(1/2\), \(2/5\) at the four
nodes where exactly one differs, and one at the central node.
Its squared norm is therefore
\(4/25+16/25+1=9/5\).  It is orthogonal to the five
relation basis vectors
\(s_1-1/2,s_2-1/2,e_{20},e_{11},e_{02}\).
The first two and \(e_{11}\) have an odd coordinate, so
their pairings vanish by the explicit sign symmetry of the
nine-node measure.  For \(e_{20}\), only the two noncentral
first-coordinate values contribute, and for each of them the
sum of the three values of \(R_2(1)\) is
\(-1/5+2/5-1/5=0\).  Its pairing is thus zero; the
same computation with the coordinates interchanged treats
\(e_{02}\).  These five independent zero-jet polynomials
span the kernel in the six-dimensional degree-at-most-two
source, whose jet map is onto the one-dimensional target.
Every other feasible polynomial differs by a vector in this
kernel.  Pythagoras and positive definiteness therefore prove
the unique-minimum assertion directly, including its actual norm.
Thus the nonzero original relation layer and its positive metric
loss are retained alongside the zero derivative layer.  This
complete finite calculation rejects only the proposed equality
between homogeneous and orthogonal-shell ranks.  The original
arithmetic shell continues to be given by (KPC.4)--(KPC.7),
and the exact graph and quotient maps relating its two presentations
are (KPC.9)--(KPC.12).

Every linear map \(T:V\to W\) in these comparisons has a
support-preserving Split-Zero lift on the following specified
carriers at a fixed support \(\lambda\):
\[
 \widehat V_\lambda=\{\tau_V\}\sqcup(\{\lambda\}\times V),
 \qquad \widehat W_\lambda=\{\tau_W\}\sqcup(\{\lambda\}\times W).
\]
Addition has external \(\tau\) as identity and uses vector
addition inside the supported fibre.  The scalar action is
\(r^\bullet(\lambda,v)=(\lambda,rv)\), while the external
scalar zero sends every input to external absence and every
scalar sends external absence to external absence.  The lift
maps \(\tau_V\) to \(\tau_W\) and
\((\lambda,v)\) to \((\lambda,Tv)\).  Its addition
identity follows from \(T(v+w)=Tv+Tw\); its supported-scalar
identity follows from \(T(rv)=rTv\), including \(r=0\).
The external cases follow from the definitions.  Thus every
displayed kernel vector maps to the represented zero at
\(\lambda\), and the graph, quotient and lower-degree maps
retain this support even when the two ranks differ.

```
