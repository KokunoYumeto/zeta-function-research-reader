# Terminal continuation: exact boundary energy and arithmetic volume closure

Date: 2026-09-12. Work lane: kernel_asymptotic_route, continuation after the separate published f6a85fc073350c78694300f05d6a7ecd6d8787cc edition.

The new authoritative proof is `tex/kernel_terminal_continuation.tex`. No earlier published fragment was edited during this continuation. This file includes KT.1–KT.28 and the complete TEC.1–TEC.32 rational finite-measure example; the separately retained `tex/terminal_energy_counterexample.tex` is a companion source witness, not an additional reader include.

The exact original polynomial metric update and three scalar updates remain defined at every packet centre, including critical quadrature intersections and the zero-column case. They give an exact transverse boundary-energy increment with all drift and cross terms. The rational terminal recurrence is related to that universal calculation by the proved original-coordinate isometry. Doubled Taylor data, with the exact square-zero extension sequence, recover the terminal metric from initial error and genuine tail data on the off-line summand; its critical kernel and projected polynomial congruence are retained.

For an actual packet closed under conjugation and reflection, coefficient reality and the trace identity prove gamma_n=0. Consequently the actual allowance is exactly

\[
\epsilon_m^2=\frac{\kappa_{d+m+1}}{\kappa_{d+m}}
\frac{(1-r_m)(1-r_{m+1})}{r_{m+1}},
\qquad r_m=\det G_m/\det G_{m-1},\qquad m\geq0,
\]

with the original fixed-section metric G_{-1}. This closes the weight expression in consecutive source-volume contractions and the actual recurrence norm ratio. It supplies no unproved asymptotic estimate of those quantities.

The complete positive nine-atom example proves that the general recurrence and reflection alone allow increasing consecutive energy. Every atom, all moments through degree ten, the actual fifth orthogonal norm 114/16^5, all packet coordinate maps, and both characteristic polynomials are computed. This example is a separate specified measure; its typed moment-to-packet construction identifies exactly the data it shares with the arithmetic calculation.

Independent reviews: `logbook/terminal_energy_independent_audit_20260912.md` covers the universal energy laws, exceptional fibres, exact model and actual quartet specialization; `logbook/terminal_doubled_jet_audit_20260912.md` covers KT.19–KT.27 with an exact subsection hash. Supplementary reproducible checks: 288 recurrence, 88 finite-model, and 66 quartet-volume identities, each passing in ordinary and optimized Python (442 per mode). These are identity calibrations on their explicitly recorded measures and packets, not theorem counts, zeta-zero computations, or proofs of an arithmetic asymptotic.

Final isolated source compile: 11 pages, no overfull boxes, undefined controls, missing characters, or remaining LaTeX/package warnings. One cosmetic underfull paragraph remains. This is a compile check; cumulative visual review belongs to the paper-build lane. Build receipt is staged separately. The final source SHA256 is 6932E3C4D350AECE95C003083D8938668D60BD81B2EBCEBA6EB1B78A510B2E9F.

The next concrete arithmetic calculation uses the original moments to estimate the two determinant contractions r_m,r_{m+1} jointly with kappa_{d+m+1}/kappa_{d+m}. For non-completed packets the universal formula retains the original transverse A-image and its real cross pairing. The exact initial-error/tail extraction remains available with all denominators and doubled jets recorded.

## Complete proof source

```latex
\section{The exact terminal step and its retained boundary energy}
\label{sec:terminal-continuation}

All measures, packet coordinates and maps in this section are the
original arithmetic ones.  Thus \(s=1/2+it\),
\(d\nu_Z=|g(s)/h(s)|^2dt/(2\pi)\),
\(E=\mathbb C[s]/(h)\), \(A=M_s\), and \(c=j_h1\).
Every selected zero occurs with its complete multiplicity in \(h\).
Retain the monic \(q_n\), their actual norms \(\kappa_n\), and
\[
 a_n=\frac{\kappa_n}{\kappa_{n-1}}>0,\qquad
 q_{n+1}(s)=(s-b_n)q_n(s)+a_nq_{n-1}(s),\qquad
 b_n+\overline b_n=1.                                      \tag{KT.1}
\]
No recurrence coefficient is replaced by a limiting value.

\subsection{A step written entirely in the original polynomial packet}

For \(n\geq d=\deg h\), put
\[
 v_j=q_j(A)c,\qquad K=K_{n-1}=\sum_{j=0}^{n-1}
                     \frac{v_jv_j^*}{\kappa_j}>0,
 \qquad M_n=\kappa_{n-1}^{-1}K_{n-1}^{-1}.
                                                               \tag{KT.2}
\]
Use the positive form \(\langle x,y\rangle_n=x^*M_ny\),
conjugate-linear in its first argument, and define
\[
 u_n=v_n,\qquad w_n=v_{n-1},\qquad
 \alpha_n=\langle w_n,w_n\rangle_n,\quad
 \beta_n=\langle u_n,u_n\rangle_n,\quad
 \gamma_n=\langle u_n,w_n\rangle_n.
                                                               \tag{KT.3}
\]
The arithmetic relative allowance at source level \(m=n-d-1\)
will be denoted by \(\epsilon^{(n)}\).  The fixed-section extension
at \(m=-1\) has already been specified; the original corrected
sequence has \(n\geq d+1\).
The exact kernel boundary identity gives
\[
 \epsilon^{(n)}=|\operatorname{Re}\gamma_n|
   +\sqrt{\alpha_n\beta_n-(\operatorname{Im}\gamma_n)^2},
 \qquad
 \operatorname{Re}\gamma_n
       =\operatorname{Re}\operatorname{tr}A-\frac d2=:g_Z.
                                                               \tag{KT.4}
\]
Indeed the kernel weight form is
\((u_nw_n^*+w_nu_n^*)/\kappa_{n-1}\).  Its possible nonzero
generalized eigenvalues are obtained by reversing the two
rectangular factors, giving
\(\operatorname{Re}\gamma_n\pm
\sqrt{\alpha_n\beta_n-(\operatorname{Im}\gamma_n)^2}\).
Taking the trace after multiplication by \(K^{-1}\) gives the
second identity.  Cauchy--Schwarz proves the nonnegativity of the
radicand and justifies the maximum absolute value in (KT.4).

\begin{theorem}[Universal scalar and metric step]
Write \(a=a_n\), and retain the exact next vector
\[
 t_n=(A-b_nI)u_n+a_nw_n=v_{n+1}.                         \tag{KT.5}
\]
Then
\[
 \boxed{M_{n+1}=\frac1a\left(M_n-
          \frac{M_nu_nu_n^*M_n}{a+\beta_n}\right),}       \tag{KT.6}
\]
\[
 \boxed{\begin{aligned}
 \alpha_{n+1}&=\frac{\beta_n}{a+\beta_n},\\
 \gamma_{n+1}&=\frac{\langle t_n,u_n\rangle_n}{a+\beta_n},\\
 \beta_{n+1}&=\frac1a\left(\langle t_n,t_n\rangle_n
             -\frac{|\langle u_n,t_n\rangle_n|^2}
                         {a+\beta_n}\right).
 \end{aligned}}                                         \tag{KT.7}
\]
Every denominator is strictly positive.  These identities hold
also when any selected critical centre equals a quadrature node,
and when \(q_n(A)\) is singular.

The exact determinant changes of the kernel and original theta
metric are
\[
 \boxed{\frac{\det K_n}{\det K_{n-1}}=1+\frac{\beta_n}{a_n},
 \qquad
 \frac{\det G_{m+1}}{\det G_m}
       =\frac{a_n}{a_n+\beta_n}=1-\alpha_{n+1}.}          \tag{KT.8}
\]
\end{theorem}

\begin{proof}
The unchanged kernel update is
\(K_n=K_{n-1}+u_nu_n^*/\kappa_n\).
Its inverse is verified by multiplication:
\[
 K_n^{-1}=K^{-1}-
   \frac{K^{-1}u_nu_n^*K^{-1}}{\kappa_n+u_n^*K^{-1}u_n}.
\]
Insert \(\kappa_n=a\kappa_{n-1}\) and the definition of
\(M_n\); this gives (KT.6).  At the next step the ordered vectors
in (KT.3) are \(u_{n+1}=t_n,w_{n+1}=u_n\).
Pair each ordered pair with (KT.6).  The three resulting expressions
are precisely (KT.7), including their conjugations.
The denominator is positive because \(a>0,\beta_n\geq0\).
The determinant of the rank-one update is
\(1+u_n^*K^{-1}u_n/\kappa_n=1+\beta_n/a\); this follows
directly by expanding the determinant multilinearly in its columns.
The original metric is
\(G_m=U_\varepsilon^*K_{n-1}^{-1}U_\varepsilon\), with the
same fixed invertible local unit at adjacent levels.  Its determinant
ratio is therefore the inverse kernel ratio.  Equation (KT.7) gives
the last equality in (KT.8).
All calculations use polynomial residues at \(A\); no inverse of
\(q_n(A)\) has been used.
\end{proof}

\subsection{The complete boundary-energy increment}

Suppose first that \(\beta_n>0\).  The exact orthogonal projection
for \(\langle\cdot,\cdot\rangle_n\) is
\[
 \begin{gathered}
 P_nx=x-u_n\frac{\langle u_n,x\rangle_n}{\beta_n},\qquad
 p_n=P_nw_n,\qquad z_n=P_nAu_n,\\
 \Delta_n=\alpha_n\beta_n-|\gamma_n|^2
                =\beta_n\|p_n\|_n^2,
 \qquad \Omega_n=\beta_n\|z_n\|_n^2.
 \end{gathered}                                         \tag{KT.9}
\]
The projection records a specified map inside the original packet;
\(Au_n\), its removed coefficient, and its remaining vector
\(z_n\) are all retained in (KT.9).

\begin{theorem}[Exact transverse energy law]
At every such step,
\[
 \boxed{\Delta_{n+1}
    =\frac{\beta_n\|z_n+a_np_n\|_n^2}
                          {a_n(a_n+\beta_n)}.}          \tag{KT.10}
\]
Consequently
\[
 \boxed{\Delta_{n+1}-\Delta_n
  =\frac{\beta_n}{a_n(a_n+\beta_n)}
       \left(\|z_n\|_n^2
        +2a_n\operatorname{Re}\langle z_n,p_n\rangle_n
        -a_n\beta_n\|p_n\|_n^2\right).}                \tag{KT.11}
\]
The exact energy law gives the following two-sided bounds by
the sharp triangle inequalities:
\[
 \frac{|a_n\sqrt{\Delta_n}-\sqrt{\Omega_n}|}
             {\sqrt{a_n(a_n+\beta_n)}}
 \leq\sqrt{\Delta_{n+1}}
 \leq\frac{a_n\sqrt{\Delta_n}+\sqrt{\Omega_n}}
             {\sqrt{a_n(a_n+\beta_n)}}.                 \tag{KT.12}
\]
The actual relative allowance is recovered exactly by
\[
 \boxed{\epsilon^{(n)}=|g_Z|+\sqrt{g_Z^2+\Delta_n}.}      \tag{KT.13}
\]
For a reflection-stable packet with its multiplicities,
\(g_Z=0\), so the energy law calculates the square of the actual
allowance without a trace term.
\end{theorem}

\begin{proof}
Let \(T=\langle t_n,t_n\rangle_n\) and
\(v=\langle u_n,t_n\rangle_n\).  Substitution of (KT.7) gives
\[
 \alpha_{n+1}\beta_{n+1}-|\gamma_{n+1}|^2
       =\frac{\beta_n T-|v|^2}{a_n(a_n+\beta_n)}
       =\frac{\beta_n\|P_nt_n\|_n^2}{a_n(a_n+\beta_n)}.
\]
Since \(P_nu_n=0\), the exact recurrence (KT.5) gives
\(P_nt_n=P_nAu_n+a_nP_nw_n=z_n+a_np_n\).
This proves (KT.10).  Expand the squared norm and subtract
\(\Delta_n=\beta_n\|p_n\|_n^2\) to prove (KT.11).
The triangle inequality and its reverse, applied to these two
specific vectors, prove (KT.12).  Finally (KT.4) gives
(KT.13).  Its real trace term is unchanged with \(n\); equivalently
the same trace computation can be performed at each adjacent
positive kernel.  Reflection permutes all roots and multiplicities,
so \(2\operatorname{Re}\operatorname{tr}A=d\) in that case.
\end{proof}

If \(\beta_n=0\), positivity of \(M_n\) forces \(u_n=v_n=0\).
Then \(\gamma_n=0\), the current kernel weight is zero,
\(K_n=K_{n-1}\), and (KT.5)--(KT.7) give the entire exceptional
step:
\[
 t_n=a_nw_n,\qquad
 \alpha_{n+1}=\gamma_{n+1}=0,\qquad
 \beta_{n+1}=a_n\alpha_n,\qquad
 \Delta_n=\Delta_{n+1}=0,
 \quad\epsilon^{(n)}=\epsilon^{(n+1)}=0.                 \tag{KT.14}
\]
Moreover \(v_n=0\) is exactly the divisibility \(h\mid q_n\).
Since every root of \(q_n\) is simple and lies on the Mellin line,
this particular event forces the selected packet to consist of
simple line roots.  It does not remove the resulting packet or
the next vectors in (KT.14).

\subsection{The exact rational terminal step and its polynomial continuation}

Where \(q_n(A)\) and \(q_{n+1}(A)\) are invertible, use the
actual terminal maps and Gram from Section~\ref{sec:kernel-resolvent}:
\[
 T_n=F_n(A),\quad r_n=T_nc,\quad Q_n=q_n(A),\qquad
 K_{n-1}=\kappa_{n-1}^{-1}Q_nS_nQ_n^*.
\]
The map \(Q_n\) is the exact isometry
\[
 Q_n:(E,S_n^{-1})\longrightarrow(E,M_n),\qquad
 Q_nc=u_n,\quad Q_nr_n=w_n.                              \tag{KT.15}
\]
Indeed \(Q_n^*M_nQ_n=S_n^{-1}\) follows by inverting the
displayed Gram congruence, and the vector identity uses
\(F_n=q_{n-1}/q_n\).  This proves the precise relation between
the rational and polynomial forms of (KT.3)--(KT.13).

The terminal recurrence gives
\[
 T_{n+1}=(A-b_nI+a_nT_n)^{-1},\qquad
 \boxed{S_{n+1}=T_{n+1}(cc^*+a_nS_n)T_{n+1}^*.}          \tag{KT.16}
\]
For a direct full-jet proof, the scalar kernel of a terminal
observation is
\[
 H_{F_n}(z,w)=\frac{F_n(z)+\overline{F_n(w)}}
                        {z+\overline w-1}.
\]
The quotient denotes its removable polynomial/rational continuation
where numerator and denominator both vanish.  It is identically the
positive resolvent Gram
\(\sum_j\sigma_{n,j}/[(z-\lambda_{n,j})
(\overline w-\overline\lambda_{n,j})]\).
Substitution of \(F_{n+1}=(z-b_n+a_nF_n)^{-1}\) gives
\[
 H_{F_{n+1}}(z,w)=F_{n+1}(z)\overline{F_{n+1}(w)}
                           [1+a_nH_{F_n}(z,w)].         \tag{KT.17}
\]
This identity holds first away from its removable sets and hence
through them by continuation.  Taking the complete residue on both
variables proves (KT.16).  It also follows from the original
kernel update and \(Q_{n+1}^{-1}Q_n=T_{n+1}\).
Thus a quadrature collision is handled by the polynomial formulas
(KT.2)--(KT.14), which retain all coordinates; (KT.15) states
exactly the isometry on the open set where the rational presentation
is defined.

In this presentation the determinant still retains the entire
polynomial factor:
\[
 \frac{\det S_{n+1}}{\det S_n}
  =\frac{a_n^{d-1}(a_n+\beta_n)}
    {|\det(A-b_nI+a_nT_n)|^2},\qquad
 \det(A-b_nI+a_nT_n)
   =\prod_{\rho\in Z}
       \left(\frac{q_{n+1}(\rho)}{q_n(\rho)}\right)^{m_\rho}.
                                                               \tag{KT.18}
\]
The determinant of \(a_nS_n+cc^*\) gives the first formula.
The second follows by evaluating the polynomial ratio on each
full triangular Taylor block \(\rho I+N_\rho\).  The determinant
has the stated multiplicity even when the block is not semisimple.

\subsection{The extra jets required to recover the metric from the tail}

There is an exact map from the scalar tail identity to the matrix
energy, with a specified number of Taylor coefficients.
For (KT.19)--(KT.22), take centres at which \(q_n\) is nonzero,
so \(F_n\) is holomorphic there.  Every off-line centre meets this
condition.  At a critical quadrature intersection the universal
polynomial formulas (KT.2)--(KT.14) retain the complete packet.
The
terminal function satisfies
\(\overline{F_n(1-\overline z)}=-F_n(z)\), by its positive
spectral sum on the line.  Thus
\[
 H_{F_n}(z,w)=
   \frac{F_n(z)-F_n(1-\overline w)}{z-(1-\overline w)}.   \tag{KT.19}
\]
For centres \(\rho,\sigma\), and Taylor orders
\(0\leq k<m_\rho,0\leq l<m_\sigma\), let
\(S_n^{\rm jet}(\rho,k;\sigma,l)\) denote the coefficient
of \((z-\rho)^k(\overline w-\overline\sigma)^l\) in this
kernel.  In particular, at a reflection pair,
\[
 \boxed{S_n^{\rm jet}(\rho,k;\sigma,l)
       =(-1)^lF_n^{[k+l+1]}(\rho)
       \quad\hbox{if }\rho=1-\overline\sigma.}          \tag{KT.20}
\]
Here \(F^{[j]}=F^{(j)}/j!\).  To prove the formula, put
\(z=\rho+x\), \(1-\overline w=\rho-y\) in (KT.19),
and expand
\[
 \frac{x^r-(-y)^r}{x+y}
      =\sum_{j=0}^{r-1}x^{r-1-j}(-y)^j.
\]
The coefficient of \(x^ky^l\) is supplied exactly by
\(r=k+l+1,j=l\), proving (KT.20) without dividing by zero.

For \(D_{\rho\sigma}=\rho+\overline\sigma-1\ne0\), the
corresponding complete coefficient is
\[
 \begin{split}
 S_n^{\rm jet}(\rho,k;\sigma,l)
 ={}&\sum_{i=0}^k F_n^{[i]}(\rho)
   \frac{(-1)^{k-i+l}\binom{k-i+l}{k-i}}
                     {D_{\rho\sigma}^{k-i+l+1}}\\
 &+\sum_{j=0}^l\overline{F_n^{[j]}(\sigma)}
   \frac{(-1)^{k+l-j}\binom{k+l-j}{k}}
                     {D_{\rho\sigma}^{k+l-j+1}}.
 \end{split}                                             \tag{KT.21}
\]
This is the full product of the numerator Taylor series and the
geometric expansion of \((D_{\rho\sigma}+x+y)^{-1}\).
Both constant terms in the numerator are retained.
If \(V_Z:E\to\bigoplus_\rho\mathbb C^{m_\rho}\) is the
fixed complete Taylor-coordinate map, then
\[
 S_n^{\rm jet}=V_ZS_nV_Z^*,\qquad
 S_n=V_Z^{-1}S_n^{\rm jet}(V_Z^{-1})^*.                  \tag{KT.22}
\]
This follows by applying \(V_Z\) to each resolvent column in
the positive Gram representation of \(S_n\).

To specify the domain of the analytic extraction, let
\(h_{\rm off}=\prod_{\operatorname{Re}\rho\ne1/2}
(s-\rho)^{m_\rho}\).  The full original algebra projects onto
\(E_{\rm off}=\mathbb C[s]/(h_{\rm off})\); the kernel is
the retained critical-line CRT summand, with its original action
of \(A\).  Above the off-line summand use the doubled algebra
\(\widehat E_{\rm off}=\mathbb C[s]/(h_{\rm off}^2)\).
Its exact reduction sequence of \(\mathbb C[s]\)-modules is
\[
 0\longrightarrow E_{\rm off}
   \xrightarrow{\ [p]\mapsto[h_{\rm off}p]\ }
   \widehat E_{\rm off}
   \xrightarrow{\ [p]\mapsto[p]\ } E_{\rm off}
   \longrightarrow0.                                   \tag{KT.23}
\]
The first map is well-defined and injective because
\(h_{\rm off}^2\mid h_{\rm off}p\) holds exactly when
\(h_{\rm off}\mid p\); its image is precisely the kernel
of the reduction.  All maps commute with multiplication by \(s\).
The reduction is also a unital algebra map.  The image of the
injection is the square-zero ideal \((h_{\rm off})/(h_{\rm off}^2)\):
the product of the images of \([p]\) and \([q]\) is
\([h_{\rm off}^2pq]=0\).  This records its complete inherited
multiplication as well as its module isomorphism with \(E_{\rm off}\).
The nilpotent lengths in the middle term are exactly
\(2m_\rho\), and reduction retains the lower \(m_\rho\)
coefficients.  At reflected actual zeros, the full multiplicities
are equal, by the functional equation and conjugation of \(g\).
Thus (KT.20) uses at most order \(2m_\rho-1\), exactly a
coefficient of this doubled algebra.  Formula (KT.21) uses only
the stated lower coefficients.  Equations (KT.20)--(KT.23) prove
the precise passage from terminal Taylor data to the full metric.

Write \(\mathcal E_n=m-m_n\) for the initial observation error,
and retain the genuine tail \(\zeta_n\) from (KR.14).
For every off-line point its real part has the sign of
\(\operatorname{Re}z-1/2\), so \(\zeta_n\ne0\).
The exact identity (KR.16) also gives
\[
 \mathcal E_n(z)=\frac{(-1)^n\kappa_n}{q_n(z)^2}
    H_n^{\rm obs}(z),\qquad
 H_n^{\rm obs}(z)=\frac1{\kappa_n}
              \int\frac{|q_n(s)|^2}{z-s}\,d\nu_Z.
\]
The real part of \(H_n^{\rm obs}\) has that same strict sign:
its defining measure is positive of total mass one.  Hence
\(\mathcal E_n(z)\ne0\) off the line as well.
Solving the actual tail equation, before taking any residues,
therefore gives the exact extraction
\[
 \boxed{F_n(z)=\frac1{a_n}
   \left(\frac{(-1)^n\kappa_n}{q_n(z)^2\mathcal E_n(z)}
                         -\frac1{\zeta_n(z)}\right).}   \tag{KT.24}
\]
It holds in the complete doubled algebra at the off-line centres.
Every reciprocal there is explicit: if
\(f(\rho+x)=\sum_{j=0}^{2m_\rho-1}f_jx^j\) modulo
\(x^{2m_\rho}\), with \(f_0\ne0\), the inverse coefficients
are
\[
 b_0=f_0^{-1},\qquad
 b_k=-f_0^{-1}\sum_{j=1}^kf_jb_{k-j}
                   \quad(1\leq k<2m_\rho).             \tag{KT.25}
\]
Multiplication of the two finite series proves all coefficients.
The already proved bounds (GC.13)--(GC.16) apply to every one of
the error coefficients required here.  Equations (KT.24)--(KT.25),
then (KT.20)--(KT.22), give a complete finite extraction of the
terminal metric on \(E_{\rm off}\) from the initial error and
genuine tail data.  In the retained monomial quotient coordinates,
set \(A_{\rm off}=M_s\),
\(\pi_{\rm off}([p]_h)=[p]_{h_{\rm off}}\), and
\(c_{\rm off}=[1]=\pi_{\rm off}c\).
Explicitly, retain the same \(\nu_Z\),
\(q_n\), nodes and terminal weights, and put
\[
 S_n^{\rm off}=\sum_j\sigma_{n,j}
   (A_{\rm off}-\lambda_{n,j}I)^{-1}c_{\rm off}c_{\rm off}^*
   (A_{\rm off}^*-\overline\lambda_{n,j}I)^{-1}.
                                                               \tag{KT.26}
\]
For the original quotient map \(\pi_{\rm off}:E\to E_{\rm off}\),
the resolvent intertwining identity gives
\(S_n^{\rm off}=\pi_{\rm off}S_n\pi_{\rm off}^*\) whenever
the full rational Gram is defined.  The right side of (KT.26)
remains defined at every off-line centre even when the full packet
has a critical quadrature collision.  No replacement of the measure
by \(|g/h_{\rm off}|^2dt/(2\pi)\) occurs in this projection.
The full polynomial quadrature formula, applied to these projected
residue columns, proves even at such a collision that
\[
 \pi_{\rm off}K_{n-1}\pi_{\rm off}^*
   =\kappa_{n-1}^{-1}q_n(A_{\rm off})S_n^{\rm off}
                                     q_n(A_{\rm off})^*.
                                                               \tag{KT.27}
\]
These extraction formulas retain the inverse error, the inverse tail, \(q_n\),
\(\kappa_n\), and \(a_n\), including their cancellations.
The initial error bound alone is not used to replace any of those
terms.  The polynomial metric step (KT.6) continues to include the
critical-line summand, where the off-line resolvent domain ends.

\subsection{Actual quartet packets close the energy in two volume ratios}

Assume here that the selected actual packet is closed under both
\(\rho\mapsto\overline\rho\) and
\(\rho\mapsto1-\overline\rho\), with the complete multiplicities.
These are exact invariances of the specified divisor; no value of
\(\operatorname{Re}\rho\) has been imposed.

\begin{theorem}[Two consecutive arithmetic volume contractions]
Let \(G_{-1}\) be the fixed-section metric already identified
with \(U_\varepsilon^*K_{d-1}^{-1}U_\varepsilon\), and define
the actual positive determinant ratios
\[
 r_m=\frac{\det G_m}{\det G_{m-1}}\quad(m\geq0).
\]
Then \(0<r_m\leq1\), and for every \(m\geq0\), with
\(n=d+m+1\),
\[
 \boxed{\epsilon_m^2
   =\frac{\kappa_{d+m+1}}{\kappa_{d+m}}
       \frac{(1-r_m)(1-r_{m+1})}{r_{m+1}}.}             \tag{KT.28}
\]
This is the original relative allowance and the original theta
Gram sequence, including their local unit and all multiplicities.
\end{theorem}

\begin{proof}
Conjugation invariance of the divisor makes every coefficient of
the monic \(h\) real.  The entire function \(g\) obeys
\(g(\overline s)=\overline{g(s)}\), so the unchanged density
\(|g(1/2+it)/h(1/2+it)|^2\) is even in \(t\).
For a monic orthogonal polynomial \(q\), form
\(q^{\rm c}(s)=\overline{q(\overline s)}\).
Substitution \(t\mapsto-t\) and conjugation of each
orthogonality equation show that \(q^{\rm c}\) is monic with
the same degree and the same lower-degree orthogonality.  Positivity
of the polynomial Gram proves uniqueness, so \(q^{\rm c}=q\).
Thus every \(q_n\) has real coefficients in the original variable
\(s\).  The coefficient of \(q_n\) in \(sq_n\) is therefore
real as well; (KT.1) proves its exact value \(b_n=1/2\).
This is a consequence of the given packet symmetries, with every
other recurrence coefficient retained.

The original companion matrix \(A\), vector \(c\), residue
columns \(v_j\), and Gram matrices \(K_{n-1},M_n\) are real.
Therefore the scalar \(\gamma_n\) in (KT.3) is real.
The second specified symmetry gives \(g_Z=0\) in (KT.4),
so \(\gamma_n=0\) exactly.  Hence
\(\epsilon_m^2=\alpha_n\beta_n\).
At the preceding and following steps (KT.7)--(KT.8) give
\[
 \alpha_n=1-r_m,\qquad
 \alpha_{n+1}=1-r_{m+1},\qquad
 \beta_n=\frac{a_n\alpha_{n+1}}{1-\alpha_{n+1}}.
\]
All these denominators are positive: \(G_m>0\) and
\(a_n/(a_n+\beta_n)>0\).  Substitution proves (KT.28),
including the exceptional zero-column steps.  The inequality
\(0<r_m\leq1\) follows directly from the same determinant
formula.  At \(m=0\) the preceding metric is precisely the
stated \(G_{-1}\), so no earlier undefined source level is used.
\end{proof}

\subsection{What the recurrence proves about boundary energy}

The unchanged arithmetic source has supplied the explicit energy
increment (KT.11).  Its three terms are the squared transverse
\(A\)-image, its real pairing with the retained terminal vector,
and the specified negative term \(-a_n\beta_n\|p_n\|_n^2\).
Thus the source recurrence produces an exactly computable boundary
energy, including its sign-determining cross term.  No sign for
their sum has been assumed.  Every term is a polynomial residue,
an actual moment Gram inverse, or a retained recurrence coefficient.
The rational route to those same quantities is (KT.15)--(KT.25).
The original theta representative and its boundary are recovered
from the preceding kernel-minimum formula and its explicit division
by \(h\).  Consequently all updates are maps between the original
source representatives, with the same quotient class and supported
zero.  For each support label the displayed linear maps lift by
\((\lambda,x)\mapsto(\lambda,Tx)\); external absence remains
\(\tau\), and a zero vector in that fibre remains its supported
zero throughout.

% Full companion model, with heading depth adapted for this section.
\subsection{An exact positive-moment counterexample to consecutive energy monotonicity}
\label{sec:terminal-energy-counterexample}

This section concerns the moment-to-packet construction for the explicitly
specified positive measure below.  It proves that positivity, the vertical
orthogonal-polynomial recurrence, reflection stability of the packet, and
the terminal rank-two identity together allow an increase of the relative
weight energy at consecutive degrees.  The measure is specified by its nine
atoms; no assertion identifies it with the arithmetic measure
\(d\nu_Z(t)=|g(\tfrac12+it)/h(\tfrac12+it)|^2dt/(2\pi)\).
The exact correspondence with that construction will be the same polynomial
residue map, multiplication operator, kernel sum and Hermitian defect, with
the measure retained as part of the data throughout.

\subsubsection{The measure and every moment needed below}

Keep the original coordinate \(s=\tfrac12+it\).  Define a probability
measure \(\nu\) on this line by the following table.  In a row containing
two signs, the displayed weight is assigned to each of the two atoms.
\[
\begin{array}{c|c}
t&\text{weight at each atom}\\\hline
0&115/288\\
\pm1/4&29/120\\
\pm1/2&13/240\\
\pm3/4&11/2520\\
\pm1&1/6720
\end{array}                                                    \tag{TEC.1}
\]
All nine weights are strictly positive, and
\[
 \frac{115}{288}+\frac{29}{60}+\frac{13}{120}
       +\frac{11}{1260}+\frac1{3360}=1.                          \tag{TEC.2}
\]
Write \(\mu_k=\int t^k\,d\nu\) and \(v=1/16\).
The paired atoms give \(\mu_k=0\) for every odd integer \(k\geq1\),
including \(k=1,3,5,7,9\).  For positive integers \(r\), the
even-moment formula, with all original atom weights retained, is
\[
 \mu_{2r}=4^{-2r}
 \left(\frac{29}{60}1^{2r}+\frac{13}{120}2^{2r}
             +\frac{11}{1260}3^{2r}+\frac1{3360}4^{2r}\right).
                                                                    \tag{TEC.3}
\]
Here the factor \(4^{-2r}\) comes from the explicitly displayed atom
locations in (TEC.1).  The four contributions and their sums are
\[
\begin{array}{c|rrrr|r}
r&\frac{29}{60}1^{2r}&\frac{13}{120}2^{2r}
 &\frac{11}{1260}3^{2r}&\frac1{3360}4^{2r}&\text{sum}\\\hline
1&29/60&13/30&11/140&1/210&1\\
2&29/60&26/15&99/140&8/105&3\\
3&29/60&104/15&891/140&128/105&15\\
4&29/60&416/15&8019/140&2048/105&105\\
5&29/60&1664/15&72171/140&32768/105&939
\end{array}                                                       \tag{TEC.4}
\]
Consequently
\[
 (\mu_0,\mu_2,\mu_4,\mu_6,\mu_8,\mu_{10})
       =(1,v,3v^2,15v^3,105v^4,939v^5).                           \tag{TEC.5}
\]
Equations (TEC.2)--(TEC.5), together with cancellation of each odd
moment between the two atoms, verify all moments through degree ten.

\subsubsection{The actual monic orthogonal polynomials of this measure}

Use the inner product
\[
 \langle P,Q\rangle_\nu
  =\int\overline{P(\tfrac12+it)}Q(\tfrac12+it)\,d\nu(t),
 \qquad x=s-\tfrac12.                                           \tag{TEC.6}
\]
The following table retains the monic polynomials in the original
\(s\)-coordinate and gives their actual squared norms.
\[
\begin{array}{c|l|c}
k&q_k(s)&\kappa_k=\langle q_k,q_k\rangle_\nu\\\hline
0&1&1\\
1&x&v\\
2&x^2+v&2v^2\\
3&x^3+3vx&6v^3\\
4&x^4+6vx^2+3v^2&24v^4\\
5&x^5+10vx^3+15v^2x&114v^5
\end{array}                                                       \tag{TEC.7}
\]

\begin{proof}
For an explicit verification, define real polynomials
\[
\begin{aligned}
 P_0(t)&=1,&P_1(t)&=t,&P_2(t)&=t^2-v,\\
 P_3(t)&=t^3-3vt,&P_4(t)&=t^4-6vt^2+3v^2,\\
 P_5(t)&=t^5-10vt^3+15v^2t.
\end{aligned}                                                     \tag{TEC.8}
\]
Direct substitution gives
\(q_k(\tfrac12+it)=i^kP_k(t)\).  Thus
\[
 \langle q_j,q_k\rangle_\nu
            =(-i)^ji^k\int P_j(t)P_k(t)\,d\nu(t).                 \tag{TEC.9}
\]
If \(j,k\) have different parity, the integrand on the right is odd
and its integral is zero.  The remaining six off-diagonal integrals,
using (TEC.5), are precisely
\[
\begin{aligned}
 \int P_0P_2\,d\nu
    &=v(1-1)=0,\\
 \int P_0P_4\,d\nu
    &=v^2(3-6+3)=0,\\
 \int P_2P_4\,d\nu
    &=v^3(15-21+9-3)=0,\\
 \int P_1P_3\,d\nu
    &=v^2(3-3)=0,\\
 \int P_1P_5\,d\nu
    &=v^3(15-30+15)=0,\\
 \int P_3P_5\,d\nu
    &=v^4(105-195+135-45)=0.
\end{aligned}                                                     \tag{TEC.10}
\]
For the diagonal integrals, direct polynomial multiplication gives
\[
\begin{aligned}
 \int P_0^2\,d\nu&=1,&\int P_1^2\,d\nu&=v,\\
 \int P_2^2\,d\nu&=v^2(3-2+1)=2v^2,\\
 \int P_3^2\,d\nu&=v^3(15-18+9)=6v^3,\\
 \int P_4^2\,d\nu&=v^4(105-180+126-36+9)=24v^4,\\
 \int P_5^2\,d\nu&=v^5(939-2100+1950-900+225)=114v^5.
\end{aligned}                                                     \tag{TEC.11}
\]
In (TEC.9), the diagonal phase is \((-i)^ki^k=1\).  These equations
therefore prove every entry of the Gram matrix asserted in (TEC.7).
Each polynomial in that table is monic.  A nonzero polynomial of degree
at most five has at most five distinct roots, so it cannot vanish at all
nine atoms in (TEC.1).  Positivity of the weights makes the inner product
positive definite on polynomials of degree at most five.  If two monic
polynomials of the same degree were both orthogonal to every lower
degree polynomial, their difference would have lower degree and zero
squared norm.  Positive definiteness forces that difference to vanish.
Thus (TEC.7) consists of the actual monic orthogonal polynomials and
norms of the stated measure, including the fifth norm.
\end{proof}

Polynomial multiplication in (TEC.7) also proves
\[
 s q_k=q_{k+1}+\tfrac12q_k-kv q_{k-1}
       \qquad(0\leq k\leq4),                                   \tag{TEC.12}
\]
where the last term is omitted for \(k=0\).  For \(1\leq k\leq4\),
the displayed coefficient is exactly
\(a_k=\kappa_k/\kappa_{k-1}=kv=k/16>0\).
Thus (TEC.12) has the required vertical sign and
\(b_k+\overline{b_k}=1\), with \(b_k=1/2\).
The fifth norm in (TEC.7) is
\(\kappa_5=114/16^5=57/524288\); its value was derived from the
actual tenth moment \(939/16^5\).

\subsubsection{The retained packet and its exact evaluation isomorphism}

Set
\[
 h(s)=(s-\tfrac34)(s-\tfrac14)=s^2-s+\tfrac3{16},\qquad
 E=\mathbb C[s]/(h),\qquad j_h:\mathbb C[s]\longrightarrow E.
                                                                    \tag{TEC.13}
\]
Both packet centres lie in \(0<\operatorname{Re}s<1\), and the
reflection \(\rho\mapsto1-\overline\rho\) exchanges them.  They are
distinct, and each has its complete multiplicity one.  In the retained
monomial basis \((1,s)\) of \(E\), the unit and multiplication operator
are
\[
 c=j_h1=\binom10,\qquad
 A=M_s=\begin{pmatrix}0&-3/16\\1&1\end{pmatrix}.                 \tag{TEC.14}
\]
Indeed \(s^2=s-3/16\) in this quotient, which proves both columns
of the multiplication matrix.

The complete evaluation map is
\[
\begin{aligned}
 T:E&\longrightarrow\mathbb C\oplus\mathbb C,&
 [p]&\longmapsto(p(3/4),p(1/4)),\\
 T&=\begin{pmatrix}1&3/4\\1&1/4\end{pmatrix},&
 T^{-1}&=\begin{pmatrix}-1/2&3/2\\2&-2\end{pmatrix}.
\end{aligned}                                                     \tag{TEC.15}
\]
Both evaluations vanish on the ideal \((h)\), so the map is well
defined.  Evaluations preserve addition, multiplication and the unit.
For any pair \((u_+,u_-)\), the polynomial
\[
 2u_+(s-\tfrac14)+2u_-(\tfrac34-s)                               \tag{TEC.16}
\]
evaluates to that pair.  It has the coefficients given by
\(T^{-1}\), and multiplication of the two matrices in (TEC.15)
gives the identity.  This proves the typed algebra isomorphism,
including its inverse.  Evaluation of \(s p\) also proves
\[
 TA=\widetilde A T,\qquad
 \widetilde A=\operatorname{diag}(3/4,1/4),\qquad
 Tc=\binom11.                                                    \tag{TEC.17}
\]

In the original quotient \(E\) one has \(x^2=v\).  Reducing the
explicit polynomials of (TEC.7), with no deletion of their supported
residue classes, gives
\[
\begin{array}{c|c}
k&v_k:=j_hq_k\text{ in the monomial basis }(1,s)\\\hline
0&(1,0)^{\mathsf T}\\
1&(-1/2,1)^{\mathsf T}\\
2&(1/8,0)^{\mathsf T}\\
3&(-1/8,1/4)^{\mathsf T}\\
4&(5/128,0)^{\mathsf T}\\
5&(-13/256,13/128)^{\mathsf T}
\end{array}                                                       \tag{TEC.18}
\]
For example \(q_3=4vx=x/4\), \(q_4=10v^2=5/128\), and
\(q_5=26v^2x=(13/128)x\) in \(E\).  These calculations establish
every entry of (TEC.18) directly from the original ideal relation.

\subsubsection{The original kernels, terminal defects and exact energies}

For \(1\leq N\leq4\), define
\[
\begin{aligned}
 K_N&=\sum_{k=0}^N\frac{v_kv_k^*}{\kappa_k},\\
 L_N&=AK_N+K_NA^*-K_N,\\
 \epsilon_N&=\left\|K_N^{-1/2}L_NK_N^{-1/2}\right\|.
\end{aligned}                                                     \tag{TEC.19}
\]
All adjoints in (TEC.19) are conjugate transposes in the explicitly
retained monomial coordinates.  The columns \(v_0,v_1\) are linearly
independent.  If a nonzero column \(u\) had \(u^*K_Nu=0\), the
positive sum in (TEC.19) would force both \(v_0^*u=0\) and
\(v_1^*u=0\), a contradiction.  Thus each \(K_N\) is positive
definite, so its positive inverse square root and the displayed
Hermitian operator norm are well defined.

Using (TEC.7) and (TEC.18), the successive kernels are
\[
\begin{aligned}
 K_1&=\begin{pmatrix}5&-8\\-8&16\end{pmatrix},&
 K_2&=\begin{pmatrix}7&-8\\-8&16\end{pmatrix},\\
 K_3&=\begin{pmatrix}53/3&-88/3\\-88/3&176/3\end{pmatrix},&
 K_4&=\begin{pmatrix}131/6&-88/3\\-88/3&176/3\end{pmatrix}.
\end{aligned}                                                     \tag{TEC.20}
\]
In particular the last step is the exact positive rank-one update
\[
 K_4-K_3=\frac{v_4v_4^*}{\kappa_4}
          =\frac{25}{6}cc^*.                                    \tag{TEC.21}
\]
Multiplication by the matrix in (TEC.14) gives
\[
 L_3=\begin{pmatrix}-20/3&20/3\\20/3&0\end{pmatrix},\qquad
 L_4=\begin{pmatrix}-65/6&65/6\\65/6&0\end{pmatrix}.             \tag{TEC.22}
\]
These defects satisfy the original terminal identity, with its exact
coefficients and signs:
\[
 L_N=\frac{v_{N+1}v_N^*+v_Nv_{N+1}^*}{\kappa_N}
                  \qquad(N=3,4).                               \tag{TEC.23}
\]
For \(N=3\), the numerator calculated from (TEC.18) is
\[
 \begin{pmatrix}-5/512&5/512\\5/512&0\end{pmatrix},
 \qquad \kappa_3=3/2048.
\]
For \(N=4\), it is
\[
 \begin{pmatrix}-65/16384&65/16384\\65/16384&0\end{pmatrix},
 \qquad \kappa_4=3/8192.
\]
Division gives exactly the two matrices in (TEC.22), proving
(TEC.23) without an appeal to a numerical rank calculation.

\begin{theorem}[Strict increase at two consecutive permitted levels]
For the positive measure (TEC.1) and the complete reflection-stable
packet (TEC.13), the energies in (TEC.19) satisfy
\[
 \epsilon_3^2=\frac{25}{99},\qquad
 \epsilon_4^2=\frac{4225}{15136},\qquad
 \epsilon_4^2-\epsilon_3^2=\frac{39875}{1498464}>0.
                                                                    \tag{TEC.24}
\]
In the indexing \(N=d+m\), with \(d=\dim_{\mathbb C}E=2\), these
are the consecutive levels \(m=1\) and \(m=2\), both with
\(m\geq0\).
\end{theorem}

\begin{proof}
Transport the two forms by the proved isomorphism (TEC.15):
\[
\begin{aligned}
 \widetilde K_3=TK_3T^*
     &=\begin{pmatrix}20/3&-2/3\\-2/3&20/3\end{pmatrix},\\
 \widetilde K_4=TK_4T^*
     &=\begin{pmatrix}65/6&7/2\\7/2&65/6\end{pmatrix}.
\end{aligned}                                                     \tag{TEC.25}
\]
By (TEC.17), the transported defect is
\[
 \widetilde L_N=TL_NT^*
 =\widetilde A\widetilde K_N+\widetilde K_N\widetilde A^*
                                      -\widetilde K_N.
                                                                    \tag{TEC.26}
\]
For either matrix \(\widetilde K=\begin{pmatrix}a&b\\b&a\end{pmatrix}\)
in (TEC.25), one has
\[
 \widetilde L=\operatorname{diag}(a/2,-a/2),\qquad
 \det(\widetilde L-\lambda\widetilde K)
       =\lambda^2(a^2-b^2)-a^2/4.                               \tag{TEC.27}
\]
To check that this calculation gives the norm defined in the original
coordinates, set \(H=K^{-1/2}LK^{-1/2}\).  Then
\[
 \det(H-\lambda I)=\det(K)^{-1}\det(L-\lambda K),\qquad
 \det(T(L-\lambda K)T^*)=|\det T|^2\det(L-\lambda K).
                                                                    \tag{TEC.28}
\]
The two determinant factors are nonzero and independent of
\(\lambda\).  Consequently the eigenvalues of the Hermitian matrix
\(H\) equal the roots of (TEC.27), with their multiplicities.  The
roots are the opposite real numbers
\(\pm a/(2\sqrt{a^2-b^2})\).  A Hermitian matrix has operator norm
equal to the greatest absolute value of its eigenvalues, so
\[
 \epsilon^2=\frac{a^2}{4(a^2-b^2)}.                              \tag{TEC.29}
\]
For \(N=3\), substitution of \(a=20/3,b=-2/3\) gives
\(\epsilon_3^2=(400/9)/(4\cdot396/9)=25/99\).
For \(N=4\), substitution of \(a=65/6,b=7/2\) gives
\(\epsilon_4^2=(4225/36)/(4\cdot3784/36)=4225/15136\).
Their difference, retaining the two denominators, is
\[
 \frac{4225\cdot99-25\cdot15136}{15136\cdot99}
   =\frac{418275-378400}{1498464}
   =\frac{39875}{1498464}>0.                                   \tag{TEC.30}
\]
Both energies are nonnegative, and their squared values have strictly
positive difference, so \(\epsilon_4>\epsilon_3\).  The original
coordinate characteristic polynomials provide the same calculation:
\[
\begin{aligned}
 \det(L_3-\lambda K_3)&=176\lambda^2-400/9,\\
 \det(L_4-\lambda K_4)&=(3784/9)\lambda^2-4225/36.
\end{aligned}                                                     \tag{TEC.31}
\]
Finally \(N=3=2+1\) and \(N=4=2+2\), proving the stated degree
range without using the lower degree \(N=1\).
\end{proof}

\subsubsection{The exact scope of the obstruction}

For this measure the construction is the composite of the polynomial
source with the original residue quotient
\[
 \mathcal P_N\lhook\joinrel\longrightarrow\mathbb C[s]
       \xrightarrow{\ j_h\ } E,
 \qquad E\xrightarrow{\ T\ }\mathbb C\oplus\mathbb C,
                                                                    \tag{TEC.32}
\]
and multiplication is intertwined exactly by (TEC.17).  Its source
inner product is (TEC.6); its monic source Gram matrix is
\(\operatorname{diag}(\kappa_0,\ldots,\kappa_N)\); its kernel is
the full sum (TEC.19).  Thus it has precisely the vertical recurrence,
positive kernel update, complete packet quotient and terminal defect
maps appearing in the arithmetic moment construction.  Equations
(TEC.24) and (TEC.30) prove that these data alone do not imply
nonincreasing consecutive energy.  An argument for that property for
\(\nu_Z\) must therefore establish and use additional identities or
estimates of its stated arithmetic density.  The present example
establishes the indicated obstruction to a universal recurrence-based
argument; it asserts no consecutive increase for \(\nu_Z\).

The companion exact checker verifies 88 rational and complex-rational
identities in both ordinary Python and optimized Python.  It checks
the atom weights and relevant moments, source Gram matrix, packet
isomorphism, residue columns, kernel updates, terminal identities and
generalized characteristic polynomials.  Those finite checks
supplement the complete computations above.

```
