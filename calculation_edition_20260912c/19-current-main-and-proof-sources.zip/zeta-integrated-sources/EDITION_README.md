# Calculation-edition source selection

Exact public main-reader sources, sidebars, formal modules, research workbenches and build/check configuration at this commit. Frozen PDF/ZIP editions and separately packaged tandem continuation prefixes are excluded. This index, not a historically inherited repository manifest, binds this source selection.

Immutable source: https://github.com/KokunoYumeto/zeta-function-research-reader/tree/a4494fba4968db837a8af6fcb952c8688cd5d1da

Read EDITION_SOURCE_SELECTION.json for the exact source-file inventory and hashes. All selected repository bytes are unchanged. README.md and the individual workbench guides give their build/check commands. The main PDF is a separate readable download; its full 55 TeX inputs are here. The new tandem continuation has its own complete source package.

Rebuilding needs the documented software, packages and fonts. Lean preparation retrieves a commit-pinned upstream source and verifies its Git blob identity; this archive is not wholly offline or dependency-free. No standalone fonts, private research library or credentials are bundled. Existing rights and source citations are retained in RIGHTS.md and the selected files.
