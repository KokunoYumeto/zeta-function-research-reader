# The diagonal divided difference linking the symmetric and exterior squares

This bounded continuation changes no canonical TeX, reader PDF, or release artifact. It retains all original coordinates, complete local orders, source units, and orbit factors. No RH statement, arithmetic upper estimate, metric replacement, separability assumption, or algebra product on one exterior degree is inferred.

## 1. Full tensor algebra and exact parity coefficient ideals

Let \(h(t)\) be any monic polynomial over \(\mathbb C\) of degree \(d\ge1\). Put
\[
 E=\mathbb C[t]/(h),\qquad
 \mathcal A=E\otimes E=\mathbb C[s_1,s_2]/(h(s_1),h(s_2)).
\]
Retain
\[
 S=s_1+s_2,\quad r=s_1-s_2,\quad\Delta=r^2,\quad
 s_1=(S+r)/2,\quad s_2=(S-r)/2,\quad R=\mathbb C[S,\Delta].
 \tag{DE.1}
\]
The substitution \(R\to\mathbb C[S,r]\) is injective, because distinct monomials \(S^a\Delta^b\) become distinct monomials \(S^ar^{2b}\). Even and odd expansion gives
\[
 \mathbb C[S,r]=R\oplus rR,\qquad
 (a+rb)(c+re)=ac+\Delta be+r(ae+bc).
 \tag{DE.2}
\]
Swap fixes \(S\) and negates \(r\). Define
\[
 H_0(S,r^2)=\frac{h((S+r)/2)+h((S-r)/2)}2,\qquad
 H_1(S,r^2)=\frac{h((S+r)/2)-h((S-r)/2)}{2r}.
 \tag{DE.3}
\]
The second numerator is an odd polynomial in the indeterminate \(r\). Dividing that polynomial before quotienting gives an even polynomial. Thus \(H_0,H_1\in R\), without localizing or dividing by a zero divisor in \(\mathcal A\). Binomial expansion proves
\[
 h(s_1)=H_0+rH_1,\quad h(s_2)=H_0-rH_1,\quad
 H_0(S,0)=h(S/2),\quad H_1(S,0)=\frac12h'(S/2).
 \tag{DE.4}
\]
The original ideal is \((H_0,rH_1)\). Multiplication by arbitrary elements gives
\[
 H_0(a+rb)+rH_1(c+re)
 =(H_0a+\Delta H_1e)+r(H_0b+H_1c).
 \tag{DE.5}
\]
The four coefficients are arbitrary. Consequently its even coefficient ideal is exactly \((H_0,\Delta H_1)\), and its odd coefficient ideal is exactly \((H_0,H_1)\). Therefore
\[
 B_+=R/(H_0,\Delta H_1),\quad B_-=R/(H_0,H_1),\qquad
 \mathcal A\cong B_+\oplus rB_-.
 \tag{DE.6}
\]
The notation \(rB_-\) denotes the actual odd module, with the injective map \([f]\mapsto[rf]\) proved by (DE.5); multiplication by \(r\) on the full algebra is not assumed injective. Every invariant or anti-invariant quotient class has a polynomial lift of that parity by the averages \((P\pm\mathrm{swap}(P))/2\). Thus \(B_+\) is the invariant algebra and \(rB_-\) is the anti-invariant subspace.

The original remainder tensors \(s_1^is_2^j\), \(0\le i,j<d\), are a basis. Their literal symmetric and alternating orbit sums have disjoint orbit supports, giving
\[
 \dim B_+=d(d+1)/2,\qquad \dim B_-=d(d-1)/2.
 \tag{DE.7}
\]
The coefficient quotient \(B_-\) has its declared quotient multiplication. It is not the multiplication inherited by the odd module: two odd elements multiply into the even algebra. No single exterior degree is declared an algebra under that tensor product.

## 2. Multiplication by r, its two coefficient maps, and both defects

Define
\[
 \pi:B_+\to B_-,\ [f]\mapsto[f],\qquad
 m:B_-\to B_+,\ [f]\mapsto[\Delta f].
 \tag{DE.8}
\]
The ideal inclusions make \(\pi\) a surjective algebra quotient map. Changing a representative for \(m\) by \(H_0a+H_1b\) changes its image by \(\Delta H_0a+\Delta H_1b=0\), proving well-definedness. Both maps are \(R\)-linear, and
\[
 m\pi=\Delta I_{B_+},\quad \pi m=\Delta I_{B_-},\quad
 M_r=\begin{pmatrix}0&m\\ \pi&0\end{pmatrix}.
 \tag{DE.9}
\]
The full multiplication transported through (DE.6) is
\[
 (a,b)(c,e)=\bigl(ac+m(be),\,\pi(a)e+\pi(c)b\bigr).
 \tag{DE.10}
\]
The sign is positive because \(r^2=\Delta\). In particular
\[
 m(b)m(c)=\Delta m(bc),\qquad m(1)=\Delta;
 \tag{DE.11}
\]
it is not generally an algebra homomorphism.

To prove \(m\) injective, note that the prime polynomial \(\Delta\) does not divide \(H_0\), since \(H_0(S,0)=h(S/2)\ne0\). If
\[
 \Delta f=H_0a+\Delta H_1b,
\]
then \(\Delta(f-H_1b)=H_0a\) forces \(a=\Delta a_1\). Cancellation in the polynomial domain \(R\), not in either quotient, gives \(f=H_0a_1+H_1b\). Hence \([f]=0\) in \(B_-\).

The image of \(m\) is \(\Delta B_+\): every representative in one coefficient quotient can be used in the other. Its cokernel is
\[
 R/(H_0,\Delta)\xrightarrow{\sim}E,\quad
 [F(S,\Delta)]\mapsto[F(2t,0)],\qquad [q(t)]\mapsto[q(S/2)]
 \tag{DE.12}
\]
in the reverse direction. The substitutions compose to the identity modulo the displayed ideals by (DE.4). Thus, with \(E\) an \(R\)-module through \(S\mapsto2t,\Delta\mapsto0\), the first exact sequence is
\[
 0\longrightarrow B_-\xrightarrow{m}B_+
 \xrightarrow{\rho}E\longrightarrow0,\qquad
 \rho[F]=[F(2t,0)].
 \tag{DE.13}
\]

For the second sequence, first prove \(\gcd(H_0,H_1)=1\) in \(R\). A common nonconstant divisor would remain nonconstant after the injection into \(\mathbb C[S,r]\) and the invertible coordinate change to \(\mathbb C[s_1,s_2]\). It would divide both \(h(s_1)\) and \(h(s_2)\). Their irreducible factors over \(\mathbb C\) are respectively \(s_1-\rho\) and \(s_2-\sigma\); the two lists have no associate factors, including when their powers repeat. This is impossible.

The kernel of \(\pi\) is exactly \(H_1B_+\). Multiplication by \(H_1\) gives a surjection
\[
 R/(H_0,\Delta)\to\ker\pi,\quad[f]\mapsto[H_1f],
\]
well-defined since \(H_0H_1=\Delta H_1=0\) in \(B_+\). If \(H_1f=H_0a+\Delta H_1b\), coprimality forces \(H_0\mid(f-\Delta b)\). This proves injectivity. Composing with (DE.12) gives
\[
 \iota:E\to B_+,\quad[q]\mapsto[H_1q(S/2)],\qquad
 0\longrightarrow E\xrightarrow{\iota}B_+
 \xrightarrow{\pi}B_-\longrightarrow0.
 \tag{DE.14}
\]
Both defects are the entire original \(E\), not its reduction. Equations (DE.9) and injectivity of \(m\) also give
\[
 \ker\pi=\operatorname{Ann}_{B_+}(\Delta)=H_1B_+,\quad
 \ker M_r=\{(\iota q,0):q\in E\},\quad
 \operatorname{coker}M_r\cong E.
 \tag{DE.15}
\]
For the last isomorphism send the class of \((a,b)\) to \(\rho(a)\): surjectivity of \(\pi\) removes the odd quotient, and (DE.13) identifies the even quotient.

## 3. Complete diagonal annihilator and exact inherited product

The multiplication map
\[
 \mu:\mathcal A\to E,\quad[F(s_1,s_2)]\mapsto[F(t,t)]
\]
has kernel the ideal \((r)\), because imposing \(s_1=s_2=t\) gives exactly \(\mathbb C[t]/h\). Therefore
\[
 \operatorname{Ann}_{\mathcal A}(\ker\mu)
 =\operatorname{Ann}_{\mathcal A}(r)=\iota(E)\subset B_+.
 \tag{DE.16}
\]
Its \(\mathcal A\)-action factors through \(E\). Indeed the polynomial
\[
 F(s_1,s_2)-F((s_1+s_2)/2,(s_1+s_2)/2)
\]
is divisible by \(r\), which annihilates \(\iota(E)\). Thus the annihilator is free rank one over the diagonal algebra \(E\), with generator the full class \(H_1\); it is not claimed free rank one over \(\mathcal A\).

Since \(\Delta H_1=0\), subtracting the coefficient at \(\Delta=0\) gives
\[
 H_1^2=H_1H_1(S,0)=H_1h'(S/2)/2.
\]
Hence the complete inherited product and diagonal image are
\[
 \boxed{\ \iota(q)\iota(p)=\iota\!\left(\frac{h'(t)}2qp\right),
 \qquad \rho\iota(q)=\frac{h'(t)}2q.\ }
 \tag{DE.17}
\]
The full \(H_1\) is not replaced by its specialization. Only its multiplying coefficient in this identity and its subsequent diagonal evaluation admit the displayed reduction.

The ordinary divided difference is
\[
 g_h(s_1,s_2)=\frac{h(s_1)-h(s_2)}{s_1-s_2}=2H_1.
\]
If \(j=2\iota\), then \(j(q)j(p)=j(h'qp)\) and \(\mu j(q)=h'q\). Thus changing the generator by the unit \(2\) preserves the ideal but changes its transported product coefficient. The literal convention (DE.3) requires \(h'/2\).

This is the classical diagonal-annihilator and monogenic-different construction. [Stacks 0BVK](https://stacks.math.columbia.edu/tag/0BVK) defines the Noether different as the image of this annihilator under \(\mu\), and [0BWI](https://stacks.math.columbia.edu/tag/0BWI) gives the monogenic ideal \((h')\). The generator is an explicit one-variable specialization of [0BWC](https://stacks.math.columbia.edu/tag/0BWC): use \(\mathbb C[x]\), quotient \(E\), diagonal generator \(x-t\), and coefficient \((h(x)-h(t))/(x-t)\). The polynomial \(h\) is a nonzero divisor, \(E\) is finite free over \(\mathbb C\), and \(x-t\) is monic and a nonzero divisor in \(E[x]\). No separability is needed. [0BWD](https://stacks.math.columbia.edu/tag/0BWD) gives the diagonal-algebra rank-one assertion and Jacobian image as well. These classical facts are not novelty claims.

## 4. Repeated roots and the degree-one edge

Write \(E=\bigoplus_\rho E_\rho\), \(E_\rho=\mathbb C[u]/u^{m_\rho}\), where \(u=t-\rho\), and put \(v_\rho(u)=h(\rho+u)/u^{m_\rho}\), so \(v_\rho(0)\ne0\). The proved exact sequences retain every whole \(E_\rho\), of dimension \(m_\rho\).

On different root blocks \(r=(\rho-\sigma)+(u-v)\) is invertible: its nonzero constant has a finite geometric-series inverse after its nilpotent remainder is factored out. Thus the annihilator is supported on equal-root blocks, with their full orders. On an equal-root block of order \(m\), the full generator in \(\mathbb C[u_1,u_2]/(u_1^m,u_2^m)\) is
\[
 H_1=\frac12v_\rho(u_1)\sum_{j=0}^{m-1}u_1^{m-1-j}u_2^j.
 \tag{DE.18}
\]
For proof, the product divided difference of \(u^mv_\rho(u)\) is \(v_\rho(u_1)\sum_j u_1^{m-1-j}u_2^j\) plus
\[
 u_2^m\,\frac{v_\rho(u_1)-v_\rho(u_2)}{u_1-u_2}.
\]
The last polynomial vanishes in the stated quotient; dividing the whole polynomial identity by the scalar \(2\) gives (DE.18). The mixed terms and the full unit \(v_\rho(u_1)\) remain.

The local product coefficient is exactly
\[
 h'(\rho+u)/2=\frac{m_\rho v_\rho(0)}2u^{m_\rho-1}
 \pmod{u^{m_\rho}}.
 \tag{DE.19}
\]
Differentiate \(u^mv_\rho(u)\); all other terms have degree at least \(m\). At a simple root this is invertible. At order \(m\ge2\) it is a nonzero socle element of square zero, and its multiplication has rank one because it retains only the constant coefficient of its multiplier. Thus, for \(K_\rho=\iota(E_\rho)\),
\[
 \dim K_\rho=m_\rho,\qquad
 K_\rho^2=\mathbb C\,\iota(u^{m_\rho-1})\ne0,\qquad
 K_\rho^3=0\quad(m_\rho\ge2).
 \tag{DE.20}
\]
Mixed-root products vanish by the CRT product and (DE.17). The full module of dimension \(m_\rho\) is not identified with its rank-one diagonal image.

For \(h=t^2\),
\[
 H_0=(S^2+\Delta)/4,\quad H_1=S/2,\quad
 B_+\cong\mathbb C[S]/S^3,\quad\Delta=-S^2,\quad B_-\cong\mathbb C,
\]
and
\[
 m(1)=-S^2,\quad\pi(S)=0,\quad
 \iota(1)=S/2,\quad\iota(t)=S^2/4\ne0,\quad\iota(1)^2=\iota(t).
 \tag{DE.21}
\]
Eliminating \(\Delta\) in the displayed ideals proves both quotient isomorphisms. The nonzero class \(\iota(t)\) has diagonal image \(t^2=0\).

Premature specialization actually loses the annihilator property. For \(h=t^3\),
\[
 H_1=(3S^2+\Delta)/8,\qquad rH_1=0,\qquad
 r(3S^2/8)=-r^3/8\ne0.
 \tag{DE.22}
\]
In the original quotient \(r^3=-3s_1^2s_2+3s_1s_2^2\) is a nonzero combination of two retained monomial tensors.

For \(d=1\), \(h=t-a\), \(H_0=S/2-a\), \(H_1=1/2\), \(B_+=\mathbb C\), and \(B_-=0\). Both exact sequences hold, with \(\iota(q)=q(a)/2\). Its product is still \(\iota(q)\iota(p)=\iota(qp/2)\). The exterior square is zero while both diagonal defects have dimension one. No reciprocal rank or positive-dimensional exterior assertion is used.

## 5. EA’s exact unscaled exterior coordinates

For the original basis \(e_i=t^i\), \(0\le i<j<d\), EA uses
\[
 I_-e_{ij}=a_{ij}=e_i\otimes e_j-e_j\otimes e_i,\qquad
 I_-^*I_-=2I,\qquad L_-=I_-^*/2.
 \tag{DE.23}
\]
Polynomial division before quotienting gives
\[
 a_{ij}=r\,b_{ij},\qquad
 b_{ij}=-p^i\sum_{q=0}^{j-i-1}s_1^{j-i-1-q}s_2^q,\qquad
 p=s_1s_2=(S^2-\Delta)/4.
 \tag{DE.24}
\]
Factor \((s_1s_2)^i\) and use the finite geometric-sum identity. The sum is symmetric and therefore a polynomial in \(S,\Delta\). The leading minus sign comes from \(r=s_1-s_2\): in particular \(b_{01}=-1\). The classes \(b_{ij}\) form a basis of \(B_-\), since the proved isomorphism \(f\mapsto rf\) sends them to its full odd orbit basis.

For the exterior quotient,
\[
 q_\wedge(a_{ij})=2e_i\wedge e_j,\qquad
 (q_\wedge|_{\mathrm{odd}})^{-1}(e_i\wedge e_j)=a_{ij}/2.
 \tag{DE.25}
\]
Thus its coefficient under division by \(r\) is \(b_{ij}/2\). EA’s unscaled coordinate inclusion instead has coefficient \(b_{ij}\). The two maps and their factor two are explicitly retained; no orbit vector or Gram is normalized.

Let \(b^+_{ij}=s_1^is_2^j+s_1^js_2^i\) for \(i<j\), but \(b^+_{ii}=s_1^is_2^i\). Direct multiplication gives
\[
 r b^+_{ij}=a_{i+1,j}-a_{i,j+1}\ (i<j),\qquad
 r b^+_{ii}=-a_{i,i+1},
 \tag{DE.26}
\]
where the antisymmetric polynomial defines \(a_{pq}\) also for reversed or equal indices. Conversely
\[
 r a_{ij}=
 \begin{cases}
 b^+_{i+1,j}-b^+_{i,j+1},&j>i+1,\\
 2b^+_{j,j}-b^+_{i,j+1},&j=i+1.
 \end{cases}
 \tag{DE.27}
\]
The coefficient two is forced by the one-term diagonal symmetric orbit. Exponents at least \(d\) are reduced by the complete original \(h\), not by selecting eigenvalues. For \(h=t^2\), this gives \(r a_{01}=2s_1s_2=-\Delta\), consistent with \(a_{01}=-r\).

## 6. Actual arithmetic unit, metric pullbacks, and the missing boundary energy

The preceding algebra applies to arbitrary monic \(h\). For the actual arithmetic source packet retain the full unit \(\upsilon=[g/h]_h\), \(g=2\xi\). For any unit \(v\in E\), the symmetric tensor unit \(u=v(s_1)v(s_2)\) gives invertible maps
\[
 U_+=M_u,\qquad U_-=M_{\pi(u)}.
\]
Using representatives in (DE.8) and evaluating on the diagonal proves
\[
 \pi U_+=U_-\pi,\quad mU_-=U_+m,\quad
 \rho U_+=M_{v(t)^2}\rho,\quad U_+\iota=\iota M_{v(t)^2}.
 \tag{DE.28}
\]
For the last identity \(\Delta H_1=0\) allows only the multiplying coefficient of \(uH_1\) to be evaluated at \(\Delta=0\). Thus both defects retain the full squared unit with all jets, not reduced values.

Let \(I_+\) insert the original literal symmetric orbits, \(L_+=(I_+^*I_+)^{-1}I_+^*\), and retain \(I_-,L_-\) from (DE.23). Write
\[
 r_A=A\otimes I-I\otimes A,\quad
 \mathsf M=L_+r_AI_-,\quad\mathsf P=L_-r_AI_+.
 \tag{DE.29}
\]
Because \(r_A\) reverses swap parity,
\[
 r_AI_-=I_+\mathsf M,\qquad r_AI_+=I_-\mathsf P.
\]
In the coefficient bases (DE.24), these are exactly the maps \(m,\pi\). Their products represent multiplication by \(\Delta\). For each actual original cutoff \(N\ge2(d-1)\), put
\[
 R_N^\pm=R_NI_\pm,\qquad G_N^\pm=(R_N^\pm)^*R_N^\pm=I_\pm^*G_NI_\pm.
\]
The metric on the source of either quotient map pulled back from its original target minimum is exactly
\[
 (R_N^+\mathsf M)^*(R_N^+\mathsf M)=\mathsf M^*G_N^+\mathsf M,\qquad
 (R_N^-\mathsf P)^*(R_N^-\mathsf P)=\mathsf P^*G_N^-\mathsf P.
 \tag{DE.30}
\]
These equalities follow by substitution and retain every orbit factor. Neither right side is declared equal to the pre-existing metric on the other parity.

There is an exact original-source comparison beyond those quotient pullbacks. Set \(r_D=D_1-D_2\) on the polynomial source. It multiplies the numerator by \(s_1-s_2\), raises its total degree by at most one, and reverses swap parity. The original full jet intertwines \(r_D\) with \(r_A\), because multiplication by the full tensor unit commutes with both coordinates. Therefore
\[
 E_N^+=r_DR_N^- -R_{N+1}^+\mathsf M,\qquad
 E_N^-=r_DR_N^+ -R_{N+1}^-\mathsf P
 \tag{DE.31}
\]
have zero complete jets and numerator degree at most \(N+1\). They have positive and negative swap parity respectively, so
\[
 E_N^\pm(\text{their finite domain})\subset
 \mathcal B_{N+1}^\pm,
\]
the corresponding parity of the original total-degree boundary space, not a newly selected relation family. By minimality the columns of \(R_{N+1}^\pm\) are orthogonal to that entire original boundary space. Expanding the squares therefore proves the full source-energy identities
\[
 \boxed{\begin{aligned}
 (r_DR_N^-)^*(r_DR_N^-)
 &=\mathsf M^*G_{N+1}^+\mathsf M+(E_N^+)^*E_N^+,\\
 (r_DR_N^+)^*(r_DR_N^+)
 &=\mathsf P^*G_{N+1}^-\mathsf P+(E_N^-)^*E_N^-.
 \end{aligned}}
 \tag{DE.32}
\]
Thus (DE.30) computes the target-minimum pullback, while (DE.32) identifies exactly the additional energy of applying the source difference operator to the existing source minimum. It does not discard that boundary energy or imply an isometry between the two old Grams.

Every correction has a computable original cochain primitive. For its numerator \(F\) of degree at most \(N+1\), ordered monic division first by \(h(s_1)\), then \(h(s_2)\), gives
\[
 F=h(s_1)C_1+h(s_2)C_2,\qquad \deg C_i\le N+1-d.
\]
The remainder is zero because its complete jet is zero and the arithmetic unit is invertible. If \(F\) has parity \(\varepsilon=\pm1\), replacing the coefficients by
\[
 C_1^\varepsilon=(C_1+\varepsilon\,\mathrm{swap}(C_2))/2,\quad
 C_2^\varepsilon=(C_2+\varepsilon\,\mathrm{swap}(C_1))/2
\]
preserves the identity and bounds, and gives \(C_2^\varepsilon=\varepsilon\,\mathrm{swap}(C_1^\varepsilon)\). The original primitive is the sum of
\[
 C_1^\varepsilon(D_1,D_2)(\phi_*\otimes F_h),\qquad
 -C_2^\varepsilon(D_1,D_2)(F_h\otimes\phi_*).
 \tag{DE.33}
\]
The second tensor differential supplies a second minus sign; the total boundary is exactly \(\mathcal T_h^{(2)}F\). The ordered polynomial division is linear in the original representative columns, making the correction and its primitive completely specified. Negative degree bounds mean zero coefficients.

For the actual source density
\[
 w_h(t)=|v_h(1/2+it)|^2/(2\pi),\quad
 u=t_1+t_2,\quad v=t_1-t_2,\quad
 S=1+iu,\quad r=iv,\quad\Delta=-v^2,
\]
the original Jacobian is \(dt_1dt_2=du\,dv/2\). Direct substitution into the original Mellin norm gives, for every symmetric polynomial \(f\),
\[
 \boxed{\ \|\mathcal T_h^{(2)}(rf)\|^2
 =\frac12\int_{\mathbb R^2}v^2|f(1+iu,-v^2)|^2
 w_h((u+v)/2)w_h((u-v)/2)\,du\,dv.\ }
 \tag{DE.34}
\]
Finite polynomial expansion and the source exponential moments justify every integral and its interchange. For \(f=\sum_a\Delta^af_a(S)\), the exact coefficient weight is
\[
 W^-_{ac}(u)=\frac{(-1)^{a+c}}2
 \int_{\mathbb R}v^{2(a+c)+2}
 w_h((u+v)/2)w_h((u-v)/2)\,dv.
 \tag{DE.35}
\]
The even coefficient weight has exponent \(2(a+c)\) instead. No mass is normalized, and both factors \(1/(2\pi)\), the Jacobian \(1/2\), and every sign remain. Polynomial division by \(r\) lowers numerator degree by one and changes its coefficient weight by the explicit \(|r|^2=v^2\). Equations (DE.30)–(DE.35), rather than an assumed isometry, give the exact metric and source-energy comparison.

## 7. Distinction from SSP’s Z-reflection and precise prior coverage

PR17’s short note section 3 and the complete frozen NOTE.tex section 4 already prove the \(B_+\) presentation, invariant lifts, full symmetric orbit basis, and original primitives. Full NOTE.tex equations (5.1)–(5.4) give the original Mellin norm and its matrix-weight substitution, and section 6 gives the minimum-metric congruence. These existing results are not counted as new.

SSP.1–15a adds quartet closure, \(d=2D\),
\[
 h(t)=(-1)^D H(-(t-1/2)^2),\qquad H(0)\ne0.
\]
It studies simultaneous reflection after already taking swap invariants. The two involutions on the original coordinates are
\[
 \mathrm{swap}:\ (S,r)\mapsto(S,-r),\qquad
 \mathrm{reflection}:\ (S,r)\mapsto(2-S,-r).
 \tag{DE.36}
\]
On \(B_+\), the second map sends \(Z=S-1\) to \(-Z\) and fixes \(\Delta\). With \(x=-Z^2\), SSP decomposes that already-even algebra as \(B_e\oplus ZB_o\), where its maps factor \(x\) and its product has the negative sign forced by \(Z^2=-x\). Here the full tensor algebra is decomposed by swap parity, its maps factor \(\Delta\), and its product has the positive sign forced by \(r^2=\Delta\). The odd modules are not identified.

Explicitly,
\[
 \dim B_-=D(2D-1),\quad\dim B_o=D^2,\quad
 \dim E=2D,\quad\dim A_H=D.
 \tag{DE.37}
\]
Our defect imposes \(r=0\), or \(s_1=s_2=t\), \(S=2t,\Delta=0\), and retains \(E\). SSP imposes \(Z=0\), or \(s_2=1-s_1\), then the one-factor even coordinate \(x_h=-(s_1-1/2)^2\), and retains \(A_H=\mathbb C[x_h]/H\). Under SSP’s hypotheses these loci are disjoint in the finite packet: \(H_0(S,\Delta)-h(1/2)\) belongs to \((S-1,\Delta)\), and \(h(1/2)\ne0\), so \((H_0,S-1,\Delta)=R\).

There is an exact relation between the derivative coefficients without identifying the modules. In the full one-factor algebra write \(z_h=t-1/2\), \(x_h=-z_h^2\). Direct differentiation gives
\[
 c_{\rm diag}=h'(t)/2=(-1)^{D+1}z_hH'(x_h),\qquad
 c_{\rm SSP}=2(-1)^Dx_hH'(x_h)=2z_hc_{\rm diag}.
 \tag{DE.38}
\]
SSP.15a already proves its own derivative-weighted ideal product and the necessity of keeping its complete mixed generator. The present generator has the corresponding explicit obstruction (DE.22).

The diagonal annihilator and different are classical literature. The even quotient and its original source norm are prior PR17 work. The following combined dictionary was not in the fully read PR17 source or SSP.1–15a: the actual swap-odd coefficient quotient \(R/(H_0,H_1)\); the two diagonal exact sequences in the same \(S,r,\Delta\) coordinates; their literal \(h'/2\) ideal multiplication; the EA factor-two maps; and the extra \(v^2\) source weight together with the exact difference-operator pullback and boundary-energy identities. These have been proved here as an assembly of original objects and classical constructions. This is a bounded source-coverage comparison, not a global novelty claim.

## 8. Exact finite evidence and limitations

The accompanying checker runs in normal Python and under optimization, using explicit guards rather than removable assertions. Each run passed 13 monic polynomial fixtures of degrees one through five, including repeated roots, mixed multiplicities, irreducible quadratic factors, a reflected quartic, and a general quintic. It executes 1,159 guards: 1,155 successful conditions and four deliberately false identities correctly rejected. SymPy 1.13.1 supplies exact rational operations.

The checks use original monomial companion matrices and their tensor square, not root-value replacements. They verify both polynomial quotient dimensions using Groebner standard monomials; divided unscaled orbit bases; the two difference-operator blocks, ranks, and compositions; the complete diagonal injection/evaluation maps; every basis-pair derivative-weighted ideal product; and the full generator’s annihilator property. Negative controls reject a lost factor \(1/2\), premature specialization of \(H_1\), a square-zero odd tensor product, and identification with SSP’s reflection-odd module.

These finite checks supplement the arbitrary-degree proofs. They do not claim numerical validation of actual \(\xi\)-source integrals, a Lean formalization, an arithmetic asymptotic bound, or certification of publication artifacts. The exact source-energy identity (DE.32) is proved symbolically from the actual representative and boundary definitions, not by substituting test metrics.
