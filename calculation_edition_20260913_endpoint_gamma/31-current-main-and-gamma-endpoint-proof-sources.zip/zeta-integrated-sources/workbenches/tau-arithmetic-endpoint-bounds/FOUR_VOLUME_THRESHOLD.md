# The two endpoint calculations give a four-volume threshold of four

## Result and motivation

The arithmetic endpoint note bounds the monic source norms. The subsequent
window-product calculation retains the repeated occurrence of every interior
volume contraction. Composing them on the window one degree shorter than the
original window improves the original four-volume lower threshold from 2 to 4:

\[
\boxed{\liminf_{k\to\infty}
\frac{\log\bigl(V_{q_k-1}V_{q_k}/(V_{2q_k-1}V_{2q_k})\bigr)}
{q_k\log k}\ge4.}
\]

This statement concerns the original arithmetic family belonging to a fixed
packet consisting exactly of a full off-line quartet, with every multiplicity
retained. It is a necessary volume-growth consequence for such a packet, not
an assertion that an off-line zero exists. No upper bound contradicting this
growth is established here.

This note is a written continuation of the two supplied calculations. It is
not included in the frozen Toda--Gamma edition DOI
[10.5281/zenodo.22730756](https://doi.org/10.5281/zenodo.22730756).

## 1. Original source, constants, and coordinates

Keep \(g=2\xi\), the fixed monic packet polynomial \(h\), and

\[
w_h(t)=\frac{|(g/h)(1/2+it)|^2}{2\pi},\quad
m_{h,k}=w_h^{*k},\quad M_h(b)=\int e^{bt}w_h(t)\,dt.
\]

The mass remains \(\mu_h^k\). The monic degree-\(j\) source norm is
\(\omega_{h,k,j}\) for the observation \(S=k/2+iu\). In this coordinate
map the leading coefficient acquires the phase \(i^j\), of squared modulus
one. Neither the source measure nor the generator is replaced.

The arithmetic endpoint proof gives constants \(c_h>0\),
\(\vartheta_h=\int_{-1}^1w_h>0\), and \(B_h=42+2\deg h\), such that

\[
m_{h,k}(u)\ge c_h\vartheta_h^{k-3}
 e^{-\pi(|u|+k-3)/2}(1+|u|+k-3)^{-B_h},\qquad k\ge3.
\tag{1}
\]

Here (1) is the proved lower envelope of the actual threefold-and-higher
convolution, not a newly postulated comparison measure. Its proof is in the
[supplied complete arithmetic note](delivery/NOTE.tex).

Choose one \(0<b<\pi/2\) and define bounding constants

\[
X_h=\max\{1,M_h(b),M_h(-b)\},\qquad
K_h=\max\{1,\vartheta_h^{-1}\}.
\]

Taking maxima here only bounds constants; it performs no rescaling of the
source, its quotient, or either Gram determinant.

## 2. The balanced-window norm estimate, with an explicit constant

For integers \(n\ge k\ge3\) and \(n/2\le r\le n\), one has

\[
\boxed{\left(\frac{\omega_{h,k,n+r}}{\omega_{h,k,n}}\right)^{1/(2r)}
\le C_h^{\rm bal} n,}
\tag{2}
\]

where the following literal finite constant suffices:

\[
C_h^{\rm bal}=256e^\pi\max\{1,3/c_h\}\,X_hK_h
\max\{1,b^{-3}\}\,6^{B_h/3}.
\tag{3}
\]

To prove this, the trial polynomial \((S-k/2)^j\) and exponential moments
give the unchanged upper estimate

\[
\omega_{h,k,j}\le(2j)!b^{-2j}
\bigl(M_h(b)^k+M_h(-b)^k\bigr).
\]

The exact monic Legendre norm on \([-n,n]\) is

\[
\mathfrak l_n(n)=\frac{2n^{2n+1}}{2n+1}
\left(\frac{2^n}{\binom{2n}{n}}\right)^2
\ge\frac{2n^{2n+1}}{(2n+1)4^n}.
\]

This follows from the Legendre leading coefficient and squared norm in
[DLMF Table 18.3.1](https://dlmf.nist.gov/18.3#T1).
Combining (1) with this least-norm calculation gives the exact finite bound

\[
\left(\frac{\omega_{h,k,n+r}}{\omega_{h,k,n}}\right)^{1/(2r)}
\le\left[
\frac{(2(n+r))!b^{-2(n+r)}
\bigl(M_h(b)^k+M_h(-b)^k\bigr)
e^{\pi(n+k-3)/2}(1+n+k-3)^{B_h}}
{c_h\vartheta_h^{k-3}\mathfrak l_n(n)}
\right]^{1/(2r)}.
\tag{4}
\]

For completeness, use \((2(n+r))!\le(4n)^{2(n+r)}\),
\(M_h(b)^k+M_h(-b)^k\le2X_h^k\),
\(\vartheta_h^{-(k-3)}\le K_h^k\), and
\(1+n+k-3\le2n\). After taking the root, the factorial and Legendre factors
are bounded by

\[
4n\,8^{n/r}\left(\frac{2n+1}{c_h n}\right)^{1/(2r)}.
\]

The remaining factors are

\[
b^{-(n+r)/r}(X_hK_h)^{k/(2r)}
e^{\pi(n+k-3)/(4r)}(2n)^{B_h/(2r)}.
\]

Now \(n/r\le2\), \((n+r)/r\le3\), \(k/(2r)\le1\), and
\((n+k-3)/(4r)\le1\). Also \(2n+1\le3n\), and
\(\log(2n)/n\) decreases for \(n\ge3\), so
\((2n)^{B_h/(2r)}\le6^{B_h/3}\). These inequalities prove (2)--(3).
The diagonal \(r=n\) recovers the scale of the supplied theorem. The needed
new case is \(r=n-1\), which lies in the same balanced range.

## 3. The exact product on the same canonical metrics

Let \(V_N=\det G_N\), \(\delta_N=V_N/V_{N-1}\in(0,1]\), and retain
the calculated real phase \(\phi_N=\sigma-\partial_\theta\log V_N\).
The original radius identity is

\[
\epsilon_N^2+\phi_N^2
=\frac{\omega_{N+1}}{\omega_N}
 (1-\delta_N)(\delta_{N+1}^{-1}-1),\qquad N\ge q.
\]

Multiply at \(N=n,\ldots,n+r-1\), without discarding intermediate factors:

\[
\prod_{j=0}^{r-1}(\epsilon_{n+j}^2+\phi_{n+j}^2)
=\frac{\omega_{n+r}V_n}{\omega_nV_{n+r}}
(1-\delta_n)(1-\delta_{n+r})
\prod_{j=1}^{r-1}(1-\delta_{n+j})^2.
\tag{5}
\]

The original phase remains on the left. Each factor on the right after the
ratio belongs to \([0,1]\). The exterior theorem bounds the aggregate
spectral defect \(L_{h,k}\) by every \(\epsilon_N\). Thus (5) proves

\[
L_{h,k}^{2r}\le
\frac{\omega_{h,k,n+r}V_n}{\omega_{h,k,n}V_{n+r}}.
\tag{6}
\]

This deduction needs neither a new metric nor an assumption that the phase
vanishes. A unit contraction makes a factor in (5) zero and directly forces
\(L_{h,k}=0\); the inequality (6) still holds. The first admitted degree
\(q-1\) is not used in any radius identity here.

## 4. Central window and the factor four

For the exact quartet \(1/2\pm\delta\pm i\gamma\), with
\(\delta,\gamma>0\) and common order \(m\), keep

\[
q_k=[1+k(m-1)](k+1)^2,\qquad
L_{h,k}=2\delta[1+k(m-1)](k+1)
\left\lfloor\frac{(k+1)^2}{4}\right\rfloor.
\]

In particular \(L_{h,k}/q_k\ge\delta k/2\). Put \(q=q_k\) and choose
\(n=q,r=q-1\). All hypotheses of the proved balanced-window estimate
are satisfied: \(q\ge k\ge3\), \(q-1\ge q/2\), and every radius index
is at least \(q\). Equations (2) and (6) yield

\[
\boxed{\log\frac{V_q}{V_{2q-1}}
\ge2(q-1)\log\frac{L_{h,k}}{C_h^{\rm bal}q}
\ge2(q-1)\left(\log k+\log\frac{\delta}{2C_h^{\rm bal}}\right).}
\tag{7}
\]

Write \(C_k=\log(V_q/V_{2q-1})\). The original four-volume budget is
exactly

\[
\begin{aligned}
\mathcal B_{h,k}
&=\log\frac{V_{q-1}V_q}{V_{2q-1}V_{2q}}\\
&=2C_k+\log\frac{V_{q-1}}{V_q}
              +\log\frac{V_{2q-1}}{V_{2q}}\ge2C_k.
\end{aligned}
\tag{8}
\]

Both last terms are nonnegative by the original rank-one kernel update.
Substitution of (7) proves

\[
\boxed{\mathcal B_{h,k}\ge
4(q_k-1)\left(\log k+\log\frac{\delta}{2C_h^{\rm bal}}\right).}
\tag{9}
\]

Since \(h\) is fixed and \(q_k\to\infty\), division by
\(q_k\log k\) gives the claimed liminf of at least 4. An upper limit
strictly below 4 would already conflict with (9); no such upper estimate
has been obtained here. The two-volume conclusion at \(n=r=q\) is also
retained: \(\liminf \log(V_q/V_{2q})/(q\log k)\ge2\).

## 5. Source maps and verification scope

All representatives remain those of the supplied arithmetic construction:
\(J^{(k)}R_N=\eta_{h,k}\) and
\(q^{(k)}R_N=\sigma_h^{\otimes k}\eta_{h,k}\). Restricting the degree
window does not alter their unit, jets, fibre labels, or cohomology classes.
The supported-zero relation and the external absence \(\tau\) retain
their original separate maps. In particular, no repeated exterior iteration
or erased multiplicity cost occurs in (5)--(9).

The analytic envelope and original norm theorem are from the supplied
Arithmetic Endpoint Bounds note. Equation (5) is the subsequent supplied
window-product calculation. Equations (2)--(4) and their composition
(7)--(9) are the present continuation. The two independent review lanes
record finite tests separately from written analytic proof; no new Lean
certificate or interval enclosure of \(C_h^{\rm bal}\) is asserted.
