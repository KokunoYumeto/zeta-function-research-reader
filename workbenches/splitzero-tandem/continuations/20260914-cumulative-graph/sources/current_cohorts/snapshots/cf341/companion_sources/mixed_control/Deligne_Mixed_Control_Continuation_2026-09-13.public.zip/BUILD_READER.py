from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT/'sources'/'SOURCE_MANIFEST.json').read_text(encoding='utf-8'))
for entry in manifest['files']:
    path = ROOT / entry['path']
    if hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
        raise RuntimeError('Source or evidence hash mismatch: ' + entry['path'])
for name in ['MCF.tex','MW.tex','MRE.tex','SP.tex','BC.tex','MARKED_PRODUCT_ORIGINAL_NOTE.tex']:
    if not (ROOT/'sources'/name).is_file():
        raise RuntimeError('Required complete proof source missing: ' + name)

PREAMBLE = r"""\documentclass[11pt,a4paper]{article}
\usepackage[T1]{fontenc}
\usepackage{lmodern,amsmath,amssymb,amsthm,mathtools,mathrsfs}
\usepackage[margin=18mm]{geometry}
\usepackage[bookmarks=false]{hyperref}
\hypersetup{colorlinks=true,linkcolor=blue,urlcolor=blue}
\newtheorem{theorem}{Theorem}[section]
\newtheorem{proposition}[theorem]{Proposition}
\newtheorem{lemma}[theorem]{Lemma}
\newtheorem{definition}[theorem]{Definition}
\newtheorem{remark}[theorem]{Remark}
\allowdisplaybreaks
\setlength{\emergencystretch}{6em}
\title{Continuing the Deligne programme over the marked $\tau$ base\\
Complete mixed-support, extension, boundary and source-control calculations}
\author{}
\date{13 September 2026}
\begin{document}
\maketitle
\section*{Reading scope and retained dependencies}
This reader contains the complete new calculation bodies MCF, MW, MRE, SP
and BC, followed by the complete mathematical body of the original
marked-product continuation. Read the accompanying \texttt{PROMPT.md}
for the continuation task and \texttt{DELIGNE\_USAGE\_OVERVIEW.md} for the
source-grounded assessment of the Deligne machinery used so far.
The local \texttt{sources} directory preserves exact source copies and
their SHA256 manifest; the \texttt{evidence} directory preserves the
independent reviews and finite checks.

The inherited theta range and packet identities AG and CAU, their original
spaces and Euler inverses, and the cited Deligne statements remain named
inputs at their stated types. The new proofs retain those inputs and
construct their displayed maps explicitly. This document does not claim
to contain a proof of RH or a completed general six-operation formalism
for the marked support category. It gives calculations from which that
programme continues, including the actual mixed faces, their source
attachments, the singular boundary family, and its finite analytic forms.

The arbitrary length-two algebra in MRE is an explicit extension
calculation. Its use does not assert that an actual zero of $2\xi$ has
multiplicity two. The centered spectral nilpotent filtration and the
boundary inertia filtration are related only by maps constructed at
their specified types; their notation alone supplies no identification.

\tableofcontents
\clearpage
"""

ERRATA = r"""\clearpage
\appendix
\section*{Original marked-product note: literal source and reading corrections}
\addcontentsline{toc}{section}{Original marked-product note and literal corrections}
The following appendix preserves the complete original body, including
its abstract and scope statements. Only its document wrapper,
\verb|\maketitle| and \verb|\tableofcontents| controls are removed here.
The separate \texttt{MARKED\_PRODUCT\_ORIGINAL\_NOTE.tex} is byte exact.
The original frequency symbol is $y$ in $S=k/2+iy$; the deformation
parameter is $u$. In the original analytic displays, the measure
written $du$ after defining a density in $y$ is read as $dy$, and the
frequency arguments written $c+iu$ are read as $c+iy$.
These are distinct original variables, and this correction does not
specialize or replace either one.

The sentence following original equation (64) overstates positivity
of the relative derivative. For the literal positive source Grams
$M(0)$ and $M(1)$, the identities
\[
 M(0)\bigl(M(0)^{-1}M(1)\bigr)=M(1),\qquad
 M(0)\bigl(M(0)^{-1}(M(1)-M(0))\bigr)=M(1)-M(0)
\]
prove that the first endomorphism is positive and self-adjoint in the
$M(0)$ metric and that the second is self-adjoint. The second need
not be positive: when $M(1)=M(0)/2$, it equals $-I/2$.
Its original operator norm and the resulting midpoint enclosure
remain meaningful without the extra positivity assertion.

The two nonnegative source/relation operators whose densities occur
in the signed four-endpoint cancellation each have trace $2q$.
Their rank is $q+1$, with spectrum $1,2,\ldots,2,1$ on their range
(the multiplicity of $2$ is $q-1$). SP6--SP8 prove this from the
actual nested source and relation projections. Thus a kernel mass
$2q$ is read as that trace, not as rank $2q$. The complete exact
cancellation and its improved bound are retained in SP1--SP13.

\begin{center}\large
The marked $\tau$-base, weight-matched external products,\\
and the signed arithmetic four-endpoint correction
\end{center}
"""

parts=[PREAMBLE]
insertions=[]
for name in ['MCF.tex','MW.tex','MRE.tex','SP.tex']:
    body=(ROOT/'sources'/name).read_text(encoding='utf-8-sig')
    if r'\begin{document}' in body or r'\end{document}' in body:
        raise RuntimeError('Proof fragment unexpectedly includes a document wrapper: '+name)
    parts += ['\n% BEGIN EXACT PROOF BODY: '+name+'\n', body, '\n% END EXACT PROOF BODY: '+name+'\n\\clearpage\n']
    insertions.append({'source':'sources/'+name,'body_sha256_lf':hashlib.sha256(body.encode()).hexdigest(),'transformation':'UTF-8 decode and universal newline conversion only; mathematical TeX body unchanged'})
boundary=(ROOT/'sources'/'BC.tex').read_text(encoding='utf-8-sig')
if boundary.count(r'\begin{document}')!=1 or boundary.count(r'\end{document}')!=1:
    raise RuntimeError('Unexpected boundary source document boundaries')
bc_preamble,body=boundary.split(r'\begin{document}',1)
body=body.split(r'\end{document}',1)[0]
if body.count(r'\maketitle')!=1:
    raise RuntimeError('Unexpected boundary title display count')
body=body.replace(r'\maketitle','',1)
body=re.sub(r'\\(label|ref|eqref)\{([^}]+)\}',lambda match:'\\'+match[1]+'{BC:'+match[2]+'}',body)
macro_lines=[line for line in bc_preamble.splitlines() if line.startswith(r'\newcommand') or line.startswith(r'\DeclareMathOperator')]
parts[0]=parts[0].replace(r'\begin{document}', '\n'.join(macro_lines)+'\n'+r'\begin{document}',1)
parts += ['\n% BEGIN COMPLETE BOUNDARY SOURCE BODY\n\\begingroup\n',
          r'\renewcommand{\theequation}{BC\arabic{equation}}'+'\n',
          r'\renewcommand{\theHequation}{BC.\arabic{equation}}'+'\n',
          r'\setcounter{equation}{0}'+'\n',
          r'\section*{The original marked product at its boundary}'+'\n',
          r'\addcontentsline{toc}{section}{The original marked product at its boundary}'+'\n',
          body,'\n\\endgroup\n% END COMPLETE BOUNDARY SOURCE BODY\n\\clearpage\n']
insertions.append({'source':'sources/BC.tex','body_sha256_lf':hashlib.sha256(body.encode()).hexdigest(),'transformation':'Keep complete document body except maketitle; common article preamble supplies packages and theorem environments and retains every original source macro declaration; prefix every label/ref/eqref with BC: and printed automatic equation numbers with BC. No mathematical proof or prose is omitted.'})
original=(ROOT/'sources'/'MARKED_PRODUCT_ORIGINAL_NOTE.tex').read_text(encoding='utf-8-sig')
if original.count(r'\begin{document}')!=1 or original.count(r'\end{document}')!=1:
    raise RuntimeError('Unexpected original document boundaries')
body=original.split(r'\begin{document}',1)[1].split(r'\end{document}',1)[0]
for control in [r'\maketitle',r'\tableofcontents']:
    if body.count(control)!=1:
        raise RuntimeError('Unexpected original display control count: '+control)
    body=body.replace(control,'',1)
parts += [ERRATA,'\n% BEGIN COMPLETE ORIGINAL NOTE BODY\n',body,'\n% END COMPLETE ORIGINAL NOTE BODY\n',r'\end{document}'+'\n']
insertions.append({'source':'sources/MARKED_PRODUCT_ORIGINAL_NOTE.tex','body_sha256_lf':hashlib.sha256(body.encode()).hexdigest(),'transformation':'Keep complete document body, remove only maketitle and tableofcontents display controls; original preamble is supplied by the common reader. No mathematical or prose corrections are silently applied.'})
result=''.join(parts)
for prohibited in [r'\input{',r'\include{']:
    if prohibited in result:
        raise RuntimeError('Reader must be flattened: '+prohibited)
destination=ROOT/'COMPLETE_CONTROL_WORK.tex'
destination.write_text(result,encoding='utf-8',newline='\n')
receipt={'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'bytes':destination.stat().st_size,'lines':len(result.splitlines()),'standalone_latex_source':True,'complete_bodies':insertions}
(ROOT/'evidence'/'READER_ASSEMBLY.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
