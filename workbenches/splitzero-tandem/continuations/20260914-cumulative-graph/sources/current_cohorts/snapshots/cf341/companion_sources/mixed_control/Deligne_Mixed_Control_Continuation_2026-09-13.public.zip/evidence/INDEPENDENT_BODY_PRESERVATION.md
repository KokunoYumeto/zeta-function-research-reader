# Independent body-preservation receipt

Status: PASS. This is an independent packaging comparison; it makes no new mathematical or PDF-rendering claim.

Reader SHA256: `07b6ee249afb443448dc80de3d5b4e1a4e86189ead697f06d54a6b246fc6f840`.

Manifest SHA256: `e5ff8d298565983ee5666f4215bd244cfac7c942cba7216ecf4af416f225e70d`.

- All 21 manifest entries have the stated SHA256 and byte count and are byte-identical to their current original files.
- MCF.tex: the entire decoded source body is identical between its unique reader markers; only universal newline decoding is applied.
- MW.tex: the entire decoded source body is identical between its unique reader markers; only universal newline decoding is applied.
- MRE.tex: the entire decoded source body is identical between its unique reader markers; only universal newline decoding is applied.
- SP.tex: the entire decoded source body is identical between its unique reader markers; only universal newline decoding is applied.
- BC.tex: the entire original document body survives after removal of its one maketitle and prefixing label/ref/eqref targets with BC:. Every one of its 11 source macro declarations survives in the common preamble. The additional enclosing group, section title and equation-number prefix agree with BUILD_READER.py; no proof prose or display is dropped.
- Original marked-product note: the entire original document body, including its abstract, is exact after removing only its single maketitle and tableofcontents controls. Errata are external reader prose and do not silently edit the original body.

The reader has exactly one document boundary pair and no input/include dependencies. No missing body, unexpected body alteration, missing source macro, or manifest mismatch was found. BUILD_READER.py was read and its body transformations were checked without executing the builder or changing any source.
