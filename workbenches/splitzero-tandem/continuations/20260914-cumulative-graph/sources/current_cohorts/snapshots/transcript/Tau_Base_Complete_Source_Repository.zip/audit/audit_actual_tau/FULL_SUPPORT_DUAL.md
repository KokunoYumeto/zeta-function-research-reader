---
title: "The complete reversed support dual of the original tau chart"
date: "2026-09-13"
---

# Scope and source pins

This calculation completes the specific promise in transcript A1545, node `baccc895-0427-42ee-b6f6-4c61752dfde2`, to compute “the full τ-chart dual, including bottom fibers created by reversed support arrows.” It uses the actual four-point chart, coefficient spaces, differential, and right adjoint of the retained *Arithmetic cohomology over the τ-base*, `NOTE.md`, SHA-256 `d03e71ad18f187bd89880cb8ca6fc9c5d6f260b3de8e8e5702c27db97e7b63c3`. The complete transcript segment U0041–U0054 has SHA-256 `e79b46722d9a2ee95b68ae6512f37a19fd41e4b3ecc4e53583cd357d0442c251`. The reconstruction convention allowing a nonzero bottom fibre is the fully read `tex/support_diagrams.tex`, equations (D1)–(D8). No generic-stalk restriction replaces global cohomology here.

# 1. Original objects, signs, and both index sets

Retain \(E=\mathbb C\), the even Schwartz space
\[
V=\{\phi\in\mathcal S(\mathbb R):\phi(-x)=\phi(x),\ \phi(0)=0,\ \widehat\phi(0)=0\},
\qquad
\widehat\phi(\xi)=\int_{\mathbb R}\phi(x)e^{-2\pi i x\xi}\,dx,
\]
and
\[
\mathscr B=\{F\in C^\infty(\mathbb R_{>0}):
\sup_{x>0}x^b|(-x\partial_x)^kF(x)|<\infty\quad(b\in\mathbb Z,k\ge0)\}.
\]
Write \(\mathcal F:V\to V\) for this Fourier transform; on this even space \(\mathcal F^{-1}=\mathcal F\). Retain
\[
\Theta\phi(x)=\sum_{n\ne0}\phi(nx),\qquad
JF(x)=x^{-1}F(1/x),\qquad J\Theta=\Theta\mathcal F,
\qquad Q=\mathscr B/\Theta V,
\]
and denote the quotient by \(q:\mathscr B\to Q\). The source proves injectivity of \(\Theta\) from its Mellin identity in \(\Re s>1\); no zero in the critical strip is assumed absent.

The geometric index poset remains \(P=\{+,-,\eta,\sigma\}\), with \(+<\eta<\sigma\) and \(-<\eta<\sigma\). The support index poset is separately
\[
L=\{\varnothing,+,-,J_0\},\qquad J_0=\{+,-\},
\]
ordered by inclusion. The symbol \(J_0\) denotes a support mask; \(J\) above denotes the original inversion operator. At active mask \(A\), the coefficient diagram \(\mathcal T_A\) retains precisely the source legs belonging to \(A\), has overlap \(\mathscr B\), and has zero vector stalk at \(\sigma\). At the empty mask it is the zero diagram. The source computes
\[
\mathsf A_\tau(F)=R\Gamma(P,F)
\simeq[F_+\oplus F_-\xrightarrow{r_+-r_-}F_\eta],
\quad
K_\tau(W)=[I_\eta(W)\longrightarrow I_+(W)\oplus I_-(W)],
\]
with degrees \(0,1\) and \(-1,0\), respectively, and differential signs \(+,-\). Its proved adjunction gives
\[
D_A(W):=R\operatorname{Hom}_{\operatorname{Fun}(P,\operatorname{Vect}_E)}
(\mathcal T_A,K_\tau(W))
\cong R\operatorname{Hom}_E(\mathsf A_\tau(\mathcal T_A),W).
\]
Here \(W\) is an ordinary coefficient vector space, and \(X^\vee=\operatorname{Hom}_E(X,W)\) throughout the algebraic calculation.

# 2. The complete complexes and every support arrow

The following are literal representatives, not just their cohomology:
\[
\begin{array}{c|c|c|c}
A&D_A^{-1}&D_A^0&\delta_A\\ \hline
\varnothing&0&0&0\\
+&\mathscr B^\vee&V^\vee&\ell\mapsto\ell\Theta\\
-&\mathscr B^\vee&V^\vee&\ell\mapsto-\ell\Theta\mathcal F\\
J_0&\mathscr B^\vee&V^\vee\oplus V^\vee&
\ell\mapsto(\ell\Theta,-\ell\Theta\mathcal F).
\end{array}
\]
For \(A\subseteq A'\), the arrow \(D_{A'}\to D_A\) is precomposition with the original coefficient inclusion. On degree \(-1\) it is the identity between active masks. On degree zero the arrows \(J_0\to+\) and \(J_0\to-\) are respectively
\[
(a,b)\mapsto a,\qquad(a,b)\mapsto b.
\]
Both leaf-to-empty arrows are zero, as is the direct joint-to-empty arrow. Applying either coordinate projection to \(\delta_{J_0}\ell\) gives the corresponding displayed leaf differential; the maps therefore commute with the differentials. Both composites from joint to empty are zero. These checks prove all naturality and composition identities in \(\operatorname{Fun}(L^{\mathrm{op}},\operatorname{Ch}(E))\).

# 3. Cohomology, with an explicit quotient and inverse

For every active mask, the degree-\(-1\) kernel is
\[
\{\ell\in\mathscr B^\vee:\ell\Theta=0\}
\xleftarrow[\sim]{q^\vee}Q^\vee,
\qquad q^\vee(\lambda)=\lambda q.
\]
The inverse sends \(\ell\) to \([F]\mapsto\ell(F)\). It is well-defined precisely because \(\ell\Theta=0\). The Fourier isomorphism makes the condition on the minus face equivalent to the same equation. All active transition maps on this kernel are the identity in these \(Q^\vee\) coordinates.

On either single leg, the degree-zero cohomology is zero. Indeed any linear functional on \(V\) extends to \(\mathscr B\) through the injective map \(\Theta\). More concretely, the global retraction constructed in transcript A1694, fully reproved with explicit fixed cutoffs and estimates in Appendix A below, is a continuous linear map \(\Lambda:\mathscr B\to V\) with \(\Lambda\Theta=1\). Then \(a\Lambda\) lifts \(a\in V^\vee\) on the plus face and \(-b\mathcal F^{-1}\Lambda\) lifts \(b\in V^\vee\) on the minus face.

At the joint mask define
\[
\pi_0:V^\vee\oplus V^\vee\longrightarrow V^\vee,
\qquad\pi_0(a,b)=a\mathcal F+b.
\]
This evaluates the functional on the original cycle \(\psi\mapsto(\mathcal F\psi,\psi)\). The composite \(\pi_0\delta_{J_0}\) is zero. Conversely, if \(a\mathcal F+b=0\), then \(b=-a\mathcal F\), and
\[
\delta_{J_0}(a\Lambda)=(a,-a\mathcal F)=(a,b).
\]
The quotient map is surjective, with representative \(c\mapsto(0,c)\). Its inverse on the quotient sends \(c\) to the class of \((0,c)\): subtracting this representative from \((a,b)\) gives
\[
(a,b)-(0,a\mathcal F+b)=(a,-a\mathcal F)=\delta_{J_0}(a\Lambda).
\]
This proves both inverse identities. Consequently the entire cohomology diagram is
\[
\begin{array}{c|cccc}
A&J_0&+&-&\varnothing\\ \hline
H^{-1}D_A&Q^\vee&Q^\vee&Q^\vee&0\\
H^0D_A&V^\vee&0&0&0.
\end{array}
\]
The arrows in degree \(-1\) are identity from joint to either leaf and zero to the empty mask. Every arrow in degree zero is zero. No degree-zero joint class is discarded.

In particular \(V^\vee\ne0\) when \(W=E\). A concrete continuous functional is \(\phi\mapsto\phi(1)\). It is nonzero on
\[
\phi_*(x)=(4\pi^2x^4-6\pi x^2)e^{-\pi x^2}\in V.
\]
The function is even, Schwartz, and vanishes at zero. Integration by parts gives
\(\int x^4e^{-\pi x^2}dx=\frac{3}{2\pi}\int x^2e^{-\pi x^2}dx\), proving its integral is zero; its value at one is \(2\pi(2\pi-3)e^{-\pi}\ne0\).

# 4. What the reversed bottom actually contains

In \(L^{\mathrm{op}}\) the bottom is \(J_0\), the join operation is original intersection, and the top is the original empty mask. Thus the dual's bottom cohomology fibres are exactly \(Q^\vee\) in degree \(-1\) and \(V^\vee\) in degree zero. In particular the latter is nonzero for \(W=E\). The rule “every bottom fibre is zero” is therefore incompatible with this calculation.

The source's full reconstruction retains these fibres. For either cohomology diagram \(H^iD\), it is
\[
M^i=\coprod_{A\in L^{\mathrm{op}}}H^iD_A,
\]
with
\[
(A,u)+(B,v)=
(A\cap B,\rho_{A,A\cap B}u+\rho_{B,A\cap B}v),
\quad
r^\bullet(A,u)=(A,ru),
\quad
\tau(A,u)=(J_0,0).
\]
The global additive zero is \((J_0,0)\), and \(e(A,u)=(A,0)\). Associativity transports three amplitudes to \(A\cap B\cap C\); equality of the two iterated transports proves the two sums agree. The zero law uses the unique map from the bottom and its zero value. Linearity of transitions proves distributivity, and the fibrewise vector-space scalar laws prove the remaining semimodule laws. This is the exact reconstruction, including nonzero vectors in the fibre of its global zero under multiplication by \(e\).

If an additional external-absence label is desired while retaining every original reversed label, it can also be constructed explicitly: adjoin a new bottom \(\bot_\dagger<L^{\mathrm{op}}\), put zero fibre there, and retain all old fibres and arrows. The new external zero is \((\bot_\dagger,0)\). The label map sending \(\bot_\dagger\) and \(J_0\) both to \(J_0\), and fixing every other label, preserves joins and bottom. With identity maps on old fibres and the zero map on the new fibre it reconstructs a surjective split-linear comparison to \(M^i\). Its only additional identification is between the new external zero and the zero vector at the old bottom \(J_0\). It does not remove any nonzero bottom vector. This proves the exact relation between the two declared conventions; it does not silently impose a zero bottom fibre on the original reversed diagram.

# 5. Strict natural splitting fails, but the derived splitting has a concrete roof

Let \(C=V^\vee\), let \(Z_C\) be the diagram supported at the bottom \(J_0\) with value \(C\), and let \(H\) be the degree-\(-1\) cohomology diagram just calculated. The maps \(q^\vee:H[1]\to D\) and \(\pi:D\to Z_C[0]\), where \(\pi\) is \(\pi_0\) only at the joint mask in degree zero, are natural cochain maps.

There is no strict natural cochain section \(s:Z_C[0]\to D\) of \(\pi\) when \(C\ne0\). At the joint mask write \(s(c)=(a(c),b(c))\). Naturality to the plus leaf forces \(a(c)=0\), since the source at that leaf is zero. Naturality to the minus leaf forces \(b(c)=0\). Hence \(\pi s=0\), contradicting \(\pi s=1_C\). This is exactly a strict-section obstruction.

It is not a derived nonsplitting statement. Here is the actual surviving derived map. Write \(b=J_0,x=+,y=-,t=\varnothing\) in the reversed diamond. For a vertex \(v\), define the projective diagram
\[
P_v(C)(w)=\begin{cases}C,&v\le w,\\0,&v\nleq w.\end{cases}
\]
The augmented resolution of \(Z_C\) is
\[
\mathcal R_C:
P_t(C)\xrightarrow{c\mapsto(c,-c)}
P_x(C)\oplus P_y(C)\xrightarrow{(a,b)\mapsto a+b}
P_b(C)\xrightarrow{\epsilon}Z_C,
\]
with degrees \(-2,-1,0\) before the augmentation. At \(b\), the augmentation is identity. At either leaf the preceding map is identity and the augmented stalk is zero. At \(t\), the stalk sequence is \(0\to C\to C^2\to C\to0\), with the displayed anti-diagonal and sum. This proves exactness stalkwise and on all arrows. Each \(P_v(C)\) is projective because its Hom functor is \(\operatorname{Hom}_E(C,-_v)\), an exact functor over a field. Thus \(\epsilon:\mathcal R_C\to Z_C[0]\) is a quasi-isomorphism.

Define \(f:\mathcal R_C\to D\) as follows. In degree zero it is determined by
\[
f_b^0(c)=(0,c),\qquad f_x^0(c)=0,\qquad f_y^0(c)=c,\qquad f_t^0(c)=0.
\]
In degree \(-1\), its map from \(P_x(C)\) is zero, and its map from \(P_y(C)\) is determined at \(y\) by
\[
f_y^{-1}(c)=-c\mathcal F^{-1}\Lambda\in\mathscr B^\vee.
\]
At \(t\) it is zero; in degree \(-2\) it is zero. These maps are natural by their projective-source definitions and the zero target at \(t\). At \(y\), the chain equation is
\[
\delta_y(-c\mathcal F^{-1}\Lambda)
=c\mathcal F^{-1}\Lambda\Theta\mathcal F=c.
\]
At \(x\) both sides are zero, and at \(t\) both sides are zero. These verify every chain equation. Finally \(\pi f=\epsilon\), so
\[
Z_C[0]\xleftarrow[\simeq]{\epsilon}\mathcal R_C\xrightarrow{f}D
\]
is an explicit right inverse of \(\pi\) in the derived category. The combined cochain map
\[
H[1]\oplus\mathcal R_C\longrightarrow D,
\qquad(h,r)\longmapsto q^\vee h+f(r),
\]
induces identity on degree \(-1\) cohomology and the displayed isomorphism on degree zero cohomology. It is therefore a quasi-isomorphism. This proves the full derived relationship without replacing the original support arrows by equalities.

# 6. The original action and the actual defect of this roof

For \(a>0\), retain \(U_aF(x)=F(x/a)\). On the source plus and minus legs the actions are \(U_a\) and \(aU_{1/a}\). On \(\mathscr B\) the action is \(U_a\). Let \(W=\mathcal L_w\) carry \(a^w\), where the source supplies \(w=0,1\). Then on the displayed dual complex the action is
\[
\ell\longmapsto a^w\ell U_{1/a},
\qquad
(\alpha,\beta)\longmapsto
(a^w\alpha U_{1/a},a^{w-1}\beta U_a).
\]
The source identities \(\Theta U_a=U_a\Theta\) and \(\mathcal F U_a=aU_{1/a}\mathcal F\) verify directly that these operators commute with every differential and support arrow. On cohomology they give
\[
H^{-1}:\lambda\longmapsto a^w\lambda\overline U_{1/a},
\qquad
H^0:c\longmapsto a^{w-1}cU_a.
\]
For \(w=1\), these are the original weight-one dual action on \(Q^\vee\) and the explicit action \(c\mapsto cU_a\) on the retained bottom \(V^\vee\).

The roof above need not be strictly equivariant because \(\Lambda\) is not asserted equivariant. Its degree-zero component is equivariant. At the minus generator of degree \(-1\), its exact failure is
\[
\begin{aligned}
U_a^{D}f_y^{-1}(c)-f_y^{-1}(U_a^{C}c)
&=a^w c\mathcal F^{-1}
\bigl(U_{1/a}\Lambda-\Lambda U_{1/a}\bigr).
\end{aligned}
\]
Here the first \(U_{1/a}\) in parentheses acts on \(V\), and the second on \(\mathscr B\). The formula follows by substitution and \(U_a\mathcal F^{-1}=a\mathcal F^{-1}U_{1/a}\). Its precomposition with \(\Theta\) is zero, using \(\Lambda\Theta=1\) and the theta intertwining. It consequently factors through the exact injection \(q^\vee:Q^\vee\to\mathscr B^\vee\), with functional
\[
[F]\longmapsto a^w c\mathcal F^{-1}
\bigl(U_{1/a}\Lambda-\Lambda U_{1/a}\bigr)F.
\]
This is the computed relation between the original action, the chosen derived roof, and the retained \(Q^\vee\) fibre. No equivariant splitting is inferred by erasing this term. In this statement each projective \(P_v(C)\) carries the displayed coefficient action \(c\mapsto a^{w-1}cU_a\) at every nonzero stalk, and its restriction maps are identities; its resolution maps therefore intertwine the actions.

The derived class of this defect is also computable. Applying \(\operatorname{Hom}(-,H)\) to the displayed projective resolution gives the complex
\[
\operatorname{Hom}_E(C,Q^\vee)
\xrightarrow{\ell\mapsto(\ell,\ell)}
\operatorname{Hom}_E(C,Q^\vee)^2
\longrightarrow0.
\]
The last term is zero because \(H_t=0\). Thus
\[
\operatorname{Ext}^1(Z_C,H)
\cong\operatorname{Hom}_E(C,Q^\vee),
\qquad[(u,v)]\longmapsto v-u,
\quad
d\longmapsto[(0,d)].
\]
The two maps are inverse: their first composite is identity, and subtracting \((0,v-u)\) from \((u,v)\) gives the diagonal pair \((u,u)\). The action defect of the chosen roof has zero plus component and minus component \(q^\vee d_a\), where
\[
d_a(c)([F])=
a^w c\mathcal F^{-1}
(U_{1/a}\Lambda-\Lambda U_{1/a})F.
\]
It therefore has the exact Ext class \(d_a\). Equivalently, a nullhomotopy would be a degree-\(-1\) map from \(P_b(C)\) to \(D\), represented by the same functional on both leaves; its degree-zero equation forces that functional to annihilate \(\Theta V\). The leaf equations require its two copies to equal \((0,q^\vee d_a)\). Such a map exists exactly when \(d_a=0\). This proves that this particular derived section intertwines the action exactly when the displayed class vanishes; it does not assert that no other equivariant section can exist.

The class is the transpose of the original global theta cocycle by an exact formula. Put
\[
s[F]=(1-\Theta\Lambda)F,\qquad k_b=\Lambda U_b s.
\]
Every \(F\) has its original decomposition \(F=\Theta\Lambda F+s qF\). Substitution, with \(\Lambda\Theta=1\) and \(U_b\Theta=\Theta U_b\), gives
\[
U_b\Lambda-\Lambda U_b=-k_b q.
\]
Consequently the same class is
\[
\boxed{d_a(c)=-a^w c\mathcal F^{-1}k_{1/a}:Q\longrightarrow W.}
\]
The minus sign, Fourier inverse, reciprocal parameter, and coefficient action are retained. The reversed-support defect and the source's scaling boundary are thus connected by a proved morphism.

# 7. Continuity and the finite residue inclusion remain attached

For \(W=E\), all the formulas also hold for continuous duals with their strong topologies. The maps \(\Theta,\mathcal F,q\) and the source's explicit \(\Lambda\) are continuous, and \(\Lambda\Theta=1\) splits the original topological sequence. Thus the plus and minus lifts used above are continuous; all quotient and inverse maps are continuous on the displayed finite products. Precomposition by a continuous linear map is strongly continuous because it takes bounded subsets to bounded subsets. This verifies the asserted topology of every displayed dual transport. The derived roof assertion in Section 5 is in the declared algebraic diagram category; no undeclared derived category of all locally convex spaces is used.

The explicit inverse pair on strong duals is
\[
\mathscr B'_b\longrightarrow V'_b\oplus Q'_b,\quad
\ell\longmapsto(\ell\Theta,\ell s),
\qquad
(\alpha,\lambda)\longmapsto\alpha\Lambda+\lambda q.
\]
Its composites are identity by \(\Lambda\Theta=1\), \(qs=1\), \(\Lambda s=0\), \(q\Theta=0\), and \(\Theta\Lambda+sq=1\). Strong continuity follows directly from
\(p_B(T'\ell)=p_{T(B)}(\ell)\) for a bounded subset \(B\) and continuous linear \(T\). In particular \(q'\) identifies \(Q'_b\) with the annihilator of \(\Theta V\), with continuous inverse \(\ell\mapsto\ell s\). The joint relation subspace is the closed kernel of \(\pi_0\), and \(c\mapsto[(0,c)]\) is its continuous quotient inverse.

For the original reflection-stable finite arithmetic packet \(A_Z\), keep \(g=2\xi\), every actual multiplicity, the complete jet map \(J_Z:Q\to A_Z\), and the full residue form
\[
R_Z(f,h)=\sum_{\rho\in Z}\operatorname{Res}_{s=\rho}
\frac{f^\dagger(s)h(s)}{g(s)}\,ds,
\qquad f^\dagger(s)=\overline{f(1-\bar s)}.
\]
The source proves its perfectness, \(J_Z\)'s surjectivity and continuity, and its covariance with \(\mathcal L_1\). Therefore the map
\[
\overline{A_Z}\longrightarrow Q'_b,
\qquad\bar f\longmapsto([F]\mapsto R_Z(f,J_Z[F]))
\]
is the same injective continuous residue map at each active vertex of \(H^{-1}D\). The active support arrows are identities, so its three naturality squares commute exactly; at the empty vertex both maps are zero. Every nilpotent remains in the full \(A_Z\) and residue pairing. The new bottom \(H^0=V'_b\), the action defect of Section 6, and the original arithmetic residue inclusion now coexist in one completely specified reversed support calculation.

For the continuous-jet assertion one can retain an explicit estimate. Write \(r=\Re\rho\) and choose an integer \(n>|r|\). Differentiating the Mellin integral and splitting it at one gives, for every \(j\ge0\),
\[
|(\mathcal MF)^{(j)}(\rho)|
\le j!\left(
\frac{p_{n,0}(F)}{(n-r)^{j+1}}+
\frac{p_{-n,0}(F)}{(n+r)^{j+1}}\right).
\]
The two integrals used here are respectively
\(\int_1^\infty x^{r-n}(\log x)^j\,dx/x=j!/(n-r)^{j+1}\)
and
\(\int_0^1x^{r+n}|\log x|^j\,dx/x=j!/(n+r)^{j+1}\).
They follow from substitution \(y=|\log x|\) and \(j\) integrations by parts. Thus every derivative in the finite jet is continuous, with its actual order retained. The map descends by the original quotient topology since it annihilates \(\Theta V\).

The finished result is the explicit dual diagram, its nonzero bottom degree-zero fibre, the precise strict-section obstruction, the constructed derived roof that survives that obstruction, and its full scaling defect. None of these computations proves a theta weight bound, removes a finite-prime trace term, or replaces \(\mathsf A_\tau\) by restriction to \(\sigma\).

# Appendix A: complete retraction on the original theta source

## A.1. Original spaces and the fixed auxiliary functions

Work over \(\mathbb C\), with Fourier convention
\[
\widehat\phi(\xi)=\int_{\mathbb R}\phi(x)e^{-2\pi ix\xi}\,dx.
\]
Retain the original spaces, with their indicated seminorm topologies:
\[
V=\{\phi\in\mathcal S(\mathbb R):\phi(-x)=\phi(x),\
\phi(0)=0,\ \widehat\phi(0)=0\},
\]
\[
\mathscr B=\{F\in C^\infty(\mathbb R_{>0}):
p_{b,k}(F)=\sup_{x>0}x^b|D^kF(x)|<\infty
\quad(b\in\mathbb Z,\ k\ge0)\},\qquad D=-x\partial_x.
\]
Use Schwartz seminorms
\(\sigma_{m,j}(u)=\sup_{x\in\mathbb R}(1+|x|)^m|u^{(j)}(x)|\).
The Fourier transform preserves the even Schwartz space and satisfies
\(\mathcal F^2\phi(x)=\phi(-x)\). Consequently it preserves \(V\), since
\(\widehat\phi(0)=\int\phi\) and
\(\int\widehat\phi=\phi(0)\).

Fix the following explicit smooth functions for the entire construction:
\[
h(t)=
\begin{cases}
e^{-1/t},&t>0,\\
0,&t\le0,
\end{cases}
\qquad
\chi(x)=
\frac{h(1/16-x^2)}
{h(1/16-x^2)+h(x^2-1/64)},\qquad \alpha=\beta=\chi.
\]
All derivatives of \(h\) at zero vanish: each derivative for \(t>0\)
is a polynomial in \(1/t\) times \(e^{-1/t}\), which tends to zero.
The denominator defining \(\chi\) never vanishes, since its two
arguments cannot both be nonpositive. Thus \(\chi\) is real, even,
smooth, lies in \([0,1]\), equals one for \(|x|\le1/8\), and vanishes
for \(|x|\ge1/4\). In particular
\[
\|\chi\|_2^2\le\frac12.
\]
These are choices of reconstruction data on the original coordinates.
The spaces, Fourier convention and arithmetic theta map remain exactly
those displayed here.

## A.2. Theta continuity and recovery on both exterior regions

The original maps are
\[
\Theta\phi(x)=\sum_{n\ne0}\phi(nx)=2\sum_{n\ge1}\phi(nx),
\qquad JF(x)=x^{-1}F(1/x).
\]
Poisson summation gives \(\Theta\mathcal F=J\Theta\) on \(V\).
For this identity, periodize the Schwartz function
\(t\mapsto\phi(xt)\); its Fourier coefficients are
\(x^{-1}\widehat\phi(n/x)\), obtained by integrating over all translated
unit intervals. Both the periodization and its Fourier series converge
absolutely with derivatives. Evaluation at zero gives
\(\sum_n\phi(nx)=x^{-1}\sum_n\widehat\phi(n/x)\).
The two zero-index terms vanish by the original moments.

The theta map is continuous into \(\mathscr B\). Indeed, for \(x\ge1\),
an integer \(N>1\), and
\(s_{N,k}(\phi)=\sup_{t>0}t^N|D^k\phi(t)|\),
\[
|D^k\Theta\phi(x)|
\le2\zeta(N)s_{N,k}(\phi)x^{-N}.
\]
Each \(s_{N,k}\) is bounded by finitely many Schwartz seminorms.
Choosing \(N\ge b\) bounds the part of \(p_{b,k}\) on \(x\ge1\).
The identities
\[
D^kJ=J(1-D)^k,\qquad
p_{b,k}(JF)\le\sum_{j=0}^k\binom{k}{j}p_{1-b,j}(F)
\]
follow by differentiating \(x^{-1}F(1/x)\).
For \(x\le1\), apply the preceding theta estimate to
\(\widehat\phi\) at \(1/x\); choosing also \(N\ge1-b\) bounds this
part by
\(2\zeta(N)\sum_{j=0}^k\binom{k}{j}s_{N,j}(\widehat\phi)\).
This proves every required bound and also continuity of \(J\).

For \(x\ne0\), define the actual arithmetic inverse series
\[
\mathcal UF(x)=\frac12\sum_{n\ge1}\mu(n)F(n|x|).
\]
Here \(\mu\) is the ordinary Möbius function; the factor \(1/2\)
inverts the sum over both nonzero integer signs. Put
\[
P_j(T)=(-1)^jT(T+1)\cdots(T+j-1),\quad P_0=1,\qquad
C_{N,j}(F)=\sum_{k=0}^j|[T^k]P_j(T)|p_{N,k}(F).
\]
The identity \(x^j\partial_x^j=P_j(D)\) follows by induction.
Therefore, for \(x>0\) and integer \(N>1\),
\[
|\partial_x^j\mathcal UF(x)|
\le\frac{\zeta(N)}2C_{N,j}(F)x^{-N-j}.                 \tag{1}
\]
The same absolute bound holds for negative \(x\). It proves locally
uniform convergence of every differentiated series away from zero.

For \(\phi\in V\), the divisor rearrangement is legitimate: for fixed
\(x>0\),
\(\sum_{m,n\ge1}|\phi(mnx)|\) is finite, by a Schwartz bound of
degree \(N>1\) and \(\sum_{m,n}(mn)^{-N}=\zeta(N)^2\).
Thus
\[
\mathcal U\Theta\phi(x)
=\sum_{k\ge1}\left(\sum_{d\mid k}\mu(d)\right)\phi(kx)
=\phi(x).
\]
The divisor sum is one for \(k=1\) and zero otherwise: prime
factorization gives the product \(\prod_{p\mid k}(1-1)\) when \(k>1\).
Evenness gives recovery on negative \(x\), and Poisson summation gives
the second exterior recovery:
\[
\boxed{\mathcal U\Theta\phi=\phi,\qquad
\mathcal UJ\Theta\phi=\widehat\phi\quad(x\ne0).}         \tag{2}
\]
In particular \(\Theta\) is injective, including at zero by continuity.
No information about zeros of zeta in a critical strip enters this proof.

## A.3. Fixed contraction and full Schwartz estimates

On \(L^2(\mathbb R,dx)\), set
\[
A=M_\chi,\qquad B=\mathcal F^{-1}M_\chi\mathcal F,\qquad T=AB.
\]
Its integral kernel is \(\chi(x)\check\chi(x-y)\).
Plancherel and the change of variable \(z=x-y\) give
\[
\|T\|^2\le\|T\|_{\rm HS}^2
=\|\chi\|_2^2\|\check\chi\|_2^2
=\|\chi\|_2^4\le\frac14.
\]
Consequently the operator-norm convergent series supplies the actual inverse:
\[
\boxed{(1-T)^{-1}=\sum_{n=0}^{\infty}T^n,\qquad
\|(1-T)^{-1}\|\le2.}                                 \tag{3}
\]
Multiplying its partial sums by \(1-T\) leaves \(1-T^{n+1}\),
which tends to the identity, proving both inverse identities.

Define exterior functions, extended by zero near the origin, by
\[
a_F=(1-\chi)\mathcal UF,\qquad
b_F=(1-\chi)\mathcal UJF,\qquad
YF=a_F+\chi\mathcal F^{-1}b_F.
\]
Here are explicit bounds verifying all their Schwartz seminorms.
Write \(c_0=1\) and \(c_r=\|\chi^{(r)}\|_\infty\) for \(r\ge1\).
Leibniz's rule and (1), with \(N=m+2\), give
\[
\sigma_{m,j}(a_F)
\le\frac{\zeta(m+2)}2\,9^m
\sum_{r=0}^j\binom jr c_r\,8^{2+j-r}C_{m+2,j-r}(F).  \tag{4}
\]
Indeed every nonzero differentiated term occurs at \(|x|\ge1/8\),
where \(1+|x|\le9|x|\) and
\(|x|^{-2-j+r}\le8^{2+j-r}\).
The same bound holds for \(b_F\) with \(JF\) in place of \(F\);
the displayed bounds for \(J\) express it in finitely many original
\(p_{b,k}(F)\). Smoothness across the plateau endpoints follows from
smoothness of the cutoffs and their identically zero interior factors.

Fourier inversion is continuous on these Schwartz seminorms. Explicitly,
integration by parts gives
\[
\sigma_{m,j}(\mathcal F^{-1}u)
\le\sum_{r=0}^m\binom mr(2\pi)^{j-r}
\bigl\|\partial_\xi^r(\xi^ju)\bigr\|_1.
\]
Each integral on the right is bounded by a finite sum of Schwartz
seminorms, using Leibniz's rule and
\(\int_{\mathbb R}(1+|\xi|)^{-2}d\xi=2\).
Together with (4), this proves that \(Y:\mathscr B\to\mathcal S^{\rm even}\)
is continuous.

The operator \(T\) also maps \(L^2\) continuously to Schwartz space.
Put
\[
b_j=\|(2\pi\xi)^j\chi(\xi)\|_2
\le\frac{(\pi/2)^j}{\sqrt2},\qquad
A_{m,j}=(5/4)^m
\sum_{r=0}^j\binom jr\|\chi^{(r)}\|_\infty b_{j-r}.
\]
Cauchy–Schwarz in the Fourier integral bounds
\(\|\partial^jBf\|_\infty\) by \(b_j\|f\|_2\).
Leibniz's rule and the support of \(\chi\) therefore give
\[
\sigma_{m,j}(Tf)\le A_{m,j}\|f\|_2.
\]
Set \(\Phi F=(1-T)^{-1}YF\), initially in \(L^2\).
The equation \(\Phi F=YF+T\Phi F\) proves that it is Schwartz, and
supplies the explicit continuity estimate
\[
\sigma_{m,j}(\Phi F)
\le\sigma_{m,j}(YF)+2A_{m,j}\|YF\|_2.                 \tag{5}
\]
The final \(L^2\) norm is bounded by
\(\sqrt2\,\sigma_{1,0}(YF)\).
Every operator preserves parity; hence \(\Phi F\) is even.
Equations (2) give
\[
Y\Theta\phi=(1-A)\phi+A(1-B)\phi=(1-T)\phi,
\qquad \Phi\Theta\phi=\phi.                          \tag{6}
\]

## A.4. The original moment correction and exact splitting

Retain
\[
\gamma_0(x)=e^{-\pi x^2},\qquad
\gamma_2(x)=2\pi x^2e^{-\pi x^2}.
\]
Their moment columns \((\phi(0),\int_{\mathbb R}\phi)\) are
\((1,1)\) and \((0,1)\).
For the integral constants, the square of the Gaussian integral is
the planar polar integral \(2\pi\int_0^\infty re^{-\pi r^2}dr=1\).
Integrating \(\partial_x(xe^{-\pi x^2})\) then gives
\(2\pi\int x^2e^{-\pi x^2}dx=1\).
Thus the continuous projection
\[
P_Vu=u-u(0)\gamma_0-
\left(\int_{\mathbb R}u-u(0)\right)\gamma_2
\]
has both original moments zero and is identity on \(V\).
Continuity follows from
\(|u(0)|\le\sigma_{0,0}(u)\) and
\(|\int u|\le2\sigma_{2,0}(u)\).
The required map is therefore
\[
\boxed{\Lambda=P_V(1-T)^{-1}Y:\mathscr B\longrightarrow V,
\qquad \Lambda\Theta=1_V.}                           \tag{7}
\]
All constants and seminorm dependence have been supplied in (1)–(5).
For the original quotient \(q:\mathscr B\to Q=\mathscr B/\Theta V\),
put \(K=1-\Theta\Lambda\).
Equation (7) gives \(K^2=K\), \(\ker K=\Theta V\), and
\(\operatorname{im}K=\ker\Lambda\).
The image \(\Theta V\) is closed because it is the kernel of continuous
\(K\). The continuous map \(K\) descends by the quotient topology to
\[
s:Q\to\mathscr B,\qquad s[F]=KF,\qquad
qs=1,\quad\Lambda s=0,\quad\Theta\Lambda+sq=1.
\]
These equations prove the continuous inverse pair
\[
V\oplus Q\longrightarrow\mathscr B,\quad
(\phi,u)\longmapsto\Theta\phi+su,\qquad
F\longmapsto(\Lambda F,qF).
\]

Finally, retain \(U_aF(x)=F(x/a)\).
It is continuous because \(p_{b,k}(U_aF)=a^bp_{b,k}(F)\);
its source action preserves \(V\) and obeys
\(U_a\Theta=\Theta U_a\).
It therefore induces \(\overline U_a\) on \(Q\).
Put \(k_a=\Lambda U_as\).
The decomposition of \(U_as\) gives
\[
U_as=\Theta k_a+s\overline U_a,\qquad
k_{ab}=U_ak_b+k_a\overline U_b,\qquad k_1=0.
\]
For the middle identity, substitute the first identity with parameter
\(b\) into \(\Lambda U_aU_bs\), and use
\(\Lambda U_a\Theta=U_a\) and \(\Lambda U_as=k_a\).
Writing \(F=\Theta\Lambda F+s qF\) also proves
\[
U_a\Lambda-\Lambda U_a=-k_aq.
\]
Consequently the reversed-support dual roof's action defect is exactly
\[
\boxed{d_a(c)=-a^wc\mathcal F^{-1}k_{1/a}.}
\]
This connects the completed retraction to the original action on
the full \(Q\), retaining its Fourier inverse, weight factor, reciprocal
parameter and sign. The calculation does not set this cocycle to zero.
