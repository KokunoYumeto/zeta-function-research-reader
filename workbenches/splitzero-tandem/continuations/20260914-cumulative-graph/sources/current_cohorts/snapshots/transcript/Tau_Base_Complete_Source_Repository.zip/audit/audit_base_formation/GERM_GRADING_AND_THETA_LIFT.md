---
title: "An exact grading comparison on the original Mellin jets and theta complex"
date: "2026-09-13"
geometry: margin=27mm
fontsize: 11pt
header-includes:
  - \usepackage{amsmath,amssymb,mathtools}
---

This calculation completes the operator comparison left unspecified in shared transcript A0961, node `a7bbd422-311c-4380-ba6c-a4bdd61fce2f`, §7. It uses the original arithmetic objects of *Arithmetic cohomology over the tau-base*, equations (10)–(14), (19), (27), and (38)–(45). It preserves the actual function $g=2\xi$, every local unit, multiplicity, coordinate, reflected-germ sign and support mask. The new grading is an explicitly constructed additional action. It is not identified with arithmetic Frobenius or with the original Mellin scaling.

## 1. Original arithmetic objects and analytic identities

Write $E=\mathbb C$ and retain
\[
 V=\{\phi\in\mathcal S(\mathbb R):\phi\text{ even},\ \phi(0)=0,
              \widehat\phi(0)=0\},\qquad
 \widehat\phi(\xi)=\int_{\mathbb R}\phi(x)e^{-2\pi i x\xi}\,dx.
\]
The target is the original Fréchet space
\[
 \mathscr B=\{F\in C^\infty(\mathbb R_{>0}):p_{b,k}(F)<\infty
                       \text{ for all }b\in\mathbb Z,k\ge0\},
 \quad p_{b,k}(F)=\sup_{x>0}x^b|D^kF(x)|,
 \quad D=-x\partial_x.
\]
Its Mellin transform is
\[
 \mathcal MF(s)=\int_0^\infty F(x)x^s\,\frac{dx}{x}.
\]
For $F\in\mathscr B$ this is entire. Indeed, for any compact set of $s$ and any derivative order, choose integers $b_-$ below every $\Re s$ in that compact set and $b_+$ above every $\Re s$. On $(0,1)$ and $(1,\infty)$ respectively, the bounds $|F(x)|\le p_{b_-,0}(F)x^{-b_-}$ and $|F(x)|\le p_{b_+,0}(F)x^{-b_+}$ give integrable dominating functions even after multiplication by any power of $|\log x|$. Differentiation under the integral is therefore justified.

Retain the two original maps
\[
 \Theta\phi(x)=\sum_{n\in\mathbb Z\setminus\{0\}}\phi(nx),
 \qquad \mathcal JF(x)=x^{-1}F(1/x).
\]
For every $\phi\in V$, $\Theta\phi\in\mathscr B$. At infinity this follows by termwise Euler differentiation and the Schwartz estimate, choosing a decay exponent greater than one so that its sum over $n$ converges. At zero Poisson summation, with both original vanishing moments, gives
\[
 \Theta\phi(x)=x^{-1}\Theta\widehat\phi(1/x).
\]
The same infinity estimates for $\widehat\phi$ apply after differentiating this identity; the resulting finite sums of Euler derivatives still decay faster than every power at zero. All sums and differentiated sums converge normally on compact positive intervals. Fourier transformation preserves $V$, and
\[
 \mathcal J\Theta\psi=\Theta\widehat\psi.
\]
Thus the original two-leg cochain complex is
\[
 C_\theta=[V\oplus V\xrightarrow{d}\mathscr B],\qquad
 d(\phi,\psi)=\Theta\phi-\mathcal J\Theta\psi
             =\Theta(\phi-\widehat\psi),
\]
in degrees $0,1$. Its degree-one quotient is $Q=\mathscr B/\Theta V$.

For clarity, the exact Mellin factor used below can be proved without replacing $g$ by its leading local monomial. Put
\[
 g(s)=2\xi(s)=s(s-1)\pi^{-s/2}\Gamma(s/2)\zeta(s).
\]
The entire continuation and reflection identity needed here follow directly from the Gaussian theta integral. With
\[
 \vartheta(x)=2\sum_{n\ge1}e^{-\pi n^2x^2},
\]
Poisson summation gives $\vartheta(x)=x^{-1}\vartheta(1/x)+x^{-1}-1$. Mellin integration for $\Re s>1$, followed by splitting at $1$ and substituting $x\mapsto1/x$ in the lower integral, yields
\[
 \pi^{-s/2}\Gamma(s/2)\zeta(s)
 =\frac1{s(s-1)}+
   \int_1^\infty\vartheta(x)(x^s+x^{1-s})\,\frac{dx}{x}.
\]
The latter integral is entire by Gaussian decay. Consequently
\[
 g(s)=1+s(s-1)\int_1^\infty\vartheta(x)(x^s+x^{1-s})\,\frac{dx}{x},
 \quad g(1-s)=g(s),\quad \overline{g(\bar s)}=g(s).
\]
In particular $g$ is not zero identically and satisfies $g^\dagger=g$ for the reflection below.

For $\phi\in V$, absolute convergence for $\Re s>1$ gives the exact factorization
\[
 \mathcal M\Theta\phi(s)=2\zeta(s)\mathcal M\phi(s)
                         =g(s)H_\phi(s),
 \qquad
 H_\phi(s)=\frac{2\pi^{s/2}\mathcal M\phi(s)}
                  {s(s-1)\Gamma(s/2)}.
\]
Here $\mathcal M\phi$ uses the positive half-line. To verify that $H_\phi$ is entire, split its integral at $1$ and subtract finitely many terms of the even Taylor expansion of $\phi$ at zero. Since $\phi(0)=0$, its only possible Mellin poles are simple poles at $s=-2,-4,\ldots$, with the corresponding even Taylor coefficients as residues. Each is canceled by the simple zero of $1/\Gamma(s/2)$. At $s=0$ the same reciprocal gamma factor cancels the displayed factor $s$. At $s=1$, $\mathcal M\phi(1)=\frac12\int_{\mathbb R}\phi=\frac12\widehat\phi(0)=0$ cancels $s-1$. This proves the asserted entire continuation. The displayed identity then holds everywhere by continuation. No vanishing at an arithmetic zero was assumed in this argument.

## 2. Full actual jet packets, reflection, and residue pairing

Fix any finite set $Z$ of actual zeros of this $g$ which is stable under
\[
 \iota\rho=1-\bar\rho.
\]
If $Z$ is empty, set $A_Z=0$, $J_Z=0$, $S=0$, and $L_q=1$; all packet identities below are the unique identities on the zero space, and no minimum or maximum over $Z$ is taken. For the remaining construction assume $Z$ is nonempty.
Retain the actual order $m_\rho\ge1$ of each zero and the coordinate $z_\rho=s-\rho$. Write the actual germ, with its unit intact, as
\[
 g_\rho(z)=g(\rho+z)=u_\rho(z)z^{m_\rho},\qquad u_\rho(0)\ne0.
\]
The coefficient algebra is
\[
 A_Z=\bigoplus_{\rho\in Z}\mathcal O_\rho/(g),
\]
where $\mathcal O_\rho$ is the ring of holomorphic germs at $\rho$. Since multiplication by the actual unit $u_\rho$ is invertible, the ideal $(g_\rho)$ equals $(z^{m_\rho})$. This equality identifies classes with unique truncated Taylor coordinates; it does not replace the denominator $g_\rho$ in a residue. Define
\[
 (J_ZF)_\rho=\sum_{j=0}^{m_\rho-1}
           \frac{(\mathcal MF)^{(j)}(\rho)}{j!}z_\rho^j.
\]
The preceding factorization proves $J_Z\Theta=0$, so $J_Z$ induces $\bar J_Z:Q\to A_Z$.

Reflection is the conjugate-linear involution
\[
 (f^\dagger)_\rho(z)
   =\overline{f_{\iota\rho}(-\bar z)}
   =\sum_{j\ge0}(-1)^j\overline{f_{\iota\rho,j}}z^j.
\]
Because $g^\dagger=g$, reflection preserves the defining ideals, $m_{\iota\rho}=m_\rho$, and the actual units satisfy
\[
 u_\rho(z)=(-1)^{m_\rho}\overline{u_{\iota\rho}(-\bar z)}.
\]
Retain the original residue form, conjugate-linear in its first variable and linear in its second:
\[
 R_Z(f,h)=\sum_{\rho\in Z}\operatorname{Res}_{z=0}
           \frac{(f^\dagger)_\rho(z)h_\rho(z)}{u_\rho(z)z^{m_\rho}}\,dz.
\]
Changing either representative by a multiple of its actual $g$ changes the integrand by a holomorphic germ, so this form is well-defined. It is perfect: if a nonzero component of $h$ starts with $h_kz^k$, choose $(f^\dagger)_\rho=z^{m_\rho-1-k}$ and all other components zero. Its residue is $h_k/u_\rho(0)\ne0$. Reflection is a bijection, so that choice of $f^\dagger$ comes from an $f$. Finite dimension then gives nondegeneracy in both variables.

The form is **skew-Hermitian**, with no phase change. In fact for a meromorphic germ $a(z)=\sum a_jz^j$, reflection changes its residue coefficient to $-\bar a_{-1}$, because $(-1)^{-1}=-1$. Applying that identity, relabeling $\rho$ by $\iota\rho$, and using $g^\dagger=g$ gives
\[
 R_Z(h,f)=-\overline{R_Z(f,h)}.
\]
This sign will not be replaced by a positivity assertion.

## 3. The exact additional grading and its inverse

For each real $q>0$ define componentwise
\[
 (C_qf)_\rho(z)=f_\rho(z/q)\pmod{g_\rho(z)}.
\]
This is an algebra automorphism of the original quotient. To check well-definedness with the original unit retained, compute
\[
 \frac{g_\rho(z/q)}{g_\rho(z)}
 =q^{-m_\rho}\frac{u_\rho(z/q)}{u_\rho(z)}.
\]
The right side is a holomorphic unit at zero. Thus substitution sends the ideal $(g_\rho)$ onto itself. Its inverse is
\[
 (C_q^{-1}f)_\rho(z)=f_\rho(qz),
\]
as is seen directly by composing the substitutions. In particular
\[
 C_pC_q=C_{pq},\qquad C_1=1,\qquad
 C_q(z_\rho^j)=q^{-j}z_\rho^j.
\]
Since $q$ is real and positive, substitution commutes with the reflected conjugation:
\[
 (C_qf)^\dagger=C_q(f^\dagger).
\]
The separate packet labels $\rho$, local coordinates, multiplicities, and positive-degree jets have all been retained.

On a component let
\[
 N_\rho f=z_\rho f,
 \qquad U_a|_\rho=a^\rho e^{(\log a)N_\rho},\quad a>0,
 \qquad a^\rho=\exp(\rho\log a),
\]
with the real logarithm of the original parameter $a$. These are exactly the jet operators induced by the original scaling $U_aF(x)=F(x/a)$. Multiplication by $a^{\rho+z}$ follows from a change of variables in the original Mellin integral. No centered or normalized scaling has been substituted.

Direct multiplication proves
\[
 U_aN_\rho U_a^{-1}=N_\rho,
 \qquad C_qN_\rho C_q^{-1}=q^{-1}N_\rho.
\]
Conjugating the full exponential gives the exact surviving comparison
\[
 \boxed{
 C_qU_a|_\rho C_q^{-1}
  =a^\rho\exp\!\left(\frac{\log a}{q}N_\rho\right)
  =a^{\rho(1-1/q)}U_{a^{1/q}}|_\rho.
 }
\]
Every exponential is its full finite sum through degree $m_\rho-1$. The factor $a^{\rho(1-1/q)}$ remains part of the formula. This is a relation between two distinct actions on the same actual arithmetic packet.
The conjugated operator $C_qU_aC_q^{-1}$ still commutes with $N_\rho$, because its displayed formula is a polynomial in $N_\rho$ times a scalar. It is $C_q$ itself, not that conjugated arithmetic operator, which scales $N_\rho$ by $q^{-1}$.

## 4. Exact obstruction to a literal simultaneous identification

Let $N=\bigoplus N_\rho$ and $U_a=\bigoplus U_a|_\rho$. Fix $q>0$, $q\ne1$, and retain any target vector space $W$ with invertible $F$ and an operator $N_D$ satisfying the exact Deligne-type relation
\[
 FN_DF^{-1}=q^{-1}N_D.
\]
Every linear map $T:A_Z\to W$ intertwining both proposed operators,
\[
 TU_a=FT,\qquad TN=N_DT,
\]
annihilates $NA_Z$. Indeed $F^{-1}T=TU_a^{-1}$, so
\[
 FN_DF^{-1}T=FTNU_a^{-1}=TU_aNU_a^{-1}=TN=N_DT.
\]
The left side is also $q^{-1}N_DT$. Since $1-q^{-1}\ne0$, $N_DT=TN=0$. Hence $T$ factors uniquely through
\[
 A_Z\twoheadrightarrow A_Z/NA_Z
       =\bigoplus_{\rho\in Z}\mathbb C,
\]
the actual residue-value observation. An injective such $T$ therefore exists only when every $N_\rho=0$, which is equivalent to every $m_\rho=1$.

This proves precisely the obstruction to the **literal simultaneous identification** of original Mellin scaling and the same full jet nilpotent with that pair. It does not forbid other functors or additional actions. There is a concrete surviving quotient map: evaluation at $z=0$ intertwines $U_a$ with $\operatorname{diag}(a^\rho)$ and sends $N$ to zero. On that quotient the target relation holds with $N_D=0$, and it imposes no condition on $\Re\rho$. Alternatively, $C_q$ retains all nilpotents and satisfies the target conjugacy relation, with its distinct semidirect interaction with $U_a$ proved above.

## 5. Residue Jacobian, adjoint, and trace contraction

Define the actual unit in each component
\[
 \kappa_{q,\rho}(z)
   =q^{1-m_\rho}\frac{u_\rho(z)}{u_\rho(qz)}.
\]
Changing the local coordinate of integration by $z=qw$ in the residue gives, with its Jacobian retained,
\[
 \begin{aligned}
 R_Z(C_qf,C_qh)
 &=\sum_\rho q\operatorname{Res}_{w=0}
       \frac{(f^\dagger)_\rho(w)h_\rho(w)}{g_\rho(qw)}\,dw\\
 &=\sum_\rho\operatorname{Res}_{w=0}
       \frac{(f^\dagger)_\rho(w)\kappa_{q,\rho}(w)h_\rho(w)}
            {g_\rho(w)}\,dw.
 \end{aligned}
\]
Thus
\[
 \boxed{R_Z(C_qf,C_qh)=R_Z(f,M_{\kappa_q}h).}
\]
In particular the factor is $q^{1-m_\rho}$, not $q^{-m_\rho}$, and the quotient of the full local units remains. The unit relation from reflection proves, without dropping its sign,
\[
 (\kappa_q^\dagger)_\rho(z)
 =q^{1-m_\rho}
   \frac{(-1)^{m_\rho}u_\rho(z)}{(-1)^{m_\rho}u_\rho(qz)}
 =\kappa_{q,\rho}(z).
\]
Put
\[
 D_q=M_{\kappa_q}C_q^{-1}.
\]
Replacing the second $C_qh$ in the residue formula by an arbitrary $h$ proves
\[
 R_Z(C_qf,h)=R_Z(f,D_qh).
\]
Skew-Hermitian symmetry then gives the equally important other-side formula
\[
 R_Z(D_qf,h)=R_Z(f,C_qh).
\]
For example, apply the first formula to $(h,f)$ and take negative complex conjugates; no phase is needed. These are the exact residue adjoint identities.

Retain the original trace contraction
\[
 J_g=M_{g'}:A_Z\to A_Z.
\]
The actual derivative is $g_\rho'(z)=m_\rho u_\rho(z)z^{m_\rho-1}+u_\rho'(z)z^{m_\rho}$. Modulo its original ideal $(g_\rho)=(z^{m_\rho})$ this gives
\[
 \begin{aligned}
 \kappa_{q,\rho}(z)g_\rho'(qz)
 &\equiv q^{1-m_\rho}\frac{u_\rho(z)}{u_\rho(qz)}
          m_\rho u_\rho(qz)q^{m_\rho-1}z^{m_\rho-1}\\
 &=m_\rho u_\rho(z)z^{m_\rho-1}
 \equiv g_\rho'(z).
 \end{aligned}
\]
Consequently
\[
 \boxed{D_qJ_gC_q=J_g.}
\]
The contracted form is therefore invariant:
\[
 R_Z(C_qf,J_gC_qh)=R_Z(f,J_gh).
\]
Its exact value is
\[
 R_Z(f,J_gh)
   =\sum_{\rho\in Z}m_\rho\overline{f_{\iota\rho}(0)}h_\rho(0)
   =\operatorname{Tr}(M_{f^\dagger h}|A_Z).
\]
For the first equality, $g_\rho'/g_\rho=m_\rho/z+u_\rho'/u_\rho$ and the second term is holomorphic. For the second, multiplication by a germ on the basis $1,z,\ldots,z^{m_\rho-1}$ is triangular with its constant coefficient on all $m_\rho$ diagonal entries. The radical of this contracted form is exactly $NA_Z$; the full residue form is perfect before contraction. $C_q$ is invertible and preserves that radical. No nilpotent or multiplicity has been discarded.

## 6. A proved continuous section on the original theta target

We now construct a section of $J_Z$ in the actual space $\mathscr B$, not in a substitute polynomial test family. Index the Taylor coordinates by
\[
 \Lambda=\{(\rho,j):\rho\in Z,\ 0\le j<m_\rho\},\qquad M=|\Lambda|.
\]
Choose fixed real numbers $\alpha<\beta$ and retain the bump
\[
 \chi(y)=
 \begin{cases}
 \exp\!\left(-\dfrac1{(y-\alpha)(\beta-y)}\right),&\alpha<y<\beta,\\
 0,&\text{otherwise}.
 \end{cases}
\]
It is smooth and all its endpoint derivatives vanish. For $i=(\rho,j)$ let
\[
 w_i(y)=e^{\rho y}\frac{y^j}{j!},\qquad
 H_{ik}=\int_{\mathbb R}\chi(y)w_i(y)\overline{w_k(y)}\,dy.
\]
The matrix $H$ is invertible. Here is the required independence proof. An identically zero linear combination of the $w_i$ on a nonempty real interval has the form $\sum_\rho e^{\rho y}P_\rho(y)=0$ with $\deg P_\rho<m_\rho$. By analyticity it vanishes everywhere. Fix $\rho$ and apply
\[
 \prod_{\sigma\in Z,\ \sigma\ne\rho}(\partial_y-\sigma)^{m_\sigma}.
\]
All other summands vanish. The remaining equation is
\[
 e^{\rho y}\prod_{\sigma\ne\rho}
       (\partial_y+\rho-\sigma)^{m_\sigma}P_\rho(y)=0.
\]
On polynomials of degree below $m_\rho$, each factor $\partial_y+c$ with $c\ne0$ is invertible: its inverse is the finite sum
\[
 c^{-1}\sum_{r=0}^{m_\rho-1}(-c^{-1}\partial_y)^r.
\]
Thus $P_\rho=0$. Doing this for every $\rho$ proves independence. For any nonzero column $v$,
\[
 v^*Hv=\int\chi(y)\left|\sum_i\overline{v_i}w_i(y)\right|^2\,dy>0,
\]
because the combination cannot vanish on the whole interval where $\chi>0$. Hence $H$ is positive definite and invertible.

Define functions in the original positive variable by
\[
 F_k(x)=\chi(\log x)\sum_{\ell\in\Lambda}
              \overline{w_\ell(\log x)}(H^{-1})_{\ell k}.
\]
Each is smooth and supported in $[e^\alpha,e^\beta]$, with all derivatives zero at its endpoints, so $F_k\in\mathscr B$. Direct substitution $y=\log x$ gives
\[
 \frac{(\mathcal MF_k)^{(j)}(\rho)}{j!}
  =\int\chi(y)w_{(\rho,j)}(y)
         \sum_\ell\overline{w_\ell(y)}(H^{-1})_{\ell k}\,dy
  =\delta_{(\rho,j),k}.
\]
Thus the explicit finite-rank map
\[
 S:A_Z\to\mathscr B,\qquad
 S\!\left(\sum_i c_i z_i^{j_i}\right)=\sum_i c_iF_i,
 \qquad J_ZS=1_{A_Z},
\]
is a continuous linear section. The notation in the sum means the specified Taylor coordinates in their separate $\rho$-components.

For explicit continuity of the observation, choose integers
\[
 b_-<\min_{\rho\in Z}\Re\rho,
 \qquad b_+>\max_{\rho\in Z}\Re\rho.
\]
For each $i=(\rho,j)$, direct integration of $|\log x|^j$ on the two half-lines proves
\[
 |(J_ZF)_{\rho,j}|
 \le\frac{p_{b_-,0}(F)}{(\Re\rho-b_-)^{j+1}}
    +\frac{p_{b_+,0}(F)}{(b_+-\Re\rho)^{j+1}}.
\]
The $j!$ in the jet definition exactly cancels the $j!$ in those elementary integrals. All constants and original seminorms remain explicit. In particular $J_Z$ and $S$ are continuous, $J_Z$ is surjective, and $\bar J_Z$ on $Q$ is surjective. No assertion about closedness of $\Theta V$ or completeness of its quotient was needed.

## 7. An exact action on the original four-point theta sheaf

Define on $\mathscr B$
\[
 \boxed{L_q=1+S(C_q-1)J_Z.}
\]
Then
\[
 J_ZL_q=C_qJ_Z,\qquad L_q|_{\ker J_Z}=1,
 \qquad L_q\Theta=\Theta.
\]
The identity $J_ZS=1$ shows by expansion that
\[
 L_pL_q=1+S(C_pC_q-1)J_Z=L_{pq},\qquad
 L_q^{-1}=1+S(C_q^{-1}-1)J_Z.
\]
These are exact inverses on the full original function space, not just on the observed packet.

Keep the original four-point upper-set space
\[
 +<\eta<\sigma,\qquad -<\eta<\sigma,
\]
with coefficient sheaf $\mathcal T_+=\mathcal T_-=V$, $\mathcal T_\eta=\mathscr B$, $\mathcal T_\sigma=0$, and restriction maps $\Theta$ and $\mathcal J\Theta$. Define a sheaf automorphism to be the identity at $+$ and $-$, $L_q$ at $\eta$, and the unique map on the zero vector space at $\sigma$. This is a sheaf morphism because $L_q$ fixes both $\Theta V$ and $\mathcal J\Theta V=\Theta V$ pointwise. On derived global sections it is precisely
\[
 \begin{array}{ccc}
 V\oplus V&\xrightarrow{\Theta-\mathcal J\Theta}&\mathscr B\\
 \downarrow 1&&\downarrow L_q\\
 V\oplus V&\xrightarrow{\Theta-\mathcal J\Theta}&\mathscr B.
 \end{array}
\]
The signs and the original two source legs are unchanged.

Consequently $L_q$ descends to an automorphism $\bar L_q$ of the exact quotient $Q$. It induces the identity on degree-zero cohomology and satisfies
\[
 \bar J_Z\bar L_q=C_q\bar J_Z.
\]
Equip $Q$ here with the quotient topology of the original $\mathscr B$. Both $\bar L_q$ and its inverse are continuous by the quotient universal property. This does not assert that $Q$ is Hausdorff or that $\Theta V$ is closed.
It is natural for the retained inclusions of nonempty support masks when the same $S$ is used on their common $\mathscr B$ stalk. Indeed each $\mathcal T_A$ has its original active source legs, this same target, and the corresponding restrictions. The source identities and common $L_q$ commute with every such inclusion. The split reconstruction acts by
\[
 \tau\mapsto\tau,\qquad (A,F)\mapsto(A,L_qF).
\]
It fixes $(A,0)$ and keeps the label $A$. Thus neither synchronization of masks nor conversion of a supported zero into $\tau$ has occurred. At $\sigma$ the reconstructed support skeleton is fixed.

The action has concrete analytic bounds. In the Taylor coordinate basis $C_q$ is diagonal, so
\[
 p_{b,k}(L_qF)
 \le p_{b,k}(F)+\sum_{\rho\in Z}\sum_{j=0}^{m_\rho-1}
      |q^{-j}-1|\,p_{b,k}(F_{\rho,j})\,|(J_ZF)_{\rho,j}|.
\]
Combining this with the preceding observation estimate proves continuity in every original Fréchet seminorm. For $q\ge1$, all $|q^{-j}-1|\le1$, so the displayed family of bounds is uniform in $q\ge1$. For its inverse replace these factors by $|q^j-1|$; it grows at most with the explicitly retained maximum degree $\max_\rho(m_\rho-1)$. Nothing here bounds the original $U_a$ in terms of $a^{1/2}$: $L_q$ is the new finite-packet grading, and its inverse need not remain bounded as $q$ grows.

The construction is noncanonical in its chosen bump and section. If $S'$ is a second section and $K=S'-S$, then $J_ZK=0$ and
\[
 L'_q-L_q=K(C_q-1)J_Z.
\]
Its image is in $\ker J_Z$, it vanishes on $\ker J_Z$, and both choices induce the same $C_q$ on $A_Z$. This formula records the exact dependence instead of asserting a canonical global arithmetic action.

## 8. Compatibility with the original right-adjoint dual map

For the declared diagram category on the four-point space, the original calculation is
\[
 \mathsf A_\tau(F)=[F_+\oplus F_-\xrightarrow{r_+-r_-}F_\eta],
 \qquad
 K_\tau(W)=[I_\eta(W)\xrightarrow{(+\mathrm{res},-\mathrm{res})}
              I_+(W)\oplus I_-(W)]
\]
in degrees $0,1$ and $-1,0$ respectively. Here $I_x(W)(y)=W$ for $y\le x$ and zero otherwise. Evaluation gives $\operatorname{Hom}(F,I_x(W))=\operatorname{Hom}(F_x,W)$; applying this to the two displayed terms proves the right-adjoint identity with differential $\ell\mapsto(\ell r_+,-\ell r_-)$. Therefore
\[
 H^{-1}R\operatorname{Hom}(\mathcal T,K_\tau(\mathcal L_1))
   =\operatorname{Hom}_E(Q,\mathcal L_1),
\]
where the original moment line $\mathcal L_1$ has the original scaling action $a$. Its underlying vector space is $E$; no action of the new grading on it is being inferred from arithmetic purity.

The original finite-packet morphism is the linear map from the conjugate vector space
\[
 \iota_Z:\overline{A_Z}\longrightarrow\operatorname{Hom}_E(Q,\mathcal L_1),
 \qquad
 \iota_Z(\bar f)([F])=R_Z(f,J_ZF).
\]
It is well-defined because $J_Z\Theta=0$, and injective by the just-proved surjectivity of $J_Z$ and perfection of $R_Z$. Precomposition with $\bar L_q$ has the exact effect
\[
 \begin{aligned}
 (\bar L_q^*\iota_Z(\bar f))([F])
 &=R_Z(f,J_ZL_qF)\\
 &=R_Z(f,C_qJ_ZF)\\
 &=R_Z(D_qf,J_ZF).
 \end{aligned}
\]
Thus the diagram into the **same** computed right-adjoint object satisfies
\[
 \boxed{\bar L_q^*\iota_Z(\bar f)=\iota_Z(\overline{D_qf}),
 \qquad D_q=M_{\kappa_q}C_q^{-1}.}
\]
Every arrow is now calculated on the original theta source and the full actual arithmetic jets. This is not merely a pairing on an unrelated finite algebra. All dual support arrows remain precomposition, and the zero functional at a present mask remains its supported zero functional.

## 9. Exact scope of the completed comparison

The new automorphism $C_q$ retains the actual zero $\rho$, its complete local algebra, and its unit. It provides the conjugacy $N\mapsto q^{-1}N$. Its continuous lift $L_q$ acts on the original theta sheaf and fixes the original relation space $\Theta V$ pointwise; its finite-packet effect and dual effect are the explicit diagrams above. These are completed maps with full proofs and analytic seminorm control.

The actual arithmetic scaling remains $U_a=a^\rho e^{(\log a)N}$. It commutes with $N$ and has the exact semidirect relation with $C_q$. The grading eigenvalues are $q^{-j}$ on the original Taylor coordinates. They do not contain a bound on $\Re\rho$. On simple packets $C_q$ is the identity for every $q$, while $U_a$ still has eigenvalue $a^\rho$.

More generally, multiplying $C_q$ on a component by any nonzero scalar $c$ leaves its conjugacy with $N$ unchanged and changes all its eigenvalues to $cq^{-j}$. The residue formula and its full unit, not that conjugacy alone, state the actual additional information carried by our chosen $C_q$. Consequently this completed comparison supplies neither a canonical arithmetic Frobenius nor an absolute arithmetic weight estimate. The original tensor-growth calculation over $\mathsf A_\tau$ remains the original problem; the new maps give a precise continuation instead of a false literal identification or an unsupported claim of irrelevance.

## Provenance

Primary source: `output/split_zero_rh_tandem_2026-09-12/sources/Tau_Base_Cohomology_2026-09-12/NOTE.md`, SHA-256 `d03e71ad18f187bd89880cb8ca6fc9c5d6f260b3de8e8e5702c27db97e7b63c3`. Canonical route: `work/f1_geometry_current_source_route_20260913.md`, SHA-256 `a8cdd18817a2c3596778c60a04ef9d76125a03ae5404759835a2bc2b18fa4c74`. Exact transcript node and its scope are recorded at the beginning. The independent algebra review is retained in `GERM_PAIRING_CHECK.md`. No Lean run, remote publication or shared-master edit is claimed.
