# Finished calculations on the retained physical and arithmetic formulas

These calculations use the objects and constants displayed in A0656 and A0706. They close bounded algebraic omissions. They do not identify the modular surface, the physical wedge, or the fluid/gravity expansion with the later split-base cohomology by assumption. The source coordinates below are LF coordinates in the pinned transcript segment.

## 1. The modular scattering coefficient retains every zero multiplicity

A0656, lines 2964–3096, displays

\[
\mathsf S(k)=\pi^{-2ik}
\frac{\Gamma(\frac12+ik)}{\Gamma(\frac12-ik)}
\frac{\zeta(1+2ik)}{\zeta(1-2ik)},
\qquad E_* = \frac{\hbar^2}{2mR^2}>0,
\qquad \mathcal E(k)=E_*(k^2+\tfrac14).
\]

Take any nontrivial zeta zero in the specified lower half-plane, with its actual multiplicity:

\[
\rho=a-i\gamma,\qquad 0<a<1,\quad\gamma>0,
\qquad q=\operatorname{ord}_{s=\rho}\zeta(s)\ge1.
\]

Solving the denominator equation exactly gives

\[
k_\rho=\frac\gamma2-\frac{i(1-a)}2,
\quad 1-2ik_\rho=\rho,
\quad 1+2ik_\rho=2-\rho,
\quad \tfrac12-ik_\rho=\tfrac\rho2,
\quad \tfrac12+ik_\rho=1-\tfrac\rho2.
\]

Both Gamma arguments have positive real part. Gamma is finite and nonzero there. Also \(\Re(2-\rho)=2-a>1\), where the absolutely convergent Euler product is nonzero. Consequently the analytic numerator

\[
N(k)=\pi^{-2ik}
\frac{\Gamma(\frac12+ik)}{\Gamma(\frac12-ik)}\zeta(1+2ik)
\]

is nonzero at \(k_\rho\). Taylor expansion at the actual zero gives

\[
\zeta(1-2ik)
=\frac{\zeta^{(q)}(\rho)}{q!}(-2i)^q(k-k_\rho)^q
+O((k-k_\rho)^{q+1}).
\]

Thus the pole order is exactly \(q\), and its leading Laurent coefficient is exactly

\[
a_{-q}=
\frac{q!N(k_\rho)}{(-2i)^q\zeta^{(q)}(\rho)}\ne0.
\]

The map to energy has derivative \(2E_*k_\rho\ne0\), so it is locally invertible at this pole. The energy-plane pole has the same order and leading coefficient

\[
b_{-q}=a_{-q}(2E_*k_\rho)^q.
\]

Direct squaring, without removing either real correction, gives

\[
\mathcal E_\rho
=E_*\left[\frac{\gamma^2}{4}-\frac{(1-a)^2}{4}+\frac14\right]
-i\frac{E_*\gamma(1-a)}2.
\]

Let \(\sum_{j=1}^{q}b_{-j}(\mathcal E-\mathcal E_\rho)^{-j}\) be the complete principal part. The positively oriented local contour contribution with the explicitly specified convention \((2\pi i)^{-1}\oint e^{-i\mathcal Et/\hbar}\mathsf S(k(\mathcal E))\,d\mathcal E\) equals

\[
e^{-i\mathcal E_\rho t/\hbar}
\sum_{j=1}^{q}\frac{b_{-j}}{(j-1)!}
\left(-\frac{it}{\hbar}\right)^{j-1}.
\]

Indeed, expand the exponential in powers of \(\mathcal E-\mathcal E_\rho\); its coefficient of power \(j-1\) is the displayed factor, which is exactly the residue paired with the order-\(j\) pole. A lower-half-plane contour used in a global inverse transform may carry a different overall orientation; the convention above fixes this sign and makes no unproved contour deformation. Every multiple zero contributes the complete polynomial of degree \(q-1\), with nonzero top coefficient, multiplying the decaying exponential. Its exponential amplitude factor is

\[
\exp\!\left[-\frac{E_*\gamma(1-a)t}{2\hbar}\right].
\]

The source's simple-pole width \(\Gamma_\rho=E_*\gamma(1-a)\) is therefore retained, and the previously undisplayed multiplicities are now explicit. This calculation concerns the principal part of the continued scattering coefficient. It does not assert a complete time-domain expansion for every wavepacket, or convert poles of a continued coefficient into nonreal eigenvalues of a self-adjoint Hamiltonian. Those claims require a specified inversion contour, packet class, and bounds on the remaining integral.

## 2. Channel redistribution is exact and need not be positive

A0656, lines 3104–3137, uses a Hilbert space \(\mathcal H\), a unitary \(U:\mathcal H\to\mathcal H\), and an orthogonal projection \(P=P^*=P^2\). For every \(\psi\in\mathcal H\),

\[
\langle\psi,(U^*PU-P)\psi\rangle
=\langle U\psi,PU\psi\rangle-\langle\psi,P\psi\rangle
=\|PU\psi\|^2-\|P\psi\|^2.
\]

Moreover,

\[
\tfrac12U^*[2P-I,U]
=\tfrac12U^*((2P-I)U-U(2P-I))
=U^*PU-P.
\]

No domain issue occurs: both operators are bounded. Unitarity does not imply positivity of this operator. In \(\mathbb C^2\) with its usual inner product, take

\[
P=\begin{pmatrix}1&0\\0&0\end{pmatrix},
\qquad U=\begin{pmatrix}0&1\\1&0\end{pmatrix}.
\]

Then

\[
U^*PU-P=\begin{pmatrix}-1&0\\0&1\end{pmatrix}.
\]

The two coordinate unit vectors have expectations \(-1\) and \(+1\). This retains the precise useful interpretation of a change in the selected observable. Any use of this identity to prove an arithmetic positivity statement still requires the actual arithmetic subspace and pairing; the identity by itself supplies no such sign.

## 3. Equal marginal histories leave a phase family even after cross-energy measurement

A0706, lines 3835–3901, displays a thermofield vector and the partial-trace map. Work on the exact countable energy eigenbasis appearing there. Put

\[
p_n=\frac{e^{-\beta E_n}}{Z(\beta)},\qquad
\rho_\beta=\sum_n p_n|n\rangle\langle n|,
\qquad \sum_n p_n=1.
\]

For every real phase sequence \(\theta=(\theta_n)\), the norm-convergent vector

\[
|\Psi_\theta\rangle=\sum_n\sqrt{p_n}e^{i\theta_n}|n\rangle_L|n\rangle_R
\]

has norm one because its summands are mutually orthogonal. In the partial trace of \(|\Psi_\theta\rangle\langle\Psi_\theta|\), the right basis inner product is \(\langle m|n\rangle=\delta_{mn}\); hence both marginal density operators are exactly \(\rho_\beta\). The product density \(\rho_\beta\otimes\rho_\beta\) has the same marginals. This proves the source's many-to-one statement.

When \(\sum_n p_nE_n^2<\infty\), diagonal summation gives

\[
\langle H_LH_R\rangle_{\Psi_\theta}=\sum_n p_nE_n^2,
\qquad
\langle\delta H_L\delta H_R\rangle_{\Psi_\theta}
=\sum_n p_nE_n^2-\left(\sum_n p_nE_n\right)^2.
\]

This value is independent of all phases. It is zero in the product state after centering because the expectation factors. Thus the particular cross-energy observable in A0706 distinguishes the displayed product state from a nonzero-variance thermofield vector, but it does not recover the phase pattern inside the entire pure-state family.

An explicit bounded cross observable that does retain this missing phase is

\[
O_{mn}=(|m\rangle\langle n|)_L\otimes(|m\rangle\langle n|)_R,
\qquad m\ne n.
\]

Direct action on the series gives

\[
\langle\Psi_\theta|O_{mn}|\Psi_\theta\rangle
=\sqrt{p_mp_n}\,e^{i(\theta_n-\theta_m)}.
\]

Its Hermitian real and imaginary parts measure respectively the cosine and sine of this relative phase, with the exact factor \(\sqrt{p_mp_n}\). This is a concrete continuation beyond the source's single cross-energy observable.

For completeness, partial trace after arbitrary local unitary driving obeys

\[
\operatorname{Tr}_R[(U_L\otimes U_R)\rho(U_L^*\otimes U_R^*)]
=U_L(\operatorname{Tr}_R\rho)U_L^*.
\]

To prove it, pair both sides with any bounded \(A_L\); cyclicity of the trace replaces \((A_L\otimes I)\) by \((U_L^*A_LU_L\otimes I)\), and the defining property of partial trace gives equality of all such expectations. The same argument applies on the right. Therefore equal initial marginals give equal histories for the same specified local unitary drives. This is an obstruction to reconstructing the joint state from those histories alone. It does not obstruct a reconstruction that includes the displayed cross observables, a joint evolution law, or an independently specified joint state.

## 4. The arithmetic occupation map, modular clock, and trace-class boundary

A0706, lines 3903–3980, gives the BC Hamiltonian

\[
\mathsf H|n\rangle=E_*\log n\,|n\rangle,
\qquad E_*>0.
\]

Let \(\mathfrak P\) denote the primes. The bosonic Fock occupation basis over \(\ell^2(\mathfrak P)\) is indexed by sequences \(m=(m_p)_{p\in\mathfrak P}\) of nonnegative integers of finite total sum. Such a sequence has finite support. Unique factorization is a bijection

\[
n\longleftrightarrow(v_p(n))_{p\in\mathfrak P},
\qquad (m_p)_p\longmapsto\prod_pp^{m_p}.
\]

Sending one orthonormal basis to the other gives a surjective isometry \(\mathcal U\), hence a unitary. On its full diagonal-operator domain,

\[
\mathcal U\mathsf H\mathcal U^*=\sum_pE_*\log p\,N_p.
\]

The equality of domains is explicit: a Fock coefficient sequence \(c_m\) belongs to this domain exactly when

\[
\sum_m\left(\sum_pE_*m_p\log p\right)^2|c_m|^2<\infty,
\]

which is the image of \(\sum_n(E_*\log n)^2|c_n|^2<\infty\). Thus this is an operator equality, including its domain, rather than a formal equality of symbols.

Write \(\sigma=\beta E_*\). The positive trace is

\[
\operatorname{Tr}(e^{-\beta\mathsf H})=\sum_{n\ge1}n^{-\sigma}.
\]

It is finite exactly when \(\sigma>1\), by comparison with \(\int_1^\infty x^{-\sigma}dx\); for \(\sigma\le0\) the terms do not even tend to zero. For any finite prime set \(F\), summing the independent geometric occupation series gives

\[
\sum_{\operatorname{supp}(m)\subset F}\prod_{p\in F}p^{-\sigma m_p}
=\prod_{p\in F}(1-p^{-\sigma})^{-1}\quad(\sigma>0).
\]

Increasing \(F\) through all primes and using nonnegative monotone sums recovers \(\sum_n n^{-\sigma}\). Hence the full Gibbs density and doubled vector exist in the displayed Hilbert-space representation exactly for \(\beta E_*>1\). In that range,

\[
|\mathrm{TFD}_\beta\rangle
=\zeta(\beta E_*)^{-1/2}\sum_{n\ge1}n^{-\beta E_*/2}|n\rangle_L|n\rangle_R,
\]

and its prime factors are exactly those displayed in A0706. Every energy moment used in the preceding calculation is finite because \(\sum_n n^{-\sigma}(\log n)^j<\infty\) for every fixed nonnegative integer \(j\) and \(\sigma>1\), as follows from the same integral comparison after \(x=e^y\).

The frequency dictionary is \(\omega_p=E_*\log p/\hbar\). Substitution into the source's thermal-coefficient match gives

\[
\beta E_*\log p=\frac{2\pi c\omega_p}{a}
\quad\Longleftrightarrow\quad
\beta=\frac{2\pi c}{\hbar a}.
\]

No prime-dependent choice remains. Combining this equality with the actual trace-class domain yields the precise domain of this global vector correspondence:

\[
0<a<\frac{2\pi cE_*}{\hbar}.
\]

At the upper endpoint, \(\beta E_*=1\), the vector normalization diverges through the harmonic series, although every individual prime's geometric factor is finite. This is an omitted global boundary in the retained response. It is a limitation of this trace-class arithmetic representation, not a theorem that an arbitrary Rindler observer lacks a KMS state.

The modular sign and proper clock also agree exactly with the source convention. On the thermofield representation the modular operator for the left algebra is

\[
\Delta=\rho_\beta\otimes\rho_\beta^{-1}.
\]

For a bounded left observable, the convention used in A0706 gives

\[
\Delta^{-is}(A\otimes I)\Delta^{is}
=(e^{i\beta s\mathsf H}Ae^{-i\beta s\mathsf H})\otimes I.
\]

The scalar partition factors cancel. Physical Heisenberg time is \(\alpha_t(A)=e^{it\mathsf H/\hbar}Ae^{-it\mathsf H/\hbar}\), so \(t=\beta\hbar s=2\pi cs/a\), exactly the source relation \(s=a\tau/(2\pi c)\). This proves a thermal representation and clock correspondence. It does not construct a spatial observable net, a relativistic stress tensor, or a cooling generator.

## 5. The force pullback has a real terminal-control issue

A0706, lines 3660–3697, constructs a one-form through the actual preterminal fluid flow:

\[
A_t=-(\Phi_t^{-1})^*\int_0^t\Phi_s^*f_s\,ds,
\qquad h_{00}=-2v^jA_j.
\]

Pulling back by \(\Phi_t\), differentiating, and using the chain rule for a transported one-form gives

\[
\Phi_t^*[(\partial_t+\mathcal L_v)A_t]=-\Phi_t^*f_t,
\quad
\partial_tA_i+v^j\partial_jA_i+A_j\partial_iv^j=-f_i.
\]

Therefore the boundary-force expression is exactly

\[
\tfrac12\partial_i h_{00}-\partial_tA_i
+v^j(\partial_iA_j-\partial_jA_i)
=-\partial_tA_i-v^j\partial_jA_i-A_j\partial_iv^j=f_i.
\]

In Lagrangian coordinates the full derivative factor is

\[
A_t(\Phi_t(x))
=-D\Phi_t(x)^{-T}
\int_0^tD\Phi_s(x)^Tf_s(\Phi_s(x))\,ds.
\]

This identifies exactly what must be computed on the source's actual flow, rather than silently inferring terminal regularity from \(f\).

The general implication from terminal-flat forcing to smooth coefficients is false even among smooth preterminal forced incompressible NS solutions. The following explicit comparison tests that implication without replacing the source's finite-energy field. Retain arbitrary viscosity \(\nu>0\), source time \(0\le t<1\), and put

\[
u=1-t,\qquad g(t)=e^{-1/u^2},
\quad v(t,x)=\left(-\frac{x_1}{u},\frac{x_2}{u},0\right),
\quad p(t,x)=g(t)x_1-\frac{x_2^2}{u^2},
\quad f=g(t)\,dx^1.
\]

The force extends smoothly by zero to \(t=1\), with all terminal time derivatives zero: every derivative is a polynomial in \(u^{-1}\) times \(e^{-1/u^2}\), which tends to zero. The velocity has divergence \(-1/u+1/u=0\) and zero Laplacian. Its first material-acceleration component is zero and its second is \(2x_2/u^2\); adding \(\nabla p=(g(t),-2x_2/u^2,0)\) gives exactly \(f\). Thus

\[
\partial_tv+v\cdot\nabla v-\nu\Delta v+\nabla p=(g(t),0,0)
\]

for every retained \(\nu>0\).

The flow and pulled-back force are

\[
\Phi_t(x)=(ux_1,u^{-1}x_2,x_3),
\qquad \Phi_s^*f_s=(1-s)g(s)\,dx^1.
\]

Writing \(I(t)=\int_0^t(1-s)g(s)\,ds\), the prescribed construction yields

\[
A_t=-\frac{I(t)}u\,dx^1,
\qquad h_{00}=-\frac{2I(t)x_1}{u^2}.
\]

Here \(I(t)\) tends to the strictly positive finite number \(\int_0^1(1-s)e^{-1/(1-s)^2}ds\), so these coefficients do not extend smoothly to the endpoint. This example is not compactly supported and does not have finite total kinetic energy; it therefore does not settle the actual NS manuscript's terminal behavior. It proves exactly that the displayed preterminal force-map identity alone cannot make that inference. The strongest continuation remains evaluating its full flow derivatives and the gravitational corrections on the actual retained NS profile.
