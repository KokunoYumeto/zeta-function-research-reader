# Exact density and completion audit of the periodized arithmetic source

Date: 2026-09-13. Scope: independent written audit of the actual Mellin amplitude, its removable values and exponential tail, the pointwise convolution density, and NOTE.tex (P26a), (P53)–(P58). This file records proofs, not a numerical or proof-assistant certificate. No tests, Lean, network request, or source modification was performed for this audit.

The complete `NOTE.tex`, `RESEARCH_NOTE.md`, and `SOURCE_REVIEW.md` were read. Their SHA-256 values are, respectively:

- `acf63a56d5f50cfaa23f57ee52a66df261ec241ce13fd81ccac39a3bbbddd3ff`;
- `f903ae8473efdfcde0f45a83878837289d2b0604c1a34903276d7c840fe972b9`;
- `924203d94169fe310937b215b3adcc280b1d1f2a7aaa8fa15176cf20798cd624`.

All three are under `output/split_zero_rh_tandem_2026-09-12/sources/web_periodized_source_delivery/Tau_Periodized_Source_Control/` in the shared math workspace.

The conclusions (P54)–(P58) are correct. The source should explicitly define `v_h` and `w_h` when incorporating them into a standalone reader: the note presently uses these inherited symbols without a displayed definition. The following proofs supply those definitions and the suppressed analytic details. They also give the exact isometry from the original Hilbert-valued circle source to the scalar weighted sequence presentation. The discussion of its comparison with the critical Schwartz quotient is being developed separately; no identification of those quotients is used below.

## 1. The unchanged theta amplitude and its canceled zeros

Use the original Mellin transform

\[
\mathcal MF(s)=\int_0^\infty F(x)x^{s-1}\,dx,
\qquad D=-x\partial_x,
\qquad g(s)=2\xi(s)=s(s-1)\pi^{-s/2}\Gamma(s/2)\zeta(s).
\tag{PSD1}
\]

The source is the supplied strong-Schwartz function satisfying

\[
v_h(s):=\mathcal MF_h(s)=\frac{g(s)}{h(s)},
\qquad h(D)F_h=\Theta\phi_*,
\quad \phi_*(x)=(4\pi^2x^4-6\pi x^2)e^{-\pi x^2}.
\tag{PSD2}
\]

Here the quotient is its entire extension, retaining the given polynomial `h`. Every chosen root occurs in `h` with its full multiplicity in `g`; no location assumption is imposed on those roots. Writing a possible leading coefficient explicitly, let

\[
h(s)=a_h\prod_{\rho\in Z_h}(s-\rho)^{m_\rho},
\qquad a_h\ne0,\qquad d=\sum_\rho m_\rho.
\tag{PSD3}
\]

For the original monic packet, `a_h=1`; retaining it in these formulas shows where that convention enters.

The theta factor is exact. For `Re(s)>1`, absolute convergence gives

\[
\begin{aligned}
\mathcal M\phi_*(s)
&=\pi^{-s/2}\bigl(2\Gamma(s/2+2)-3\Gamma(s/2+1)\bigr)\\
&=\frac{s(s-1)}2\pi^{-s/2}\Gamma(s/2),\\
\mathcal M(\Theta\phi_*)(s)
&=2\zeta(s)\mathcal M\phi_*(s)=g(s).
\end{aligned}
\tag{PSD4}
\]

The factor two in `Theta` and the factor one-half in the Mellin transform of `phi_*` remain visible. Logarithmic integration by parts gives `M(DF)=s MF` for the given strong-Schwartz source; the boundary terms vanish at both ends. Thus (PSD2) has the same Mellin transform as its original theta right-hand side. The conditions `phi_*(0)=0` and `integral_R phi_*=2 M phi_*(1)=0` also retain the two source moments.

At a selected zero `rho` of order `m`, put

\[
g(s)=(s-\rho)^m a(s),\qquad h(s)=(s-\rho)^m b(s),
\qquad a(\rho)b(\rho)\ne0.
\]

The canceled value is therefore

\[
v_h(\rho)=\frac{a(\rho)}{b(\rho)}
=\frac{g^{(m)}(\rho)}{h^{(m)}(\rho)}\ne0.
\tag{PSD5}
\]

This value applies when a selected critical zero lies exactly on a sampled Fourier frequency. It must not be evaluated as an uncanceled `0/0` or assigned zero. The entire jet is fixed as well: with

\[
a_r=\frac{g^{(m+r)}(\rho)}{(m+r)!},\quad
b_r=\frac{h^{(m+r)}(\rho)}{(m+r)!},\quad
v_h(\rho+z)=\sum_{j\ge0}c_jz^j,
\]

one has

\[
c_0=a_0/b_0,\qquad
c_j=\frac{a_j-\sum_{r=1}^j b_r c_{j-r}}{b_0}\quad(j\ge1).
\tag{PSD6}
\]

The arithmetic density used throughout the periodized note is exactly

\[
w_h(t)=\frac1{2\pi}\left|v_h(1/2+it)\right|^2,
\qquad m_{h,k}=\underbrace{w_h*\cdots*w_h}_{k\ \mathrm{factors}}.
\tag{PSD7}
\]

Because `v_h` is entire and not identically zero, its zeros on the vertical line form a discrete subset of the real parameter `t`. Consequently `w_h` is continuous, nonnegative, and strictly positive outside that discrete subset. Formula (PSD5) determines the values at every canceled critical root. No zero-location theorem is used.

## 2. A proved exponential tail, with the original constants

An elementary contour estimate supplies the needed gamma decay without substituting a numerical approximation. If `a>0`, `y` is real, and `0<theta<pi/2`, rotating the gamma-integral ray by `sign(y) theta` gives

\[
|\Gamma(a+iy)|
\le \Gamma(a)(\cos\theta)^{-a}e^{-\theta|y|}.
\tag{PSD8}
\]

For completeness, take the branch of `z^{a+iy-1}` in the sector between the positive ray and that rotated ray. Integrate `z^{a+iy-1}e^{-z}` around its boundary between radii `epsilon` and `R`. For each fixed `y`, the small arc is bounded by a constant times `epsilon^a` and tends to zero. On the large arc `Re(z)>=R cos(theta)>0`, so exponential decay dominates the power of `R`. The two ray integrals agree in the limit. Parametrizing the rotated ray by `z=e^{i sign(y) theta}r` contributes the exact factor `e^{i sign(y) theta(a+iy)}`, whose modulus is `e^{-theta|y|}`. Taking the modulus inside the remaining integral gives `integral_0^infinity r^{a-1}e^{-r cos(theta)}dr=Gamma(a)(cos(theta))^{-a}`. At `y=0` the same bound follows from either ray.

On the original critical line, an elementary bound for zeta follows from the alternating Dirichlet series. For `Re(s)>0`, its partial summation formula is

\[
\eta(s)=s\int_1^\infty A(x)x^{-s-1}\,dx,
\quad A(x)=\sum_{1\le n\le x}(-1)^{n-1}\in\{0,1\}.
\]

The integral converges locally uniformly there and agrees with the alternating series; the finite partial-summation boundary has modulus at most `N^{-Re(s)}` and tends to zero. For `s=1/2+it`,

\[
|\eta(s)|\le2|s|,
\quad |1-2^{1-s}|\ge\sqrt2-1,
\quad |\zeta(s)|\le\frac{2|s|}{\sqrt2-1}.
\tag{PSD9}
\]

The identity `eta(s)=(1-2^{1-s})zeta(s)` first follows by absolutely convergent rearrangement for `Re(s)>1`, then by analytic continuation. Its denominator on the line has the displayed strictly positive lower bound.

Apply (PSD8) with `a=1/4`, `y=t/2`, and retain `|pi^{-s/2}|^2=pi^{-1/2}`. For every real `t` with `h(1/2+it) != 0`, (PSD1), (PSD7), and (PSD9) give

\[
w_h(t)\le
\frac{2\Gamma(1/4)^2}
{\pi^{3/2}(\sqrt2-1)^2\sqrt{\cos\theta}}
\frac{(t^2+1/4)^3}{|h(1/2+it)|^2}
e^{-\theta|t|}.
\tag{PSD10}
\]

The power `(t^2+1/4)^3` comes from `|s(s-1)|^2|s|^2`; no asymptotic equality is asserted. Let

\[
R=\max\left(\{1\}\cup\{2|\rho-1/2|:\rho\in Z_h\}\right).
\]

This definition also gives \(R=1\) for the retained analytic seed \(h=1\), whose selected-root set is empty; all product and tail formulas then use \(d=0\) and \(a_h=1\).

For `|t|>=R`, each factor satisfies

\[
|1/2+it-\rho|\ge |t|-|\rho-1/2|\ge |t|/2,
\qquad |h(1/2+it)|\ge |a_h|(|t|/2)^d.
\]

Thus, with the exact constant in front of the fraction in (PSD10) denoted by `C_theta`,

\[
w_h(t)\le
C_\theta\frac{4^d}{|a_h|^2}
\frac{(t^2+1/4)^3}{|t|^{2d}}e^{-\theta|t|}
\qquad(|t|\ge R).
\tag{PSD11}
\]

On the compact interval `[-R,R]`, the entire canceled quotient in (PSD2) is continuous, so `B_R=max_{|t|<=R} w_h(t)<infinity`. For any `0<b<pi/2`, choose `b<theta<pi/2`. The compact bound together with (PSD11) proves

\[
A_b:=\|e^{b|\cdot|}w_h\|_\infty<\infty,
\qquad B_b:=\|e^{b|\cdot|}w_h\|_1<\infty.
\tag{PSD12}
\]

For example, source-dependent upper bounds are the maximum of `e^{bR}B_R` and the supremum of the right side of (PSD11) multiplied by `e^{b|t|}` on the two tails, and

\[
B_b\le 2Re^{bR}B_R+
2C_\theta\frac{4^d}{|a_h|^2}
\int_R^\infty\frac{(T^2+1/4)^3}{T^{2d}}
e^{-(\theta-b)T}\,dT.
\tag{PSD13}
\]

The remaining integral is finite because `theta-b>0`. These are analytical constants of the original source; this audit has not computed their values or interval enclosures.

## 3. Pointwise convolution, strict positivity, and the full scalar-circle map

Convolution is taken with ordinary Lebesgue measure, with the factors `1/(2pi)` already contained in every `w_h`. The triangle inequality for `u=t_1+...+t_k` gives pointwise

\[
e^{b|u|}m_{h,k}(u)
\le(e^{b|\cdot|}w_h)^{*k}(u)
\le A_bB_b^{k-1}.
\tag{PSD14}
\]

For two factors this follows directly by bounding one factor by `A_b` and integrating the other. Induction gives the displayed expression for every `k`. The integrals are absolutely convergent for every `u`. The same bounds and continuity under translation give a continuous representative of the convolution. For instance, `w_h` is bounded, continuous, and tends to zero at infinity by (PSD11), hence uniformly continuous; dominated convergence against the integrable other factor proves continuity at every `u`.

For `k=2` and fixed `u`, the sets where `w_h(t)=0` or `w_h(u-t)=0` are discrete. There is a `t_0` outside their union. The continuous nonnegative integrand is strictly positive on a neighborhood of `t_0`, and therefore

\[
(w_h*w_h)(u)>0\quad\hbox{for every real }u.
\tag{PSD15}
\]

For the induction step, a continuous everywhere-positive convolution is integrated against `w_h`, which is positive on some open interval. The resulting convolution is strictly positive at every `u`. Consequently all (P53) weights are strictly positive for `k>=2`, including `n=0`.

Retain the original diagonal coordinate isometry `U_k`, the space `K`, and the plus-sign Fourier transform from (P11)–(P14). Put

\[
\psi_0=\mathcal U_kF_h^{\otimes k},\quad
u_n=2\pi n/L,\quad S_n=k/2+iu_n,\quad
b_n=\widehat\psi_0(u_n)\in\mathcal K.
\]

In the simultaneous Fourier variables for `(r,z_1,...,z_{k-1})`, the amplitude is exactly

\[
\prod_{j<k}v_h(1/2+it_j)\;
v_h\left(1/2+i\left(u-\sum_{j<k}t_j\right)\right).
\]

For each fixed `u`, partial Plancherel in the retained `z` variables therefore gives

\[
\|\widehat\psi_0(u)\|_{\mathcal K}^2
=(2\pi)^{-(k-1)}\int_{\mathbb R^{k-1}}
\prod_{j<k}|v_h(1/2+it_j)|^2
\left|v_h\left(1/2+i\left(u-\sum_{j<k}t_j\right)\right)\right|^2d\mathbf t
=2\pi m_{h,k}(u).
\tag{PSD16}
\]

The equality holds pointwise, not just almost everywhere: the original transformed source is Schwartz in the Hilbert-valued variable, and both sides are continuous; alternatively the preceding absolutely convergent integral computes the partial transform at each `u`. Thus no choice of an almost-everywhere convolution version can alter a lattice sample.

Let `H_orig,cyc,L` denote the closure in the original `L^2(circle;K)` of the periodized polynomial source. Define the weighted scalar space

\[
H_\nu=\ell^2(\mathbb Z,\nu),\qquad
\nu_n=\frac{2\pi}{L}m_{h,k}(u_n)=\frac{\|b_n\|_{\mathcal K}^2}{L}.
\tag{PSD17}
\]

There is an exact isometry into the original Hilbert-valued circle space:

\[
I_L:H_\nu\longrightarrow L^2(\mathbb R/L\mathbb Z;\mathcal K),
\qquad \widehat{I_La}(n)=L^{-1/2}a_nb_n.
\tag{PSD18}
\]

The hats on the right are coefficients in the unchanged orthonormal basis `L^{-1/2}exp(-2pi i nr/L)`. Parseval gives `||I_La||^2=sum_n nu_n|a_n|^2`. For a polynomial `P`, (P13) and (P16) give

\[
I_L\bigl((P(S_n))_n\bigr)
=\mathcal P_L\mathcal U_k\mathcal V_{h,k}P.
\tag{PSD19}
\]

Polynomial density, proved next, identifies the range of (PSD18) with `H_orig,cyc,L`. Its inverse on that range is

\[
a_n=\sqrt L\,
\frac{\langle b_n,\widehat f(n)\rangle_{\mathcal K}}{\|b_n\|_{\mathcal K}^2},
\tag{PSD20}
\]

with the inner product conjugate-linear in its first variable. Every denominator is positive for `k>=2`. These maps retain the amplitude `b_n`, the actual source measure, and every Fourier constant.

## 4. Polynomial density with an explicit analytic strip and uniqueness

Fix `k>=2` and `L>0`. By (PSD14), for each `0<b<pi/2`,

\[
\nu_n\le\frac{2\pi}{L}A_bB_b^{k-1}e^{-b|u_n|}.
\tag{PSD21}
\]

For every fixed polynomial `Q` and `0<c<b`,

\[
\sum_{n\in\mathbb Z}e^{c|u_n|}|Q(S_n)|^2\nu_n<\infty.
\tag{PSD22}
\]

Indeed `|Q(k/2+iu)|^2` is bounded by a finite polynomial in `|u|`, and the remaining factor is `exp(-(b-c)|u_n|)` on a lattice with spacing `2pi/L`. All polynomial moments exist.

Here is the density proof for any positive submeasure `mu_n` on a subset `I` of this lattice satisfying a finite exponential moment `sum_I e^{c|u_n|}mu_n<infinity` for some `c>0`. Suppose `f in ell^2(I,mu)` is orthogonal to all polynomial sequences `P(S_n)`. For `0<a<c/2`, Cauchy–Schwarz gives

\[
\sum_{n\in I}|f_n|\mu_ne^{a|u_n|}
\le\left(\sum_{n\in I}|f_n|^2\mu_n\right)^{1/2}
\left(\sum_{n\in I}e^{2a|u_n|}\mu_n\right)^{1/2}<\infty.
\tag{PSD23}
\]

Consequently

\[
F(z)=\sum_{n\in I}\overline{f_n}\mu_ne^{izu_n}
\tag{PSD24}
\]

is holomorphic on `|Im(z)|<c/2`. On every smaller closed strip, the series and all its derivative series converge normally: choose a further positive margin inside `c/2`, and absorb each fixed power of `|u_n|` into the exponential margin in (PSD23). The half-width is justified by the square in Cauchy–Schwarz; no full-width extension is needed.

For every `j>=0`, the exact polynomial `P_j(S)=((S-k/2)/i)^j` evaluates to `u_n^j`, so orthogonality gives

\[
F^{(j)}(0)=i^j\sum_{n\in I}\overline{f_n}\mu_nu_n^j=0.
\tag{PSD25}
\]

The Taylor expansion and the identity theorem on the connected strip imply `F=0` there. Uniqueness can be proved directly with the actual lattice, rather than invoked abstractly: extend the coefficients by zero outside `I`. Since (PSD23) gives absolute summability, termwise integration is valid and

\[
\frac1L\int_0^L F(x)e^{-iu_mx}\,dx
=\sum_{n\in I}\overline{f_n}\mu_n\,
\frac1L\int_0^L e^{2\pi i(n-m)x/L}\,dx
=\begin{cases}\overline{f_m}\mu_m,&m\in I,\\0,&m\notin I.\end{cases}
\tag{PSD26}
\]

The left side is zero. Positivity of each `mu_m` on `I` implies `f_m=0`. The orthogonal complement of the polynomials is zero, proving their density.

Apply this first to `mu=nu` and `I=Z`. It proves the assertion used in (PSD19). Apply it again to

\[
I=\{n:\chi(S_n)\ne0\},\qquad
\mu_n=|\chi(S_n)|^2\nu_n.
\tag{PSD27}
\]

The exponential moment follows from (PSD22) with `Q=chi`. Zero atoms are removed rather than divided by. This establishes exactly the weighted density needed for (P56).

## 5. The exact closed relation space, quotient metric, and kernel

Let `chi` be the original nonconstant packet-sum polynomial of degree `q`, and set

\[
\mathcal Z_L=\{n\in\mathbb Z:\chi(S_n)=0\},\qquad
p_L(S)=\prod_{n\in\mathcal Z_L}(S-S_n).
\tag{PSD28}
\]

The set is finite because `chi` is a nonzero polynomial and the `S_n` are distinct. The empty product is one. These are exact sampled roots; no tolerance rule is introduced.

Every `chi P` vanishes on `Z_L`. Coordinate evaluation is continuous on `H_nu`, since `|f_n|<=nu_n^{-1/2}||f||_nu`. Therefore the closure of `chi C[S]` is contained in the closed subspace

\[
V_L=\{f\in H_\nu:f_n=0\ (n\in\mathcal Z_L)\}.
\]

Conversely take `f in V_L` and define `g_n=f_n/chi(S_n)` on its complement `I`. Then

\[
\sum_{n\in I}|g_n|^2|\chi(S_n)|^2\nu_n
=\sum_{n\in I}|f_n|^2\nu_n<\infty.
\]

By (PSD27), polynomials `P_j` approximate `g` in that weighted space. Multiplication by `chi` gives

\[
\|\chi P_j-f\|_\nu^2
=\sum_{n\in I}|P_j(S_n)-g_n|^2|\chi(S_n)|^2\nu_n\longrightarrow0.
\tag{PSD29}
\]

Thus `closure(chi C[S])=V_L`. The orthogonal complement is the sequence space supported on `Z_L`, and the Hilbert quotient is isometric to that subspace by restriction. Its metric is exactly `sum_{n in Z_L}nu_n|v_n|^2`.

The resulting algebraic comparison is the surjection

\[
\theta_L:\mathbb C[S]/(\chi)\longrightarrow
H_\nu/\overline{\chi\mathbb C[S]}
\simeq\bigoplus_{n\in\mathcal Z_L}\mathbb C,
\qquad [P]\longmapsto(P(S_n))_{n\in\mathcal Z_L}.
\tag{PSD30}
\]

It is well-defined because `chi(S_n)=0`. Surjectivity follows from the explicit Lagrange polynomials

\[
\ell_n(S)=\prod_{m\in\mathcal Z_L,\ m\ne n}\frac{S-S_m}{S_n-S_m},
\qquad \ell_n(S_m)=\delta_{nm}.
\tag{PSD31}
\]

For an empty set the target is the zero vector space, and the map is the unique surjection onto it. Since the sampled roots are distinct, a polynomial vanishes on them if and only if it is divisible by `p_L`. Moreover `p_L` divides `chi`. Hence

\[
\ker\theta_L=(p_L)/(\chi),\qquad
\operatorname{rank}\theta_L=|\mathcal Z_L|,\qquad
\dim\ker\theta_L=q-|\mathcal Z_L|.
\tag{PSD32}
\]

These formulas include the empty set, when `(p_L)/(chi)=C[S]/(chi)`.

The generator intertwines exactly. With `A[P]=[SP]` on the original algebra and `A_L(v_n)=(S_nv_n)` on the finite target,

\[
\theta_LA=A_L\theta_L.
\tag{PSD33}
\]

The kernel is therefore an invariant submodule; it has not been removed before forming the comparison.

There is a precise cyclic presentation of this invariant kernel. Put `t_L=chi/p_L` and define

\[
\mu_{p_L}:\mathbb C[S]/(t_L)\longrightarrow E,
\qquad [Q]_{(t_L)}\longmapsto[p_LQ]_{(\chi)}.
\tag{PSD33a}
\]

This is well-defined because `p_L t_L=chi`. Its image is `(p_L)/(chi)`. If `p_LQ` is divisible by `chi=p_Lt_L`, polynomial cancellation gives divisibility of `Q` by `t_L`, so the map is injective. No coprimality between `p_L` and `t_L` is used. Consequently the entire comparison is the exact sequence

\[
0\longrightarrow\mathbb C[S]/(\chi/p_L)
\xrightarrow{\;\mu_{p_L}\;}\mathbb C[S]/(\chi)
\xrightarrow{\;\theta_L\;}\mathbb C^{\mathcal Z_L}
\longrightarrow0.
\tag{PSD33b}
\]

Multiplication commutes in the polynomial ring, hence `A mu_{p_L}=mu_{p_L} A_{t_L}`, with `A_{t_L}` the original multiplication by `S` on the source algebra. Together with (PSD33), this proves equivariance of both arrows.

The Fourier-side generator has the same typed action. Define

\[
T_La=(S_na_n)_n,\qquad
\mathcal D(T_L)=\left\{a\in H_\nu:\sum_n\nu_n|S_na_n|^2<\infty\right\}.
\tag{PSD33c}
\]

It is closed: convergence of `a` and `T_La` in `H_nu` implies convergence of each coordinate, giving the displayed pointwise relation in the limit and its square summability. The coordinate projection `Q_{Z_L}` commutes with `T_L` on this domain and has range in it, because its support is finite. On polynomials, `T_L(P(S_n))=((SP)(S_n))`; under (PSD18) it is exactly the circle operator `-partial_r+k/2`. It induces `A_L` on the quotient. Therefore the quadratic generator also intertwines exactly:

\[
\theta_L(A^2-kA)=(A_L^2-kA_L)\theta_L,
\qquad S_n(S_n-k)=-k^2/4-(2\pi n/L)^2.
\tag{PSD33d}
\]

## 6. Full repeated-root blocks and the canonical metric limit

Factor the actual polynomial as `chi(S)=a_chi product_lambda(S-lambda)^{m_lambda}`. The exact Chinese-remainder map is

\[
\mathbb C[S]/(\chi)\xrightarrow{\sim}
\bigoplus_\lambda\mathbb C[\epsilon_\lambda]/(\epsilon_\lambda^{m_\lambda}),
\qquad
[P]\longmapsto
\left(\sum_{j=0}^{m_\lambda-1}\frac{P^{(j)}(\lambda)}{j!}\epsilon_\lambda^j\right)_\lambda.
\tag{PSD34}
\]

Under this map, `A` acts on each summand by `lambda+epsilon_lambda`. At an unsampled root the whole summand lies in `ker(theta_L)`. At a sampled root `lambda=S_n`, the comparison takes the constant coefficient of this full Taylor class, and its kernel is exactly

\[
\epsilon_\lambda\mathbb C[\epsilon_\lambda]/(\epsilon_\lambda^{m_\lambda}).
\tag{PSD35}
\]

In particular every nonconstant generalized-jet direction is retained in the explicit kernel. The induced action on the remaining constant coefficient is multiplication by `lambda`; (PSD33) follows in these coordinates as well. This proves the full multiplicity statement rather than inferring it from a list of sampled eigenvalues.

The inverse in (PSD34) is explicit. Set `H_lambda(S)=chi(S)/(S-lambda)^{m_lambda}`. Its value at `lambda` is nonzero. Let `V_lambda(epsilon)` be the Taylor polynomial of `1/H_lambda(lambda+epsilon)` through degree `m_lambda-1`, and put `e_lambda(S)=H_lambda(S)V_lambda(S-lambda)`. Modulo the `lambda` primary factor this polynomial equals one; modulo every other primary factor it equals zero. The inverse sends a tuple `F_lambda(epsilon)` to `[sum_lambda e_lambda(S)F_lambda(S-lambda)]_(chi)`. Both composites are the identity: their differences are divisible by every pairwise coprime primary factor, hence by their product, which differs from `chi` only by its original nonzero leading coefficient.

At a sampled root, write `p_L(lambda+epsilon)=epsilon u_lambda(epsilon)`, where `u_lambda(0)=product_{mu sampled, mu!=lambda}(lambda-mu) != 0`. Multiplication by `p_L` identifies the `t_L` block `C[epsilon]/(epsilon^{m_lambda-1})` with (PSD35) by multiplication by `epsilon u_lambda`. At an unsampled root, `p_L(lambda+epsilon)` is a unit and identifies the entire `t_L` block with the original full block. Thus the kernel generator has block length `m_lambda-1` at each sampled root and length `m_lambda` at each unsampled root, with the original eigenvalues retained.

Now retain the note's fixed remainder-coordinate basis on `E=C[S]/(chi)`, the degree-`N` polynomial source `P_N`, and the canonical constrained minimum `G_N(L)`. For every `N>=q-1`, its source Gram is positive definite: the summands have positive weights and a nonzero polynomial has only finitely many zeros, whereas this lattice is infinite. The finite-dimensional minimum therefore exists uniquely and is precisely

\[
e^*G_N(L)e=
\min\{\|P\|_\nu^2:P\in\mathcal P_N,\ [P]=e\}.
\tag{PSD36}
\]

Choose the unique degree-less-than-`q` remainder `R_e` of `e`. The permitted representatives are `R_e+chi P_{N-q}`, with the relation space understood to be zero when `N=q-1`. These relation spaces increase with `N`, so the forms `G_N(L)` decrease in Loewner order. Their union is `chi C[S]`; their closure is the space computed in (PSD29). For a closed-subspace distance, approximation in that closure proves

\[
\begin{aligned}
\lim_{N\to\infty}e^*G_N(L)e
&=\inf_{Q\in\mathbb C[S]}\|R_e+\chi Q\|_\nu^2\\
&=\operatorname{dist}(R_e,V_L)^2
=\sum_{n\in\mathcal Z_L}\nu_n|R_e(S_n)|^2.
\end{aligned}
\tag{PSD37}
\]

The equality with the infimum is exact: every polynomial `Q` appears at a finite degree, so the decreasing finite-degree infima converge to the infimum over the union; the norm is continuous, so replacing the union by its closure does not change that infimum.

Let `J_{Z_L}` be evaluation at the sampled roots in the same remainder basis. Equation (PSD37) gives the matrix limit

\[
G_N(L)\downarrow
G_\infty(L):=J_{\mathcal Z_L}^*
\operatorname{diag}(\nu_n)_{n\in\mathcal Z_L}J_{\mathcal Z_L}.
\tag{PSD38}
\]

Polarization of (PSD37) gives every matrix entry; finite dimension then gives convergence in matrix norm. Since all sampled weights are positive,

\[
\operatorname{rad}G_\infty(L)=\ker J_{\mathcal Z_L}
=(p_L)/(\chi).
\tag{PSD39}
\]

Thus a nonzero repeated-jet class in (PSD35) has positive norm for every finite `N`, while its minimum norm tends to zero as `N` tends to infinity at this fixed `L`. More explicitly, choose such a class `e` and its minimizing representatives \(P_{N,e}\). They retain the complete prescribed remainder, hence every original Taylor coefficient, and (PSD37) proves \(\|P_{N,e}\|_\nu\longrightarrow0\). Any Taylor functional that is nonzero on `e` is consequently unbounded for this completed polynomial norm. This supplies the actual relation between retained finite-degree generalized jets and their fixed-circle completion.

There is a strict finite-degree strengthening. For `e != 0`, let `P_{N,e}` be its nonzero minimizing polynomial in (PSD36). It has the prescribed values `R_e(S_n)` on `Z_L`. Hence

\[
e^*\bigl(G_N(L)-G_\infty(L)\bigr)e
=\sum_{n\notin\mathcal Z_L}\nu_n|P_{N,e}(S_n)|^2>0.
\tag{PSD40}
\]

The complement of the finite set `Z_L` is infinite, all its weights are positive, and a nonzero polynomial cannot vanish at every node there. Thus `G_N(L)-G_infinity(L)` is positive definite for every finite `N>=q-1`, although it converges to zero. The proof gives no positive lower bound uniform in `N`. The limit has rank `|Z_L|`; in particular it is positive definite exactly when all roots of `chi` are simple and sampled. When `Z_L` is empty, the exact sequence has kernel equal to all of `E` and `G_N(L)` tends to zero.

For `k=1`, the density and closed-relation quotient proofs apply to the positive support \(\mathcal I_{h,L}=\{n:w_h(2\pi n/L)>0\}\). The Hilbert space, all evaluations, and the definition of `Z_L` must be restricted to that support. On this support, the formula (PSD20) also gives the inverse of the source-to-sequence isometry. The all-integer positivity, the positive-definite matrix assertions for every finite degree at arbitrary fixed `L`, and the strict difference in (PSD40) have been proved here for `k>=2`. For `k=1`, the source's separately proved large-period comparison (P34)–(P37) supplies the finite-degree injectivity used there; no assertion that every fixed circle has all integer atoms with positive weight is inserted into that result.

For the actual one-fold packet, \(\chi_{h,1}=h\). If \(h(S_n)=0\) with \(S_n=1/2+2\pi i n/L\), the full-order cancellation formula (PSD5) gives

\[
w_h(2\pi n/L)=\frac1{2\pi}
\left|\frac{g^{(m)}(S_n)}{h^{(m)}(S_n)}\right|^2>0,
\qquad m=\operatorname{ord}_{S_n}h=\operatorname{ord}_{S_n}g.
\tag{PSD41}
\]

Consequently the sampled-root set \(\mathcal Z_L=\{n:h(1/2+2\pi i n/L)=0\}\) is already contained in \(\mathcal I_{h,L}\). Restricting the Hilbert space to its positive support therefore retains every sampled root of this original one-fold packet. Its reduced evaluation quotient is \(\mathbb C^{\mathcal Z_L}\), with the original weights, and its algebraic kernel is \((p_L)/(h)\) by the same proof as (PSD28)–(PSD32). Each factor of \(p_L\) is a critical-line factor of \(h\), occurring once, so \(p_L\) divides the full-multiplicity critical factor \(\chi_{c,1}\). This is exactly the cancellation fact used by the accompanying critical-jet comparison (DC1)–(DC30). It asserts positivity at the selected sampled roots; it does not assert positivity at every other integer atom or invertibility of every high-degree Gram at arbitrary fixed \(L\).

## 7. Integration disposition

The original note needs no correction to (P54), (P56), (P57), or (P58). To make the public mathematical presentation standalone, include the explicit definitions (PSD1)–(PSD7), the original-source tail proof (PSD8)–(PSD14), the source-to-sequence isometry (PSD18)–(PSD20), and the density/completion proof (PSD21)–(PSD41). The half-width in (PSD23) is a proof detail, not a change to the note's theorem. The full sampled weights, zero mode, remainder basis, factorial Taylor coefficients, and generator `S` are preserved throughout.

The independent peer proof is `work/periodized_completion_peer_20260913.md`, SHA-256 `0cfb3c474a47d5c07beb0a8ef7f022cf854da35748ee0a6d8635360d96b0af63`. It was read in full. Its exact cyclic kernel sequence, explicit Taylor CRT inverse, closed Fourier generator, and strict finite-degree strengthening have been incorporated and proved above; its analytical density input is supplied here by Sections 2–4.

No growth estimate for the tensor-degree endpoint volume is proved by this audit. The result computed here is the precise fixed-`L` completion and the finite-degree metric limit already stated in the source; it supplies its full analytic justification and exact original-space maps.
