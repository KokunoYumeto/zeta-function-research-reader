# Independent proof review: arithmetic determinant transport

Date: 13 September 2026. Review status: the mathematical statements AT1–AT22, including AT2a, are accepted on the corrected source pinned below. The first-pass proof-order issue in the explanation of AT6 has been repaired. This review retains the original Tau Base cohomology, arithmetic theta source, full Taylor unit, tensor sum coordinate, and both reference and arithmetic masses.

## 1. Sources and scope

The complete first-pass root source was read at SHA-256 41c7b45a0a94f0e65d422b213a4bcbddedbf983ab5127da6095e449e001fef98. Its corrected proof paragraph was then read completely. The accepted source is work/tau_arithmetic_determinant_transport_20260913.tex, 17706 bytes, SHA-256 24cf7ce5be6a43cc656641b516185df10b2e4d7824600ece657120d1c549deae. No displayed formula changed between those editions.

The original dependencies checked directly were:

| Source relative to output/split_zero_rh_tandem_2026-09-12 | Bytes | SHA-256 | Scope |
|---|---:|---|---|
| sources/Tau_Base_Cohomology_2026-09-12/NOTE.tex | 28353 | e7a494d79e01b774ad18045b1e244b28738ddf7b85aec31c58724e2fe35c3aba | Lines 225–408 and 672–755: coefficient sheaf, support faces, projective resolution, actual cohomology, tensor signs and top quotient |
| sources/web_cyclic_sum_delivery/Tau_Cyclic_Sum_Control/NOTE.tex | 41804 | 2cdfd5b25631464f9500dc5fd07c4c8f5c927c8877eb1bf076307ec5dcbc2e8c | Lines 108–183 and 300–349: source, full unit, exact cyclic map and theta primitive |
| tex/arithmetic_input.tex | 14644 | a50b0fb587b644c4ea94dba45b2b423d038f2bfbe7fef188543939ba850e58d2 | Complete A1–A19, already fully read in this audit |

The Gamma norms, all-multiplicity quartet theorem, and exact original arithmetic comparison were independently proved in work/deligne_bound_gamma_independent_review_20260913.md, SHA-256 57069ebc4b4eab844d18d3bca9b4b7bd26cda138d9497fe3c126ee65bdfb9186. Its complete 72-equation proof remains a dependency of the application AT22. The section and variation proof for the present transport is given completely in RV6–RV11 below.

The exact finite fixtures described at the end exercise these transport formulas. They are calibration measures for the formulas; they do not assert values of arithmetic zeta moments or the existence of a selected zeta packet. No old suite, Lean process, or remote mutation is part of this review.

## 2. Original cohomology and the two separately typed injections

On the four-point chart \(+,-<\eta<\sigma\), the original coefficient diagram is

\[
(\mathcal T_+,\mathcal T_-,\mathcal T_\eta,\mathcal T_\sigma)
=(V,V,\mathscr B,0),\qquad
r_+=\Theta,\quad r_-=J\Theta=\Theta\mathcal F.
\tag{RV1}
\]

Here \(V\) is the original even Schwartz space with its value and integral zero, \(\mathscr B\) is the original strong Schwartz space on the multiplicative line, \(JF(x)=x^{-1}F(1/x)\), and \(\mathcal F\) is the original Fourier transform. The diagram category is the declared linear-fibre realization of the Tau Base chart. At each chart point, the projective resolution

\[
0\to P_\eta\xrightarrow{v\mapsto(v,-v)}
P_+\oplus P_-\xrightarrow{(u,v)\mapsto u+v}\mathbf C\to0
\tag{RV2}
\]

is exact: at \(+\) and \(-\), its last map is identity; at \(\eta\) and \(\sigma\), its kernel is the displayed anti-diagonal. Applying its Hom complex to RV1 gives

\[
\mathsf A_\tau(\mathcal T)
=[V\oplus V\xrightarrow{\Theta(\phi-\widehat\psi)}\mathscr B].
\tag{RV3}
\]

Its degree-one image is exactly \(\Theta V\), so its degree-one cohomology is the original \(Q=\mathscr B/\Theta V\). Tensoring the resolution uses the literal differential sign \((-1)^{\sum_{j<i}|x_j|}\). At top degree the source is \(\mathscr B^{\otimes k}\), and the relation subspace is the sum of all tensors with \(\Theta V\) in one factor. Tensoring the quotient maps over the field therefore identifies the top cohomology with \(Q^{\otimes k}\). This proves the use of AT1 in the specified category, without replacing the pushforward by evaluation at the zero coefficient stalk \(\sigma\).

For an actual full packet \(h\), retain \(E_h=\mathbb C[s]/(h)\), \(\upsilon_h=j_h(g/h)\in E_h^\times\), \(g=2\xi\), and the actual \(F_h\) with Mellin transform \(g/h\). The polynomial tensor algebra is \(E_h^{\otimes k}\), its operator is multiplication by \(S=s_1+\cdots+s_k\), and its cyclic annihilator is the original \(\chi=\chi_{h,k}\).

The injective algebra map \(\alpha:E=\mathbb C[S]/(\chi)\to E_h^{\otimes k}\) sends \([P]\) to \(P(A_h^{(k)})1\). Its kernel before quotienting is exactly the defining cyclic annihilator, proving injectivity. Multiplication by the full tensor unit has inverse multiplication by its inverse. Hence the first injection is

\[
\eta=M_{\upsilon_h^{\otimes k}}\alpha:
E\hookrightarrow E_h^{\otimes k}.
\tag{RV4}
\]

It is a module map; multiplication by a unit is not being assigned the type of a unital algebra map. The original single-packet section \(\sigma_h:E_h\hookrightarrow Q\) has a left inverse induced by its full arithmetic jet observation. Tensoring this left inverse proves that \(\sigma_h^{\otimes k}\) remains injective. The separate cohomology injection is consequently

\[
\sigma_h^{\otimes k}\eta:E\hookrightarrow Q^{\otimes k}.
\tag{RV5}
\]

The two target spaces in RV4 and RV5 are carried by the explicit arrow \(\sigma_h^{\otimes k}\); neither is substituted for the other. Applying the original source map
\(\mathcal VP=P(D_1+\cdots+D_k)F_h^{\otimes k}\)
gives exactly \(J^{(k)}\mathcal VP=\eta[P]\) and \(q^{(k)}\mathcal VP=\sigma_h^{\otimes k}\eta[P]\), as in AT2 and AT2a.

Every relation \(\chi(S)P(S)\) has its original theta primitive. Indeed, the cyclic annihilator says it belongs to the tensor ideal \((h(s_1),\ldots,h(s_k))\). Fixed-order monic division writes it as \(\sum_i h(s_i)P_i(\mathbf s)\). In factor \(i\), replace \(F_h\) by \(\phi_*\), apply \(P_i(D_1,\ldots,D_k)\), and assign the primitive sign \((-1)^{i-1}\). The tensor differential supplies a second \((-1)^{i-1}\); their product is \(+1\), and \(h(D)F_h=\Theta\phi_*\) recovers the desired source relation. This checks that every variation below retains an actual top cochain boundary.

## 3. Finite source, zero relation space, and variations

Let \(q=\deg\chi\ge1\). For \(N\ge q-1\), use the original exact sequence

\[
0\to\mathcal P_{N-q}\xrightarrow{B_N=\times\chi}\mathcal P_N
\xrightarrow{J_N}E\to0
\tag{RV6}
\]

in increasing monomial frames, with the fixed remainder section \(s_N\). Its coefficient maps do not depend on the real interpolation parameter \(t\). The densities are precisely \(m_0=r_{1/4,k}\), of mass \((2\pi)^{k/2}\), and \(m_1=w_h^{*k}\), of mass \(\mu_h^k\), in \(S=k/2+iu\). Neither mass is changed.

Each source density is positive almost everywhere and has moments of every finite degree. For the arithmetic density, the zeros of the nonzero entire function \(g/h\) on a real line are discrete; at \(k\ge2\), its convolution preserves almost-everywhere positivity. A nonzero polynomial has only finitely many zeros on this line, so the two source Grams are positive definite. Their convex interpolation \(M_N(t)\) remains positive definite on \(0\le t\le1\). At a fixed finite degree, its eigenvalues have a positive lower bound on this compact interval. The relation Gram \(H_N=B_N^*M_NB_N\) is positive on its actual domain by injectivity of \(B_N\). These facts justify all finite differentiations, including a small open neighborhood of the interval.

The minimum section is \(R=s-BH^{-1}B^*Ms\). Orthogonality gives \(JR=I\), \(B^*MR=0\), and \(G=R^*MR>0\). To prove the inverse expression without presupposing it, decompose every vector \(p\in\mathcal P_N\) uniquely as \(By+RJp\). Then

\[
R^*Mp=GJp,\qquad MR=J^*G,\qquad
(JM^{-1}J^*)G=I.
\tag{RV7}
\]

The last equality follows from \(JR=I\); it proves \(G=(JM^{-1}J^*)^{-1}\). This is the noncircular derivation now in the corrected AT6 proof.

The determinant-line sign is also retained. With \(r=N-q+1\), the increasing-degree matrix \([s\ B]\) is triangular with determinant one because \(\chi\) is monic. Thus \([B\ s]\) has determinant \((-1)^{qr}\). The actual line map wedges the \(r\) relation vectors before the \(q\) quotient lifts. Replacing a lift by a relation leaves this wedge unchanged. Its Gram block Schur complement is \(G\), so

\[
\det H\,\det G
=|(-1)^{qr}|^2\det M=\det M,\qquad
V_N=\det G=\det M/\det H.
\tag{RV8}
\]

At \(r=0\), the domain \(\mathcal P_{-1}\) is zero, its determinant is one, and its unique endomorphism is invertible as a map from the zero space to itself. Every composite through that space has the zero map of its stated outer domain and codomain. The formula gives \(R=s\), \(G=s^*Ms\), and \(V_N=\det M\); no earlier singular quotient Gram is inverted.

Differentiation of \(JR=I\) shows that \(\dot R\) lies in \(\operatorname{im}B\). Differentiation of \(B^*MR=0\) fixes its coefficient. Thus

\[
\dot R=-BH^{-1}B^*\Delta M R,\qquad
\dot G=R^*\Delta M R,\qquad
\ddot G=-2R^*\Delta M BH^{-1}B^*\Delta M R.
\tag{RV9}
\]

The two terms involving \(\dot R\) vanish in the first derivative of \(R^*MR\) by orthogonality. In the next derivative they are the two equal displayed negative terms because \(\Delta M\) is Hermitian. These identities prove AT7 and show that \(G\) is concave as an original Hermitian form.

Taking determinant derivatives in RV8, or directly in \(G\), gives

\[
\frac d{dt}\log V_N
=\operatorname{Tr}(M^{-1}\Delta M)
-\operatorname{Tr}(H^{-1}B^*\Delta MB)
=\operatorname{Tr}(G^{-1}R^*\Delta MR).
\tag{RV10}
\]

The second derivative is exactly

\[
\frac {d^2}{dt^2}\log V_N
=-2\|H^{-1/2}B^*\Delta MR G^{-1/2}\|_{\rm HS}^2
-\|G^{-1/2}\dot G G^{-1/2}\|_{\rm HS}^2.
\tag{RV11}
\]

Each square is for the indicated exact isometry of the original source forms. No term is removed in this identity. It proves AT8 and AT9, including the empty first square when \(r=0\).

Applying \(\mathcal V\) to the relation-valued \(\dot R\) gives the primitive constructed after RV5. The jet \(J^{(k)}\mathcal V R=\eta\) and cohomology class \(\sigma_h^{\otimes k}\eta\) are constant in \(t\). On a fixed nonempty support label \(A\), every such linear map lifts as \((A,v)\mapsto(A,fv)\), with \(\tau\mapsto\tau\). Thus a nonzero relation vector can map to the supported zero while its energy in RV9–RV11 is retained. Its preimage is the whole source kernel on that label, not only the zero vector.

## 4. The exact common-source projection trace

Set \(N_*=2q\), and let \(I_N:\mathcal P_N\hookrightarrow\mathcal P_{N_*}\) be the literal coefficient inclusion. In the common metric \(M_*=M_{N_*}(t)\), define

\[
\begin{aligned}
P_N&=I_NM_N^{-1}I_N^*M_*,\\
Q_N&=I_NB_NH_N^{-1}B_N^*I_N^*M_*,\\
C&=M_*^{-1}\Delta M_*.
\end{aligned}
\tag{RV12}
\]

The first two are orthogonal projections with images \(I_N\mathcal P_N\) and \(I_N\operatorname{im}B_N\). Substitution uses \(I_N^*M_*I_N=M_N\) to verify idempotence and \(M_*\)-self-adjointness. Since the relation image lies in the polynomial image, \(P_NQ_N=Q_NP_N=Q_N\). Thus \(P_N-Q_N\) is the orthogonal projection onto \(I_NR_N(E)\), with rank and trace \(q\).

The cyclic trace computation has no omitted metric factor:

\[
\begin{aligned}
\operatorname{Tr}(P_NC)
&=\operatorname{Tr}(M_N^{-1}I_N^*\Delta M_*I_N)
=\operatorname{Tr}(M_N^{-1}\Delta M_N),\\
\operatorname{Tr}(Q_NC)
&=\operatorname{Tr}(H_N^{-1}B_N^*\Delta M_NB_N).
\end{aligned}
\tag{RV13}
\]

Combining these equalities with RV10 proves AT12.

For \(i_0=q-1,i_1=q,j_0=2q-1,j_1=2q\), set

\[
U=(Q_{j_0}-Q_{i_0})+(Q_{j_1}-Q_{i_1}),\qquad
W=(P_{j_0}-P_{i_0})+(P_{j_1}-P_{i_1}).
\tag{RV14}
\]

For nested subspaces \(X\subset Y\) of one Hilbert space, their orthogonal projections satisfy \(P_XP_Y=P_YP_X=P_X\); hence \(P_Y-P_X\) is the projection onto \(Y\cap X^\perp\). Each difference in RV14 is therefore a positive projection of rank \(q\): the polynomial dimensions differ by \(q\); the relation dimensions \(N-q+1\), including zero at \(q-1\), also differ by \(q\). Consequently

\[
U\succeq0,\quad W\succeq0,\quad
\operatorname{Tr}U=\operatorname{Tr}W=2q.
\tag{RV15}
\]

Their sums need not be idempotent, their two summands need not have orthogonal images, and no such assertion enters RV15. Subtracting the four exact traces in RV13 gives

\[
\frac d{dt}\log\frac{V_{i_0}V_{i_1}}{V_{j_0}V_{j_1}}
=\operatorname{Tr}((U-W)C).
\tag{RV16}
\]

All inverses are smooth and bounded on the parameter interval. Integrating proves AT15 with the exact arithmetic correction \(\Delta\mathcal B\). The individual concavity in RV11 gives no sign to this four-term difference; RV16 is its complete signed expression.

## 5. Pointwise expression and arithmetic density zeros

The two orthogonal source images \(\operatorname{im}B_N\) and \(\operatorname{im}R_N\) decompose the whole finite polynomial space. Their projection formulas imply

\[
M_N^{-1}=B_NH_N^{-1}B_N^*+
R_NG_N^{-1}R_N^*.
\tag{RV17}
\]

For example, multiplication on the right by \(M_N\) acts as identity separately on each of those two images, by orthogonality and their own Gram identities; it therefore acts as identity on their direct sum.

For \(v_N(u)=(1,S(u),\ldots,S(u)^N)\), evaluation of RV17 gives the exact nonnegative function

\[
\begin{aligned}
d_N(t,u)
&=v_NM_N^{-1}v_N^*
-|\chi(S(u))|^2v_{N-q}H_N^{-1}v_{N-q}^*\\
&=v_NR_NG_N^{-1}R_N^*v_N^*\ge0.
\end{aligned}
\tag{RV18}
\]

At \(N=q-1\) the relation term is absent and defined as zero. The factor \(|\chi|^2\) follows from the actual evaluation identity \(v_N B_N=\chi(S(u))v_{N-q}\); it is not a replacement of the relation polynomial or its powers.

Integration against \(m_t\) yields
\(\int d_Nm_t=\operatorname{Tr}(G_N^{-1}R_N^*M_NR_N)=q\).
Integration against \(\Delta m\), using the original moment matrices, gives

\[
\frac d{dt}\log V_N=\int d_N(t,u)\Delta m(u)\,du.
\tag{RV19}
\]

Subtracting at the four endpoints and integrating \(t\) is exactly AT17. To justify both steps without any quotient of densities, note that \(d_N(t,u)\) is a fixed finite-degree polynomial in \(S(u)\) and \(\overline{S(u)}\), whose coefficients are bounded for \(0\le t\le1\). Its absolute value is bounded by a fixed constant times \(1+|u|^{2N_*}\). The inequality \(|\Delta m|\le m_0+m_1\) and the two actual moment bounds prove absolute integrability on \([0,1]\times\mathbb R\). Fubini applies. At a zero of \(m_1\), this expression is still an ordinary polynomial times a finite signed density; no division by \(m_1\) appears. This proves the claimed zero-set and unbounded-ratio domains.

## 6. Spectral width and the condition number

The operator \(D_*=M_*(0)^{-1}M_*(1)\) is positive and self-adjoint for the original \(M_*(0)\) metric. Let \(b_{\min},b_{\max}>0\) be its extreme eigenvalues. Factor the interpolated Gram in its stated matrix order:

\[
M_*(t)=M_*(0)((1-t)I+tD_*),\qquad
C(t)=((1-t)I+tD_*)^{-1}(D_*-I).
\tag{RV20}
\]

No commutation of the two original Gram matrices is required for this factorization. The matrix on the right of \(C(t)\) is a rational function of the single diagonalizable positive operator \(D_*\). Its eigenvalue on a \(b\)-eigenvector is

\[
c_b(t)=\frac{b-1}{1-t+tb}.
\tag{RV21}
\]

The denominator is positive throughout the closed interval. Differentiating with respect to \(b\) gives \((1-t+tb)^{-2}>0\), so the extrema are attained at the same \(b_{\min},b_{\max}\) for every \(t\). Repeated eigenvalues cause no exception. The operator \(C(t)\) is self-adjoint in \(M_*(t)\) because \(M_*(t)C(t)=\Delta M_*\) is Hermitian.

For any positive self-adjoint \(Z\) on that same Hilbert space,
\[
c_{\min}\operatorname{Tr}Z
\le\operatorname{Tr}(ZC)
\le c_{\max}\operatorname{Tr}Z.
\]
Indeed \(\operatorname{Tr}(Z(c_{\max}I-C))\) is nonnegative: by cyclicity it is the trace of the positive matrix \(Z^{1/2}(c_{\max}I-C)Z^{1/2}\). The lower bound is proved the same way. This does not require \(Z\) to commute with \(C\). Applying it to RV15 and subtracting gives

\[
|\operatorname{Tr}((U-W)C)|
\le2q(c_{\max}-c_{\min}).
\tag{RV22}
\]

For \(b>0\), \(c_b(t)\) is the derivative of \(\log(1-t+tb)\). For \(b=1\), both are respectively zero and the constant zero logarithm, so the same integral gives \(\log b=0\). Hence

\[
\int_0^1(c_{\max}-c_{\min})\,dt
=\log b_{\max}-\log b_{\min}
=\log\kappa_*,\qquad \kappa_*=b_{\max}/b_{\min}.
\tag{RV23}
\]

The triangle inequality for the real integral of RV16, followed by RV22–RV23, proves

\[
|\Delta\mathcal B|\le2q\log\kappa_*.
\tag{RV24}
\]

This confirms AT18–AT21 with the factor \(2q\). The source data at \(N_*=2q\) are actual finite Gram data. No bound uniform in packet or tensor degree, and no pointwise upper or lower bound for \(m_1/m_0\), is used.

## 7. Mass and frame covariance

If \(M_*(1)=cM_*(0)\) with its literal positive scalar \(c\), every degree form is \((1-t+tc)M_N(0)\), and every minimum section remains the same. Its quotient form is \((1-t+tc)G_N(0)\), so its determinant is \((1-t+tc)^qV_N(0)\). The two numerator and two denominator factors in \(\mathcal B(t)\) cancel exactly. Thus \(\Delta\mathcal B=0\), also implied by \(\kappa_*=1\). The separate original masses and determinant factors remain those displayed in these formulas.

For a precise source-frame arrow, let \(F\) carry new common-source coefficients to old coefficients. Then \(M_*'=F^*M_*F\), \(\Delta M_*'=F^*\Delta M_*F\), \(D_*'=F^{-1}D_*F\), \(C'=F^{-1}CF\), and every projection transforms as \(P'=F^{-1}PF\) onto the correspondingly transported subspace. Its inclusion matrix is transported as \(I_N'=F^{-1}I_N\) if the internal frame of \(\mathcal P_N\) is unchanged. Products and traces are then identical by conjugacy. This includes nonunitary complex frames and frames mixing the displayed common-source degree coordinates, because the actual degree subspaces are transported with them.

Independently, let a fixed \(Y:E_{\rm new}\to E_{\rm old}\) change the common quotient frame. Then \(R_N'=R_NY\), \(G_N'=Y^*G_NY\), and \(V_N'=|\det Y|^2V_N\), with the same factor for every \(N,t\). That factor cancels from the four endpoint ratios. These explicit frame maps prove the covariance paragraph following AT21; they do not change the original source norms.

## 8. Original quartet application and scope

For the stipulated actual reflection-stable quartet \(1/2\pm\delta\pm i\gamma\), with \(\delta>0\), nonzero imaginary displacement, and complete common order \(m\), the independent Gamma theorem retains
\[
q=[1+k(m-1)](k+1)^2,\qquad
\mathcal B^\Gamma_{h,k}\ge4q\log\left(\frac{\delta k}{2\sqrt5}\right).
\]
The exact arithmetic/reference comparison RV24 therefore yields

\[
\mathcal B^{\rm ar}_{h,k}\ge
4q\log\left(\frac{\delta k}{2\sqrt5}\right)-2q\log\kappa_*.
\tag{RV25}
\]

Since \(2q>0\), moving terms and dividing gives
\[
\log\kappa_*\ge
2\log\left(\frac{\delta k}{2\sqrt5}\right)
-\frac{\mathcal B^{\rm ar}_{h,k}}{2q}.
\tag{RV26}
\]

Both are exactly AT22. They require no existence claim for such a packet. If the fixed packet restriction is invoked, its \(g/h\), Taylor unit, theta primitive, and finite jet injection remain the original ones in RV4–RV6. In particular this is an analytic comparison on the original finite Tau Base complex with its action-compatible arithmetic observation, and does not replace it by a freely chosen polynomial.

The result computes a finite signed arithmetic term and bounds its magnitude using an actual relative Gram spectrum. It neither proves an arithmetic sub-threshold estimate nor draws a conclusion that the entire Tau Base or F1 geometry program has failed.

## 9. Exact finite fixtures and final review record

The independent fixture source and its exact JSON receipt are work/tau_arithmetic_determinant_transport_exact_fixtures_20260913.py and the same basename with .json. The calibration retains the literal original Gamma coordinate \(S=1/2+iu\) and mass \(\sqrt{2\pi}\), takes the test relation \(\chi=S^2-S+3/16\), and compares that Gamma density with \((u^2+u/3+2)m_0(u)\). This latter multiplier is positive since it is \((u+1/6)^2+71/36\), and it is unbounded. Its mass is \(5\sqrt{2\pi}/2\). The test relation is explicitly a calibration polynomial, not a zero-packet assertion.

The fixture tests the first empty relation domain and all four endpoints \(1,2,3,4\) on cutoff \(4\). It checks the exact minimum section, relation orthogonality, full inverse splitting, Schur determinants, common-source traces, both positive-sum traces, and the signed four-endpoint identity at \(t=0,1/3,1\). It explicitly verifies that each sum \(U,W\) is not an idempotent and that neither commutes with \(C\) in this calibration, exercising two assumptions deliberately absent from the proof.

It also differentiates the exact inverse-kernel construction at the first nonzero relation space and checks both matrix variations and both nonzero logarithmic curvature losses. Omitting either loss is detected by a nonzero exact residual. A second fixture rescales the source mass by \(7/3\), checks every quotient scales by that literal scalar and the four-volume correction is zero, and verifies that the relative source operator is \((7/3)I\). A complex nonunitary frame change additionally verifies the exact similarity of \(D_*\).

One initial harness comparison encountered an unevaluated symbolic zero written \(0\sqrt2\). Its exact expression evaluator was repaired; no mathematical identity, hypothesis, or expected value was changed. The actual completed run and source hashes are recorded in the attached receipt. These finite checks supplement the written proof RV1–RV26; they do not prove its analytic moment facts by sampling.

The completed run passed 98 exact checks. Its fixture source SHA-256 is 8f29a721b8409708e3cc6e3b469cf35429743b3e19150fba467636d98085a497, and its JSON output SHA-256 is 367bb7b3c59e092e6b9ea9e444739d83bcf69701e0dd45545dc595f4bbfd67b6. It gives the exact nonzero correction

\[
\exp(\Delta\mathcal B)
=\frac{66206077200175080056805947}{54881827734195887080729255}.
\tag{RV27}
\]

At \(t=1/3\), the positive relation contribution and the positive metric contribution whose negatives occur in RV11 are, respectively,

\[
\frac{77593974624}{617198528867},\qquad
\frac{88134062040620154}{21159417165147361}.
\tag{RV28}
\]

Thus this execution checks the two distinct curvature terms with nonzero exact values. No rounding or interval approximation enters these fixture results.

The AT6 proof-order issue was resolved in the accepted source. No further mathematical correction was found. The complete written calculation in RV1–RV28 and the exact fixture receipt support the mathematical acceptance recorded here.
