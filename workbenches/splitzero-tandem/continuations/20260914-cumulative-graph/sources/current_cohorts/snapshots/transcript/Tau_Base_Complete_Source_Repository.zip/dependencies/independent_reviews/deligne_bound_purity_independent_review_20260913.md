# Independent audit of the Deligne bound comparison

Date: 13 September 2026. This is a complete written review of the operator, coefficient, period, purity, and critical-kernel parts of the delivered `Tau_Deligne_Bound_Audit/NOTE.tex`. The complete note was read, including its Gamma argument; independent verification of the quantitative Gamma estimate belongs to the separate Gamma review. This document supplies full proofs for its new comparison statements. It preserves the delivered note unchanged.

## Finding and precise scope

The delivered note proves a failure of a particular implication from auxiliary exponential Frobenius purity to the original arithmetic operator estimate. Its rank-one and reflection-stable counterexamples survive the review below. They do not prove failure of the Split-Zero or broader F1 geometry program. Their test polynomials are not known to be factors of the actual function \(g=2\xi\), and the exact arithmetic comparison records that difference by multiplication by \(j_hg\).

Two narrow corrections are required in the exposition. The rank and trace statements attached to the Artin--Schreier equation must specify the nontrivial additive-character sheaf, or equivalently its character summand in the cover. The whole affine cover also has a degree-two compact-support contribution. Furthermore, vanishing of \(j_{h_0}g\) and entire divisibility by \(h_0\) do not require that every selected zero order be its full actual order; the extra full-order condition makes \(j_{h_0}(g/h_0)\) a unit. Neither correction invalidates the exhibited operator counterexamples.

The strongest comparisons proved here include a complete classification of the possible pure-target intertwiners, with nilpotent lengths and exponential collisions retained; a universal observable quotient for each specified target Frobenius; and a tensor construction from the original arithmetic packet whose finite-field realization has the correct tensor weight \(k\). The latter has an explicit injective complex period map retaining the original Taylor unit and sum action. Its existence prevents a failure of the simpler rank-\(q_k\), weight-one auxiliary inference from being mistaken for failure of every geometric comparison.

## 1. The actual coefficient complex and its recovered operator

Retain the original monic annihilator

\[
\chi(S)=S^q+\sum_{a=0}^{q-1}c_aS^a,\qquad q>0,
\quad E=\mathbb C[S]/(\chi),\quad A=M_S,
\]

and the specified potential

\[
\Phi_t(S)=\frac{S^{q+1}}{q+1}
 +\sum_{a=0}^{q-1}\frac{c_aS^{a+1}}{a+1}-tS.
\tag{DP.1}
\]

Let \(B=\mathbb C[u,t]\). The two-term complex in degrees zero and one is

\[
\mathcal C=[B[S]\xrightarrow{D}B[S]dS],\qquad
D(P)=(u\partial_SP+(\chi-t)P)dS.
\tag{DP.2}
\]

For a nonzero polynomial \(P\) of degree \(n\) and leading coefficient \(b\), the term of degree \(n+q\) in \(D(P)/dS\) is exactly \(bS^{n+q}\). Every other term has smaller degree. Thus \(D\) is injective. For a polynomial \(Q\) of degree at least \(q\), subtract the image under \(D/dS\) of its leading coefficient times \(S^{\deg Q-q}\). The degree strictly decreases. The procedure terminates and writes \(Q=D(P)/dS+R\) with \(\deg R<q\). Uniqueness follows because a nonzero image has degree at least \(q\). Consequently

\[
B[S]=\operatorname{im}(D/dS)\oplus
 \bigoplus_{b=0}^{q-1}B S^b,
\quad H^0(\mathcal C)=0,
\quad \mathcal H=H^1(\mathcal C)\cong B^q.
\tag{DP.3}
\]

This proves freeness over the displayed coefficient ring and its compatibility with every coefficient specialization. The special fibre at \((u,t)=(0,0)\) is exactly \(E\). No repeated root is removed.

On \(u\ne0\), put \(\nabla_t=\partial_t-S/u\) on polynomial coefficients in both terms. Directly,

\[
[\partial_t,D/dS]=-1,
\qquad [-S/u,u\partial_S]=1,
\qquad [-S/u,\chi-t]=0.
\]

Their sum is zero, so \(\nabla_t\) descends to \(\mathcal H[u^{-1}]\). In the fixed increasing-power frame, reduction of \(S\cdot S^{q-1}=S^q\) uses only \(D(1)=(\chi-t)dS\); therefore the matrix is

\[
\nabla_t=\partial_t-A(t)/u,
\qquad A(t)=A+t\mathcal R,
\qquad \mathcal R=1_E\otimes\ell,
\quad \ell[P]=[S^{q-1}]\operatorname{rem}_{\chi}P.
\tag{DP.4}
\]

The operator \(-u\nabla_t=-u\partial_t+A(t)\) preserves \((u,t)\mathcal H\): its derivative on \(tv\) contributes \(-uv\), which belongs to that ideal. Hence it induces precisely \(A\) on the special fibre. This is a regular operator specialization even though \(\nabla_t\) itself has a pole. Multiplication by \(S\) on arbitrary representatives does not separately define an algebra structure on \(\mathcal H\); the displayed connection and fixed-frame endomorphism give its exact replacement.

## 2. Rank-one periods, orientation, and the finite-field trace

For \(\chi(S)=S-\lambda\), with \(\lambda=3/4\), the coefficient ring \(\mathbb Z[1/2]\) contains every coefficient. Let \(u>0\), put \(b=\lambda+t\), and first take \(b\) real. On the upward contour \(S=ix\), \(-\infty<x<\infty\),

\[
\Pi_{\mathrm{up}}(u,t)
=i\int_{\mathbb R}e^{-x^2/(2u)}e^{-ibx/u}\,dx.
\tag{DP.5}
\]

Write the real integral as \(I(b)\). Differentiation is justified by a Gaussian bound. Integration by parts, whose endpoint terms vanish, gives

\[
0=\int_{\mathbb R}\partial_x
       (e^{-x^2/(2u)}e^{-ibx/u})dx
=-u^{-1}\int x e^{-x^2/(2u)}e^{-ibx/u}dx
 -ibu^{-1}I(b).
\]

Thus \(I'(b)=-bI(b)/u\). The Gaussian value \(I(0)=\sqrt{2\pi u}\), obtained by squaring the integral and using polar coordinates, yields

\[
\Pi_{\mathrm{up}}=i\sqrt{2\pi u}
 e^{-b^2/(2u)},\qquad
-u\frac{\partial_t\Pi_{\mathrm{up}}}{\Pi_{\mathrm{up}}}=b,
\quad |\Pi_{\mathrm{up}}|^2=2\pi u e^{-b^2/u}.
\tag{DP.6}
\]

Both sides of the unsquared period identity are entire in \(b\): compact sets of complex \(b\) still admit an integrable Gaussian majorant. Hence the unsquared identity extends to complex \(t\); the last real norm formula is asserted only for real \(b\).

For the inherited ray order, \(d=2\), \(\theta_0=\pi/2\), \(\theta_1=3\pi/2\), and \(\Gamma_1=-\ell_0+\ell_1\). Its path travels from \(+i\infty\) to zero and then to \(-i\infty\). Thus \(\Gamma_{\mathrm{up}}=-\Gamma_1\) as oriented chains and \(\Pi_{\mathrm{up}}=-\Pi_1\). The unsquared sign in the delivered note is correct.

Now fix a finite field \(\mathbb F_Q\) of odd characteristic, a nontrivial complex additive character \(\psi\), \(u\in\mathbb F_Q^\times\), and \(b\in\mathbb F_Q\). Translation \(x\mapsto x+b\) is a bijection and gives

\[
\sum_x\psi((x^2/2-bx)/u)
=\psi(-b^2/(2u))G_Q(u),
\quad G_Q(u)=\sum_x\psi(x^2/(2u)).
\tag{DP.7}
\]

The character takes values in roots of unity, so its conjugate at \(y\) is its value at \(-y\). The invertible coordinate change

\[
(x,y)\mapsto(r,s)=(x-y,x+y),
\quad (r,s)\mapsto((s+r)/2,(s-r)/2)
\]

therefore gives

\[
|G_Q(u)|^2=\sum_{r,s}\psi(rs/(2u))=Q.
\tag{DP.8}
\]

Indeed the inner sum is \(Q\) at \(r=0\). For \(r\ne0\), choose \(a\) with \(\psi(ra/(2u))\ne1\); shifting \(s\) by \(a\) multiplies that inner sum by a number unequal to one, so the inner sum vanishes.

The cohomological object for this sum is

\[
H_c^1(\mathbb A^1_{\overline{\mathbb F}_Q},
 \mathcal L_{\psi}((S^2/2-bS)/u)).
\tag{DP.9}
\]

With the geometric-Frobenius convention in the source, its trace is the negative of DP.7. The degree-two character-polynomial theorem makes DP.9 one-dimensional and all other compact cohomology of this **character sheaf** zero. Thus the sole Frobenius eigenvalue has modulus \(\sqrt Q\), including its trace sign.

For precision about the cover, fix \(\Psi:\mathbb F_p\to\overline{\mathbb Q}_{\ell}^{\times}\) and write a nontrivial \(\psi\) as \(\Psi\circ\operatorname{Tr}_{\mathbb F_Q/\mathbb F_p}(a\,\cdot)\), \(a\ne0\). The cover used for this summand is \(Y^p-Y=a f(S)\); alternatively fix \(a=1\) and the corresponding character. The finite étale pushforward from that cover decomposes by the character idempotents of its translation group \(\mathbb F_p\). Its trivial summand is the constant sheaf on \(\mathbb A^1\), whose \(H_c^2\) is \(\overline{\mathbb Q}_{\ell}(-1)\). Every nontrivial character summand has the type DP.9. Consequently the whole cover has an additional degree-two contribution, whereas DP.9 has the rank and alternating-trace sign used in the note. This is the required clarification of its equations (14) and (22)--(23).

Finally, on the recovered complex one-dimensional source \(A=3/4\), any positive scalar Gram \(G\) gives

\[
A^*G+GA-G=\tfrac12G.
\tag{DP.10}
\]

This identity and DP.8 coexist in the same coefficient family. Hence the indicated coefficient specialization and period identity do not imply a vanishing arithmetic weight-one defect.

## 3. Primary-source hypotheses and the reflection-stable example

The local original Deligne scan was inspected visually on complete printed pages 215 and 216, including the theorem, its character-sheaf definition, and its family argument. The complete relevant S20 French text and the dated primary correction were also read. The primary bibliographic page was checked online: [Deligne, La conjecture de Weil II](https://www.numdam.org/item/PMIHES_1980__52__137_0/).

The theorem used is Weil II (3.7.2.3): for a degree-\(d\) polynomial in \(n\) variables, \(p\nmid d\), and smooth leading projective hypersurface, the associated nontrivial additive-character sheaf has compact cohomology concentrated in degree \(n\), of dimension \((d-1)^n\), pure of weight \(n\). The parameter sheaves are lisse by (3.7.3). Its propagation argument uses mixedness as well as lissity in (1.8.12). In (3.7.4) the final reference is Roman **I.8.11**. This audit does not claim a fresh proof of Deligne's theorem or a visual rereading of all Weil II pages.

For DP.1, \(n=1\), \(d=q+1\), and \(u\ne0\), the leading coefficient is exactly \(1/(du)\). In \(\mathbb P^0\), its zero scheme is empty because that coefficient is invertible. The empty scheme is smooth. Taking \(p>d\) is stronger than the required \(p\nmid d\) and retains all denominators. The lower critical points may collide; they do not alter this leading homogeneous hypothesis. Thus the stated theorem applies after each specified good coefficient reduction.

The proposed quartet polynomial is correct. With \(x=S-1/2\), its four factors have roots \(x=\pm1/4\pm i\). Pairing conjugates at each real part gives

\[
\begin{aligned}
h_*(S)
&=((x-1/4)^2+1)((x+1/4)^2+1)\\
&=(x^2+17/16)^2-x^2/4\\
&=x^4+(15/8)x^2+289/256.
\end{aligned}
\tag{DP.11}
\]

It is monic over \(\mathbb Z[1/2]\), real, and invariant under \(S\mapsto1-S\). Its roots have real parts \(1/4,3/4\), including both signs of their nonzero imaginary parts. Its degree-five potential has leading coefficient \(1/5\). For all specified good reductions with \(p>5\), the previous theorem applies to its character sheaf and yields weight one. Thus reflection symmetry does not restore the failed operator implication. The statement does not assert that \(h_*\) divides \(2\xi\).

The exact translation proof in the retained source was also read in full. For \(\chi_a(S)=\chi(S-a)\), \(\Phi_a(S)=\Phi(S-a)-\Phi(-a)\), and \(T_aP(X)=P(X+a)\), direct substitution gives the chain isomorphism and

\[
T_aA_aT_a^{-1}=A+aI,
\quad \Pi_a=f_a\Pi C_a,
\quad f_a=e^{(-\Phi(-a)-ta)/u}.
\tag{DP.12}
\]

The fixed-frame matrix \((C_a)_{rb}=\binom br a^{b-r}\) for \(r\le b\) has inverse \(C_{-a}\). The scalar is nonvanishing on \(u\ne0\) and is retained. For a holomorphic determinant-line metric multiplied by \(|f_a|^{2p}\), the curvature change is \(2p\,\partial\bar\partial\operatorname{Re}\log f_a=0\) locally; logarithm branches differ by constants and give the same derivative. The corresponding additive trace defect changes by \(2p\operatorname{Re}a\). The reflection-preserving DP.11 shows that the broader counterexample does not rely on changing the original reflection centre by DP.12.

## 4. Classification of all intertwiners to a specified pure target

Fix \(Q>1\), \(a=\log Q>0\), and a finite-dimensional complex vector space \(V\) with an invertible operator \(F\). Let the source be the **original** cyclic algebra \(E=\mathbb C[S]/(\chi)\), \(A=M_S\), and \(U=e^{aA}\). We classify

\[
\mathscr T=\{T\in\operatorname{Hom}_{\mathbb C}(E,V):TU=FT\}.
\tag{DP.13}
\]

Write \(\chi=\prod_{\lambda}(S-\lambda)^{r_\lambda}\). The Chinese-remainder map, with the full powers, gives

\[
E=\bigoplus_\lambda E_\lambda,
\quad E_\lambda=\mathbb C[\epsilon_\lambda]/(\epsilon_\lambda^{r_\lambda}),
\quad A|_{E_\lambda}=\lambda I+N_\lambda,
\quad N_\lambda=M_{\epsilon_\lambda}.
\tag{DP.14}
\]

Its inverse exists by Bezout: for each factor, the product of the other factors is a unit modulo that factor; multiply its inverse there and sum the resulting mutually orthogonal idempotent lifts. This retains every nilpotent power.

Let \(V_\mu=\ker(F-\mu I)^{s_\mu}\) be a full primary summand of \(F\), with \(s_\mu\) any exponent at least its longest Jordan length. When \(\mu=e^{a\lambda}\), define the nilpotent polynomial

\[
L_\mu=\frac1a\sum_{j=1}^{s_\mu-1}
 \frac{(-1)^{j+1}}j(\mu^{-1}F-I)^j
\quad\text{on }V_\mu.
\tag{DP.15}
\]

The expression is independent of enlarging \(s_\mu\), because additional powers vanish. The formal identities \(\log(\exp z)=z\) and \(\exp(\log(1+z))=1+z\), valid in the formal power-series ring, become finite polynomial identities after substituting a nilpotent. Therefore

\[
e^{aL_\mu}=\mu^{-1}F,
\qquad \frac1a\log(e^{aN_\lambda})=N_\lambda.
\tag{DP.16}
\]

The source satisfies \((U-e^{a\lambda})^{r_\lambda}=0\) on \(E_\lambda\). Intertwining carries this equation to \((F-e^{a\lambda})^{r_\lambda}T=0\). Projection to any different target primary summand gives zero because \(F-e^{a\lambda}\) is invertible there. Hence \(T(E_\lambda)\subseteq V_{e^{a\lambda}}\), interpreted as zero if that primary summand is absent. Applying the logarithm polynomial to the intertwining equation proves

\[
TN_\lambda=L_{e^{a\lambda}}T.
\tag{DP.17}
\]

Conversely DP.17 implies the exponential intertwining by DP.16. Since \(1_\lambda\) generates the source block under \(N_\lambda\), every such map is determined by

\[
v_\lambda=T(1_\lambda)\in
 \ker L_{e^{a\lambda}}^{r_\lambda},
\qquad
T\Bigl(\sum_{j=0}^{r_\lambda-1}c_j\epsilon_\lambda^j\Bigr)
=\sum_{j=0}^{r_\lambda-1}c_jL_{e^{a\lambda}}^jv_\lambda.
\tag{DP.18}
\]

These are inverse constructions. Consequently

\[
\mathscr T\cong
\bigoplus_\lambda\ker L_{e^{a\lambda}}^{r_\lambda}.
\tag{DP.19}
\]

No injectivity of \(\lambda\mapsto e^{a\lambda}\) is assumed. If two roots differ by \(2\pi i n/a\), their source blocks have the same exponential eigenvalue and map independently into the same target primary space. Their images can overlap. Formula DP.18 retains those overlaps and therefore does not incorrectly identify the total kernel with the sum of the individual block kernels for an arbitrary fixed \(T\).

If \(F\) is pure of weight \(k\) in its specified complex realization, every \(\mu\) has modulus \(Q^{k/2}\). For \(\operatorname{Re}\lambda\ne k/2\), \(|e^{a\lambda}|=Q^{\operatorname{Re}\lambda}\) differs, so that target primary space is absent. It follows that

\[
E_{\mathrm{off}}:=\bigoplus_{\operatorname{Re}\lambda\ne k/2}E_\lambda
\subseteq\ker T
\qquad(T\in\mathscr T).
\tag{DP.20}
\]

This proves the delivered note's off-critical annihilation including every generalized vector. Purity alone does not assert semisimplicity of \(F\); DP.15--DP.19 therefore retain all target nilpotents as well.

There is also an exact quotient visible to **all** such maps. Let \(d_\mu\) be the largest Jordan length of \(F\) on \(V_\mu\), and set \(d_\mu=0\) when that summand is absent. The nilpotent \(L_\mu\) has the same Jordan lengths as \(F-\mu I\), because it is the latter times an invertible polynomial with nonzero constant coefficient \(1/(a\mu)\). Put \(b_\lambda=\min(r_\lambda,d_{e^{a\lambda}})\). Then

\[
K_F:=\bigcap_{T\in\mathscr T}\ker T
=\bigoplus_\lambda
 \frac{(\epsilon_\lambda^{b_\lambda})}
      {(\epsilon_\lambda^{r_\lambda})}.
\tag{DP.21}
\]

To prove this, DP.18 makes every map kill \(\epsilon_\lambda^{b_\lambda}\). Conversely choose a target Jordan chain of length \(d=d_{e^{a\lambda}}>0\). If \(d\ge r_\lambda\), choose \(v\) of nilpotent length exactly \(r_\lambda\) within that chain; if \(d<r_\lambda\), take a top vector of length \(d\). The vectors \(v,Lv,\ldots,L^{b_\lambda-1}v\) are independent, so the map defined by this \(v\) has kernel exactly the displayed ideal in that source block. Set the other source-block maps to zero. This also proves DP.21 in the presence of exponential collisions. If \(d=0\), the displayed ideal is the entire source block.

The quotient has a canonical faithful realization in a pure target without choosing individual maps:

\[
\mathrm{ev}:E\longrightarrow
 \operatorname{Hom}_{\mathbb C}(\mathscr T,V),
\qquad \mathrm{ev}(x)(T)=T(x),
\qquad \ker\mathrm{ev}=K_F.
\tag{DP.22}
\]

The operator on its target is \(F_{\mathrm{out}}\phi=F\circ\phi\). For every \(T\), \(\mathrm{ev}(Ux)(T)=TUx=FTx\), hence \(\mathrm{ev}\,U=F_{\mathrm{out}}\mathrm{ev}\). The target is a direct sum of \(\dim\mathscr T\) copies of \((V,F)\), so it is pure of the same weight. Thus DP.22 induces an injection of \(E/K_F\) onto its actual image. This construction is the maximal quotient detected by all maps of the required type to the specified \(F\). It supplies a complete typed relation rather than replacing a missing faithful map by an assertion of unrelatedness.

In particular, even a critical block can be invisible when its exponential eigenvalue is absent from \(F\). A semisimple target has \(d_\mu=1\), so all higher critical nilpotents are killed by DP.21. A nonsemisimple pure target can preserve them up to its actual Jordan length. No reduction to simple zeros is justified by purity alone.

## 5. A weight-matched tensor construction from the original arithmetic packet

Let \(h\) be the original finite packet polynomial, with its full actual zero orders, and retain

\[
E_h=\mathbb C[s]/(h),\quad A_h=M_s,\quad
\upsilon_h=j_h(g/h),\quad g=2\xi.
\tag{DP.23}
\]

The original packet uses the product of its monic linear powers, so \(h\) is monic in this construction. If an earlier presentation carried a nonzero scalar leading factor, the ideal map is multiplication by that recorded scalar and the factor in \(g/h\) must be retained; no such factor is set to one here. Complete zero orders make \(\upsilon_h\) a unit in the actual finite algebra. Its inverse is \(j_h(h/g)\), with the quotient analytically filled at every selected zero.

For the fixed tensor degree \(k\), let

\[
\mathcal E_k=E_h^{\otimes k},\qquad
\mathcal A_k=\sum_{j=1}^k
 I^{\otimes(j-1)}\otimes A_h\otimes I^{\otimes(k-j)},
\quad v_k=1_h^{\otimes k}.
\tag{DP.24}
\]

Let \(\chi_{h,k}\) be the original minimal annihilator of the cyclic vector \(v_k\) under \(\mathcal A_k\). This is the sum polynomial already used in the source, with all its multiplicities. Polynomial evaluation gives the injective map

\[
\iota_k:E_{h,k}=\mathbb C[S]/(\chi_{h,k})\longrightarrow\mathcal E_k,
\quad [P]\longmapsto P(\mathcal A_k)v_k.
\tag{DP.25}
\]

Indeed its kernel in \(\mathbb C[S]\) is the ideal generated by that minimal annihilator, proving injectivity on the displayed quotient. Multiplication by \(S\) gives \(\mathcal A_k\iota_k=\iota_k A_k\), where \(A_k=M_S\). Let \(U_k=M_{\upsilon_h}^{\otimes k}\). Each tensor factor of this unit is a polynomial in the corresponding \(A_h\); hence \(U_k\) commutes with \(\mathcal A_k\). It is invertible with inverse \(M_{j_h(h/g)}^{\otimes k}\). Therefore

\[
\eta_{h,k}=U_k\iota_k,
\qquad \mathcal A_k\eta_{h,k}=\eta_{h,k}A_k,
\qquad \eta_{h,k}\text{ is injective}.
\tag{DP.26}
\]

This is precisely the original arithmetic inclusion. It retains the full Taylor unit rather than replacing it by a basis convention. At the source level the already defined original map satisfies

\[
J^{(k)}\mathcal V_{h,k}=\eta_{h,k}\pi_{\chi_{h,k}},
\quad \mathcal V_{h,k}P=P(D_1+\cdots+D_k)F_h^{\otimes k},
\quad \mathcal M F_h=g/h.
\tag{DP.27}
\]

In particular the arithmetic source being embedded is the original one.

Apply DP.1--DP.4 to the original degree-\(d_h\) polynomial \(h\), with independent parameters \(t_1,\ldots,t_k\) and the same nonzero parameter \(u\). Tensor the resulting coefficient complexes over
\(\mathbb C[u,t_1,\ldots,t_k]\). The total differential has the usual signs: on a homogeneous tensor it differentiates the \(j\)-th factor with sign \((-1)^{e_1+\cdots+e_{j-1}}\), where \(e_i\in\{0,1\}\) are the preceding cochain degrees. The direct decomposition in DP.3 contracts each factor onto its free degree-one remainder module: its other summand is an isomorphism from its degree-zero module onto its own differential image. Tensoring these decompositions leaves exactly the tensor of the degree-one remainders in degree \(k\); every summand containing one of the isomorphism complexes is contracted using its inverse, with the same total-complex signs. Thus the tensor cohomology is free of rank \(d_h^k\), concentrated in degree \(k\), and its special fibre is \(\mathcal E_k\).

The parameter connections commute on distinct factors. Their recovered sum is

\[
\mathfrak A=-u\sum_{j=1}^k\nabla_{t_j}
=-u\sum_{j=1}^k\partial_{t_j}
 +\sum_{j=1}^k A_h(t_j)^{[j]},
\qquad
\mathfrak A\bmod(u,t_1,\ldots,t_k)=\mathcal A_k.
\tag{DP.28}
\]

Here the bracket means insertion in that tensor factor. This is the sum, with no division by \(k\).

Let \(\Pi_h(u,t_j)\) be the full period matrix in the original ray ordering, including every unsquared phase. Fix \(u\ne0\) in a sector with the stated choice of \(\arg u\); the labelled rays have angles \(\theta_r=(\arg u+\pi)/(d_h+1)+2\pi r/(d_h+1)\), and \(\Gamma_r=-\ell_0+\ell_r\), \(1\le r\le d_h\). Each \(t_j\) is an arbitrary complex parameter. Its invertibility follows directly as follows. At the monomial potential the \((r,b)\) period is a nonzero Gamma/ray factor times \(\zeta^{r(b+1)}-1\), with \(\zeta^{d_h+1}=1\). A column dependence would give a polynomial of degree at most \(d_h\) vanishing at all \(d_h+1\) roots of unity, hence every coefficient is zero. Along a straight coefficient path the periods satisfy \(\Pi'=\Pi B\), because integration of the image of DP.2 is an exact derivative and the endpoints vanish. Uniform domination by a negative leading exponential times a polynomial justifies each derivative. The adjugate determinant identity yields \((\det\Pi)'=(\operatorname{Tr}B)\det\Pi\), so its initially nonzero determinant never vanishes. This argument includes repeated roots.

Consequently the map

\[
\mathscr P_k(u,\mathbf t)
=\Pi_h(u,t_1)\otimes\cdots\otimes\Pi_h(u,t_k)
:\mathcal E_k\longrightarrow\mathbb C^{d_h^k}
\tag{DP.29}
\]

is invertible, with inverse the tensor of the exact inverses. The original arithmetic cyclic source therefore has the explicit injective rectangular period map

\[
P_{h,k}(u,\mathbf t)=\mathscr P_k(u,\mathbf t)\eta_{h,k}
:E_{h,k}\hookrightarrow\mathbb C^{d_h^k}.
\tag{DP.30}
\]

Holding \(\eta_{h,k}\) fixed in its original marked coordinates, the individual period equations and DP.26 give the exact first-order identity at \(\mathbf t=0\):

\[
-u\sum_{j=1}^k\partial_{t_j}P_{h,k}(u,0)
=\mathscr P_k(u,0)\mathcal A_k\eta_{h,k}
=P_{h,k}(u,0)A_k.
\tag{DP.31}
\]

The nilpotent blocks are retained because DP.30 is injective and DP.31 intertwines the displayed recovered action. No invariance of its image under all deformed \(A_h(t_j)\), and no missing higher-order period identity, is assumed.

For any original finite-cutoff positive Gram \(G_{k,N}\), put \(P=P_{h,k}(u,0)\) and \(L=(P^*P)^{-1}P^*\). Then \(LP=I\), and the concrete positive form on \(\operatorname{im}P\) is the restriction of \(L^*G_{k,N}L\). Its pullback is

\[
P^*L^*G_{k,N}LP=G_{k,N}.
\tag{DP.32}
\]

The action on that image is \(PA_kL\), and its control form pulls back to \(A_k^*G_{k,N}+G_{k,N}A_k-kG_{k,N}\). Thus every original mass, source norm, and generalized defect is preserved by an actual metric-and-action map. The ambient form may be degenerate outside the image; no positive extension or orthogonal-complement invariance is asserted.

There is a finite coefficient model retaining this injection. Form the finitely generated subring of \(\mathbb C\) containing the coefficients of \(h\), \(\chi_{h,k}\), \(\upsilon_h\), its inverse, and the matrices in DP.25--DP.26, together with all denominators \(1/(d_h+1)!\). Since \(\eta_{h,k}\) has full column rank, choose one of its nonzero square maximal minors \(\Delta\) and adjoin \(\Delta^{-1}\). Call the resulting ring \(R_{h,k}\). The selected rows give a left inverse by their adjugate divided by \(\Delta\). Thus \(\eta_{h,k}\) is a split injection over this very ring, and its action identity holds there because every entry is an element of its subring in \(\mathbb C\) and the equality holds in \(\mathbb C\).

For each specified reduction \(R_{h,k}\to\mathbb F_Q\) with \(p>d_h+1\), the same matrices remain a split injection and intertwiner of the reduced coefficient algebras. Its reduced cyclic image is therefore isomorphic, through those matrices, to the literal quotient \(\mathbb F_Q[S]/(\overline\chi_{h,k})\). Every nilpotent power of that reduced image is the corresponding power in this quotient, including any root collisions after reduction. The nonzero minor used for this particular finite construction has been inverted. This does not claim that every prime is allowed or that one localization works for unbounded \(k\).

On the finite-field branch, form the **external product** of the \(k\) original one-variable nontrivial additive-character sheaves. The Künneth map for compact support identifies its degree-\(k\) cohomology, with product-coordinate orientation, with

\[
\bigotimes_{j=1}^k
H_c^1(\mathbb A^1_{\overline{\mathbb F}_Q},
 \mathcal L_{\psi}(\Phi_{h,t_j}/u)).
\tag{DP.33}
\]

Each factor is concentrated in degree one and pure of weight one by the checked theorem. Thus DP.33 is concentrated in degree \(k\), has rank \(d_h^k\), and is pure of weight \(k\): its Frobenius is the tensor product, whose eigenvalues are all products of the factor eigenvalues. To see the last assertion including nonsemisimple factors, triangularize each complex coefficient realization; the tensor basis makes the tensor product triangular, with precisely those products on its diagonal. Each product has modulus \((\sqrt Q)^k\). The alternating trace sign is \((-1)^k\), agreeing with the product of the \(k\) one-variable negative trace signs.

The retained construction therefore has a weight-matched common coefficient span, with DP.28--DP.32 on its complex side and DP.33 on its finite-field side. The reduced finite coefficient injection is not, by its existence, a map into the separate \(\ell\)-adic cohomology. A specified operator-compatible comparison with that target is governed exactly by DP.13--DP.22. This locates the remaining comparison inside an explicit surviving geometric construction, preserving the arithmetic input and tensor degree throughout.

## 5A. Placement inside the original cohomology program over the privileged tau point

The preceding tensor construction is now placed in the actual base program, using the complete original `Tau_Base_Cohomology_2026-09-12/NOTE.md`, read in full. It does not replace that base by a finite field.

Retain the original pointed blueprint

\[
\mathbf F_{1,\tau}=\{\tau,1\},\qquad
\mathfrak b_\tau=\operatorname{Spec}\mathbf F_{1,\tau},
\quad \jmath_R:\mathbf F_{1,\tau}\to B_R,
\quad \tau\mapsto\tau,\quad1\mapsto1_R^\bullet.
\tag{DB.1}
\]

Its additive zero relation is that the empty sum represents \(\tau\); no Boolean equation \(1+1=1\) is introduced into this base. For each original nonzero ring \(R\), \(B_R\) is the blueprint of \(G(R)=\{\tau\}\sqcup R^\bullet\) with its original additive relations. A prime of \(B_R\) contains \(\tau\) and does not contain the multiplicative identity. Its inverse image under \(\jmath_R\) is therefore exactly \(\{\tau\}\). This proves that the structural spectrum map lands at the single privileged point through the actual prime inverse-image map. The arithmetic map \(p_R(\tau)=0\), \(p_R(r^\bullet)=r\), and the Boolean support map \(b_R(\tau)=0\), \(b_R(r^\bullet)=1\), remain attached. Their pair is injective, since support separates \(\tau\) from every represented element and amplitude distinguishes represented elements. The map here is DB.1; the separate localization that forces \(e_R=1\) is not performed.

For a coefficient map \(\varphi:R\to R'\), its split lift satisfies

\[
G(\varphi)\jmath_R=\jmath_{R'},\qquad
p_{R'}G(\varphi)=\varphi p_R,\qquad
b_{R'}G(\varphi)=b_R.
\tag{DB.2}
\]

Each equality follows on \(\tau\) and on each \(r^\bullet\), the two exhaustive kinds of elements. Apply DB.2 to the maps from \(R_{h,k}\) in DP.26--DP.33, to the complex coefficient realization, and to every specified finite-field reduction. All these diagrams remain over the same \(\mathfrak b_\tau\).

There is an exact categorical version for the linear fibres. For an \(R\)-module \(M\), set \(M^\tau=\{\tau\}\sqcup M^\bullet\), with

\[
v^\bullet+w^\bullet=(v+w)^\bullet,\quad
r^\bullet v^\bullet=(rv)^\bullet,
\quad \tau+z=z,
\quad \tau z=\tau,
\quad r^\bullet\tau=\tau.
\tag{DB.3}
\]

For an \(R\)-linear map \(f:M\to N\), its lift sends \(\tau\) to \(\tau\) and \(v^\bullet\) to \(f(v)^\bullet\). This is \(G(R)\)-linear by the two ordinary linearity identities and the rules for \(\tau\). Conversely, a \(G(R)\)-linear map between these objects which preserves represented support restricts to a map \(f:M\to N\). Its additive and scalar identities are exactly the original \(R\)-linear identities. Moreover its value on \(0_M^\bullet=e_Rv^\bullet\) is \(0_N^\bullet\). Thus this gives a fully faithful equivalence with the category consisting of these split module objects and support-preserving maps.

In that category the zero morphism is the supported-zero map \(v^\bullet\mapsto0_N^\bullet\), with \(\tau\mapsto\tau\). The zero object is \(\{\tau,0^\bullet\}\). These assertions follow either by the fully faithful correspondence or directly from DB.3: each zero-object arrow preserving support is forced, and composition through it gives exactly that supported-zero map. Consequently the original equation \(d^{i+1}d^i=0\) is carried to the correct supported-zero composition, preserving the separate absorbing element. This supplies the precise linear-fibre category in which the original support cohomology is reconstructed. With the several masks of the source, apply it at each admitted mask and retain all inclusion transports; do not tensor the masks as if they were unrecorded vector coordinates.

Now retain the actual chart poset

\[
+<\eta<\sigma,\qquad -<\eta<\sigma,
\quad\mathcal A=\operatorname{Fun}(P,\operatorname{Vect}_{\mathbb C}),
\tag{DB.4}
\]

and the actual coefficient sheaf

\[
\mathcal T_+=\mathcal T_-=V,\quad
\mathcal T_\eta=\mathscr B,\quad\mathcal T_\sigma=0,
\quad r_+=\Theta,\quad r_-=\Theta\mathcal F=J\Theta.
\tag{DB.5}
\]

The \(J\) in DB.5 is the original reflection \(JF(x)=x^{-1}F(1/x)\); the finite jet map below is written \(J_Z\). Let \(P_x(y)=\mathbb C\) for \(x\le y\) and zero otherwise. Evaluation gives \(\operatorname{Hom}(P_x,F)=F_x\), hence these diagrams are projective. The sequence

\[
0\to P_\eta\xrightarrow{v\mapsto(v,-v)}P_+\oplus P_-
 \xrightarrow{(u,v)\mapsto u+v}\mathbf C\to0
\tag{DB.6}
\]

is exact: at \(+\) and \(-\) its last map is the identity, and at \(\eta\) and \(\sigma\) its kernel is exactly the displayed anti-diagonal. Each map commutes with the poset arrows because its entries are the same scalar identity at all nonzero stalks. Applying \(\operatorname{Hom}(-,F)\) proves

\[
\mathsf A_\tau(F)=R\Gamma(P,F)
\simeq[F_+\oplus F_-\xrightarrow{r_+-r_-}F_\eta].
\tag{DB.7}
\]

On DB.5 this is the original two-leg theta complex. Its degree-zero kernel consists of \((\widehat\psi,\psi)\), since \(\Theta\) is injective, and its degree-one quotient is \(Q\). This identifies the actual arithmetic cohomology over the privileged base point. Restriction to the \(\sigma\) stalk is a separate map: its two degree-zero representatives \(r_{+\sigma}x\) and \(r_{-\sigma}y\) differ by \(r_{\eta\sigma}(r_+x-r_-y)\), so the homotopy is exactly \(r_{\eta\sigma}\). This proves its derived comparison to DB.7 without replacing global cohomology by the support stalk.

Define \(I_x(W)(y)=W\) for \(y\le x\) and zero otherwise. The identity \(\operatorname{Hom}(F,I_xW)=\operatorname{Hom}(F_x,W)\) and exactness of evaluation show that each is injective over \(\mathbb C\). Dualizing DB.6 gives

\[
K_\tau(W)=
[I_\eta W\xrightarrow{(+\mathrm{res},-\mathrm{res})}
 I_+W\oplus I_-W]
\quad\text{in degrees }-1,0.
\tag{DB.8}
\]

Applying \(\operatorname{Hom}(F,-)\) gives the explicit differential \(\ell\mapsto(\ell r_+,-\ell r_-)\), which is the dual of DB.7. This proves its stated adjunction to \(\mathsf A_\tau\). The stalk complexes at \(+,-\) are \([W\xrightarrow{1}W]\) and \([W\xrightarrow{-1}W]\), so they are acyclic; at \(\eta\) the sole term is \(W\) in degree \(-1\), and at \(\sigma\) all terms vanish. Thus \(K_\tau(W)\simeq S_\eta W[1]\), with the exact inherited shift.

Tensor DB.6 over \(\mathbb C\) in the fixed factor order to resolve the constant diagram on \(P^k\). Its differential is the signed sum with sign \((-1)^{\sum_{i<j}e_i}\). In top degree the actual coefficient numerator is \(\mathscr B^{\otimes k}\), and the boundary subspace is the sum of tensors with \(\Theta V\) in at least one factor. Quotienting one factor at a time proves, by the defining relations of the tensor quotient,

\[
H^k\mathsf A_{\tau,k}(\mathcal T^{\boxtimes k})
=Q^{\otimes k},\qquad
K_{\tau,k}(W)\simeq S_{(\eta,\ldots,\eta)}W[k].
\tag{DB.9}
\]

The second identity follows by the same dual tensor resolution: any stalk with at least one \(+\) or \(-\) factor contains its signed two-term identity contraction, any \(\sigma\) factor gives zero, and the all-\(\eta\) stalk has exactly \(W\) in degree \(-k\). This proves the product right-adjoint calculation with its signs and no deleted cohomological shift.

Use the actual full-jet map \(J_Z:\mathscr B\to E_h\). Since \(\mathcal M\Theta\phi=gH_\phi\), its jets vanish through every full selected zero order; only holomorphy in neighborhoods of those selected zeros in the strip is required here. The map with component \(J_Z\) at \(\eta\) and zero at the other stalks is therefore a sheaf map \(\mathcal T\to S_\eta E_h\). Its tensor product gives the actual top-cohomology arrow

\[
\mathcal J_k:
H^k\mathsf A_{\tau,k}(\mathcal T^{\boxtimes k})=Q^{\otimes k}
\longrightarrow\mathcal E_k,
\qquad\mathcal J_k=\overline J_Z^{\otimes k}.
\tag{DB.10}
\]

It is surjective because \(\overline J_Z\sigma_Z=I\) in the original full-order packet; tensoring that explicit right inverse gives a right inverse of DB.10. Compose the other way with the original cyclic inclusion to obtain the arithmetic split pair

\[
\sigma_Z^{\otimes k}\eta_{h,k}:E_{h,k}\hookrightarrow Q^{\otimes k},
\qquad
\mathcal J_k\sigma_Z^{\otimes k}\eta_{h,k}=\eta_{h,k}.
\tag{DB.11}
\]

Thus DP.30 is the period realization of the actual cyclic submodule of this tau-base cohomology: the map is \(\mathscr P_k\mathcal J_k\) restricted through DB.11. The units in \(\eta_{h,k}\), the full jets, and the original cochain representative boundaries are all present. On top cohomology the scaling action is \(U_a^{\otimes k}\); its exact intertwining through DB.10 and DB.11 is \(e^{(\log a)\mathcal A_k}\eta_{h,k}=\eta_{h,k}e^{(\log a)A_k}\). This follows from DP.26 by the convergent exponential series, or by its finite nilpotent expansions on each block.

The original right-adjoint dual injection also extends to this cyclic module. For the original reflection-stable packet \(Z\), let \(R_Z\) be the full residue form from the tau-base note,

\[
R_Z(f,v)=\sum_{\rho\in Z}\operatorname{Res}_{\rho}
 \frac{f^\dagger(s)v(s)}{g(s)}ds,
\qquad f^\dagger(s)=\overline{f(1-\bar s)}.
\tag{DB.12}
\]

Its local denominator is the actual \(g=z^m u(z)\), \(u(0)\ne0\). Multiplication by \(u^{-1}\) is an invertible triangular Taylor map; extracting the coefficient of \(z^{m-1}\) pairs powers \(z^j,z^{m-1-j}\) with nonzero anti-diagonal. Reflection sends the opposite block's \(z^j\) to \((-1)^j\bar z^j\) in coefficients. Hence this sesquilinear form is nondegenerate on the full finite direct sum, retaining all nilpotents and the exact reflection signs. Tensor its numerical values in the fixed order to get a nondegenerate sesquilinear pairing \(R_Z^{\otimes k}\) on \(\mathcal E_k\); the tensor Gram is the tensor of invertible Grams and has the tensor of their inverses. No phase is inserted to claim positivity. In particular the skew-Hermitian parity is retained as \((-1)^k\) under conjugate exchange.

Let \(\mathcal L_k=\mathcal L_1^{\otimes k}\) be the original moment line, with scaling action \(a^k\). Define

\[
\begin{aligned}
\mathcal D_{h,k}:\overline{E_{h,k}}&\longrightarrow
H^{-k}R\operatorname{Hom}_{\mathcal A(P^k)}
 (\mathcal T^{\boxtimes k},K_{\tau,k}(\mathcal L_k))\\
&\cong\operatorname{Hom}_{\mathbb C}(Q^{\otimes k},\mathcal L_k),\\
\mathcal D_{h,k}(\bar x)(q)&=
R_Z^{\otimes k}(\eta_{h,k}x,\mathcal J_k q).
\end{aligned}
\tag{DB.13}
\]

The displayed cohomological identification follows from the adjunction DB.8--DB.9: over the field, taking the algebraic dual is exact, so degree \(-k\) is the dual of top degree \(k\). The formula is linear in \(\bar x\). It is well-defined on \(Q^{\otimes k}\) because DB.10 is, including every theta relation. If it vanishes for all \(q\), surjectivity of DB.10 and nondegeneracy of the tensor residue form imply \(\eta_{h,k}x=0\); injectivity of DP.26 then implies \(x=0\). Thus DB.13 is an actual injection to the computed tau-base dual object.

For real \(a>0\), the original scaling multiplier satisfies \((a^s)^\dagger=a^{1-s}\). Multiplying the two factors in DB.12 therefore gives exactly \(a\), so \(R_Z(U_af,U_av)=aR_Z(f,v)\), including the full Taylor expansions. Tensoring gives the factor \(a^k\). On the algebraic dual the action is \((U_a\ell)(q)=a^k\ell(U_a^{-\otimes k}q)\). It follows by direct substitution in DB.13 that this injection is equivariant with the conjugate of the original cyclic scaling action. This proves the tensor counterpart of the original tau-base note's (43), with \(K_{\tau,k}\) and the correct moment line, rather than leaving the pairing outside the cohomological model.

Finally, each nonempty original support mask retains its copy of the coefficient complex and each transport retains its stated linear map. Reconstructing them by DB.3 gives the supported degree-one object \(\{\tau\}\sqcup\coprod_{A\ne\varnothing}\{A\}\times Q\) and the original tensor supported cohomology. All maps DB.10--DB.13 preserve the admitted mask; a zero amplitude maps to that mask's supported zero and external absence maps to \(\tau\). The dual mask arrows are precomposition in the opposite mask category, as in the original note. This completes the placement of the weight-matched auxiliary tensor comparison **inside** the actual split cohomology program over \(\mathfrak b_\tau\).

## 6. Original critical-line comparison and the retained kernel

The complete local proof of the critical-only comparison and of the arbitrary-polynomial theta sequence is supplied in the companion `deligne_bound_critical_kernel_subreview_20260913.md`. Its sources were read in full independently. The exact sequence from the original theta complex is

\[
0\longrightarrow Q[h_0(D)]\longrightarrow E_{h_0}
 \xrightarrow{\times j_{h_0}g}E_{h_0}
 \longrightarrow Q/h_0(D)Q\longrightarrow0.
\tag{DP.34}
\]

The first arrow sends a class represented by \(F\), with \(h_0(D)F=\Theta\phi\), to \(j_{h_0}H_\phi\). It is independent of the representative because changing \(F\) by \(\Theta\psi\) changes \(\phi\) by \(h_0(D)\psi\). The source and target Euler inverse formulas in `arithmetic_input.tex` show that this arrow identifies \(Q[h_0(D)]\) with the kernel of the displayed multiplication. The target jet map identifies its cokernel with \(Q/h_0(D)Q\). This retains the exact theta source, not an arbitrary test spectral model.

At a selected centre, write \(\epsilon=s-\rho\),
\(h_0=\epsilon^n a\), \(g=\epsilon^m u\), with \(a(\rho)u(\rho)\ne0\), and \(r=\min(n,m)\); when \(g(\rho)\ne0\), set \(m=r=0\). In \(\mathbb C[\epsilon]/\epsilon^n\), multiplication by \(j_{h_0}g\) has kernel \((\epsilon^{n-r})/(\epsilon^n)\) and cokernel \(\mathbb C[\epsilon]/\epsilon^r\). Indeed the factor \(u\) is invertible and multiplication by \(\epsilon^m\) has precisely these kernel and image ideals. These formulas prove that vanishing occurs whenever \(n\le m\), including undercounted orders. Exact full order \(n=m\) makes \(g/h_0=u/a\) a unit; it is that unit which appears in DP.23 and the full packet retraction. The precise local map from the kernel to the quotient, through the original cohomology, is proved in the companion, so that no equality between two different jet presentations is presumed here.

For a full actual packet \(Z\), the existing Connes comparison has

\[
T_Z=\Gamma\sigma_Z:E_Z\longrightarrow
\mathcal S(\mathbb R)/\overline{\zeta(1/2+it)\mathcal S(\mathbb R)},
\qquad \ker T_Z=E_{Z,\mathrm{off}}.
\tag{DP.35}
\]

The full higher-jet inverse on the selected critical blocks identifies its actual image with \(E_{Z,\mathrm{crit}}\). Thus DP.35 yields an exact equivariant sequence

\[
0\longrightarrow E_{Z,\mathrm{off}}
\longrightarrow E_Z\xrightarrow{T_Z}\operatorname{im}T_Z
\longrightarrow0,
\tag{DP.36}
\]

with the canonical primary splitting of its source. Its two-term comparison complex \([E_Z\xrightarrow{T_Z}\operatorname{im}T_Z]\), in degrees zero and one, has degree-zero cohomology \(E_{Z,\mathrm{off}}\) and degree-one cohomology zero. The inclusion of the kernel in degree zero is therefore a quasi-isomorphism. If the full target is retained instead, degree-one cohomology is its quotient by \(\operatorname{im}T_Z\); it must not be silently set to zero. This is an exact derived record of everything killed by the critical comparison.

For any receiving vector-space fibre labelled by \(\lambda\), the split lift of a linear map is

\[
\widetilde T(\tau)=\tau,
\qquad \widetilde T(\lambda,v)=(\lambda,Tv).
\tag{DP.37}
\]

The preimages are exactly

\[
\widetilde T^{-1}\{(\lambda,0)\}
=\{(\lambda,v):v\in\ker T\},
\qquad \widetilde T^{-1}\{\tau\}=\{\tau\}.
\tag{DP.38}
\]

Consequently DP.35 retains its full off-critical kernel as supported source vectors. The support observation distinguishes those vectors from external absence; it does not turn an annihilating linear map into an injection. At the same time DP.36 gives the precise surviving morphism and the complex that records the lost blocks. That is a structural continuation of the program, not a refutation of it.

## 7. Acceptance and the next exact arithmetic calculation

Equations (12)--(13), (17)--(24), (26)--(27), and (44)--(50) of the delivered note have the stated mathematical scope after the character-summand clarification. The note's full-order sentence following (57) needs the distinction proved in DP.34. Its quantitative Gamma estimate is covered by the separate independent Gamma review; this document does not convert a full reading of that section into an independent numerical or all-\(k\) certificate.

The note's period congruence is exact: with a common invertible \(\Pi\),
\(\widetilde G=\Pi^{-*}G\Pi^{-1}\) and
\(\widetilde W=\Pi^{-*}W\Pi^{-1}\) give
\(\widetilde G^{-1}\widetilde W=\Pi(G^{-1}W)\Pi^{-1}\) by direct multiplication. In particular every generalized eigenvalue and every common-index determinant ratio is retained. This is consistent with the faithful tensor map DP.30 and the original theta relation DP.27.

The actual arithmetic multiplier still enters the two source metrics through their identity coefficient map and their different least-norm sections. Its signed endpoint determinant correction in delivered (54) remains an exact quantity in the program. The present audit neither assumes that correction is small nor replaces its calculation by a condition. It establishes the full comparison diagram that remains valid while that source-specific calculation proceeds.

The phrase “the F1 geometry program has failed” does not follow from this package. A defensible conclusion is: the displayed auxiliary purity, by itself and through the existing maps, does not force the desired original theta-source estimate. The exact failures and surviving maps have now been calculated, including a weight-\(k\) tensor construction and the complete target-dependent comparison kernel.

## Source pins and actual reading record

The companion JSON records SHA-256, byte counts, and reading scope for every selected source, this review, and the independent critical-kernel proof. The new delivered note was read completely. `arithmetic_input.tex`, `Exponential_Translation_Comparison.tex`, and the primary correction were read completely. The SGA trace-period note was read from Sections 6 through 12, including all coefficient, period, tensor-weight, and metric formulas used above. The original Deligne scan was visually inspected on complete printed pages 215--216 only. The retained S20 text is a location aid; the original scan supplies the theorem typography.

No Lean invocation, remote mutation, whole-library audit, or numerical certification is claimed in this review.
