# Exact spectra and trace spread of the original four relation windows

13 September 2026. Independent mathematical continuation of the original arithmetic determinant transport. This note leaves the sealed transport TeX and its PDF unchanged. It derives the complete spectra of the actual window operators, proves the spectral trace extremum directly, and integrates it against the original relative Gram eigenvalues. The packet, tensor degree, polynomial coordinate, measures, and all four cutoff indices remain fixed.

## 1. Original common source and projections

Fix the original actual packet \(h\), tensor degree \(k\ge1\), and its literal cyclic annihilator \(\chi=\chi_{h,k}\), of degree \(q\ge1\). Keep the common coefficient space

\[
\mathcal H=\mathcal P_{2q}=\mathbb C[S]_{\le2q},
\qquad \dim\mathcal H=n=2q+1,
\tag{WS1}
\]

with its original increasing-power frame. Let \(M_0\) and \(M_1\) be the two actual positive source Grams at this cutoff, retaining the Gamma mass and arithmetic mass. Set

\[
M(t)=(1-t)M_0+tM_1,
\quad \Delta M=M_1-M_0,
\quad D=M_0^{-1}M_1,
\quad C(t)=M(t)^{-1}\Delta M,
\quad 0\le t\le1.
\tag{WS2}
\]

No rescaling of either Gram is performed. Positivity of \(M(t)\) follows because its quadratic form on a nonzero vector is a convex combination of two strictly positive numbers.

Write \(P_N(t)\) for the \(M(t)\)-orthogonal projection onto the original coefficient subspace \(\mathcal P_N\). Write \(Q_N(t)\) for the same-metric orthogonal projection onto

\[
\mathcal R_N=\chi\mathcal P_{N-q},
\qquad \mathcal P_{-1}=0,
\qquad N\ge q-1.
\tag{WS3}
\]

Multiplication by the nonzero polynomial \(\chi\) is injective, so \(\dim\mathcal R_N=N-q+1\). In particular \(Q_{q-1}=0\). These are the original relation images, with every power of \(\chi\) and every finite coefficient retained.

The two actual operators are

\[
\begin{aligned}
U(t)&=(Q_{2q-1}-Q_{q-1})+(Q_{2q}-Q_q)
     =Q_{2q-1}+Q_{2q}-Q_q,\\
W(t)&=(P_{2q-1}-P_{q-1})+(P_{2q}-P_q).
\end{aligned}
\tag{WS4}
\]

All projections in WS4 are computed in the one space WS1 with the same form \(M(t)\). Every equation below is pointwise in this retained parameter unless an integral is displayed.

For completeness, if \(E\subseteq F\) are subspaces and \(P_E,P_F\) their orthogonal projections for that form, then \(P_FP_E=P_E\) because \(P_Ev\in F\). Also \(P_E P_F=P_E\), because \(v-P_Fv\in F^\perp\subseteq E^\perp\). Hence \(P_F-P_E\) is self-adjoint, idempotent, and has image \(F\cap E^\perp\). This proves every nested-projection decomposition used below; none of them assumes unrelated subspaces are orthogonal.

## 2. The exact relation and polynomial window spectra

The original relation spaces have the nested flag

\[
\mathcal R_q=\chi\mathcal P_0
\subseteq\mathcal R_{2q-1}=\chi\mathcal P_{q-1}
\subseteq\mathcal R_{2q}=\chi\mathcal P_q,
\tag{WS5}
\]

of dimensions \(1,q,q+1\). For \(q=1\), the first two spaces coincide; the following middle complement is then the zero space. Define

\[
\begin{aligned}
L_{U,0}&=\mathcal R_{2q}^{\perp},\qquad &&\dim L_{U,0}=q,\\
L_{U,1a}&=\mathcal R_q, &&\dim L_{U,1a}=1,\\
L_{U,2}&=\mathcal R_{2q-1}\cap\mathcal R_q^{\perp},
&&\dim L_{U,2}=q-1,\\
L_{U,1b}&=\mathcal R_{2q}\cap\mathcal R_{2q-1}^{\perp},
&&\dim L_{U,1b}=1.
\end{aligned}
\tag{WS6}
\]

The four spaces are mutually orthogonal and their dimensions add to \(2q+1\). The flag decomposition proves that they span \(\mathcal H\). On them the three summands in \(U\) act respectively as follows:

\[
\begin{array}{c|rrrr}
&L_{U,0}&L_{U,1a}&L_{U,2}&L_{U,1b}\\\hline
Q_{2q-1}&0&1&1&0\\
Q_{2q}&0&1&1&1\\
Q_q&0&1&0&0\\\hline
U&0&1&2&1
\end{array}
\tag{WS7}
\]

Every entry is a restriction of the actual projection, not an assigned new operator.

The original polynomial flag is

\[
\mathcal P_{q-1}\subseteq\mathcal P_q
\subseteq\mathcal P_{2q-1}\subseteq\mathcal P_{2q}=\mathcal H.
\tag{WS8}
\]

Its dimensions are \(q,q+1,2q,2q+1\); the middle two coincide for \(q=1\). The corresponding four orthogonal pieces are

\[
\begin{aligned}
L_{W,0}&=\mathcal P_{q-1},&&\dim L_{W,0}=q,\\
L_{W,1a}&=\mathcal P_q\cap\mathcal P_{q-1}^{\perp},
&&\dim L_{W,1a}=1,\\
L_{W,2}&=\mathcal P_{2q-1}\cap\mathcal P_q^{\perp},
&&\dim L_{W,2}=q-1,\\
L_{W,1b}&=\mathcal H\cap\mathcal P_{2q-1}^{\perp},
&&\dim L_{W,1b}=1.
\end{aligned}
\tag{WS9}
\]

On these pieces \(P_{2q-1}-P_{q-1}\) has respective values \(0,1,1,0\), while \(I-P_q=P_{2q}-P_q\) has respective values \(0,0,1,1\). Therefore \(W\) acts by \(0,1,2,1\).

Combining WS6--WS9 proves the complete spectra, including multiplicities:

\[
\boxed{\quad
\operatorname{spec}U=\operatorname{spec}W
=\{0^{[q]},\ 1^{[2]},\ 2^{[q-1]}\}.
\quad}
\tag{WS10}
\]

Both traces are \(2+2(q-1)=2q\). Both eigenvalue-two spaces have dimension zero when \(q=1\); no nonexistent vector or inverse is used.

Equivalently, introduce the actual spectral projections

\[
\begin{aligned}
E_{U,1}&=Q_{2q},&E_{U,2}&=Q_{2q-1}-Q_q,\\
E_{W,1}&=I-P_{q-1},&E_{W,2}&=P_{2q-1}-P_q.
\end{aligned}
\tag{WS11}
\]

They satisfy \(E_{X,2}\le E_{X,1}\), with ranks \(q-1\) and \(q+1\), respectively, and

\[
U=E_{U,1}+E_{U,2},\qquad
W=E_{W,1}+E_{W,2}.
\tag{WS12}
\]

This is also a useful direct explanation of the repeated eigenvalues in WS10.

## 3. Direct proof of the spectral trace extremum

Let \(C\) be any self-adjoint endomorphism of the same finite-dimensional Hilbert space, with eigenvalues

\[
c_1\le c_2\le\cdots\le c_n,
\qquad n=2q+1.
\tag{WS13}
\]

All repetitions are retained. By the finite spectral theorem there is an orthonormal eigenbasis \(e_1,\ldots,e_n\) for this **same** source form. This use of coordinates is an isometry of the original form, not a change of any vector's norm or any scalar mass.

For an orthogonal projection \(E\) of rank \(r\), put \(w_i=\langle e_i,Ee_i\rangle=\|Ee_i\|^2\). Then

\[
0\le w_i\le1,\quad\sum_iw_i=r,
\qquad\operatorname{Tr}(EC)=\sum_i c_iw_i.
\tag{WS14}
\]

For \(0<r<n\), set \(a=c_{n-r+1}\). The difference between the largest-\(r\) eigenvalue sum and the last expression is exactly

\[
\begin{aligned}
\sum_{i=n-r+1}^n c_i-\sum_{i=1}^n c_iw_i
={}&\sum_{i=n-r+1}^n(c_i-a)(1-w_i)\\
&+\sum_{i=1}^{n-r}(a-c_i)w_i\ \ge0.
\end{aligned}
\tag{WS15}
\]

To verify equality, expand the right side; its coefficient of \(a\) is
\(-r+\sum_{i=n-r+1}^nw_i+\sum_{i=1}^{n-r}w_i=0\), leaving the displayed difference. Each remaining summand is nonnegative because of the sorted eigenvalues and WS14. Applying this calculation to \(-C\) gives the lower bound. When \(r=0\) the trace and both sums are zero; when \(r=n\), \(E=I\) and both sides equal \(\sum c_i\). Thus in every case

\[
\sum_{i=1}^r c_i\le\operatorname{Tr}(EC)
\le\sum_{i=n-r+1}^{n}c_i.
\tag{WS16}
\]

This proof requires no strict eigenvalue inequality. It also gives the precise equality condition. At the upper endpoint, \(E\) is identity on all eigenspaces with eigenvalues strictly above the cutoff \(c_{n-r+1}\), zero on all eigenspaces strictly below it, and may select the needed rank within the cutoff eigenspace. Indeed a strict coefficient in WS15 forces \(w_i=1\) or \(w_i=0\), and those identities imply \(Ee_i=e_i\) or \(Ee_i=0\) by orthogonal projection. The lower endpoint has the reversed condition. Repeated cutoff values therefore allow their full indicated subspace choices rather than requiring a distinguished eigenbasis there.

Apply WS16 to each projection in WS11. Their ranks give, for \(X=U\) or \(W\),

\[
L_q(c)\le\operatorname{Tr}(XC)\le H_q(c),
\tag{WS17}
\]

where the exact endpoints are

\[
\begin{aligned}
L_q(c)&=2\sum_{j=1}^{q-1}c_j+c_q+c_{q+1},\\
H_q(c)&=c_{q+1}+c_{q+2}
       +2\sum_{j=q+3}^{2q+1}c_j.
\end{aligned}
\tag{WS18}
\]

The sums of length \(q-1\) are empty for \(q=1\). The upper bound is the sum of the largest \(q+1\) eigenvalues and the largest \(q-1\) eigenvalues; the lower bound is the corresponding sum of the smallest eigenvalues. They are attained by nested spectral subspaces of these ranks, so the rank bounds are simultaneously consistent with the nested form WS12.

Subtracting WS17 for \(U\) and \(W\), in both orders, proves

\[
\boxed{
\begin{aligned}
\left|\operatorname{Tr}((U-W)C)\right|
&\le H_q(c)-L_q(c)\\
&=c_{q+2}-c_q
 +2\sum_{j=1}^{q-1}(c_{2q+2-j}-c_j).
\end{aligned}}
\tag{WS19}
\]

No commutation between \(U\), \(W\), and \(C\) has been assumed. All traces are real: for self-adjoint \(X,C\), conjugating \(\operatorname{Tr}(XC)\) gives \(\operatorname{Tr}(CX)=\operatorname{Tr}(XC)\).

The bound in WS19 is the optimal one from the separate spectra WS10 and WS13. To prove this assertion explicitly, take the two endomorphisms whose diagonal entries in the eigenbasis of \(C\) are the list

\[
(0,\ldots,0,1,1,2,\ldots,2)
\quad\text{and its reverse}.
\tag{WS20}
\]

Their spectra are precisely WS10. The first attains \(H_q(c)\), the second \(L_q(c)\), and their difference attains the positive right side of WS19. Exchanging them attains the negative endpoint. This remains true for repeated \(c_i\), with equality inside any repeated block understood through WS15. It proves a sharp statement about the indicated unitary orbits; additional alignment information from the literal polynomial and relation flags remains available and can improve a particular instance.

## 4. Integration along the unchanged arithmetic Gram path

The original \(D=M_0^{-1}M_1\) is positive and self-adjoint for \(M_0\), because \(M_0D=M_1\) is Hermitian and its quadratic form is positive. Thus it is diagonalizable with positive eigenvalues

\[
0<b_1\le\cdots\le b_{2q+1},
\qquad\kappa=b_{2q+1}/b_1.
\tag{WS21}
\]

Factor WS2 in its actual order:

\[
M(t)=M_0((1-t)I+tD),
\qquad\Delta M=M_0(D-I),
\qquad
C(t)=((1-t)I+tD)^{-1}(D-I).
\tag{WS22}
\]

The denominator is invertible because each of its eigenvalues \(1-t+tb_i\) is positive. Also \(M(t)C(t)=\Delta M\) is Hermitian, proving self-adjointness for the exact source metric used in WS4. Functional calculus on the diagonalization of \(D\) gives its eigenvalues

\[
c_i(t)=\frac{b_i-1}{1-t+tb_i}.
\tag{WS23}
\]

The derivative of \((b-1)/(1-t+tb)\) with respect to \(b\) is exactly \((1-t+tb)^{-2}>0\). Hence the same ordered list WS21 supplies the ordered list WS13 at every \(t\), including \(t=0,1\), repeated eigenvalues, and values \(b_i=1\). No eigenvalue branch relabelling is needed.

The original determinant transport proves, with these exact projections,

\[
\Delta\mathcal B
=\log\frac{T_{q-1}T_q}{T_{2q-1}T_{2q}}
=\int_0^1\operatorname{Tr}((U(t)-W(t))C(t))dt,
\qquad T_N=V_N(1)/V_N(0).
\tag{WS24}
\]

Here \(V_N\) is the determinant of the original least-norm quotient Gram, so WS24 is the signed arithmetic/reference endpoint correction. The identity was read in the complete sealed source; this review supplies the new spectral refinement. Its integrand is continuous: projection coefficients are rational expressions in positive finite Grams and their positive relation restrictions, so their inverses remain continuous on the compact path.

The elementary derivative

\[
\frac{d}{dt}\log(1-t+tb_i)=c_i(t)
\]

holds also when \(b_i=1\), where both sides are zero. Thus \(\int_0^1c_i(t)dt=\log b_i\). Apply WS19 at every \(t\), integrate, and use the triangle inequality in WS24. This gives the complete ordered-eigenvalue estimate

\[
\boxed{
|\Delta\mathcal B|
\le\mathscr S_q(b)
:=\log\frac{b_{q+2}}{b_q}
 +2\sum_{j=1}^{q-1}\log\frac{b_{2q+2-j}}{b_j}.
}
\tag{WS25}
\]

All ratios in WS25 are at least one and are literal ratios of eigenvalues of the original relative Gram. Every such ratio is at most \(\kappa\). The total positive coefficient count is \(1+2(q-1)=2q-1\). Therefore

\[
\boxed{\quad |\Delta\mathcal B|
\le\mathscr S_q(b)\le(2q-1)\log\kappa.\quad}
\tag{WS26}
\]

For \(q=1\), the statement is exactly \(|\Delta\mathcal B|\le\log(b_3/b_1)\); there is no sum and no factor two. If all \(b_i\) equal a positive scalar \(c\), then WS23 makes \(C(t)\) a scalar multiple of the identity and the traces of \(U,W\) cancel. Equations WS25--WS26 give zero as well. The original common scalar mass remains present in the individual Grams; it cancels only in this signed ratio.

The coefficient \(2q-1\) cannot be decreased using only the separate spectra of \(U,W\) and the extremes of \(D\). For any retained numbers \(0<a<d\), choose the ordered data

\[
b_1=\cdots=b_q=a,
\qquad b_{q+1}=c\in[a,d],
\qquad b_{q+2}=\cdots=b_{2q+1}=d.
\tag{WS27}
\]

Then every ratio in WS25 is \(d/a\), so \(\mathscr S_q(b)=(2q-1)\log(d/a)\). Choose the two commuting spectral flags WS20 in a fixed \(M_0\)-orthogonal eigenbasis of \(D\). Since \(M(t)\) only changes each basis vector's squared norm by the positive factor \(1-t+tb_i\), these coordinate projections stay orthogonal for every original \(t\) in this abstract comparison. They attain WS19 with the same sign at every \(t\), hence its integrated value is exactly WS25 and WS26. This is an equality construction within the stated spectral-data class, preserving arbitrary positive \(a,d\). It does not identify arbitrary spectral flags with the actual multiplication-by-\(\chi\) flag.

## 5. What the literal polynomial flag retains beyond the spectra

The original relation and polynomial flags impose the exact incidence

\[
\chi\mathcal P_{q-1}\cap\mathcal P_{q-1}=0.
\tag{WS28}
\]

A nonzero product \(\chi P\) has degree \(q+\deg P\ge q\), whereas every polynomial on the right has degree at most \(q-1\); this proves WS28. In particular independent opposite eigenvalue alignments need not be attainable by these specific subspaces.

For example, assume \(C\) has strictly increasing eigenvalues and \(q\ge2\). Equality at the positive endpoint of WS19 forces \(U\) to have its eigenvalue-two space on the largest \(q-1\) eigenspaces of \(C\), and forces \(W\) to vanish on its largest \(q\) eigenspaces, by the equality criterion in WS15. Hence \(L_{U,2}\subseteq L_{W,0}=\mathcal P_{q-1}\). But \(L_{U,2}\subseteq\chi\mathcal P_{q-1}\) and has positive dimension \(q-1\), contradicting WS28. At the negative endpoint the same argument uses the smallest eigenspaces: minimizing \(U\) puts its eigenvalue-two space in the smallest \(q-1\) eigenspaces, while maximizing \(W\) makes those eigenspaces part of its kernel. Thus that endpoint is also impossible for these literal flags and simple \(C\).

At \(q=1\), the actual formulas reduce to

\[
U=Q_2=I-P_{\mathcal R_2^\perp},
\quad W=I-P_0,
\quad U-W=P_0-P_{\mathcal R_2^\perp}.
\tag{WS29}
\]

For simple \(C\), a positive equality in WS19 makes \(\ker U=\mathcal R_2^\perp\) the lowest eigenline and \(\ker W=\mathcal P_0\) the highest eigenline. They are orthogonal, which would force \(\mathcal P_0\subseteq\mathcal R_2=\chi\mathcal P_1\). This is impossible because the nonzero constant polynomial is not divisible by the degree-one \(\chi\). The negative endpoint is excluded by exchanging the lowest and highest eigenlines. The strictness statement concerns nonconstant simple spectral data; repeated cutoff eigenspaces have precisely the freedom retained in WS15.

These incidence calculations identify an exact additional relation that the source-specific unitary, commutator, and full-jet observations can use. The spectral estimate WS25 remains valid for the original flags, while its equality statement is explicitly scoped. The signed determinant correction itself remains WS24, with all four original endpoints and all relation primitives present.

## 6. The original one-dimensional quotient gives a nonlinear bound

This section concerns exactly \(q=1\), with the original common source \(\mathcal P_2\), original vertical line \(S=k/2+iu\), original positive measures \(m_t\), and original degree-one relation polynomial \(\chi=S-a\). It makes no assertion that the same two-line formula applies in higher quotient dimension.

The four cutoff indices become \(0,1,1,2\), so the two copies of \(V_1\) cancel in this specified ratio and

\[
\mathcal B(t)=\log\frac{V_0(t)}{V_2(t)}.
\tag{WS30}
\]

Let \(e=1\) be the original constant polynomial, \(\mathcal N=(\chi\mathcal P_1)^\perp\), and \(z=R_2(t)[1]\) its canonical minimum-norm representative. Every polynomial with remainder one differs from \(e\) by an element of \(\chi\mathcal P_1\), so orthogonal minimization gives \(z=P_{\mathcal N}e\). The norms are the unchanged quotient values

\[
\langle e,e\rangle_t=V_0(t),\quad
\langle z,z\rangle_t=V_2(t),\quad
\langle e,z\rangle_t=V_2(t)>0.
\tag{WS31}
\]

The last equality follows by the orthogonal splitting of \(e\); its sign and phase are fixed. Positivity of \(V_2\) follows independently from \(J_2z=1\), which makes \(z\ne0\). Hence the angle between the two lines has

\[
\cos^2\theta(t)
=\frac{|\langle e,z\rangle_t|^2}
        {\langle e,e\rangle_t\langle z,z\rangle_t}
=\frac{V_2(t)}{V_0(t)}=e^{-\mathcal B(t)}>0.
\tag{WS32}
\]

This ratio is strictly below one for the actual source measures. Indeed equality would give \(e\in\mathcal N\), hence both \(\int\chi(S)m_t=0\) and \(\int S\chi(S)m_t=0\). On the retained vertical line, \(\bar S=k-S\), so

\[
|\chi(S)|^2=((k-\bar a)-S)\chi(S).
\tag{WS33}
\]

The two vanishing integrals would force \(\int|\chi(S)|^2m_t=0\). This contradicts positive definiteness of the original Gram on the nonzero polynomial \(\chi\); alternatively positivity almost everywhere of \(m_t\) and the finite zero set of \(\chi\) give the contradiction directly. Thus \(0<\theta(t)<\pi/2\) and \(\mathcal B(t)>0\) on the entire compact interval. This argument uses the actual source line and its measure, not an arbitrary coefficient Gram calibration.

Put \(p=e/\sqrt{V_0}\) and \(n_0=z/\sqrt{V_2}\). Their inner product is the positive real number \(c=\sqrt{V_2/V_0}\). Set \(s=\sqrt{1-c^2}>0\), and \(r=(n_0-cp)/s\). Directly \(\langle p,r\rangle_t=0\) and \(\|r\|_t=1\). These are explicit coordinates with the original norms displayed, so no Gram factor or mass is removed. In the basis \((p,r)\), the difference in WS29 is

\[
P_0-P_{\mathcal N}
=\begin{pmatrix}s^2&-sc\\-sc&-s^2\end{pmatrix}
\quad\text{on }\operatorname{span}(p,r),
\tag{WS34}
\]

and is zero on its orthogonal complement. The displayed matrix has trace zero and determinant \(-s^2\), so the full three eigenvalues are \(s,0,-s\). This proves the exact alignment-dependent spectrum

\[
\operatorname{spec}(U-W)
=\left\{\sqrt{1-e^{-\mathcal B(t)}},\ 0,
         -\sqrt{1-e^{-\mathcal B(t)}}\right\}.
\tag{WS35}
\]

Write its positive and negative rank-one spectral projections as \(E_+\) and \(E_-\). Then \(U-W=s(E_+-E_-)\). Applying the already proved rank-one bound WS16 to their two traces gives

\[
|\dot{\mathcal B}(t)|
\le\sqrt{1-e^{-\mathcal B(t)}}\,(c_3(t)-c_1(t)).
\tag{WS36}
\]

Here \(\dot{\mathcal B}\) is the original derivative in WS24; the equality identifying it uses all four original window signs even though their scalar endpoint expression has the cancellation in WS30.

For real \(B>0\), let \(\Phi(B)=2\operatorname{arcosh}(e^{B/2})\), using the nonnegative real inverse of \(\cosh\). Differentiating \(\cosh(\Phi(B)/2)=e^{B/2}\) gives

\[
\Phi'(B)=\frac{e^{B/2}}{\sqrt{e^B-1}}
=\frac1{\sqrt{1-e^{-B}}}.
\tag{WS37}
\]

Since \(\mathcal B(t)\) is continuous and strictly positive on the compact interval, it has a positive minimum; every composition and division in WS37 is therefore defined and smooth on this whole path. Multiplying WS36 by WS37 yields \(|(\Phi\circ\mathcal B)'|\le c_3-c_1\). Integrating WS23 gives the exact nonlinear endpoint control

\[
\boxed{
\left|2\operatorname{arcosh}(e^{\mathcal B(1)/2})
      -2\operatorname{arcosh}(e^{\mathcal B(0)/2})\right|
\le\log\frac{b_3}{b_1}.
}
\tag{WS38}
\]

Equivalently, put \(A_0=\operatorname{arcosh}(e^{\mathcal B(0)/2})\) and \(L=\tfrac12\log(b_3/b_1)\). Then \(\operatorname{arcosh}(e^{\mathcal B(1)/2})\) lies between \(\max(0,A_0-L)\) and \(A_0+L\). The function \(A\mapsto2\log\cosh A\) is increasing for \(A\ge0\), because its derivative is \(2\tanh A\ge0\). Hence

\[
2\log\cosh(\max\{0,A_0-L\})
\le\mathcal B(1)\le2\log\cosh(A_0+L).
\tag{WS39}
\]

The lower bound may be zero although the actual value was proved strictly positive. A scalar relative Gram gives \(L=0\) and the exact equality of the two original endpoint values, in agreement with WS25. This is an additional analytic calculation on the actual \(q=1\) source, retaining its canonical line angle.

## 7. Complete independent review of the root AW1--AW23 source

The complete `tau_relation_window_spectral_transport_20260913.tex` was read and checked at SHA-256 `c79e76c087efd59871e3234ff44fb18964515dbd34f0318dffba6b3f1440f6ec`. No mathematical correction is requested at that pin.

The following checks cover the new assertions rather than only their final inequalities.

1. **Original objects and types.** AW1--AW6 retain the exact arithmetic Taylor unit, two distinct injected observations into the full tensor jet module and into \(Q^{\otimes k}\), the common \(2q\) coefficient cutoff, the full masses, and the same-metric projection formulas. The correction sign agrees with the four terms of the sealed AT15, whose source pin is `24cf7ce5be6a43cc656641b516185df10b2e4d7824600ece657120d1c549deae`.
2. **Smooth actual isometry.** The Gram recursion AW9 retains every positive norm \(a_j\). Linear independence of each original list makes every residual nonzero; positive square roots are smooth along the entire compact path. The canonical quotient list lies in \((\chi\mathcal P_q)^\perp\) because of the original minimum-section orthogonality and spans it because \(J_{2q}R_{2q}=I\). Thus AW10 maps an actual orthonormal basis to another one, with matching eigenvalues from WS7 and WS9. It proves \(T^*MT=M\) and \(UT=TW\), including the empty middle list at \(q=1\).
3. **Commutator and unchanged cohomology observation.** Finite trace cyclicity gives \(\operatorname{Tr}((TWT^{-1}-W)C)=\operatorname{Tr}(WT^{-1}(CT-TC))\), with precisely the displayed sign. The original observation has kernel \(\chi\mathcal P_q\) because its two later maps are injective. Therefore \(\ker(\mathcal O T)=T^{-1}(\chi\mathcal P_q)\). The explicit AW10 basis assignment identifies this with \(\operatorname{span}(p_q,\ldots,p_{2q})=\mathcal P_{q-1}^{\perp}\). The full observation defect \(\sigma_h^{\otimes k}\eta J_{2q}(T-I)\) is retained, so this isometry is not assigned an unwritten identity on arithmetic classes. The support lift preserves the label and gives exactly that supported-zero inverse image.
4. **Repeated spectra and integration.** AW13--AW17 agree with the independently derived WS14--WS26. The zero rank at \(q=1\), repeated Gram eigenvalues, values \(b_i=1\), and the full coefficient \(2q-1\) are all covered. The claimed sharpness is expressly restricted to the separate spectral constraint; its text does not freely orient the original polynomial relations. AW18 is a correct substitution of the supplied Gamma lower estimate into this new finite-source bound, with the actual quartet restriction retained.
5. **One-dimensional continuation.** AW19--AW23 are independently proved in full by WS30--WS39 above. The vertical-line identity, positive phase of \(\langle e,z\rangle\), exact two-dimensional projection matrix, remaining zero eigenvalue, positive derivative divisor, and both real hyperbolic-function branches are correct. The factor on the right of AW22 is \(\log(b_3/b_1)\), while AW23 correctly uses half that number in its \(\cosh\) arguments. The calculation remains explicitly restricted to \(q=1\).

The whole AW source is accepted at the exact pin above. The original finite Gram data remain the input to the proved estimates; no uniform bound in \(k\) has been presumed.

## 8. Source and verification scope

The complete sealed `tau_arithmetic_determinant_transport_20260913.tex` was read. Its AT11--AT15 fix the original common Hilbert space, projection conventions, correction sign, and relative Gram path used here. This note proves WS5--WS39 directly from those data and the actual \(q=1\) measures; it does not alter the sealed source or its PDF. The complete root AW1--AW23 source was also read and accepted as recorded above. These complete written proofs constitute the closed mathematical review; no supplementary source is needed for any acceptance recorded here.

No external trace extremum theorem was used: WS14--WS16 are its direct finite-dimensional proof, including repeated eigenvalues. No Lean execution, remote mutation, numerical-only proof, source-multiplier boundedness hypothesis, or unproved asymptotic estimate is asserted.
