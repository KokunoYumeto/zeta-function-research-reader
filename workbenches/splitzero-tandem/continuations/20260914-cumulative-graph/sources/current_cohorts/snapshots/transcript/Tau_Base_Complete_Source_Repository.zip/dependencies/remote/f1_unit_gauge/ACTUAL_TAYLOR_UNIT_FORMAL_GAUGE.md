# The original arithmetic Taylor unit as a formal geometric gauge

13 September 2026. This calculation continues the original cohomology over
the absolute tau base. It retains the actual unit `j_h(g/h)` in the
exponential deformation, constructs every localization and inverse map,
and proves that the newly introduced pole quotient is contractible in the
specified formal neighbourhood. It does not replace that unit by a constant,
replace an arithmetic metric, or identify formal and analytic cohomology.

## 1. Fixed arithmetic input

Use the retained theta complex and its actual finite packet:

\[
C_+=[V\xrightarrow{\Theta}\mathscr B],\quad
Q=\mathscr B/\Theta V,\quad g=2\xi,\quad
h(s)=\prod_{\rho\in Z}(s-\rho)^{m_\rho}.
\tag{UG1}
\]

Every selected order is its full original zero order. Set `d=deg h`,
`E_h=C[s]/(h)`, and retain

\[
\upsilon_h=j_h(g/h),\qquad
\nu(s)=\operatorname{rem}_h(\upsilon_h),\qquad
\epsilon_h=\upsilon_h^{-1}=j_h(h/g).
\tag{UG2}
\]

Here `rem_h` in the middle denotes the unique polynomial of degree less
than d with those full Hermite jets, not a remainder of an entire function
obtained by dropping its Taylor derivatives. The actual `g/h` is nonzero
at every selected root, so `nu` and h are relatively prime. Polynomial
Euclidean division gives coefficients `a,b` with `a h+b nu=1`. These are
facts about the retained packet. No additional zero of g is postulated.

The original arithmetic source section and cyclic tensor inclusion stay

\[
J_ZR_{\rm ref}=I,\quad
\mathcal M R_{\rm ref}x=(g/h)\operatorname{rem}_h(\epsilon_hx),
\]
\[
\eta_{h,k}[P]=\upsilon_h^{\otimes k}
 P(A_h^{(k)})1,\qquad A_h^{(k)}=\sum_{i=1}^k A_i.
\tag{UG3}
\]

The full inverse unit remains in the source section, and the full direct
unit remains in eta. They are not mutually cancelled across different
arrows or used to change the original theta norm.

## 2. The actual completed rings and pole quotient

Write `s` for the single-factor polynomial coordinate and `(u,t)` for
the existing deformation parameters. The two rings used below are

\[
\widehat B=\mathbb C[s][[u,t]],\qquad
\widehat B_\nu=\mathbb C[s,\nu(s)^{-1}][[u,t]].
\tag{UG4}
\]

They are coefficientwise formal power series. In the second ring the
power of nu in a denominator may grow with the `(u,t)` coefficient.
We do not silently replace it by a localization allowing only one
uniform denominator for the whole series.

Let

\[
M=\mathbb C[s,\nu^{-1}]/\mathbb C[s].
\]

Coefficientwise inclusion and quotient give the exact sequence

\[
0\longrightarrow\widehat B\xrightarrow{i}\widehat B_\nu
 \xrightarrow{\pi} M[[u,t]]\longrightarrow0.
\tag{UG5}
\]

An explicit section sigma of pi is the proper rational part at infinity.
Divide each rational function `P/nu^n` into its polynomial part and a
remainder with numerator degree strictly smaller than `deg(nu^n)`.
The proper part depends only on the class modulo polynomials: a rational
function both polynomial and vanishing at infinity is zero. This defines
sigma independently of the presentation with denominator `nu^n`.
Apply it coefficient by coefficient. If nu is a nonzero constant,
M is zero, pi and sigma are zero, and all the formulas below remain valid.

## 3. Multiplication by h is invertible on the pole quotient only

Multiplication by h on M is injective. If `hP/nu^n` is polynomial,
relative primality forces `nu^n` to divide P, so the original class is zero.
It is surjective: choose `a_n,b_n` with

\[
a_n h+b_n\nu^n=1.
\]

For `[P/nu^n]`, the class `[a_n P/nu^n]` maps to it, since the difference
is the polynomial `-b_n P`. Injectivity shows that this inverse does not
depend on the Bezout representative. Denote this exact inverse by H.

\[
H=(M_h|_M)^{-1}:M\longrightarrow M.
\tag{UG6}
\]

This inverse is **not** an inverse to h on `E_h`: there multiplication
by h is still zero with all original jets present. The two operators
occur on the different, explicitly related terms of (UG5).

Differentiation preserves both rational functions with poles among
zeros of nu and polynomials; it therefore induces `partial_s` on M.
Neither this derivative nor H is asserted to commute with the other.

## 4. An explicit contracting homotopy for the additional pole complex

The original formal exponential differential is

\[
D=u\partial_s+h(s)-t,
\quad\widehat C=[\widehat B\xrightarrow D\widehat B\,ds],
\quad\widehat C_\nu=[\widehat B_\nu\xrightarrow D\widehat B_\nu\,ds].
\tag{UG7}
\]

It respects (UG5). On its pole quotient put `E=u partial_s-t` and

\[
\boxed{J=D_M^{-1}=\sum_{n=0}^\infty(-HE)^nH.}
\tag{UG8}
\]

The order of these operators is part of the formula. The operator HE
raises `(u,t)`-adic order by at least one. Thus each fixed coefficient
of (UG8) contains only finitely many terms; this is a defined continuous
operator on `M[[u,t]]`. Because `D_M=M_h(I+HE)`, multiplication of
finite partial sums gives a remainder of arbitrarily high parameter
order. Completeness yields both `J D_M=I` and `D_M J=I`.

It follows that the two-term quotient complex

\[
[M[[u,t]]\xrightarrow{D_M}M[[u,t]]\,ds]
\tag{UG9}
\]

is contractible, with degree-minus-one homotopy J. This conclusion uses
the displayed inverse, not a claim that a common support label makes a
kernel vanish. In particular the entire arithmetic quotient of the
original complex is retained.

There is an explicit deformation retraction, not only a cohomology count.
Set

\[
K=\sigma J\pi:\widehat C_\nu^1\longrightarrow\widehat C_\nu^0,
\]
\[
r^0=I-KD=I-\sigma\pi,\qquad r^1=I-DK.
\tag{UG10}
\]

Each r has its image in the corresponding original polynomial-series
space: for r0 this follows from its definition, and
`pi r1=pi-D_M J pi=0`. Direct multiplication gives

\[
r^1D=Dr^0,\qquad ri=I_{\widehat C},\qquad
ir=I_{\widehat C_\nu}-(DK+KD).
\tag{UG11}
\]

In this last expression the degree-one component is `DK` and the
degree-zero component is `KD`; no sum of incompatible-degree maps is
intended. Since `pi i=0`, one also has `Ki=0`. Formula (UG10) is a
coefficientwise evaluable inverse to localization in the derived
category. It retains the explicit pole complex and contracts it.

For comparison, the map from the mapping cone of i to (UG9) sends
its localized component to its quotient and the other component to
zero. The kernel is the cone of the identity on the original complex,
which contracts directly. Thus the mapping-cone account and (UG10)
give the same vanishing of this additional pole contribution.

## 5. The original Taylor unit supplies a gauge isomorphism

Multiplication by nu is invertible on `Bhat_nu`. Compute its conjugation
of the unchanged differential:

\[
\boxed{D^{\nu}=\nu D\nu^{-1}
=u\partial_s+h-t-u\frac{\nu'}{\nu}.}
\tag{UG12}
\]

Indeed `partial_s(P/nu)=P'/nu-P nu'/nu^2`. Consequently

\[
D^{\nu}(\nu P)=\nu DP
\]

for every localized formal coefficient. Multiplication by nu in both
degrees is an exact cochain isomorphism

\[
\widehat C_\nu\xrightarrow{\times\nu}
\widehat C_\nu^{\nu}
=[\widehat B_\nu\xrightarrow{D^{\nu}}\widehat B_\nu\,ds].
\tag{UG13}
\]

Its inverse is multiplication by the same full rational `nu^{-1}`.
The new rational derivative term is written explicitly, with its sign
and coefficient u; it is not dropped or called a change of coordinates.

Combining (UG11) and (UG13) provides the geometric arrow

\[
\boxed{\widehat C\xrightarrow{i}\widehat C_\nu
\xrightarrow{\times\nu}\widehat C_\nu^{\nu}.}
\tag{UG14}
\]

It is a quasi-isomorphism of formal complexes. The original special
fibre is `[C[s] --h--> C[s] ds]`, with H1=`E_h` and H0=0.
The localized special fibre has the same cohomology, because nu is
invertible modulo h. Under those original coefficient identifications,
the special-fibre map (UG14) is exactly

\[
E_h\xrightarrow{\times\upsilon_h}E_h.
\tag{UG15}
\]

At this fibre `D^nu=h`, but the cochain map is still multiplication
by nu. In particular a basis change using `nu,nu s,...` must retain
its transition matrix to the original monomial frame; otherwise it
would conceal the actual arithmetic unit in (UG15).

## 6. The same arithmetic scaling flow commutes with this gauge

The previously constructed regular lift of theta dilation is

\[
L=u\partial_t-s,\qquad [D,L]=0,
\quad \exp(aL)P=e^{-as}P(u,t+ua,s)
\tag{UG16}
\]

in the a-adic cochain completion. Because nu depends only on s,

\[
[L,M_\nu]=[L,M_{\nu^{-1}}]=0,
\qquad[D^{\nu},L]=\nu[D,L]\nu^{-1}=0.
\tag{UG17}
\]

Thus (UG14) intertwines the **same** formal scaling operator L and
its a-adic exponential. No modified scaling generator or replacement
moment line is needed. The proper-rational retraction need not itself
commute strictly with L: its exact chain homotopies remain available;
the quasi-isomorphism i and the gauge do commute strictly.

In the target frame represented by `nu s^j`, the induced finite flow
matrix is the already calculated C_a. In the special-fibre original
frame, the transition is the full multiplication matrix `M_(upsilon_h)`.
It commutes with `p^(+/-A_h)` because both are multiplication operators
on the same full algebra, not because its higher jets have been ignored.
The finite entire evaluation of C_a for `a=log p` is as proved in the
scaling note; no convergence of the rational formal gauge in arbitrary
analytic `(u,t)` neighbourhoods is inferred here.

## 7. The tensor inclusion is recovered without changing the sum module

Apply the construction to each original h factor, using its coordinate
`s_i` and its deformation parameters. External tensor maps have degree
zero, so tensoring (UG14) introduces no new Koszul sign in those maps;
the differentials keep the original tensor signs. More precisely use
independent parameters `(u_i,t_i)` and the coefficientwise completion
defined by the cofinal rectangular truncations
`(u_i,t_i)^(n_i+1)=0` for every factor i. Each fixed multi-index receives
only finitely many terms from the homotopies (UG10).

There is an explicit tensor homotopy, so no inverse-limit exactness
assertion is needed. Set `P_i=i_i r_i`. On homogeneous tensors the
j-th term of the tensor homotopy is

\[
(-1)^{|x_1|+\cdots+|x_{j-1}|}
P_1x_1\otimes\cdots\otimes P_{j-1}x_{j-1}
\otimes K_jx_j\otimes x_{j+1}\otimes\cdots\otimes x_k.
\]

Summing these terms gives K_total. The differential's original Koszul
rule cancels its cross terms and gives
`d K_total+K_total d=I-P_1 tensor ... tensor P_k`, by telescoping.
The other retraction identity follows by tensoring `r_i i_i=I`.
These are coefficientwise identities on every rectangular truncation
and hence on the specified completed coefficient space.

The special-fibre map is

\[
\mathcal E_k=E_h^{\otimes k}
\xrightarrow{M_{\upsilon_h}^{\otimes k}}\mathcal E_k.
\tag{UG18}
\]

Compose it with the original cyclic inclusion

\[
E_{h,k}\longrightarrow\mathcal E_k,
\qquad[P]\longmapsto P(A_h^{(k)})1.
\]

The resulting map is exactly eta in (UG3). This proof does not assume
that the full tensor unit is a polynomial in the single sum coordinate
S; different occupancies with the same sum remain in the original
tensor object. The original cyclic annihilator and its full jet
lengths are unchanged. The original section into `Q^(tensor k)` and
the tau-base pushforward therefore receive the very same map eta.

For any fixed admitted support mask, every map above has its existing
split lift `(mask,v)->(mask,f(v))`, with tau going to tau. A formal
coefficient specializing to zero goes to that mask's e. The structural
map over `F_(1,tau)` is retained; neither localization at e nor
restriction of global cohomology to the sigma skeleton has been used.

## 8. The residue-dual arrow retains the inverse unit as well

For this section use the original reflection-stable packet of the
tau-base residue construction. Then dagger is an endomorphism of its
full jet space. The localization and gauge proofs above did not need
reflection; this specifies the original domain of the residue-dual
arrow, rather than silently applying it to an arbitrary packet.

Let the original polynomial residue pairing be

\[
\mathscr S_h(f,v)=\sum_{\rho\in Z}\operatorname{Res}_\rho
\frac{f(s)v(s)}{h(s)}ds.
\]

On full jets, the arithmetic residue is exactly

\[
\boxed{R_Z(f,v)=\mathscr S_h(f^\dagger,\epsilon_hv),
\qquad\epsilon_h=j_h(h/g)=\upsilon_h^{-1}.}
\tag{UG19}
\]

To prove it, write `g=h(g/h)` in each germ. The inverse of `g/h`
agrees with epsilon to every order needed for the residue, so replacing
that inverse by epsilon changes the integrand by a holomorphic germ.
The original dagger carries its full alternating Taylor signs.

The dual of (UG15) is its actual transpose, and the inverse-dual
transport uses `M_(upsilon_h)^(-T)`. After tensoring and composing
the source's residue-dual arrow to `K_(tau,k)(L_k)`, (UG19) retains
the same inverse units that already occur there. The weight factor
`p^k` is still the original moment representation. Thus the formal
gauge joins the direct unit-bearing inclusion and its specified
residue dual, rather than discarding one of their arithmetic factors.

## 9. Exact scope for the ongoing geometric argument

This is a formal-neighbourhood computation over the original base
program. It establishes an explicit quasi-isomorphism carrying the
actual Taylor unit, its localization cone and contraction, its
commuting arithmetic scaling, and its tensor and dual maps.

The Neumann series was justified in the `(u,t)`-adic topology only.
Specializing it at a nonzero complex u is not an authorized inference
from that proof. Such an analytic comparison would require its actual
continuation and contour/pole contribution to be calculated. The
original canonical theta metrics and their source/relation volumes
remain the analytic quantities in the owner's separate continuation;
this note neither chooses a new metric nor asserts a weight bound.

The completed result improves the concrete program nonetheless: the
original arithmetic unit is now present in a proved formal geometric
map through the same deformation, with its exact extra term and
contractible pole quotient, rather than being left outside that map.

## Source and verification record

The original tau-base note was read completely in the preceding turn,
SHA256 `d03e71ad18f187bd89880cb8ca6fc9c5d6f260b3de8e8e5702c27db97e7b63c3`.
The full current `tex/arithmetic_input.tex` was also read completely;
A7–13 give the full unit, actual source section, quotient square and
equivariant roof used here. The original exponential family and its
constant residue duality are those of the retained exponential note,
not a new arbitrary replacement. The adjoining accepted scaling and
reflection notes supply the exact flow and moment-weight transport.

All localization, contraction and gauge claims above have their
elementary proofs in this note. Finite algebra fixtures are supporting
checks and do not certify actual zero data, all analytic coefficients,
or an RH statement. No new Lean or public upload is claimed here.
