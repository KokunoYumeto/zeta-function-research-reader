---
title: "Deligne's exponential-family step and the original arithmetic packet"
subtitle: "A flat rank-q deformation, its exact operator connection, and the logarithmic image of the preceding comparison curve"
author: "Owner-directed SplitZero research continuation"
date: "13 September 2026"
---

## 1. What is new, and what the source actually supplies

This continuation reads further into Deligne's *La conjecture de Weil II*, especially §§3.7.2–3.7.4, while completing the cohomological calculation of the preceding representative curve. There are two new applications, with different roles.

First, the logarithmic de Rham complex of that curve is calculated, rather than inferred from its underlying coherent bundle. Its arithmetic coefficients occur in degrees zero and two; its degree-one middle image is zero. This identifies it as a constant-coefficient comparison curve, not as a nonconstant constituent in Deligne's pencil argument. The full coefficients and the source-induced metric are retained by explicit maps.

Second, an actual polynomial-exponential family is built from the existing cyclic relation polynomial. Its characteristic-zero cohomology is a free module of exactly the original packet rank, including at repeated roots. Its special fibre is the original cyclic quotient, and the original sum operator is the exact polar coefficient of its parameter connection. Its finite-field realizations have precisely the form to which Deligne applies his exponential-sum theorem. The two realizations are exhibited as base changes of the same polynomial data, not declared isomorphic and not assigned the same operator.

The new algebraic statements below have proofs. The finite-field purity statement is an application of Deligne's theorem under the hypotheses verified in Section 9. No arithmetic norm comparison between these exponential periods and the original theta metric is proved here. In particular, the finite-field Frobenius has not been identified with the original sum operator.

## 2. Reading Deligne, rather than using the word purity

The supplied S20 archive was reassembled in this turn. All six binary parts were checked against their declared lengths and SHA-256 hashes. The resulting archive has 216,580,466 bytes, 312 members, and SHA-256 `e2005bf31e1fcf362765f73c315c855e0f504f24f34d3a0ab188049da522b7c8`.

The retained French and English LaTeX were read at the selected passages recorded in `SOURCE_REVIEW.md`, alongside the current page-local French records. No PDF extraction or OCR was used. The historical TeX is retained as a witness, not automatically treated as an error-free edition.

On printed pages 202–203, Deligne's argument has three separate inputs: the exceptional-fibre exact sequence, the integer weights of nonconstant constituents, and the independent bound strictly below two. Constant constituents have zero first cohomology on the projective line. The tensor-square step then improves the bound on the same Frobenius eigenvalue. On page 206, compact-support and ordinary-cohomology bounds meet on the image of their actual comparison.

The additional reading is printed pages 215–216. For a degree-d polynomial with d prime to the residue characteristic and nonsingular leading projective hypersurface, Deligne proves concentration of the exponential-sheaf cohomology in degree n, dimension $(d-1)^n$, and weight n. His next step is to put the polynomials into a parameter space, prove lissity by local acyclicity including at infinity, and use connectedness and the weight results to reduce to a particular polynomial. The purity propagation used in that argument is explicitly stated on page 178, Corollary 1.8.12: on a connected base, a lisse mixed sheaf pure at one point is pointwise pure. Its proof passes through the filtration into pure constituents, rather than inferring purity merely from constant rank. This supplies an actual geometric family to build from our relation polynomial. The supplied reference for the final monomial case has an internal numbering mismatch, recorded in `SOURCE_REVIEW.md`; the displayed exponential theorem is used with its stated scope, not represented as a newly verified entire historical proof.

The source does not say that the critical points of a polynomial have real part one half. The operator singled out by its purity theorem is finite-field Frobenius. The connection coefficient calculated below is a different output of the same potential data, linked through the displayed realization diagram rather than an assumed equality.

## 3. Original data and their supported realization

Retain the scalar construction and its specified maps:

$$
G(R)=\{\tau\}\sqcup\{r^\bullet:r\in R\},\qquad e_R=0_R^\bullet,
\qquad p_R(\tau)=0_R,\quad p_R(r^\bullet)=r.
\tag{1}
$$

The original coefficient square remains

$$
\begin{array}{ccc}
G(\mathbb Z)&\xrightarrow{G(\jmath)}&G(\mathbb C)\\
p_{\mathbb Z}\downarrow&&\downarrow p_{\mathbb C}\\
\mathbb Z&\xrightarrow{\jmath}&\mathbb C.
\end{array}
\tag{2}
$$

The first target is infinite. Every lifted scalar specialization below fixes external absence and sends a represented scalar zero to the represented zero of the receiving ring.

Keep the original theta complex, source function, full packet, and sum coordinate:

$$
C_+=[V\xrightarrow{\Theta}\mathscr B],\quad
Q=\mathscr B/\Theta V,\quad D=-x\partial_x,\quad g=2\xi,
\quad h(s)=\prod_\rho(s-\rho)^{m_\rho}.
\tag{3}
$$

At tensor degree k, write

$$
E=\mathbb C[S]/(\chi),\qquad \chi=\chi_{h,k},\qquad q=\deg\chi>0,
\qquad A=M_S,
\tag{4}
$$

where $S=s_1+\cdots+s_k$, not its average. The existing cyclic inclusion is

$$
\eta:E\hookrightarrow E_h^{\otimes k},\qquad
\eta[P]=\upsilon_h^{\otimes k}P(A_k)1,
\quad \upsilon_h=j_h(g/h).
\tag{5}
$$

Its characteristic polynomial as a cyclic sum module need not be the characteristic polynomial of the entire tensor module. The actual injection (5), the previously constructed equivariant retraction, and its complementary module retain that distinction.

For an admitted degree N, retain the original canonical representative $R_N$ and the source map $\mathcal V$:

$$
J^{(k)}\mathcal V R_N=\eta,\qquad
q^{(k)}\mathcal V R_N=\sigma_h^{\otimes k}\eta,
\quad R_N^*O_NR_N=G_N.
\tag{6}
$$

The monic norms in $O_N$ have their original mass $\omega_0=\mu_h^k$. No metric is chosen in this note to make an operator unitary. The empty-packet case has $E=0$ and is handled outside all formulas requiring q positive.

## 4. First compute the logarithmic cohomology of the preceding curve

For an original degree pair $i\le j$, retain

$$
\Delta=L_{ij}R_i-R_j,\quad C=\Delta^*O_j\Delta=G_i-G_j,
\quad R(z)=R_j+z\Delta,
\quad G(z)=G_j+|z|^2C.
\tag{7}
$$

The predecessor constructs the image lattice on $X=\mathbb P^1_{\mathbb C}$, with boundary $D_\infty=\{\infty\}$ and $w=1/z$:

$$
\mathcal M_{E_0}=E_0\mathcal O+wE\mathcal O,\qquad E_0=\ker\Delta.
\tag{8}
$$

Its smallest A-stable enlargement is $\mathcal M_F=F\mathcal O+wE\mathcal O$, where

$$
F=E_0+AE_0+\cdots+A^{q-1}E_0.
\tag{9}
$$

All statements below concern this original target E. Let $Q_F=E/F$ denote this finite quotient, not the theta quotient Q.

### 4.1 The actual differential

For any positive integer m, define the lattice

$$
\mathcal M_{F,m}=F\mathcal O+\mathcal O(-mD_\infty)E
\subset E\mathcal O,
\tag{10}
$$

and its two-term logarithmic complex, in degrees zero and one,

$$
\mathcal K_{F,m}=
[\mathcal M_{F,m}\xrightarrow{d}
 \mathcal M_{F,m}\otimes\Omega_X^1(\log D_\infty)].
\tag{11}
$$

The differential is the restriction of the constant coefficient connection: in the local frame $w^m e$ its coefficient is $w\partial_w+m$. Consequently it preserves (10) after tensoring with logarithmic forms. Because F is A-stable, A acts on the entire complex. A choice of complement $E=F\oplus J$ gives the coefficient description $\mathcal M_{F,m}=F\mathcal O\oplus J\mathcal O(-m)$; the action can have an off-diagonal block and is not asserted to split with that choice.

**Computed cohomology.** The canonical identifications as A-modules are

$$
\boxed{\mathbb H^0(X,\mathcal K_{F,m})=F,\qquad
\mathbb H^1(X,\mathcal K_{F,m})=0,\qquad
\mathbb H^2(X,\mathcal K_{F,m})=Q_F.}
\tag{12}
$$

Here is a direct calculation retaining the coefficients. For the compactly supported component, use the two affine charts and the finite frame at z. The Cech groups are

$$
H^1(\mathcal O(-mD_\infty))
=\operatorname{span}\{z^{-1},\ldots,z^{-(m-1)}\},
$$

$$
H^1(\mathcal O(-mD_\infty)\otimes\Omega^1(\log D_\infty))
=\operatorname{span}\{z^{-1}dz,\ldots,z^{-m}dz\}.
$$

The induced differential is exactly

$$
 z^{-a}\longmapsto-a\,z^{-(a+1)}dz,\qquad 1\le a<m.
\tag{13}
$$

It is injective, and its cokernel is the line generated by $z^{-1}dz$. For the ordinary logarithmic component the complex is $[\mathcal O\to\mathcal O(-1)]$, with only the constant H0. The exact sequence of complexes with subobject $F$ and quotient $Q_F$ then gives (12) canonically, without an A-invariant complement. In particular the degree-two identification is residue in the displayed coordinate.

If the original arithmetic cochain degree k is restored by the shift $[-k]$, the coefficient groups are in degrees k and k+2. For every polynomial f,

$$
\boxed{\operatorname{Str}(f(A)\mid R\Gamma\mathcal K_{F,m}[-k])
=(-1)^k\bigl(\operatorname{Tr}f(A|F)+\operatorname{Tr}f(\bar A|Q_F)\bigr)
=(-1)^k\operatorname{Tr}f(A|E).}
\tag{14}
$$

The quotient retains all induced Jordan data. This is trace additivity on the original exact sequence, not deletion of its second term.

### 4.2 Compact, middle, and ordinary comparisons

Put

$$
\mathcal K_!=[E\mathcal O(-D_\infty)\to E\Omega_X^1],\quad
\mathcal K_{\mathrm{mid}}=[E\mathcal O\to E\Omega_X^1],\quad
\mathcal K_*=[E\mathcal O\to E\Omega_X^1(\log D_\infty)].
\tag{15}
$$

Their natural inclusions compute the usual compact-support, smooth middle, and ordinary comparisons for the constant coefficient system on $\mathbb A^1$. At m=1 the mixed complex fits $\mathcal K_!\to\mathcal K_{F,1}\to\mathcal K_*$. The cohomology groups are

$$
H^a(\mathcal K_!)=\begin{cases}E&a=2,\\0&a\ne2,\end{cases}
\qquad
H^a(\mathcal K_*)=\begin{cases}E&a=0,\\0&a\ne0,\end{cases}
\tag{16}
$$

and $\mathcal K_{\mathrm{mid}}$ has E in degrees zero and two. In particular,

$$
\boxed{\operatorname{im}\bigl(H_c^1(\mathbb A^1,E)\to H^1(\mathbb A^1,E)\bigr)=0.}
\tag{17}
$$

This is an application of Deligne's constant-constituent test to the actual constructed curve. It locates its role: it is a metric comparison with retained boundary data, not yet the nonconstant cohomological image carrying E in degree one. The constructive continuation to such a cohomological family begins in Section 5.

The two boundary comparisons remain explicit. For m=1, the termwise quotient $\mathcal K_*/\mathcal K_{F,1}$ is the punctual complex $[Q_F\xrightarrow{0}Q_F]$ in degrees zero and one, while $\mathcal K_{F,1}/\mathcal K_!$ is $[F\xrightarrow{0}F]$. For general m the first quotient has local coefficient differential

$$
 w^a\longmapsto a w^a\,dw/w,\qquad 0\le a<m.
\tag{18}
$$

Every positive a is paired with its exact inverse coefficient $1/a$; the constant class survives in both degrees. Thus the extra coherent length is kept before its logarithmic differential is taken. In the split construction those cycles, boundaries, and their quotients use the original fibrewise operations. External absence is never used as the image of a represented boundary.

### 4.3 Ramification and saturation retain the metric cost

The ramified parameter map $f_m:\mathbb P^1\to\mathbb P^1$, $z\mapsto z^m$, gives the actual representative $R_m(z)=R_j+z^m\Delta$. Its pulled-back determinant curvature has radial density

$$
\kappa_m(t)=m^2t^{m-1}\operatorname{Tr}\bigl(Z(I+t^mZ)^{-2}\bigr),
\qquad Z=G_j^{-1}C.
\tag{19}
$$

Substitution $v=t^m$ proves

$$
\boxed{\int_0^\infty\kappa_m(t)dt=m\operatorname{rank}C,\qquad
\int_0^1\log(1/t)\kappa_m(t)dt=\log(V_i/V_j).}
\tag{20}
$$

The pullback on the surviving degree-two de Rham class is $dz/z\mapsto m\,dz/z$. It is not an identity disguised by dividing the trace by m.

In the A-stable enlargement, let $s_A=\dim F-\dim E_0$. Its determinant metric in the infinity chart is the old one multiplied by $|w|^{-2ms_A}$. With the retained curvature definition $(i/2\pi)\partial\bar\partial\log\det G$, the current is

$$
\boxed{c_1((\det\mathcal M_{F,m})^\vee,h^\vee)
=\mu_m-ms_A\delta_\infty.}
\tag{21}
$$

Indeed $(i/2\pi)\partial\bar\partial\log|w|^2=\delta_\infty$. Its total mass is $m(q-\dim F)$, the degree of the dual determinant. Full saturation subtracts $m\operatorname{rank}C$ at infinity and has total degree zero, but leaves the endpoint logarithmic integral (20) unchanged. The negative atom is a geometric current; it is not a negative support label.

## 5. An actual rank-q cohomological deformation of the cyclic packet

Write the original monic polynomial in its original coordinate:

$$
\chi(S)=S^q+\sum_{a=0}^{q-1}c_aS^a.
\tag{22}
$$

Introduce two new parameters u and t. They are independent of the scalar $\tau$, the arithmetic coordinate S, the logarithmic comparison parameter z, and the tensor degree k. Put $R=\mathbb C[u,t]$ and define

$$
\Phi(S)=\frac{S^{q+1}}{q+1}+\sum_{a=0}^{q-1}\frac{c_aS^{a+1}}{a+1},
\qquad\Phi_t(S)=\Phi(S)-tS.
\tag{23}
$$

This is the specified primitive with $\Phi(0)=0$, with every coefficient $1/(a+1)$ written. It changes no source coefficient in $g=2\xi$. Define the two-term complex

$$
\mathcal C_{u,t}=[R[S]\xrightarrow{\mathcal D_{u,t}}R[S]dS],
\qquad
\mathcal D_{u,t}(P)=\bigl(uP'(S)+(\chi(S)-t)P(S)\bigr)dS,
\tag{24}
$$

in degrees zero and one.

**Flatness and exact rank.** There is a direct sum of R-modules

$$
\boxed{R[S]=\mathcal D_{u,t}(R[S])/dS\ \oplus\ R[S]_{<q}.}
\tag{25}
$$

In particular,

$$
\boxed{H^0(\mathcal C_{u,t})=0,\quad
\mathcal H:=H^1(\mathcal C_{u,t})\cong R^q,
\quad \mathcal H/(u,t)\mathcal H\cong E.}
\tag{26}
$$

**Proof.** If P has degree a and leading coefficient b, then $uP'+(\chi-t)P$ has degree a+q and leading coefficient b. It cannot be zero. For any polynomial F of degree at least q, subtract $\mathcal D_{u,t}(bS^{\deg F-q})/dS$ to remove exactly its highest term. Repeating terminates with a remainder of degree below q. Uniqueness follows from the leading-degree statement. The coefficients stay in R throughout. The same proof survives arbitrary base change of R, so (25) is a split exact presentation, not only a dimension count over its fraction field. Specializing u=t=0 turns (24) into multiplication by the literal $\chi$, proving the final isomorphism.

Let $\operatorname{red}_{u,t}$ denote the resulting coefficient-linear remainder map and $s_{<q}$ its specified polynomial section. The fibre map in (26) is $[P]_{\mathcal D}\mapsto[P|_{u=t=0}]_\chi$, with inverse induced by the chosen remainder basis.

There is no ring quotient asserted for u nonzero. Its exact relationship to multiplication is the commutator

$$
[\mathcal D_{u,t}/dS,M_S]=uI.
\tag{27}
$$

For example, $\mathcal D(1)/dS=\chi-t$, while $\mathcal D(S)/dS=u+S(\chi-t)$; hence $[S(\chi-t)]=-u[1]$ in $\mathcal H$. The image of the differential is generally not an ideal. Formula (25) supplies the coefficient module and its section; the next paragraph supplies the operator that really descends.

## 6. The parameter connection contains the original sum operator

On $\mathcal H[u^{-1}]$, define

$$
\nabla_t[P]=[\partial_tP-S P/u].
\tag{28}
$$

The exact relation

$$
[\mathcal D_{u,t}/dS,\partial_t]=I,
\qquad
[\mathcal D_{u,t}/dS,-M_S/u]=-I
\tag{29}
$$

proves that their sum commutes with the differential. Thus (28) descends without asserting that multiplication by S separately descends.

In the specified remainder basis $1,S,\ldots,S^{q-1}$, the connection is

$$
\boxed{\nabla_t=\partial_t-\frac{A(t)}u,
\qquad A(t)=A+t\mathcal R,\quad
\mathcal R=e_0e_{q-1}^{\,T}.}
\tag{30}
$$

Here $A e_a=e_{a+1}$ for $a<q-1$ and

$$
A(t)e_{q-1}=(-c_0+t)e_0-c_1e_1-\cdots-c_{q-1}e_{q-1}.
\tag{31}
$$

Only a degree-q polynomial has to be reduced in deriving (30); $\mathcal D(1)=\chi-t$ gives exactly (31), including the sign of t.

The operator $-u\nabla_t=-u\partial_t+A(t)$ is regular in u and obeys the exact coefficient rule $(-u\nabla_t)(fv)=f(-u\nabla_t)v-u(\partial_t f)v$. It is a parameter-scaled connection in the t direction, not a derivative in u. Its reduction at u=0 is the honest endomorphism $A(t)$, and

$$
\boxed{(-u\nabla_t)\bmod(u,t)=A=M_S\text{ on }E.}
\tag{32}
$$

This is the precise operator bridge. It contains a minus sign fixed by (24) and (28). The original arithmetic scaling is not renamed Frobenius.

### Carry the parameter through the original theta representative

Let $r_N=\mathcal V R_N:E\to\mathscr B^{\widehat\otimes k}$. On its specified test-function domain, use the earlier full jet map followed by the fixed equivariant cyclic retraction to obtain $j_E$ with

$$
j_Er_N=I_E,\quad j_ED^{(k)}=Aj_E,
\quad j_E\text{ kills the original theta boundaries}.
\tag{33}
$$

The construction of $j_E$ uses the retained equivariant retraction, not an arbitrary quotient of the full tensor packet. Define the concrete finite-rank perturbation

$$
\boxed{D_t^{(k)}=D^{(k)}+t\,r_N\mathcal R j_E.}
\tag{34}
$$

Then

$$
j_ED_t^{(k)}=A(t)j_E,
\qquad
\boxed{D_t^{(k)}r_N-r_NA(t)=D^{(k)}r_N-r_NA=dK_N.}
\tag{35}
$$

Both identities follow by substitution. The added term vanishes on every original boundary because $j_E$ does. Thus the deformation has an explicit source realization preserving the original relation primitive. At t=0 it is exactly the original generator. At t nonzero it is the displayed finite-rank deformation, not a new assertion about the zero set of $g$.

The canonical arithmetic metric remains $G_N$. Its parameter control is explicitly

$$
\boxed{W_N(t)=W_N(0)+tG_N\mathcal R+\bar t\,\mathcal R^*G_N.}
\tag{36}
$$

No positive metric has been selected from the exponential family to replace $G_N$.

### 6.1 The exponential periods are constructed and proved to span

Fix a nonzero complex u, write d=q+1, and fix an argument of u. Set

$$
\theta_0=\frac{\arg u+\pi}{d},\qquad
\theta_j=\theta_0+\frac{2\pi j}{d}\quad(0\le j<d).
\tag{36a}
$$

Let $\ell_j$ be the oriented ray from zero to infinity with angle $\theta_j$, and set $\Gamma_j=-\ell_0+\ell_j$ for $1\le j\le q$. The minus sign makes the initial endpoint contributions cancel. For a polynomial P define

$$
\mathcal P_j(P)=\int_{\Gamma_j}e^{\Phi_t(S)/u}P(S)\,dS,
\qquad
\Pi_{jb}(u,t)=\mathcal P_j(S^b),\quad 0\le b<q.
\tag{36b}
$$

These are absolutely convergent contour integrals. Along each ray the leading exponent is $-r^d/(d|u|)$. Lower-degree terms are dominated by that negative term outside a sufficiently large compact interval, uniformly when the lower coefficients and t range over a compact set. The same estimate after multiplying by any polynomial proves holomorphic dependence on those parameters and justifies their differentiation under the integral.

Integration of the actual total derivative gives

$$
\mathcal P_j\bigl(uP'+(\chi-t)P\bigr)
=u\int_{\Gamma_j}d\bigl(e^{\Phi_t/u}P\bigr)=0.
\tag{36c}
$$

Both ends at infinity have zero boundary value, and the two values at zero cancel. Consequently the periods descend through the very differential (24), not through a quotient chosen afterwards.

**The period matrix is invertible for every choice of the lower coefficients and every t, at this fixed nonzero u.** Here is a direct proof, including the singular critical-point cases.

Temporarily regard the coefficients $c_0,\ldots,c_{q-1}$ as independent parameters. The coefficient-direction connections are

$$
\nabla_{c_a}=\partial_{c_a}+\frac{S^{a+1}}{(a+1)u},
\qquad [\mathcal D/dS,\nabla_{c_a}]=0.
\tag{36d}
$$

The two commutator terms are $-S^a$ and $+S^a$. Reducing $S^{a+b+1}/((a+1)u)$ by (25) gives the b-th column of a q-by-q matrix $B_a$. Every entry is a polynomial in the lower coefficients and t, with powers of the fixed $u^{-1}$. Thus

$$
\partial_{c_a}\Pi=\Pi B_a,\qquad
\partial_t\Pi=-\Pi A(t)/u.
\tag{36e}
$$

At the monomial potential $\Phi=S^d/d$, t=0, direct substitution in the ray integral gives

$$
\Pi_{jb}^{\mathrm{mon}}
=\frac{(d|u|)^{(b+1)/d}}{d}
\Gamma\!\left(\frac{b+1}{d}\right)
 e^{i(b+1)\theta_0}
 \left(e^{2\pi i j(b+1)/d}-1\right).
\tag{36f}
$$

All Gamma factors, all powers, and all phases remain. The final q-by-q matrix is nonsingular: a dependence among its columns would give a polynomial $\sum_{l=1}^{q}a_l(z^l-1)$ of degree at most q vanishing at every d-th root of unity, including 1. It has d=q+1 distinct zeros, so it is the zero polynomial and every $a_l$ vanishes.

For the phase matrix $V_{jl}=e^{2\pi i jl/d}-1$, $1\le j,l<d$, finite root-of-unity summation also gives $V^*V=d(I_q+\mathbf1\mathbf1^T)$ and $\det(V^*V)=d^d$. This evaluates its nonzero size without absorbing any of the Gamma factors in (36f).

Join this monomial parameter to the actual parameter by a straight line in the coefficient space, keeping the rays fixed. Equations (36e) give $\Pi'=\Pi B$ with an everywhere continuous, explicitly reduced matrix B. Differentiation of the determinant, valid through the adjugate formula even at a putative singular matrix, yields

$$
(\det\Pi)'=(\operatorname{Tr}B)\det\Pi.
\tag{36g}
$$

Its initial value is nonzero by (36f). The scalar equation has solution given by that value times the exponential of the integral of $\operatorname{Tr}B$, and never vanishes. This proves the stated invertibility without assuming simple critical points or a basis of unproved cycles.

It follows that the actual period map is the coefficient-linear isomorphism

$$
\boxed{\mathcal H_{u,t}\xrightarrow{\ (\mathcal P_1,\ldots,\mathcal P_q)\ }\mathbb C^q,
\qquad [P]\longmapsto\Pi(u,t)\operatorname{red}_{u,t}(P),}
\tag{36h}
$$

with inverse given by $\Pi(u,t)^{-1}$ followed by the specified degree-below-q section. Polynomial-exponential de Rham cohomology and rapid-decay period pairings are established machinery; (36a)–(36h) give an elementary proof of the particular one-variable comparison used here, with its contours and factors fixed.

### 6.2 Transport the period norm through the original source map

Use the explicit coefficient identification

$$
\jmath_{u,t}:E\xrightarrow{\sim}\mathcal H_{u,t},
\qquad[P]_\chi\longmapsto[\operatorname{rem}_\chi P]_{\mathcal D_{u,t}}.
\tag{36i}
$$

This is a complex-linear basis comparison. It is not a ring morphism when the target differential image is not an ideal. Equations (30)–(35) are the operator comparisons attached to it.

The original representative image now has an actual period isomorphism and inverse:

$$
\boxed{r_N(E)\xrightarrow{\ \Pi(u,t)j_E\ }\mathbb C^q,
\qquad y\longmapsto r_N\Pi(u,t)^{-1}y.}
\tag{36j}
$$

Their two composites are identities on the specified domains, by $j_Er_N=1$. The same map applied to a retained theta boundary gives zero because $j_E$ kills that boundary; its split lift gives the receiving supported zero, not external absence.

The operator comparison also holds at the level of actual period functions. For a t-independent F in the admitted theta test-function domain, (33), (35), and (36e) give

$$
\boxed{-u\,\partial_t\bigl(\Pi(u,t)j_EF\bigr)
=\Pi(u,t)j_ED_t^{(k)}F.}
\tag{36j.1}
$$

At t=0 the right side uses the original $D^{(k)}$. On the full test-function domain the kernel of this period observation is exactly $\ker j_E$, because $\Pi$ is invertible. It remains an explicit retained kernel; the isomorphism (36j) concerns only the stated representative image $r_N(E)$.

Give the period-coordinate target its explicitly chosen ordinary coordinate Gram $I_q$ and write

$$
H_\Pi=\Pi^*\Pi,\qquad
B_N^{\mathrm{per}}=G_N^{-1}H_\Pi.
\tag{36k}
$$

Then $B_N^{\mathrm{per}}$ is positive self-adjoint in the original $G_N$, and

$$
\|\Pi v\|^2=v^*G_NB_N^{\mathrm{per}}v,
\qquad
\boxed{\log\frac{V_i}{V_j}
=\log\frac{\det B_j^{\mathrm{per}}}{\det B_i^{\mathrm{per}}}.}
\tag{36l}
$$

The latter follows from $\det B_N^{\mathrm{per}}=\det H_\Pi/\det G_N$ at the same (u,t). Thus the endpoint cost has been carried into two explicit period-to-source norm comparisons; it has not been set to zero by choosing period coordinates. The degree of the cyclic packet and the fixed contour-coordinate metric remain in the formula. Equation (36l) is a comparison identity, not a uniform bound on those determinants.

For q=1, $\chi(S)=S-\lambda$, real u>0, and the contour $i\mathbb R$ oriented from $-i\infty$ to $+i\infty$, the integral is exactly

$$
\boxed{\Pi(u,t)=i\sqrt{2\pi u}\,
\exp\!\left(-\frac{(\lambda+t)^2}{2u}\right),
\qquad -u\partial_t\log\Pi=\lambda+t.}
\tag{36m}
$$

This uses the displayed orientation; it is the negative of the q=1 ray-difference cycle in (36a). The positive metric value for real $\lambda,t$ is $2\pi u\exp(- (\lambda+t)^2/u)$. Its exponentially singular u-behaviour is retained. Thus even in rank one, passage through u=0 is a substantive norm-comparison question, not a consequence of finite-field purity of a different operator.

## 7. A constant residue pairing gives the exact dual connection

On the remainder basis define the complex-bilinear form

$$
\mathscr S_t(P,Q)=\sum_{\chi(\lambda)=t}
\operatorname{Res}_{S=\lambda}\frac{P(S)Q(S)}{\chi(S)-t}\,dS.
\tag{37}
$$

Multiplicity is handled by the residue, not by an assumption that the roots are simple. The form can equivalently be evaluated as the coefficient of $S^{-1}$ in the Laurent expansion at infinity of the displayed rational function. This is minus the residue at infinity, so the sign agrees with the sum of the finite residues.

For degree-below-q P,Q,

$$
\boxed{\mathscr S_t(P,Q)=\mathscr S_0(P,Q).}
\tag{38}
$$

Indeed,

$$
\frac1{\chi-t}-\frac1\chi=\frac{t}{\chi(\chi-t)},
$$

and multiplication by PQ, whose degree is at most $2q-2$, gives a Laurent expansion beginning at $S^{-2}$. Its $S^{-1}$ coefficient is zero. Let $\mathsf S$ be the constant matrix. Its entries below the first nonzero antidiagonal vanish and that antidiagonal has entries one, so

$$
\det\mathsf S=(-1)^{q(q-1)/2},\qquad
\boxed{A(t)^T\mathsf S=\mathsf S A(t).}
\tag{39}
$$

The latter equation follows because multiplication by S is self-adjoint for the residue pairing on the algebra $\mathbb C[S]/(\chi-t)$; (30) is precisely its multiplication matrix in this basis.

Let $\iota_u$ be the base involution $(u,t)\mapsto(-u,t)$. The actual dual map is

$$
\boxed{\mathcal H[u^{-1}]\longrightarrow
(\iota_u^*\mathcal H[u^{-1}])^\vee,
\qquad v\longmapsto(w\mapsto v^T\mathsf S w).}
\tag{40}
$$

It is horizontal:

$$
\partial_t(v^T\mathsf S w)
=(\nabla_t^{u}v)^T\mathsf S w
+v^T\mathsf S(\nabla_t^{-u}w).
\tag{41}
$$

This is a bilinear duality; the original Hermitian arithmetic pairing is connected on the special fibre by its retained antilinear reflection $f\mapsto f^{\dagger_k}$. In particular the Jacobian contraction is still

$$
\boxed{\mathscr S_0(f^{\dagger_k},\chi'v)
=\operatorname{Tr}_{E}M_{f^{\dagger_k}v}.}
\tag{42}
$$

The proof is the local equality $\chi'/\chi=\ell_\lambda/(S-\lambda)+$ a holomorphic term. The trace on the full original tensor or symmetric packet is still obtained through $\eta$ and its retained complement; (42) is not silently substituted for that larger trace. Likewise the original factor $\upsilon_h^{\otimes k}$ stays in (5) and (6).

## 8. The split coefficient maps and the original derivative tower

The family is over $R=\mathbb C[u,t]$, with scalar map $G(\mathbb C)\to G(R)$. Its reconstruction at any original support label $\ell$ has classes $(\ell,v)$, and

$$
e_R(\ell,v)=(\ell,0),\qquad \tau(\ell,v)=\tau.
\tag{43}
$$

The specialization $R\to\mathbb C$, $u,t\mapsto0$, lifts to a semiring map $G(R)\to G(\mathbb C)$, fixing $\tau$ and carrying both $u^\bullet,t^\bullet$ to the receiving e. The induced coefficient map is

$$
(\ell,[P]_{\mathcal D})\longmapsto
(\ell,[P(0,0,S)]_\chi).
\tag{44}
$$

For every P, the exact family relation is

$$
[\chi P]=t[P]-u[P']\quad\text{in }\mathcal H.
\tag{45}
$$

At u=t=0, this becomes the original supported zero. This family identity must not be substituted for the already formalized derivative between powers of the original relation ideal. Their precise polynomial relationship is

$$
\partial_S(\chi P)=\chi'P+\chi P',\quad
[\partial_S(\chi P)]_\chi=[\chi'P]_\chi,
\tag{46}
$$

whereas the u-term of (45) contains $-P'$. Both are obtained from the same polynomial and the displayed maps. The conormal response $\chi'P$ remains exactly the Jacobian in (42). None of the new parameters is another scalar zero-adjunction, and no original ideal-power level is replaced by a power of a contracted first ideal.

## 9. This potential has actual Deligne exponential-sheaf fibres

Let $R_0$ be the finitely generated subring of $\mathbb C$ generated by the coefficients $c_a$ and $1/(q+1)!$. Keep its specified embedding into $\mathbb C$. Equations (23) and (24) are defined over $R_0[u,t]$.

For every specified ring map $R_0\to\mathbb F_Q$ with residue characteristic $p>q+1$, and every $u_0\in\mathbb F_Q^*$ and $t_0\in\mathbb F_Q$, the same potential gives the explicit Artin–Schreier cover

$$
\boxed{Y^p-Y=\frac{\Phi(S)-t_0S}{u_0}.}
\tag{47}
$$

The infinity calculation in Deligne's lissity proof can be made explicitly on this family. Put $d=q+1$ and $w=1/S$. Then

$$
\frac{\Phi(S)-tS}{u}=w^{-d}b(w,u,t),\qquad
b(w,u,t)=\frac1u\left[\frac1d+\sum_{a=0}^{q-1}\frac{c_a}{a+1}w^{q-a}-t w^q\right].
\tag{47a}
$$

At w=0 its value is the unit $1/(du)$. On the neighborhood where b is invertible, adjoin the unit v by $b v^d=1$ and define $x_\infty=w v$. This is an explicit finite étale cover: the derivative in v is $d b v^{d-1}$, whose inverse on the cover is v/d. The new relative coordinate has invertible derivative at w=0. Direct substitution gives

$$
\boxed{\frac{\Phi(S)-tS}{u}=x_\infty^{-d},\qquad
x_\infty=w v,\quad b v^d=1.}
\tag{47b}
$$

Every coefficient in b is retained, as is the cover's root-of-unity action $v\mapsto\zeta v$, $\zeta^d=1$. This is the local, étale source map used to see a constant exponential model at infinity. Together with the locally constant sheaf on the smooth affine part, it is exactly the local-acyclicity mechanism used in Deligne's §3.7.3. The open u nonzero remains necessary; this map makes no claim at u=0.

Choose a nontrivial additive character $\psi:\mathbb F_p\to\overline{\mathbb Q}_\ell^*$, with $\ell\ne p$, and let $\mathcal L_\psi((\Phi-t_0S)/u_0)$ be the corresponding eigensheaf. The polynomial on the right has degree q+1, prime to p, and leading coefficient $1/((q+1)u_0)$. In one variable its leading projective zero locus in $\mathbb P^0$ is empty, and is smooth. Thus the precise hypotheses of Deligne §3.7.2 hold.

His theorem supplies

$$
\boxed{
H_c^a(\mathbb A^1_{\overline{\mathbb F}_Q},
\mathcal L_\psi((\Phi-t_0S)/u_0))=0\ (a\ne1),\quad
\dim H_c^1=q,\quad H_c^1\text{ is pure of weight }1.
}
\tag{48}
$$

The universal-polynomial argument in §§3.7.3–3.7.4 supplies a lisse family on the parameter open $u\ne0$, after that finite-field specialization. This is a direct application of Deligne's result, not a new proof of it.

The exact realization diagram is a span of specified base changes:

$$
(R_0,\Phi,u,t)\longrightarrow
\begin{cases}
(\mathbb C,\mathcal C_{u,t},\nabla_t),\\
(\mathbb F_Q,\mathcal L_\psi((\Phi-tS)/u),R^1p_!).
\end{cases}
\tag{49}
$$

Its characteristic-zero branch has the proved specialization (26) and operator formula (32). Its finite-field branch has Frobenius and (48). No field map $\mathbb C\to\mathbb F_Q$ is asserted; both arrows start at the actual ring $R_0$. Nor is a comparison equating the two operators supplied. The arithmetic theta metric $G_N$ is not part of Deligne's finite-field conclusion until an additional comparison theorem carries it there.

This places the cyclic relation in a genuine family of the kind Deligne studies, instead of attributing his nonconstant-constituent argument to the constant representative curve. It leaves an explicit operator/norm comparison to investigate.

### A calibration of the operator distinction

Take the declared algebraic polynomial $\chi(S)=S-3/4$; this is not an asserted zeta packet. Then

$$
\Phi(S)=S^2/2-3S/4,\qquad A(t)=3/4+t,
\qquad\nabla_t=\partial_t-(3/4+t)/u.
\tag{50}
$$

All the rank, specialization, and duality results above hold. At every finite-field realization of characteristic greater than two where the coefficient is defined, (48) still gives weight-one Frobenius. The characteristic-zero special coefficient remains $3/4$. This exact example shows why a purity theorem for the displayed Artin–Schreier family does not, by itself, locate the spectrum of (32). The additional comparison must use the specific original arithmetic source, not only the fact that a polynomial-exponential realization exists.

## 10. What this changes in the programme

The predecessor's nonconcentration problem remains

$$
\mathcal B_{h,k}
=\sum_{\ell=0}^1\int_{|z|<1}\log(1/|z|^2)\,d\mu_\ell.
\tag{51}
$$

The reviewed source-norm theorem and consecutive-window result still force the inherited off-line threshold of four. Neither log extension, finite ramification, nor saturation changes its original endpoint metric cost; (20) and (21) state precisely how those operations act.

What is added is a cohomological family with the exact original cyclic special fibre, an explicit connection containing A, an explicit dual connection, and finite-field exponential fibres covered by a theorem actually read in Deligne. The source-side realization (34)–(36) specifies the finite-rank deformation and keeps the theta boundary. The contour periods now give actual isomorphisms at u nonzero and the matrices $B_N^{\mathrm{per}}=G_N^{-1}\Pi^*\Pi$ give their exact comparison to the fixed arithmetic metric. Equation (36l) carries the endpoint volume into their determinant ratio. The remaining estimate must control those specified matrices through singular u=0 and along the original tensor/degree windows. The existence of the period isomorphism or of scalar support is not itself that uniform estimate.

This continuation proves no new upper bound contradicting the endpoint threshold. It does provide the actual family and the exact maps on which a Deligne-style comparison can be attempted, after calculating and retaining the limitations of the earlier constant curve.

## References and verification scope

Deligne, P. (1980), *La conjecture de Weil II*, Publications Mathématiques de l'IHÉS 52, 137–252. Selected current source records: printed pages 201–203, 206, 215–216, 248. Retained French and English TeX windows are listed in `SOURCE_REVIEW.md`.

The Stacks Project, Section 50.15, Tag 0FMU, *Log poles along a divisor*. Its residue exact sequence fixes the complexes in (15); the actual calculations in (12), (13), and (18) are given here. The comparison is made in complexes of complex vector-space sheaves, since their connections are coefficient-linear, not $\mathcal O_X$-linear.

The new exact tests are finite regression checks of the displayed polynomial, matrix, quotient, connection, residue, and Cech formulas. They do not certify infinite arithmetic integrals, compile new Lean modules, or prove a realization comparison absent from this note. The frozen predecessor is preserved. No remote branch is modified by this delivery.

Marco Hien (2009), *Periods for flat algebraic connections*, Inventiones Mathematicae 178, 1–22, DOI 10.1007/s00222-009-0185-7, is primary background for de Rham/rapid-decay duality. Only its bibliographic record and abstract were consulted here; no general theorem from it is needed in the direct contour proof (36a)–(36h).
