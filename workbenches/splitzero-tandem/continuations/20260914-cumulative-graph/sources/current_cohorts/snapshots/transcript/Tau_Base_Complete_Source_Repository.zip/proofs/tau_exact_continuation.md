---
title: "Exact continuation of the tau-base restriction and adjunction"
author: ""
date: "13 September 2026"
---

# 1. Objects, provenance, and cochain conventions

The complete successor *A global retraction of the original theta complex over the tau base*, retained as Tau_Global_Comparison_2026-09-12/RESEARCH_NOTE.md, was also read completely. Its SHA256 is 496f3ec752e3e67ddafaae7423feb300b1faa789ca6907872f8d539bdf6e1859. Equations (6.12a)–(6.12i) below reproduce its constructive retraction and evaluate the previously general closure kernel for this exact source.

This calculation continues equations (18)–(48) of *Arithmetic cohomology over the tau-base*. The complete source `NOTE.md` has SHA256 `d03e71ad18f187bd89880cb8ca6fc9c5d6f260b3de8e8e5702c27db97e7b63c3`. Its complete retained dependency `sources/Split_Support_Actual_Comparison__CONTINUATION.tex` has SHA256 `98e8aaa63b1f7ee4661c043cd985ca274646b749f36d23d2ec46cbc4b0737dc5`. Both were read completely for this calculation. The category, original theta source, masks, analytic topology, multiplicities, and actions below are those sources' objects.

Let \(E=\mathbb C\), let \(P\) have order \(+<\eta<\sigma\) and \(-<\eta<\sigma\), and let \(\mathcal A=\operatorname{Fun}(P,\operatorname{Vect}_E)\). A diagram \(F\in\mathcal A\) is specified by
\[
U=F_+,\quad V_-=F_-,\quad M=F_\eta,\quad S=F_\sigma,
\qquad r_+:U\to M,\quad r_-:V_-\to M,\quad t:M\to S.
\tag{1.1}
\]
Its remaining two arrows are the composites \(tr_+\) and \(tr_-\). The symbol \(V_-\) here denotes a general stalk; \(V\) in Section 5 denotes the original even Schwartz source.

Use cohomological complexes. For a chain map \(f:C\to D\), define
\[
\operatorname{Cone}(f)^n=D^n\oplus C^{n+1},\qquad
d(y,x)=(d_Dy+fx,-d_Cx),\qquad
d_{C[k]}=(-1)^k d_C.
\tag{1.2}
\]
After ordering its summands as \(C^n\oplus D^{n-1}\), the homotopy fibre is
\[
\operatorname{Fib}(f)=\operatorname{Cone}(f)[-1],\qquad
d(c,y)=(d_Cc,-d_Dy-fc).
\tag{1.3}
\]
For internal Hom use
\[
d_{\operatorname{Hom}}h=d_Wh-(-1)^{|h|}h d_C.
\tag{1.4}
\]
These conventions, including the minus sign in the second component of (1.3), remain fixed throughout.

# 2. The original pushforward and the complete restriction fibre

Define \(P_x(y)=E\) for \(x\le y\), and zero otherwise, with identity arrows between nonzero stalks. A natural map \(P_x\to F\) is uniquely specified by the image of \(1\in P_x(x)\), so \(\operatorname{Hom}(P_x,F)=F_x\). Evaluation is exact, hence \(P_x\) is projective. The sequence
\[
0\longrightarrow P_\eta
\xrightarrow{v\mapsto(v,-v)}P_+\oplus P_-
\xrightarrow{(u,v)\mapsto u+v}\mathbf E\longrightarrow0
\tag{2.1}
\]
is exact: at \(+\) and \(-\) its last arrow is identity; at \(\eta,\sigma\) its kernel is the displayed anti-diagonal; all restriction squares commute. Consequently a representative of the source functor is
\[
C(F)=\mathsf A_\tau(F)
=[U\oplus V_-\xrightarrow{\delta}M],\qquad
\delta(u,v)=r_+u-r_-v,
\tag{2.2}
\]
in degrees \(0,1\). With (1.4), applying internal Hom to (2.1) initially gives differential \(-\delta\); the explicit isomorphism to (2.2) is identity in degree zero and minus identity in degree one. This is a change between two stated cochain presentations, not a modification of the arithmetic differential in (2.2).

The two representatives of derived restriction are
\[
f_+(u,v)=tr_+u,\qquad f_-(u,v)=tr_-v,
\qquad C(F)\longrightarrow S[0].
\tag{2.3}
\]
They are chain maps because the target has only degree zero. Their difference is \(t\delta\). Thus \(h^1=t:M\to S\) satisfies \(f_+-f_-=d_Sh+h d_C\). In particular both represent the same natural derived morphism.

Using \(f_+\), the complete fibre is
\[
\boxed{B_\sigma(F)=
[U\oplus V_-\xrightarrow{b}M\oplus S],\quad
b(u,v)=(r_+u-r_-v,-tr_+u).}
\tag{2.4}
\]
The cone itself has degrees \(-1,0\) and differential
\[
U\oplus V_-\longrightarrow S\oplus M,
\qquad (u,v)\longmapsto(tr_+u,-r_+u+r_-v).
\tag{2.5}
\]
No stalk or quotient has been dropped in either presentation.

Put
\[
I=\operatorname{im}r_+\cap\operatorname{im}r_-\subset M.
\tag{2.6}
\]
Then the complete cohomology of (2.4) is
\[
H^0B_\sigma(F)=
\{(u,v):r_+u=r_-v\in\ker t\},
\tag{2.7}
\]
\[
H^1B_\sigma(F)=
\frac{M\oplus S}
{\{(r_+u-r_-v,-tr_+u):u\in U,v\in V_-\}},
\tag{2.8}
\]
and all its other cohomology groups vanish. There are exact sequences
\[
0\longrightarrow\ker r_+\oplus\ker r_-
\longrightarrow H^0B_\sigma(F)
\xrightarrow{(u,v)\mapsto r_+u}I\cap\ker t
\longrightarrow0,
\tag{2.9}
\]
\[
0\longrightarrow S/t(I)
\xrightarrow{[s]\mapsto[(0,s)]}H^1B_\sigma(F)
\xrightarrow{[(m,s)]\mapsto[m]}
M/(\operatorname{im}r_++\operatorname{im}r_-)
\longrightarrow0.
\tag{2.10}
\]
For (2.9), every element of the displayed intersection has a preimage under each leg, and the kernel is exactly the indicated direct sum. For (2.10), the last map is well defined and surjective. A class in its kernel has \(m=\delta(u,v)\); subtracting \(b(u,v)\) replaces it by \((0,s+tr_+u)\). The class of \((0,s)\) vanishes exactly when there exist \(u,v\) with \(r_+u=r_-v\) and \(s=-tr_+u\), which is precisely \(s\in t(I)\). This proves the sequence, including the sign in its presentation. These are exact sequences of specified objects, without a chosen splitting.

Equivalently the restriction long exact sequence is
\[
0\to H^0B_\sigma(F)\to\ker\delta
\xrightarrow{f_+}S
\xrightarrow{s\mapsto[(0,-s)]}H^1B_\sigma(F)
\to\operatorname{coker}\delta\to0.
\tag{2.11}
\]
Its signs agree with (1.2): when the fibre-to-source arrow is the positive projection, the rotated distinguished triangle has boundary arrow minus the inclusion of \(S\) in \(\operatorname{Cone}(f)=B_\sigma(F)[1]\). This accounts for the minus in (2.11); the independently specified exact presentation (2.10) uses the positive inclusion. The only nonzero possible cone cohomology is \(H^{-1}\operatorname{Cone}(f)=H^0B_\sigma(F)\) and \(H^0\operatorname{Cone}(f)=H^1B_\sigma(F)\).

The two representative fibres are related by the chain isomorphism
\[
B_{\sigma,+}(F)\longrightarrow B_{\sigma,-}(F),\qquad
\Phi^0=1,\quad\Phi^1(m,s)=(m,s+tm),
\tag{2.12}
\]
whose inverse subtracts \(tm\). Indeed \(-f_++t\delta=-f_-\). Thus the fibre calculation does not depend on a privileged choice of the plus leg.

# 3. Naturality and the right-adjoint comparison

A morphism \(a:F\to F'\) consists of maps \(a_+,a_-,a_\eta,a_\sigma\) commuting with \(r_+,r_-,t\). The fibre map is exactly
\[
B_\sigma(a)^0=a_+\oplus a_-,\qquad
B_\sigma(a)^1=a_\eta\oplus a_\sigma.
\tag{3.1}
\]
For example its second differential component is
\(-a_\sigma tr_+u=-t'r'_+a_+u\); the first follows from the two other commutative squares. Formula (3.1) also commutes with (2.12), because \(a_\sigma t=t'a_\eta\). This proves the naturality of every kernel, quotient, exact sequence, and representative comparison above.

For a vector space \(W\), let \(I_x(W)(y)=W\) for \(y\le x\), and zero otherwise. A natural map \(F\to I_x(W)\) is uniquely determined by its component \(F_x\to W\); the other nonzero components are precomposition with \(F_y\to F_x\). Hence
\[
\operatorname{Hom}_{\mathcal A}(F,I_x(W))=\operatorname{Hom}_E(F_x,W).
\tag{3.2}
\]
Every vector space is injective over \(E\): a linear map on a subspace extends after extending a basis. Therefore the right side is exact contravariantly in \(F\), and \(I_x(W)\) is injective.

Let
\[
K_\tau(W)=[I_\eta(W)\xrightarrow{(+\mathrm{res},-\mathrm{res})}
I_+(W)\oplus I_-(W)]
\tag{3.3}
\]
have degrees \(-1,0\). It is a bounded injective complex. Applying (3.2) gives
\[
R\operatorname{Hom}_{\mathcal A}(F,K_\tau(W))=
[\operatorname{Hom}(M,W)\xrightarrow{\ell\mapsto(\ell r_+,-\ell r_-)}
\operatorname{Hom}(U,W)\oplus\operatorname{Hom}(V_-,W)].
\tag{3.4}
\]
The internal Hom of (2.2) into \(W[0]\) has exactly this differential: the element \(\ell\) has degree \(-1\), so (1.4) gives \(d\ell=+\ell\delta\). In particular the signs in the original single-factor adjoint and residue arrow require no repair.

For completeness the adjunction holds for bounded complexes, with all totalization signs specified. Define
\[
C(F)^n=(F_+^n\oplus F_-^n)\oplus F_\eta^{n-1},
\quad d(b,m)=(d_Fb,\delta b-d_Fm),
\tag{3.5}
\]
and \(K_\tau(W)=K_\tau(E)\otimes W\), with tensor differential. A degree \(n\) map \(F\to K_\tau(W)\) consists of
\(b_p:F_+^p\oplus F_-^p\to W^{p+n}\) and \(a_p:F_\eta^p\to W^{p+n+1}\). The isomorphism to \(\operatorname{Hom}^n(C(F),W)\) keeps \(b_p\) and takes
\[
\ell_p=(-1)^{n+1}a_p.
\tag{3.6}
\]
On the source differential these components become
\[
a'_p=-d_Wa_p-(-1)^n a_{p+1}d_F,
\quad b'_p=d_Wb_p+a_p\delta-(-1)^n b_{p+1}d_F.
\tag{3.7}
\]
On the target they become
\[
\ell'_p=d_W\ell_p+(-1)^n\ell_{p+1}d_F,
\quad b'_p=d_Wb_p-(-1)^n(b_{p+1}d_F+\ell_p\delta).
\tag{3.8}
\]
Substitution of (3.6) gives equality in both components. Bounded injective targets compute derived Hom, and (2.1), with the degree \(n\) multiplier \((-1)^n\) on its eta component, gives (3.5) from its projective resolution. This proves the bounded derived adjunction as an actual natural chain isomorphism.

The stalk complexes of (3.3) are \([W\xrightarrow{1}W]\) at \(+\), \([W\xrightarrow{-1}W]\) at \(-\), \(W[1]\) at \(\eta\), and zero at \(\sigma\). The stalkwise kernel diagram is \(S_\eta W\), supported only at \(\eta\). Its inclusion in degree \(-1\) is a natural quasi-isomorphism
\[
S_\eta W[1]\longrightarrow K_\tau(W).
\tag{3.9}
\]

Since every point of \(P\) lies below \(\sigma\), \(I_\sigma(W)\) is the constant diagram \(W\). It represents the dual of the sigma stalk. The actual adjoint of restriction is
\[
\alpha_+:I_\sigma(W)\longrightarrow K_\tau(W),
\tag{3.10}
\]
given in degree zero by restriction into \(I_+(W)\), and zero into \(I_-(W)\). The alternative \(\alpha_-\) restricts into \(I_-(W)\). Their difference is \(d_Kh\), where \(h:I_\sigma(W)\to I_\eta(W)\) is restriction in degree \(-1\). Applying Hom to (3.10) sends \(w:S\to W\) to \((wtr_+,0)\), which is exactly precomposition with \(f_+\). This identifies the morphism, rather than only comparing its endpoints.

# 4. The dual of the restriction fibre and its nonsplit extension

Define the bounded injective complex
\[
R_\tau(W)=
[I_\eta(W)\oplus I_\sigma(W)
\xrightarrow{d_R} I_+(W)\oplus I_-(W)],
\tag{4.1}
\]
in degrees \(-1,0\), where
\[
d_R(\ell,w)=(\ell\mathrm{res}_+-w\mathrm{res}_{\sigma,+},
-\ell\mathrm{res}_-).
\tag{4.2}
\]
Here restriction symbols denote the natural maps of injective diagrams. Formula (3.2) makes its Hom differential
\[
(\ell,w)\longmapsto(\ell r_+-wtr_+,-\ell r_-).
\tag{4.3}
\]
This is precisely precomposition with the two components \((\delta,-f_+)\) of (2.4), with the positive sign supplied by degree \(-1\) in (1.4). Therefore
\[
\boxed{R\operatorname{Hom}_{\mathcal A}(F,R_\tau(W))
\cong R\operatorname{Hom}_E(B_\sigma(F),W).}
\tag{4.4}
\]
Equivalently \(R_\tau(W)=\operatorname{Cone}(-\alpha_+)\). Multiplying its \(I_\sigma(W)\) cone summand by \(-1\) identifies this presentation with \(\operatorname{Cone}(\alpha_+)\); (4.2) fixes which presentation is being used in (4.4).

At \(+\), the differential is \((\ell,w)\mapsto\ell-w\), with kernel \((w,w)\). At \(-\), it is \((\ell,w)\mapsto-\ell\), with kernel \((0,w)\). At \(\eta\) it has domain \(W\oplus W\) and zero target, and at \(\sigma\) it has domain \(W\) and zero target. All degree-zero cokernels vanish. Consequently, if \(D(W)\) has stalks
\[
D(W)_+=W,\quad D(W)_-=W,\quad D(W)_\eta=W\oplus W,
\quad D(W)_\sigma=W,
\tag{4.5}
\]
and arrows
\[
w\longmapsto(w,w)\quad(+\to\eta),\qquad
w\longmapsto(0,w)\quad(-\to\eta),\qquad
(u,w)\longmapsto w\quad(\eta\to\sigma),
\tag{4.6}
\]
the kernel inclusion is a natural quasi-isomorphism \(D(W)[1]\to R_\tau(W)\).

There is an exact sequence of diagrams
\[
\boxed{0\longrightarrow S_\eta W
\xrightarrow{u\mapsto(u,0)}D(W)
\xrightarrow{\text{second coordinate}}I_\sigma(W)
\longrightarrow0.}
\tag{4.7}
\]
At \(+,-,\sigma\) the last map is identity under (4.5); at eta its kernel is the first coordinate. Naturality follows directly from (4.6). For \(W\ne0\), the extension has no natural splitting. Indeed a splitting is identity at the plus and minus stalks, since the quotient there is identity. Commutation along \(+\to\eta\) forces its eta component to be \(w\mapsto(w,w)\), whereas commutation along \(-\to\eta\) forces \(w\mapsto(0,w)\). They disagree on every nonzero \(w\in W\). This proves nonsplitting explicitly.

In the original case \(F_\sigma=0\), every term \(\operatorname{Hom}(F,I_\sigma(W))=\operatorname{Hom}(0,W)\) is zero. Thus the inclusion \(K_\tau(W)\to R_\tau(W)\) induces an actual equality of the represented Hom complexes, as well as an isomorphism in the derived category. The nonzero original global arithmetic classes are therefore all in the relative fibre, and their original adjoint is precisely the restriction of (4.4) to these objects.

# 5. Calculation on the original theta source and every mask

Retain the exact original spaces and maps
\[
V=\{\phi\in\mathcal S(\mathbb R):\phi(-x)=\phi(x),
\ \phi(0)=0,\ \widehat\phi(0)=0\},
\quad\widehat\phi(\xi)=\int_{\mathbb R}\phi(x)e^{-2\pi i x\xi}\,dx,
\tag{5.1}
\]
\[
\mathscr B=\{F\in C^\infty(\mathbb R_{>0}):
\sup_{x>0}x^b|(-x\partial_x)^kF(x)|<\infty
\text{ for all }b\in\mathbb Z,k\ge0\},
\tag{5.2}
\]
\[
\Theta\phi(x)=\sum_{n\in\mathbb Z\setminus\{0\}}\phi(nx),
\qquad JF(x)=x^{-1}F(1/x),\qquad J\Theta=\Theta\mathcal F.
\tag{5.3}
\]
The last identity is the retained Poisson identity. Explicitly, the full Poisson equation is
\(\sum_n\phi(nx)=x^{-1}\sum_n\widehat\phi(n/x)\); the two zero terms vanish by (5.1), giving (5.3). At infinity every differentiated summand is bounded by a constant times \((|n|x)^{-N}\) for any chosen \(N>1\); summing \(2\sum_{n\ge1}n^{-N}\) proves rapid decay. Applying (5.3) proves arbitrary power decay at zero, with all derivatives, so \(\Theta:V\to\mathscr B\). The Fourier transform preserves (5.1) because it exchanges the value and integral conditions, and its square is reflection, which is identity on even functions.

The map \(\Theta\) is injective. For \(\Re s=c>1\), absolute convergence gives
\[
\mathcal M\Theta\phi(s)=2\zeta(s)\mathcal M\phi(s),
\qquad\mathcal M F(s)=\int_0^\infty F(x)x^s\,\frac{dx}{x}.
\tag{5.4}
\]
For absolute convergence, the integral of \(|\phi(nx)|x^{c-1}\) is \(n^{-c}\int_0^\infty|\phi(u)|u^{c-1}du\), and both the integral and \(\sum n^{-c}\) are finite. The Euler product is nonzero for \(c>1\), as follows from absolute convergence of its logarithm. If \(\Theta\phi=0\), (5.4) makes \(\mathcal M\phi(c+it)=0\) for every real \(t\). This is the Fourier transform, with its frequency sign explicitly reversed, of the integrable function \(y\mapsto e^{cy}\phi(e^y)\). Fourier uniqueness gives zero almost everywhere and continuity gives zero everywhere. Evenness then gives \(\phi=0\) on the full real line.

The joint sheaf is
\[
\mathcal T=(V,V,\mathscr B,0;\Theta,\Theta\mathcal F,0),
\qquad C(\mathcal T)=[V\oplus V\xrightarrow{\Theta(\phi-\widehat\psi)}\mathscr B].
\tag{5.5}
\]
Its restriction map is zero on both chain representatives, so
\[
\boxed{B_\sigma(\mathcal T)=C(\mathcal T),\quad
\operatorname{Cone}(\operatorname{res}_\sigma)=C(\mathcal T)[1].}
\tag{5.6}
\]
Injectivity just proved gives
\[
H^0B_\sigma(\mathcal T)=\{(\widehat\psi,\psi):\psi\in V\},\qquad
H^1B_\sigma(\mathcal T)=Q:=\mathscr B/\Theta V.
\tag{5.7}
\]
The quotient here is the algebraic quotient with its original quotient locally convex topology. The later global retraction source proves that this image is closed; its exact retraction and the resulting zero closure kernel are included after (6.12) below.

Let \(L=\mathcal P(\{+,-\})\). For each nonempty mask \(A\in L\), retain \(V\) at each admitted leg and the zero coefficient space at a missing leg, retain \(\mathscr B\) at eta and zero at sigma, and retain the restrictions in (5.5). The empty mask has the zero diagram. Every nonempty \(A\) has restriction fibre exactly \(C(\mathcal T_A)\); its differential image is \(\Theta V\), since both \(\Theta\) and \(\Theta\mathcal F\) have that image. A one-leg differential is injective, with its literal plus or minus sign retained. It follows that
\[
H^0B_\sigma(\mathcal T_A)=
\begin{cases}V,&A=\{+,-\},\\0,&|A|=1,\end{cases}
\qquad H^1B_\sigma(\mathcal T_A)=Q\quad(A\ne\varnothing).
\tag{5.8}
\]
For mask inclusions the eta map is identity and leg maps are coordinate inclusions, hence the induced \(H^1\) map is exactly identity on \(Q\). This explicitly proves compatibility with every original mask transport.

Reconstruction gives
\[
\widetilde H^1B_\sigma=
\{\tau\}\sqcup\bigsqcup_{\varnothing\ne A\subseteq\{+,-\}}
\{A\}\times Q.
\tag{5.9}
\]
The scalar \(e=0_E^\bullet\in G(E)\) sends \((A,q)\) to \((A,0)\). The scalar \(\tau\) sends it to the absent element. Linear restriction to the zero coefficient at sigma sends \(q\) to zero, but its supported reconstruction is \((A,q)\mapsto(A,0)\), preserving \(A\). No class of (5.9) becomes absent merely because its coefficient restricts to zero. The same statement applies to (2.4), (3.4), and (4.4) fibrewise, with dual label arrows given by actual precomposition and hence indexed by \(L^{\mathrm{op}}\).

# 6. Finite jets, their full kernel, and the retained topology

Put \(g=2\xi\), where
\[
\xi(s)=\tfrac12 s(s-1)\pi^{-s/2}\Gamma(s/2)\zeta(s).
\tag{6.1}
\]
The source's full-plane multiplier identity is
\[
\mathcal M\Theta\phi=gH_\phi,
\qquad H_\phi=\frac{\mathcal M\phi}{\tfrac12 s(s-1)\pi^{-s/2}\Gamma(s/2)}\in\mathcal O(\mathbb C).
\tag{6.2}
\]
Here is the full continuation used in this identity. Write the Taylor expansion of the even Schwartz function at zero as \(\phi(x)=\sum_{j=0}^N a_{2j}x^{2j}+O(x^{2N+2})\). Subtract this finite sum in its Mellin integral over \((0,1)\). The remainder is holomorphic for \(\Re s>-2N-2\), while the subtracted terms have integrals \(a_{2j}/(s+2j)\). The integral over \((1,\infty)\) is entire by Schwartz decay. Since \(N\) is arbitrary, \(\mathcal M\phi\) has meromorphic continuation with only possible simple poles at the nonpositive even integers. The reciprocal \(1/\Gamma(s/2)\) has a simple zero at each such integer and cancels each possible pole. At \(s=0\), the condition \(a_0=\phi(0)=0\) removes the Mellin pole, and \(1/\Gamma(s/2)\) cancels the explicit factor \(s\) in the denominator of \(H_\phi\). At \(s=1\), evenness and the integral condition give \(\mathcal M\phi(1)=\tfrac12\int_{\mathbb R}\phi=0\), cancelling \(s-1\). No other denominator zero occurs, since the gamma function has no zeros. Thus the displayed \(H_\phi\) is entire. Formula (5.4) proves (6.2) first on \(\Re s>1\), and analytic continuation proves it everywhere, with the original factor \(g=2\xi\) retained.

Let \(Z\) be a finite set of actual zeros of \(g\) with their actual orders \(m_\rho\), and write
\[
z_\rho=s-\rho,\quad g(s)=u_\rho(z_\rho)z_\rho^{m_\rho},
\quad u_\rho(0)\ne0,
\quad A_Z=\bigoplus_{\rho\in Z}\mathcal O_\rho/(g).
\tag{6.3}
\]
The germ coordinate \(z_\rho\), the full jet length, and the actual unit \(u_\rho\) are retained. The jet arrow is
\[
J_Z:\mathscr B\longrightarrow A_Z,\qquad
(J_ZF)_\rho=\sum_{j=0}^{m_\rho-1}\frac{(\mathcal MF)^{(j)}(\rho)}{j!}z_\rho^j.
\tag{6.4}
\]
Equation (6.2) proves \(J_Z\Theta=0\), so it induces \(q_Z:Q\to A_Z\).

Here is a full finite interpolation proof, with the original \(dx\) Riesz density preserved. Index jets by \(\alpha=(\rho,j)\), and fix any \(R>0\) and \(0<R'<R\). Let
\[
\eta_{R'}(y)=
\begin{cases}\exp[-1/((R')^2-y^2)],&|y|<R',\\0,&|y|\ge R',\end{cases}
\quad r_\alpha(x)=x^{\bar\rho-1}(\log x)^j/j!.
\tag{6.5}
\]
Set
\[
B_{\alpha\beta}=
\frac1{j!k!}\int_{-R'}^{R'}\eta_{R'}(y)
e^{(\rho+\bar\sigma-1)y}y^{j+k}\,dy,
\qquad\beta=(\sigma,k).
\tag{6.6}
\]
This is \(\ell_\alpha(\eta_{R'}(\log x)r_\beta(x))\), where \(\ell_\alpha\) is the corresponding component of (6.4). It is Hermitian. For a column \(c\), its quadratic form is
\[
\bar c^{\mathsf T}Bc=
\int_{-R'}^{R'}\eta_{R'}(y)e^{-y}
\left|\sum_\alpha\bar c_\alpha e^{\rho y}y^j/j!\right|^2dy.
\tag{6.7}
\]
The exponential polynomials are independent: for a fixed exponent \(\rho\), apply \(\prod_{\sigma\ne\rho}(\partial_y-\sigma)^{m_\sigma}\) to a vanishing linear combination. It kills every other exponent block, and acts on the remaining block by \(e^{\rho y}\) times \(\prod_{\sigma\ne\rho}(\partial_y+\rho-\sigma)^{m_\sigma}\). Each factor on finite-degree polynomials is invertible, since it is a nonzero constant plus a nilpotent differentiation operator, with inverse given by the terminating geometric series. Hence that polynomial block is zero. This holds for every \(\rho\), proving independence. Therefore (6.7) is strictly positive for \(c\ne0\), so \(B\) is invertible.

For \(v\in A_Z\), the function
\[
s_Z(v)(x)=\eta_{R'}(\log x)
\sum_\beta(B^{-1}v)_\beta r_\beta(x)
\tag{6.8}
\]
is smooth, belongs to \(\mathscr B\), has support in \([e^{-R'},e^{R'}]\subset(e^{-R},e^R)\), and satisfies \(J_Zs_Z(v)=v\) by matrix multiplication. Thus (6.4) and \(q_Z\) are surjective, with an explicitly calculated finite-dimensional continuous section of (6.4).

For continuity, choose an integer \(N>|\Re\rho|\) and put
\(p_N(F)=\max(\sup x^N|F(x)|,\sup x^{-N}|F(x)|)\). Splitting the integral at one gives the exact bound
\[
|\ell_{\rho,j}(F)|\le p_N(F)
\left((N+\Re\rho)^{-j-1}+(N-\Re\rho)^{-j-1}\right).
\tag{6.9}
\]
Indeed the two integrals of \(|\log x|^j/j!\) against \(x^{N+\Re\rho}dx/x\) and \(x^{-N+\Re\rho}dx/x\) are the two displayed terms. This also proves that the Mellin jet derivatives used here are well-defined by dominated differentiation.

Define the actual retained kernel spaces, using \(\mathscr K_Z\) to avoid changing the different space named \(\mathscr B_Z\) in the source's finite arithmetic extension:
\[
\mathscr K_Z=\ker J_Z,\qquad
Q_Z^0=\mathscr K_Z/\Theta V.
\tag{6.10}
\]
They give exact sequences
\[
0\longrightarrow\mathscr K_Z\longrightarrow\mathscr B
\xrightarrow{J_Z}A_Z\longrightarrow0,
\quad
\boxed{0\longrightarrow Q_Z^0\longrightarrow Q
\xrightarrow{q_Z}A_Z\longrightarrow0.}
\tag{6.11}
\]
The first is split by (6.8); the second is split as a topological vector-space sequence by the induced section. No equivariance of this section is asserted: only the arrows (6.11) are canonical scaling morphisms.

To verify the topology assertion, the map
\((F_0,v)\mapsto F_0+s_Z(v)\) is a continuous linear bijection \(\mathscr K_Z\oplus A_Z\to\mathscr B\), with continuous inverse \(F\mapsto(F-s_ZJ_ZF,J_ZF)\). Since \(\Theta V\subset\mathscr K_Z\), passing to the quotient gives the claimed topological direct sum. By (6.9), \(\mathscr K_Z\) is closed, so \(\overline{\Theta V}\subset\mathscr K_Z\). The same proof gives
\[
0\to\mathscr K_Z/\overline{\Theta V}
\to Q^{\mathrm H}:=\mathscr B/\overline{\Theta V}
\to A_Z\to0,
\quad
\ker(Q\to Q^{\mathrm H})=\overline{\Theta V}/\Theta V.
\tag{6.12}
\]
Thus every finite jet survives both specified quotients, with the closure kernel written explicitly. No new global topology has been substituted.

For this actual source the kernel in (6.12) is zero. We include the later source's constructive reason, retaining its auxiliary cutoffs and contraction constant. Let \(\mu\) be the arithmetic Möbius function, and define on \(x\ne0\)
\[
\mathcal UF(x)=\tfrac12\sum_{n\ge1}\mu(n)F(n|x|).
\tag{6.12a}
\]
For \(j\ge0\), write \(x^j\partial_x^j=P_j(D)\), where \(P_j(T)=(-1)^jT(T+1)\cdots(T+j-1)\), and let \(C_{N,j}(F)\) be the sum of \(p_{N,k}(F)=\sup x^N|D^kF|\) weighted by the absolute coefficients of \(P_j\). For each integer \(N>1\), termwise differentiation gives
\[
|\partial_x^j\mathcal UF(x)|
\le\tfrac12\zeta(N)C_{N,j}(F)x^{-N-j}\qquad(x>0).
\tag{6.12b}
\]
Uniform convergence away from zero justifies each derivative. On the original theta image the double sum is absolutely convergent, bounded by \(\sum_{k\ge1}d(k)|\phi(kx)|\), which converges by Schwartz decay and \(d(k)\le k\). The identity \(\sum_{n\mid k}\mu(n)=1\) for \(k=1\), zero otherwise, therefore proves
\[
\mathcal U\Theta\phi=\phi,\qquad
\mathcal UJ\Theta\phi=\widehat\phi\quad(x\ne0).
\tag{6.12c}
\]
Choose the original type of real even compactly supported smooth cutoffs \(0\le\alpha,\beta\le1\), each equal to one near zero, and set on \(L^2(\mathbb R,dx)\)
\[
T=M_\alpha\mathcal F^{-1}M_\beta\mathcal F,\quad c=\|T\|,\qquad
YF=(1-\alpha)\mathcal UF+
\alpha\mathcal F^{-1}((1-\beta)\mathcal UJF).
\tag{6.12d}
\]
The kernel of \(T\) is \(\alpha(x)\check\beta(x-y)\), with squared \(L^2\) norm \(\|\alpha\|_2^2\|\beta\|_2^2\), so \(T\) is compact. Both its factors are contractions. If \(c=1\), compactness supplies a norm-attaining unit vector \(f\); equality in both contraction inequalities forces \(\widehat f\) to have compact support where \(\beta=1\) and \(f\) to have compact support where \(\alpha=1\). Compact Fourier support makes the inverse Fourier integral entire, because the compactly supported \(L^2\) transform is \(L^1\) and allows all complex derivatives under its integral. This entire function vanishes on a real interval outside the support of \(f\), hence vanishes identically, a contradiction. Therefore \(c<1\), and
\[
(1-T)^{-1}=\sum_{n\ge0}T^n,\qquad
\|(1-T)^{-1}\|\le(1-c)^{-1}.
\tag{6.12e}
\]
The cut-off exterior maps in \(Y\) are continuous into even Schwartz functions by (6.12b); their values are extended by zero where the cutoff vanishes near zero. The operator \(T:L^2\to\mathcal S\) is continuous: compact Fourier support bounds every derivative of \(\mathcal F^{-1}M_\beta\mathcal Ff\) by Cauchy–Schwarz, and multiplication by smooth compactly supported \(\alpha\) controls every Schwartz seminorm. Thus \(\Phi=(1-T)^{-1}Y\) is Schwartz-valued and continuous: the equation \(\Phi F=YF+T\Phi F\) bounds each Schwartz seminorm \(p\) by
\[
p(\Phi F)\le p(YF)+C_p(1-c)^{-1}\|YF\|_2 .
\tag{6.12f}
\]
It preserves evenness. With \(\gamma_0=e^{-\pi x^2}\) and \(\gamma_2=2\pi x^2e^{-\pi x^2}\), whose value/integral columns are \((1,1)\), \((0,1)\), define \(P_V:\mathcal S(\mathbb R)^{\mathrm{even}}\to V\) by
\[
P_V\phi=\phi-\phi(0)\gamma_0-
\left(\int_{\mathbb R}\phi-\phi(0)\right)\gamma_2,\qquad
\Lambda=P_V(1-T)^{-1}Y.
\tag{6.12g}
\]
This continuous projection has image \(V\) and is identity on \(V\). On \(\Theta\phi\), (6.12c) gives \(Y\Theta\phi=(1-T)\phi\), so
\[
\Lambda\Theta=1_V,\quad
K=1_{\mathscr B}-\Theta\Lambda,\quad
K^2=K,\quad \ker K=\Theta V.
\tag{6.12h}
\]
The last equality follows in both directions by direct substitution. Since \(K\) is continuous, its kernel is closed. Therefore \(\overline{\Theta V}=\Theta V\), \(Q=Q^{\mathrm H}\), and the closure kernel in (6.12) is exactly zero. The section
\[
s:Q\to\mathscr B,\quad s[F]=KF
\tag{6.12i}
\]
is well-defined and continuous in the quotient topology, satisfies \(qs=1\) and \(\Lambda s=0\), and gives the topological decomposition \(\mathscr B\cong V\oplus Q\) by \(F\mapsto(\Lambda F,qF)\). Every cutoff and the factor \((1-c)^{-1}\) remain in this construction. It establishes closedness of the theta image, and makes no assertion that the different kernel \(Q_Z^0\) in (6.11) vanishes.

Let \(\mathcal T_Z\) have the same source legs and sigma stalk as \(\mathcal T\), eta stalk \(\mathscr K_Z\), and the original restrictions. Then
\[
0\to\mathcal T_Z\to\mathcal T\xrightarrow{J_Z}S_\eta A_Z\to0
\tag{6.13}
\]
is exact at each stalk; its eta surjectivity is (6.8). Applying the explicit complexes gives a termwise exact sequence
\[
0\to C(\mathcal T_Z)\to C(\mathcal T)
\to A_Z[-1]\to0.
\tag{6.14}
\]
The kernel inclusion into the homotopy fibre of the last map is a quasi-isomorphism. This follows directly by quotienting that inclusion: the quotient fibre is the fibre of the identity of \(A_Z[-1]\), whose two identical terms have an invertible differential and zero cohomology. Therefore the full cohomology of this jet-comparison fibre is
\[
H^0=V\quad\text{via }\psi\mapsto(\widehat\psi,\psi),
\qquad H^1=Q_Z^0,
\tag{6.15}
\]
and nothing else. On a nonempty one-leg mask \(H^0=0\) and \(H^1=Q_Z^0\); the same proof applies to each exact mask diagram. On \(S_\eta A_Z\) itself, sigma restriction is zero, its restriction fibre is exactly \(A_Z[-1]\), and its restriction cone is \(A_Z[0]\).

For disjoint finite packets \(Z,W\) of actual zeros, simultaneous application of (6.8) to \(Z\cup W\) with prescribed coordinates \((0,w)\) proves the further exact surjection
\[
Q_Z^0\longrightarrow A_W.
\tag{6.16}
\]
Consequently the kernel in (6.11) retains all these explicitly reachable omitted packets. It has not been set to zero.

# 7. Original scaling, generator, and dual actions

For \(a>0\), retain \(U_aF(x)=F(x/a)\). Substitution \(x=ay\) gives
\[
\mathcal MU_aF(s)=a^s\mathcal MF(s),\qquad
\widehat{U_a\phi}=aU_{1/a}\widehat\phi.
\tag{7.1}
\]
These operators preserve the original test spaces: dilation rescales each defining Schwartz or \(\mathscr B\) seminorm by finite constants, preserves evenness and the value-zero condition, and multiplies the integral by \(a\). The source sheaf action is exactly
\[
U_a^{\mathcal T}:
(\phi,\psi,F)\longmapsto(U_a\phi,aU_{1/a}\psi,U_aF).
\tag{7.2}
\]
The identities \(\Theta U_a=U_a\Theta\) and (7.1) give
\[
d(U_a\phi,aU_{1/a}\psi)=U_a\Theta(\phi-\widehat\psi).
\tag{7.3}
\]
Thus (7.2) is a diagram automorphism and (3.1) proves equivariance of every restriction-fibre map. On \(H^0=V\) in the parameter \(\psi\) of (5.7), its action is \(\psi\mapsto aU_{1/a}\psi\); on \(Q\) it is \([F]\mapsto[U_aF]\). Every support mask is fixed.

The infinitesimal generator for \(a=e^t\) at \(t=0\) is \(D=-x\partial_x\) on the plus and eta stalks, and \(1-D\) on the minus stalk. Differentiating (7.1) gives the original relation \(\mathcal F D=(1-D)\mathcal F\). Integration by parts, with zero boundary terms because \(F\in\mathscr B\), gives \(\mathcal M(DF)=s\mathcal MF\).

On the full local jet algebra,
\[
U_a|_\rho=a^\rho\exp((\log a)N_\rho)
=a^\rho\sum_{k=0}^{m_\rho-1}\frac{(\log a)^k}{k!}N_\rho^k,
\quad N_\rho(z_\rho^j)=z_\rho^{j+1},
\tag{7.4}
\]
where \(N_\rho(z_\rho^{m_\rho-1})=0\). The generator is \(\rho I+N_\rho\). This follows by multiplying the jet by the exact germ \(a^{\rho+z_\rho}\), so (6.4), (6.11), (6.13), and (6.14) intertwine it; in particular \(\mathscr K_Z\) and \(Q_Z^0\) are stable under scaling. Nilpotent directions have not been replaced by their trace.

Let \(\mathcal L_1=E\) with action \(w\mapsto aw\), the original integral-moment line. On every dual object the action is the induced Hom action
\[
(U_a\ell)(v)=a\ell(U_{1/a}v).
\tag{7.5}
\]
The formula is forced by the evaluation map \(\ell\otimes v\mapsto\ell(v)\in\mathcal L_1\): applying (7.5) and \(U_a\) to both inputs multiplies the result by \(a\). Since all maps in Sections 3 and 4 are defined by precomposition and restriction, this proves their equivariance with (7.5), including every contravariant mask transport.

The known continuous section (6.12i) has an exact, retained scaling defect. Denote the induced action on \(Q\) by \(\overline U_a\), and define
\[
k_a=\Lambda U_a s:Q\to V,\qquad
U_a s-s\overline U_a=\Theta k_a.
\tag{7.6}
\]
To prove the second equality, use \(1_{\mathscr B}=sq+\Theta\Lambda\) on \(U_as\), and \(qU_as=\overline U_a\). The group identity then gives, without dropping a boundary term,
\[
k_{ab}=U_a k_b+k_a\overline U_b,\qquad k_1=0.
\tag{7.7}
\]
Indeed expand \(U_{ab}s-s\overline U_{ab}\) by first applying the equation for \(b\), then that for \(a\), and cancel the injective \(\Theta\). These maps are continuous by their formulas. Thus the known topological splitting is accompanied by the full original source-valued action defect.

# 8. Full finite residue arrow and its chain degree

The symmetry of the original \(g=2\xi\) used here follows directly from the original Gaussian Poisson formula, with no assumption on its zeros. Put \(\psi_0(t)=\sum_{n\ge1}e^{-\pi n^2t}\). Poisson gives \(\psi_0(t)=t^{-1/2}\psi_0(1/t)+\tfrac12(t^{-1/2}-1)\). For \(\Re s>1\), termwise integration gives \(\pi^{-s/2}\Gamma(s/2)\zeta(s)=\int_0^\infty\psi_0(t)t^{s/2}\,dt/t\). Splitting at one and substituting \(t=1/v\) in the reflected term therefore yields the entire continuation
\[
g(s)=1+s(s-1)\int_1^\infty\psi_0(t)
\bigl(t^{s/2}+t^{(1-s)/2}\bigr)\,\frac{dt}{t}.
\tag{8.0}
\]
The constant is exactly one: the remaining elementary integral is \(1/(s-1)-1/s=1/[s(s-1)]\). The bound \(\psi_0(t)\le e^{-\pi t}/(1-e^{-\pi t})\) for \(t\ge1\) proves locally uniform convergence with all \(s\)-derivatives. The expression is invariant under \(s\mapsto1-s\), and its real coefficients give conjugation symmetry. Consequently \(g^\dagger=g\), and \(g\) is not the zero function (for example its continuation has \(g(0)=1\)).

Assume \(Z\) is reflection-stable, meaning the finite chosen set satisfies \(\iota Z=Z\) for \(\iota\rho=1-\bar\rho\); this selects an actual finite divisor, without a hypothesis on the location of its points. The completed function has \(g^\dagger=g\) for \(f^\dagger(s)=\overline{f(1-\bar s)}\). In original coordinates,
\[
f_\rho^\dagger(z_\rho)=
\sum_j(-1)^j\overline{f_{\iota\rho,j}}z_\rho^j,
\quad
u_\rho(z)=(-1)^{m_\rho}\overline{u_{\iota\rho}(-\bar z)}.
\tag{8.1}
\]
The residue pairing, with its raw orientation, is
\[
R_Z(f,h)=\sum_{\rho\in Z}\operatorname{Res}_\rho
\frac{f^\dagger(s)h(s)}{g(s)}\,ds.
\tag{8.2}
\]
Changing any representative by a multiple of \(g\) adds a holomorphic differential, so this is well-defined. At \(\rho\), if \(u_\rho(z)^{-1}=\sum_{k\ge0}c_{\rho,k}z^k\), its literal formula is
\[
R_Z(f,h)=\sum_\rho\sum_{i,j=0}^{m_\rho-1}
(-1)^i\overline{f_{\iota\rho,i}}h_{\rho,j}
c_{\rho,m_\rho-1-i-j},
\qquad c_{\rho,k}=0\ (k<0).
\tag{8.3}
\]
The matrix \(G_{ij}=c_{\rho,m_\rho-1-i-j}\) has determinant
\((-1)^{m_\rho(m_\rho-1)/2}u_\rho(0)^{-m_\rho}\ne0\): reversing the columns makes it triangular with diagonal \(u_\rho(0)^{-1}\), and reversal has the displayed sign. Multiplication of the \(i\)-th row by \((-1)^i\), together with the invertible reflection-permutation of blocks, preserves invertibility. Hence \(R_Z\) is perfect, including all nilpotent jets and actual analytic units.

For a meromorphic function \(k\), expansion in \(z_\rho\) gives
\[
\operatorname{Res}_\rho k^\dagger(s)\,ds
=-\overline{\operatorname{Res}_{\iota\rho}k(s)\,ds}.
\tag{8.4}
\]
Only its coefficient of \(z^{-1}\) contributes, and reflection multiplies that coefficient by \((-1)^{-1}=-1\). Apply (8.4) to \(k=h^\dagger f/g\), sum over the permuted divisor, and use \(g^\dagger=g\). The result is
\[
R_Z(f,h)=-\overline{R_Z(h,f)}.
\tag{8.5}
\]
The raw pairing is therefore skew-Hermitian. No phase has been inserted.

The identity \((a^s)^\dagger=a^{1-s}\) gives
\[
R_Z(U_af,U_ah)=aR_Z(f,h).
\tag{8.6}
\]
Thus the following is an injective linear equivariant map from the conjugate vector space:
\[
\boxed{\overline{A_Z}\longrightarrow
H^{-1}R\operatorname{Hom}_{\mathcal A}(\mathcal T,K_\tau(\mathcal L_1)),
\quad \bar f\longmapsto \ell_f,\quad
\ell_f(F)=R_Z(f,J_ZF).}
\tag{8.7}
\]
Here \(\ell_f\) is literally the degree \(-1\) cochain on \(\mathscr B\) in (3.4). It is closed, since (6.2) gives \(\ell_f\Theta=0\), and \(\ell_f\Theta\mathcal F=0\). There is no degree \(-2\) term, so this cocycle represents zero exactly when it is the zero functional. Surjectivity of \(J_Z\) and perfectness of (8.2) then prove injectivity. Formula (8.6), evaluated on \(J_ZU_{1/a}F\), proves \(\ell_{U_af}(F)=a\ell_f(U_{1/a}F)\), exactly (7.5). Bound (6.9) also proves that all these functionals are continuous on the original quotient topology, even though the adjunction (3.4) uses the full algebraic dual. Thus (8.7) exhibits a specified subspace of continuous functionals inside that full dual, by an actual injection.

The contraction \(J_g:h\mapsto g'h\) retains its local form
\[
g'=m_\rho u_\rho(z)z^{m_\rho-1}+u'_\rho(z)z^{m_\rho}
\equiv m_\rho u_\rho(z)z^{m_\rho-1}\pmod{z^{m_\rho}}.
\tag{8.8}
\]
Using \(g'/g=m_\rho/z+u'_\rho/u_\rho\) gives
\[
R_Z(f,J_gh)=\sum_\rho m_\rho
\overline{f(\iota\rho)}h(\rho)
=\operatorname{Tr}(M_{f^\dagger h}\mid A_Z).
\tag{8.9}
\]
The trace equality follows because multiplication by a germ in the ordered basis \(1,z,\ldots,z^{m-1}\) is triangular with its value repeated \(m\) times on the diagonal. The radical in either variable of (8.9) is exactly the subspace of all packets whose constant term is zero: the formula annihilates that subspace, and arbitrary constant terms in the reflected block detect every nonzero remaining value. The differentiated symmetry is \((g')^\dagger=-g'\), which together with (8.5) also confirms the Hermitian orientation of (8.9). No positivity of the raw residue form was used or asserted.

Every arrow in (8.7) is reconstructed at its original label \(A\). A zero functional is \((A,0)\), and the absent input alone is sent to \(\tau\). Precomposition with the mask inclusions commutes with the residue formula because \(H^1\) transport in (5.8) is identity. This completes the labelled adjoint arrow with its degree, sign, topology, and action.

# 9. Tensor compatibility, including the dual Koszul sign

All coefficient tensors in this section are the original algebraic tensors over \(E\); no unproved completed tensor topology is substituted. For a product \(P^r\), tensoring the stalkwise exact resolution (2.1) produces a finite projective resolution of the constant diagram. To see exactness without assuming a tensor theorem, at each stalk split an exact finite complex into its cohomology and elementary two-term identity complexes by choosing complements to boundaries and cycles. Tensoring an elementary identity complex with any complex is contractible, by its usual contracting homotopy tensored with identity. Only the tensor of the degree-zero constant cohomology remains. Each external product of the \(P_x\)'s represents evaluation at the corresponding product point and is projective. This proves the claimed resolution and yields the natural cochain identity
\[
\mathsf A_{\tau,r}(F_1\boxtimes\cdots\boxtimes F_r)
\simeq C(F_1)\otimes\cdots\otimes C(F_r),
\tag{9.1}
\]
with the full differential
\[
d(x_1\otimes\cdots\otimes x_r)=
\sum_{j=1}^r(-1)^{\sum_{k<j}|x_k|}
x_1\otimes\cdots\otimes dx_j\otimes\cdots\otimes x_r.
\tag{9.2}
\]
The standard cross product of cohomology classes is an isomorphism because the same split-complex argument kills all summands with a contractible factor. The proof uses a splitting to verify that the canonical cross product is bijective; it does not make that map dependent on the splitting.

Product restriction is the tensor \(f_1\otimes\cdots\otimes f_r\) to \(S_1\otimes\cdots\otimes S_r[0]\). Changes from plus to minus representatives are compatible: for \(g_i=f_{i,-}\) and \(f_i=f_{i,+}\), a homotopy is
\[
H=\sum_{j=1}^r g_1\otimes\cdots\otimes g_{j-1}
\otimes h_j\otimes f_{j+1}\otimes\cdots\otimes f_r,
\tag{9.3}
\]
where tensor maps act with the Koszul sign and \(h_j^1=t_j\). The differential of each tensor summand is the same tensor with \(d_{\operatorname{Hom}}h_j=f_j-g_j\); every other factor is a degree-zero chain map. Summing telescopes to \(\bigotimes f_i-\bigotimes g_i\), proving the homotopy identity.

For the original sheaves and all nonempty masks, every \(S_i=0\). Thus product restriction is zero and
\[
B_{\sigma^r}(\mathcal T_{A_1}\boxtimes\cdots\boxtimes\mathcal T_{A_r})
=\bigotimes_{i=1}^r C(\mathcal T_{A_i})
=\bigotimes_{i=1}^r B_\sigma(\mathcal T_{A_i}).
\tag{9.4}
\]
The complete cohomology is the graded tensor product of the two groups in (5.8). Explicitly its degree \(n\) is the direct sum over subsets \(I\subseteq\{1,\ldots,r\}\), \(|I|=n\), with \(Q\) in factors indexed by \(I\) and \(H^0C(\mathcal T_{A_i})\) in the other factors. In particular
\[
\boxed{H^rB_{\sigma^r}(\mathcal T^{\boxtimes r})=Q^{\otimes r}.}
\tag{9.5}
\]
The numerator is \(\mathscr B^{\otimes r}\), and its denominator is exactly
\[
\sum_{j=1}^r\mathscr B^{\otimes(j-1)}\otimes\Theta V
\otimes\mathscr B^{\otimes(r-j)}.
\tag{9.6}
\]
Signs in (9.2) change none of these subspaces but remain in the differential itself. The quotient map to \(Q^{\otimes r}\) has kernel (9.6), by successive tensoring of the quotient presentation over the field.

For general diagrams one cannot replace the fibre of a tensor product by the tensor of fibres. The exact replacement can itself be computed. For composable chain maps \(X\xrightarrow fY\xrightarrow gZ\), put \(B(f)=\operatorname{Fib}(f)\) with (1.3). There are chain maps
\[
u:B(f)\to B(gf),\quad (x,y)\mapsto(x,gy),
\qquad v:B(gf)\to B(g),\quad(x,z)\mapsto(fx,z).
\tag{9.7}
\]
Their composite has nullhomotopy \(H(x,y)=(-y,0)\), since \(dH+Hd=(fx,gy)\). A surjective chain map
\[
\operatorname{Cone}(u)\longrightarrow B(g),\quad
(x,z;x',y')\longmapsto(fx-y',z)
\tag{9.8}
\]
has kernel \(z=0,y'=fx\), with remaining coordinates \(x\in X^n,x'\in X^{n+1}\) and differential \((x,x')\mapsto(dx+x',-dx')\). The degree \(-1\) map \((x,x')\mapsto(0,x)\) contracts this kernel. Thus (9.8) is a quasi-isomorphism and proves the fibre triangle explicitly. Apply this with \(f=f_1\otimes1_{C_2}\) and \(g=1_{S_1}\otimes f_2\). The resulting triangle is
\[
B(f_1)\otimes C_2\longrightarrow B(f_1\otimes f_2)
\longrightarrow S_1\otimes B(f_2)\longrightarrow(B(f_1)\otimes C_2)[1].
\tag{9.9}
\]
The first fibre identification follows immediately from (1.3) and the tensor differential; in the second, \(S_1\) is in degree zero. This proves the general tensor relation and explains precisely why it reduces to (9.4) for the original source.

The product right adjoint is
\[
K_{\tau,r}(W)=K_\tau(E)^{\boxtimes r}\otimes W,
\qquad K_{\tau,r}(W)\simeq S_{(\eta,\ldots,\eta)}W[r].
\tag{9.10}
\]
Its terms are finite direct sums of \(I_{(x_1,\ldots,x_r)}(W)\), hence injective. Its only cohomology follows by the same stalkwise contraction proof used for (3.9) and (9.1). No assertion that an infinite-dimensional algebraic dual commutes with tensor products is used.

The adjunction on the product has a sign that must be stated. In total degree \(-p\), multiply the coefficient functional arising from \(K_\tau(E)^{\boxtimes r}\) by
\[
\epsilon_p=(-1)^{p(p-1)/2}
\tag{9.11}
\]
to identify it with \(\operatorname{Hom}^{-p}(\bigotimes C(F_i),W)\). To check this, an index set \(I\) of \(p\) eta factors contributes to degree \(-p\). Removing \(j\in I\) in \(d_K\) has sign \((-1)^{|I\cap\{1,\ldots,j-1\}|}\). The corresponding incoming cochain differential in (9.2) has the same sign, while its internal Hom differential has the additional factor \((-1)^{p+1}\) from (1.4). The equality \(\epsilon_{p-1}=(-1)^{p+1}\epsilon_p\) proves commutation in every component. This verifies the sign on every product differential.

In top degree the identification is therefore
\[
H^{-r}R\operatorname{Hom}_{\mathcal A(P^r)}
(\mathcal T^{\boxtimes r},K_{\tau,r}(W))
\cong\operatorname{Hom}_E(Q^{\otimes r},W),
\tag{9.12}
\]
with the coefficient multiplier \(\epsilon_r\). In particular, for \(r=2\) it is \(-1\). If a product residue arrow is written on the right of (9.12) as the literal functional
\[
([F_1]\otimes\cdots\otimes[F_r])\longmapsto
\prod_{i=1}^rR_Z(f_i,J_ZF_i),
\tag{9.13}
\]
its coefficient representative in the unaltered tensor complex \(K_{\tau,r}\) is \(\epsilon_r\) times that product. This is the cohomological Koszul sign, not a phase inserted into (8.2) and not a modification of its positivity properties.

Tensoring (6.11) gives the exact surjection \(Q^{\otimes r}\to A_Z^{\otimes r}\), with kernel
\[
\sum_{j=1}^r Q^{\otimes(j-1)}\otimes Q_Z^0\otimes Q^{\otimes(r-j)}.
\tag{9.14}
\]
This follows by successively quotienting each factor; a vector-space complement verifies equality of the kernel, without imposing an equivariant complement. The fibre of the cochain jet map
\[
C(\mathcal T)^{\otimes r}\longrightarrow A_Z^{\otimes r}[-r]
\tag{9.15}
\]
has the same cohomology as \(C(\mathcal T)^{\otimes r}\) in degrees below \(r\), has (9.14) in degree \(r\), and zero above \(r\). Indeed the target has only degree \(r\), its degree-\(r\) map is the proved surjection, and the explicit fibre long exact sequence then has exactly these kernels and cokernels.

The action in all tensor expressions is the tensor of the original (7.2) and (7.4). On a specified packet tuple \((\rho_1,\ldots,\rho_r)\) it is
\[
a^{\rho_1+\cdots+\rho_r}
\exp\left((\log a)\sum_{j=1}^r1\otimes\cdots\otimes N_{\rho_j}\otimes\cdots\otimes1\right).
\tag{9.16}
\]
The summands commute, so their exponential is exactly the product of the terminating exponentials in (7.4). On the target line \(\mathcal L_1^{\otimes r}\) the action is \(a^r\); (8.6) proves covariance of (9.13) by this exact factor. Formula (9.16) retains every nilpotent term, not only its eigenvalue. Support reconstruction is performed on each original admitted tensor fibre and its balancing relations: a zero tensor amplitude remains the supported zero of that fibre, whereas an absent tensor input is absorbing. The proof never identifies the coefficient tensor with a Cartesian product of label sets.

There is also the source's proved passage to completed projective tensor products, now obtained from the retained continuous contraction instead of an assumed exactness of completion. For the joint complex \(C=C(\mathcal T)\), let \(H_0=V[0]\oplus Q[-1]\), with zero differential, and put
\[
p^0(\phi,\psi)=\psi,\quad p^1=q,\qquad
i^0(\psi)=(\widehat\psi,\psi),\quad i^1=s,\qquad
H^1(F)=(\Lambda F,0).
\tag{9.17}
\]
Then \(pi=1\) and \(1-ip=dH+Hd\): in degree zero the latter equation is \((\phi,\psi)-(\widehat\psi,\psi)=(\phi-\widehat\psi,0)\), obtained from \(\Lambda\Theta=1\); in degree one it is \(1-sq=\Theta\Lambda\). All the maps are continuous in the already specified topologies. If \(P=ip\), the tensor homotopy
\[
H_r=\sum_{j=1}^rP^{\otimes(j-1)}\otimes H
\otimes1^{\otimes(r-j)}
\tag{9.18}
\]
uses the sign \((-1)^{\sum_{k<j}|x_k|}\) on homogeneous inputs. The differential telescopes to \(1-P^{\otimes r}\), since \(d_{\operatorname{Hom}}H=1-P\), while \(P,1\) are chain maps of degree zero. Every finite tensor map is continuous for the projective tensor topology and therefore extends uniquely to its completion; the identity extends by density. The completed complex is thus continuously homotopy equivalent to \(H_0^{\widehat\otimes_\pi r}\). Its degree \(n\) cohomology is the direct sum of ordered completed tensors with \(Q\) in \(n\) slots and \(V\) in the others, and in particular its top cohomology is \(Q^{\widehat\otimes_\pi r}\). The comparison from (9.5) is the canonical completion map on these tensors. For an individual one-leg mask replace \(H_0\) by \(Q[-1]\), keep \(p^1=q,i^1=s\), and take \(H^1=\Lambda\) on the plus leg or \(H^1=-\mathcal F\Lambda\) on the minus leg. On the latter the differential is \(-\Theta\mathcal F\), so \(Hd=\mathcal F\Lambda\Theta\mathcal F=1_V\) and \(dH=\Theta\Lambda=1-sq\); the plus leg has the same identities with its positive signs. Thus the same tensor proof applies to every mask. This specifies the exact completed continuation while retaining the algebraic tensor calculation and the action defect (7.6).

# 10. Exact consequences for continuation

The original global arithmetic object, its generic-boundary restriction, and its right adjoint are related by the explicit maps (2.3), (3.10), and (4.4), and the nonsplit extension (4.7). On the original theta sheaf, the restriction fibre is the original cochain complex itself, with every supported copy of \(Q\) retained. Finite jets give the exact kernel sequence (6.11), its sheaf and fibre realizations (6.13)–(6.15), and the injective continuous residue arrow into the original adjoint (8.7). Tensor products give (9.5), (9.14), and the full action (9.16), with the independently checked Koszul sign (9.11).

These are completed calculations on the original \(\Theta,V,\mathscr B,\mathsf A_\tau,K_\tau\) and \(g=2\xi\). No vanishing of \(Q\), of the finite-jet kernel \(Q_Z^0\), or of an arithmetic boundary contribution was used to obtain them. The calculations establish exact comparison morphisms and retain their kernels; they supply no upper estimate for the original tensor action beyond the identities proved here.
