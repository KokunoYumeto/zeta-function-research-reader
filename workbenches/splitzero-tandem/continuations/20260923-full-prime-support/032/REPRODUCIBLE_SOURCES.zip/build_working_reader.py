from pathlib import Path
import subprocess,json,re,hashlib
base=Path(__file__).resolve().parent
for n in range(3):
    r=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error','RECOVERED_PROGRAMME.tex'],
                     cwd=base,capture_output=True)
    (base/f'build_pass_{n+1}.txt').write_bytes(r.stdout+r.stderr)
    if r.returncode: print((r.stdout+r.stderr).decode(errors='replace')[-5000:]);raise SystemExit(r.returncode)
log=(base/'RECOVERED_PROGRAMME.log').read_text(errors='replace')
warnings=[line for line in log.splitlines() if any(x in line for x in ['Overfull','undefined','multiply defined','destination with'])]
pdf=base/'RECOVERED_PROGRAMME.pdf'
print(json.dumps({'pdf_bytes':pdf.stat().st_size,'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),
                  'warnings':warnings,'pages':re.findall(r'Output written on.*',log)}))
