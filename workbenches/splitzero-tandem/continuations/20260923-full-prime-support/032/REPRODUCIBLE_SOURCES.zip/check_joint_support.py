from pathlib import Path
import hashlib, json
base=Path(__file__).resolve().parent
cases=[]
for n in range(1,6):
    count=1<<n
    moments=lambda c,t:sum(c[a] for a in range(count) if (a&t)==t)
    for s in range(count):
        vector=[(-1)**((a&s).bit_count()) for a in range(count)]
        for t in range(count):
            expected=(-1)**s.bit_count()*2**(n-t.bit_count()) if (s&t)==s else 0
            assert moments(vector,t)==expected
    for a in range(count):
        for b in range(count):
            for i in range(n):
                bit=1<<i
                lhs=int(bool((a|b)&bit))-int(bool(a&bit))
                rhs=int(bool(b&bit))*(1-int(bool(a&bit)))
                assert lhs==rhs
    units=[(b,a) for a in range(count) for b in range(count) if (a&b)==a]
    assert len(units)==3**n
    for s in range(count):
        c=[(-1)**((a^s).bit_count()) if (a&s)==s else 0 for a in range(count)]
        for b in range(count):
            image=[0]*count
            for a in range(count):image[a|b]+=c[a]
            expected=c if (b&s)==b else [0]*count
            assert image==expected
    cases.append({'places':n,'support_states':count,'incidence_dimension':len(units),
                  'joint_moments':'pass','join_commutator':'pass','primitive_eigenvectors':'pass'})
h=[1,-1,-1,1]
joint=[[sum(h[a] for a in range(4) if a&(1<<i) and a&(1<<j)) for j in range(2)] for i in range(2)]
assert joint==[[0,1],[1,0]]
for sign in [-1,1]:
    local=[3,sign*5]
    value=sum(joint[i][j]*local[i]*local[j] for i in range(2) for j in range(2))
    assert value==sign*30
receipt={'status':'pass','cases':cases,'two_place_coefficient_matrix':joint,
         'scope':'Finite exact regressions supplement JMD proofs; no analytic trace or RH assertion.',
         'source_sha256':hashlib.sha256((base/'independent/JOINT_SUPPORT_DISTRIBUTION.tex').read_bytes()).hexdigest()}
(base/'JOINT_SUPPORT_CHECK.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
