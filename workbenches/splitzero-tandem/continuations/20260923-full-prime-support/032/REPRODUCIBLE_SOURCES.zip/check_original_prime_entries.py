"""Independent numerical checks of the proved Gamma identity, not an RH test."""
from pathlib import Path
import hashlib,json
import mpmath as mp
mp.mp.dps=55
base=Path(__file__).resolve().parent

def coeffs(poly):
    current={1:-6*mp.pi,2:4*mp.pi**2}; out={}
    for p in poly:
        for j,b in current.items(): out[j]=out.get(j,0)+p*b
        nxt={}
        for j,b in current.items():
            nxt[j]=nxt.get(j,0)-2*j*b
            nxt[j+1]=nxt.get(j+1,0)+2*mp.pi*b
        current=nxt
    return out
def fp(x,b): return mp.exp(-mp.pi*x*x)*sum(v*x**(2*j) for j,v in b.items())
def gamma_h(a,b):
    return sum(v*mp.conj(w)*mp.gamma(j+l+mp.mpf('.5'))/mp.pi**(j+l+mp.mpf('.5'))*
               mp.exp(-(2*l+mp.mpf('.5'))*a)/(1+mp.exp(-2*a))**(j+l+mp.mpf('.5'))
               for j,v in b.items() for l,w in b.items())/2
checks=[]
for poly in [[1],[0,1],[1,2+1j,-1j]]:
    b=coeffs(poly)
    for a in [mp.mpf(0),mp.log(2),mp.log(3),-mp.log(2)]:
        exact=gamma_h(a,b)
        integral=mp.exp(-a/2)*mp.quad(lambda x:fp(x,b)*mp.conj(fp(mp.exp(-a)*x,b)),[0,1,mp.inf])
        error=abs(exact-integral)/(1+abs(exact))
        assert error<mp.mpf('1e-45'), (poly,a,error)
        assert abs(gamma_h(-a,b)-mp.conj(exact))<mp.mpf('1e-44')*(1+abs(exact))
        checks.append({'polynomial':[str(p) for p in poly],'a':str(a),'relative_error':str(error)})
    for s in [mp.mpf('0'),mp.mpf('1'),mp.mpc('.7','1.2')]:
        integral=mp.quad(lambda x:fp(x,b)*x**(s-1),[0,1,mp.inf])
        phi= -1 if s==0 else (s*(s-1)*mp.pi**(-s/2)*mp.gamma(s/2)/2)
        expected=sum(p*s**r for r,p in enumerate(poly))*phi
        assert abs(expected-integral)<mp.mpf('1e-44')*(1+abs(expected))

# Exact signed mixed vectors: all individual branch marginals vanish.
mixed=0
for n in range(2,7):
    for t in range(1,1<<n):
        if t.bit_count()<2: continue
        c=[(-1)**((a&t).bit_count()) for a in range(1<<n)]
        assert sum(c)==0
        for i in range(n): assert sum(c[a] for a in range(1<<n) if a&(1<<i))==0
        for a in range(1<<n):
            recovered=sum((-1)**((u^a).bit_count())*sum(c[b] for b in range(1<<n) if b&u==u)
                          for u in range(1<<n) if u&a==a)
            assert recovered==c[a]
        mixed+=1

receipt={'status':'PASS','precision_decimal_digits':mp.mp.dps,'gamma_cases':checks,
         'mellin_cases':9,'exact_mixed_vectors':mixed,
         'meaning':'Checks of finite identities. Complete proofs are in the TeX; no RH conclusion.',
         'source_hashes':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in
             ['ORIGINAL_GAUSSIAN_PRIME_ENTRIES.tex','FULL_LATTICE_CONNES_AND_PRIMES.tex']}}
(base/'ORIGINAL_PRIME_ENTRIES_CHECK.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({k:receipt[k] for k in ['status','mellin_cases','exact_mixed_vectors']}))
