from pathlib import Path
import hashlib, json, urllib.request
from fractions import Fraction

base = Path(__file__).resolve().parent
checks = []
for n in range(1, 6):
    size = 1 << n
    # Independent character transform and inverse for the join monoid.
    transform = [[int((a & b) == a) for a in range(size)] for b in range(size)]
    primitive = [[((-1) ** ((b ^ a).bit_count())) if (a & b) == a else 0
                  for b in range(size)] for a in range(size)]
    for a in range(size):
        for c in range(size):
            value = sum(transform[c][b] * primitive[a][b] for b in range(size))
            assert value == int(a == c)
    for a in range(size):
        for b in range(size):
            for c in range(size):
                assert transform[c][a | b] == transform[c][a] * transform[c][b]
    # Every individual Boolean branch loses exactly noncoatom proper factors.
    for a in range(size - 1):
        hits = [int(a == ((size - 1) ^ (1 << i))) for i in range(n)]
        assert (not any(hits)) == ((size - 1 - a).bit_count() >= 2)
    checks.append({'boolean_coordinates': n, 'states': size,
                   'character_inverse': 'pass', 'join_product': 'pass',
                   'all_branch_kernel': 'pass'})

# Negative and positive integer powers in the literal dual-number quotient.
def mul(x, y):
    return (x[0] * y[0], x[0] * y[1] + x[1] * y[0])
for a in range(-12, 13):
    for b in range(-12, 13):
        assert mul((1, a), (1, b)) == (1, a + b)

receipt = {'status': 'pass', 'checks': checks, 'integer_jet_products': 625,
           'scope': 'finite exact checks supplement full FSJ proofs',
           'source_sha256': hashlib.sha256((base/'FULL_LATTICE_SUPPORT_JET.tex').read_bytes()).hexdigest()}
(base/'SUPPORT_JET_CHECK.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')

print(json.dumps(receipt))
