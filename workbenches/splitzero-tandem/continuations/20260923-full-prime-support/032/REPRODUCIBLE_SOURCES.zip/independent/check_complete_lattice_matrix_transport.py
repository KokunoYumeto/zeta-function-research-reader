"""Exact finite tests of CLM support transport over the four-element lattice.

The examples test the proved identities and preserve complex amplitudes.
They are not substitutions for the original programme's G_N or coefficients.
"""
from pathlib import Path
from itertools import product
import hashlib
import json
import sympy as s

HERE=Path(__file__).resolve().parent
BOTTOM, TOP = 0, 3  # Powerset lattice on two labelled atoms.
checks=[]

def eq(name,lhs,rhs):
    if isinstance(lhs,s.MatrixBase):
        assert lhs.shape==rhs.shape and all(s.simplify(x)==0 for x in lhs-rhs),name
        entries=lhs.rows*lhs.cols
    elif isinstance(lhs,s.Expr):
        assert s.simplify(lhs-rhs)==0,name
        entries=1
    else:
        assert lhs==rhs,name
        entries=1
    checks.append({'name':name,'entries':entries})

def identity(n):
    return tuple(tuple(TOP if i==j else BOTTOM for j in range(n)) for i in range(n))

def join(a,b):
    return tuple(tuple(x|y for x,y in zip(ar,br)) for ar,br in zip(a,b))

def multiply(a,b):
    out=[]
    for row in a:
        r=[]
        for j in range(len(b[0])):
            value=0
            for k in range(len(b)):
                value |= row[k]&b[k][j]
            r.append(value)
        out.append(tuple(r))
    return tuple(out)

def closure(a):
    total, power = identity(len(a)), identity(len(a))
    for j in range(1,len(a)):
        power=multiply(power,a)
        total=join(total,power)
    return total

def beta(t):
    return tuple(tuple(TOP if s.simplify(t[i,j])!=0 else BOTTOM for j in range(t.cols)) for i in range(t.rows))

for values in product(range(4),repeat=4):
    a=(values[:2],values[2:])
    astar=closure(a)
    eq('CLM9 idempotent full-lattice closure '+str(values),multiply(astar,astar),astar)
    power=identity(2)
    for j in range(7):
        eq('CLM9 every path bounded '+str(values)+' power '+str(j),join(astar,power),astar)
        power=multiply(power,a)

G=s.Matrix([[2,1],[1,2]])
e=s.Matrix([1,0])/s.sqrt(2)
f=s.I*s.Matrix([1,-2])/s.sqrt(6)
edag=e.conjugate().T*G
fdag=f.conjugate().T*G
R=3*f*edag
Pi=e*edag+f*fdag
I2=s.eye(2)
full=((TOP,TOP),(TOP,TOP))
eq('CLM4 original weighted orthogonality',(edag*f)[0],s.Integer(0))
eq('CLM4 projector amplitude',Pi,I2)
eq('CLM5 exact nilpotent amplitude',R*R,s.zeros(2))
eq('CLM6 surviving nilpotent support',multiply(beta(R),beta(R)),full)
eq('CLM7 supported projector cancellation',join(beta(e*edag),beta(f*fdag)),((TOP,TOP),(BOTTOM,TOP)))
eq('CLM7 weighted adjoint retains extra incidence',beta(edag),((TOP,TOP),))
eq('CLM7 conjugate transpose does not replace adjoint support',beta(e.conjugate().T),((TOP,BOTTOM),))
for n in (2,3,5,9):
    C=s.zeros(n)
    for j in range(n-1):
        C[j+1,j]=1
    C[0,n-1]=2+s.I
    eq('CLM14 companion path closure dimension '+str(n),closure(beta(C)),tuple(tuple(TOP for j in range(n)) for i in range(n)))

def act(a,mask):
    return tuple(row[0] for row in multiply(a,tuple((x,) for x in mask)))

for mask in product(range(4),repeat=2):
    fixed=act(full,mask)
    eq('CLM15 saturated mask '+str(mask),fixed,(mask[0]|mask[1],mask[0]|mask[1]))
    eq('CLM15 exact fixed masks '+str(mask),fixed==mask,mask[0]==mask[1])
for lam in range(4):
    fibre=[mask for mask in product(range(4),repeat=2) if act(full,mask)==(lam,lam)]
    eq('CLM25 zero amplitude fibre '+str(lam),fibre,[mask for mask in product(range(4),repeat=2) if mask[0]|mask[1]==lam])
    eq('CLM26 exact zero-amplitude fibre count '+str(lam),len(fibre),(2**2-1)**lam.bit_count())
eq('CLM25 nonzero amplitude fibre',[(a,b) for a,b in product(range(4),repeat=2) if a==TOP and act(full,(a,b))==(TOP,TOP)],[(TOP,b) for b in range(4)])
eq('CLM26 exact nonzero-amplitude fibre count',len([(a,b) for a,b in product(range(4),repeat=2) if a==TOP and act(full,(a,b))==(TOP,TOP)]),2**(2*1))

T=s.Matrix([[1,s.I],[1,-s.I]])
Tinverse=T.inv()
eq('CLM19 recovered inverse amplitude',Tinverse*T,I2)
eq('CLM19 free inverse support is retract',multiply(beta(Tinverse),beta(T)),full)
assert full != identity(2)

def point(v,mask):
    assert v==s.zeros(v.rows,1) or mask==TOP
    return v,mask

def add(x,y):return (x[0]+y[0],x[1]|y[1])
def up(t,x):return (t*x[0],x[1])
def pairing(x,y):return ((x[0].conjugate().T*G*y[0])[0],x[1]&y[1])
def scalar_add(x,y):return (s.simplify(x[0]+y[0]),x[1]|y[1])
points=[point(s.zeros(2,1),mask) for mask in range(4)]+[point(s.Matrix([1,s.I]),TOP),point(s.Matrix([-1,-s.I]),TOP)]
for ix,x in enumerate(points):
    eq('CLM19 synchronized inverse amplitude '+str(ix),up(Tinverse,up(T,x))[0],x[0])
    eq('CLM20 zero map retains exact support '+str(ix),up(s.zeros(2),x)[1],x[1])
    for iy,y in enumerate(points):
        lhs=pairing(up(T,x),y)
        tdag=G.inv()*T.conjugate().T*G
        rhs=pairing(x,up(tdag,y))
        eq('CLM22 adjoint amplitude '+str((ix,iy)),s.simplify(lhs[0]),s.simplify(rhs[0]))
        eq('CLM22 adjoint support '+str((ix,iy)),lhs[1],rhs[1])
        for iz,z in enumerate(points):
            lhs=pairing(add(x,y),z)
            rhs=scalar_add(pairing(x,z),pairing(y,z))
            eq('CLM21 sesquilinear amplitude '+str((ix,iy,iz)),s.simplify(lhs[0]),s.simplify(rhs[0]))
            eq('CLM21 sesquilinear support '+str((ix,iy,iz)),lhs[1],rhs[1])

source=HERE/'COMPLETE_LATTICE_MATRIX_TRANSPORT.tex'
receipt={
    'status':'PASS',
    'groups':len(checks),
    'entries':sum(c['entries'] for c in checks),
    'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'sympy_version':s.__version__,
    'lattice':'All four support values of the powerset lattice on two labelled atoms; join is union, meet is intersection.',
    'scope':'Exhaustive two-by-two full-lattice path closure; exact weighted complex nilpotent cancellation; companion support recovery; synchronized metric, inverse and full-mask fibre identities and counts. General proofs remain in CLM1–26.',
    'checks':checks,
}
(HERE/'COMPLETE_LATTICE_MATRIX_TRANSPORT_CHECK.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:receipt[key] for key in ('status','groups','entries','source_sha256')}),flush=True)
