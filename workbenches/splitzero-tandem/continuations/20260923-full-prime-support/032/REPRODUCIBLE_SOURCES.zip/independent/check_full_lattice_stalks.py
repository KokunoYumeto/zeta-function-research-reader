"""Exact finite checks of the full-lattice localization derivation."""
from itertools import product
from pathlib import Path
import hashlib
import json


def downsets(n, relations):
    return [frozenset(i for i in range(n) if mask & (1 << i))
            for mask in range(1 << n)
            if all(not mask & (1 << b) or mask & (1 << a)
                   for a, b in relations)]


def localization_classes(xs, denominators, mul):
    unseen = set(xs)
    classes = []
    while unseen:
        x = next(iter(unseen))
        cls = {y for y in xs if any(mul(s, x) == mul(s, y)
                                   for s in denominators)}
        assert cls <= unseen
        classes.append(cls)
        unseen -= cls
    return classes


records = []
examples = [
    ("three-element chain", 2, [(0, 1)]),
    ("four-element Boolean lattice", 2, []),
    ("two incomparable lower points under one top", 3, [(0, 2), (1, 2)]),
    ("four-point diamond poset", 4,
     [(0, 1), (0, 2), (0, 3), (1, 3), (2, 3)]),
]
for name, n, relations in examples:
    lattice = downsets(n, relations)
    top = frozenset(range(n))
    fibre_checks = 0
    for labels in product([0, 1, 2], repeat=n):
        # 0: branch omitted; 1: observed negative; 2: observed positive.
        observed = {i for i, state in enumerate(labels) if state}
        positives = {i for i, state in enumerate(labels) if state == 2}
        negatives = observed - positives
        lower = set(positives) | {a for a, b in relations if b in positives}
        forbidden = set(negatives) | {b for a, b in relations if a in negatives}
        upper = set(top) - forbidden
        actual_fibre = {a for a in lattice if a & observed == positives}
        predicted_fibre = {a for a in lattice if lower <= a <= upper}
        assert actual_fibre == predicted_fibre
        fibre_checks += 1
    records.append({"lattice": name, "exact_branch_fibres_checked": fibre_checks})
    for point in range(n):
        filt = [a for a in lattice if point in a]
        minimal = frozenset.intersection(*filt)
        cls = localization_classes(lattice, filt, lambda a, b: a & b)
        predicted = [a for a in lattice if a <= minimal]
        assert len(cls) == len(predicted)
        for c in cls:
            assert len({a & minimal for a in c}) == 1
        assert {next(iter(c)) & minimal for c in cls} == set(predicted)

        ring_modulus = 3
        semiring = {(0, a) for a in lattice} | {(r, top) for r in range(ring_modulus)}
        mul = lambda x, y: ((x[0] * y[0]) % ring_modulus, x[1] & y[1])
        p = {(0, a) for a in lattice if point not in a}
        semiring_cls = localization_classes(semiring, semiring - p, mul)
        assert len(semiring_cls) == len(predicted)
        records.append({"lattice": name, "lattice_size": len(lattice),
                        "branch_point": point, "support_stalk_size": len(cls),
                        "residue_size": 2})

    ring_modulus = 6
    semiring = {(0, a) for a in lattice} | {(r, top) for r in range(ring_modulus)}
    mul = lambda x, y: ((x[0] * y[0]) % ring_modulus, x[1] & y[1])
    for prime in [2, 3]:
        denominators = {(r, top) for r in range(ring_modulus) if r % prime}
        cls = localization_classes(semiring, denominators, mul)
        assert len(cls) == len(lattice) + prime - 1
        zero_classes = []
        for a in lattice:
            zero_classes.append(next(i for i, c in enumerate(cls) if (0, a) in c))
        assert len(set(zero_classes)) == len(lattice)
        records.append({"lattice": name, "ring": "Z/6", "arithmetic_prime": prime,
                        "arithmetic_stalk_size": len(cls),
                        "distinct_zero_labels_retained": len(set(zero_classes))})

source = Path(__file__).with_name("FULL_LATTICE_STALKS.tex")
receipt = {"status": "PASS", "arithmetic": "exact finite sets and modular rings",
           "scope": "finite tests supplement the universal proofs; no test of arbitrary infinite frames",
           "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
           "records": records}
Path(__file__).with_name("FULL_LATTICE_STALKS_CHECK.json").write_text(
    json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "PASS", "records": len(records),
                  "source_sha256": receipt["source_sha256"]}))
