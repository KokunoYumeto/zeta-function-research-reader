"""Exact finite checks of TDP block, support and tensor identities.

The test matrices verify the algebra independently. They do not replace
the programme's G_N or assert that these sample matrices are its metric.
"""
from pathlib import Path
import hashlib
import json
import sympy as s

HERE = Path(__file__).resolve().parent
checks = []

def eq(name, lhs, rhs):
    difference = lhs-rhs
    if isinstance(difference, s.MatrixBase):
        assert all(s.simplify(v) == 0 for v in difference), name
        entries = difference.rows*difference.cols
    else:
        assert s.simplify(difference) == 0, name
        entries = 1
    checks.append({'identity': name, 'entries': entries})

I3, I2 = s.eye(3), s.eye(2)
J = s.Matrix([[2,1],[-2,2],[1,2]])/3
K = s.Matrix([-2,-1,2])/3
W = J.row_join(K)
e = s.Matrix([1,0,0])
f = s.Matrix([0,s.I,0])
epsilon = s.Integer(3)
R = epsilon*f*e.conjugate().T
Pi = e*e.conjugate().T+f*f.conjugate().T
P, Q = J*J.conjugate().T, K*K.conjugate().T
u, v = J.conjugate().T*e, J.conjugate().T*f
a = (u.conjugate().T*u)[0]
d = (v.conjugate().T*v)[0]
r = (u.conjugate().T*v)[0]
kappa = epsilon*r
T = J.conjugate().T*R*J
eK, fK = K.conjugate().T*e, K.conjugate().T*f
B, C, D = J.conjugate().T*R*K, K.conjugate().T*R*J, K.conjugate().T*R*K
A = J.conjugate().T*Pi*J
eq('isometry', W.conjugate().T*W, I3)
eq('nilpotent source', R**2, s.zeros(3))
eq('TDP12 compression quadratic', T**2, kappa*T)
eq('TDP12 phase', (eK.conjugate().T*fK)[0], -r)
eq('TDP13 kernel eigenvalue', D, s.Matrix([[-kappa]]))
eq('TDP13 memory at zero', B*C, -kappa*T)
for n in range(7):
    eq(f'TDP13 memory coefficient {n}', B*D**n*C, -kappa*(-kappa)**n*T)
for m in range(1,7):
    c = s.Symbol('c')
    eq(f'TDP14 true prime power {m}', J.conjugate().T*(I3+c*R)**m*J, I2+m*c*T)
    eq(f'TDP14 compressed prime power {m}', (I2+c*T)**m, I2+((1+c*kappa)**m-1)/kappa*T)

c, w = s.symbols('c w')
Fp = I3+c*R
Ap, Bp, Cp, Dp = J.conjugate().T*Fp*J, J.conjugate().T*Fp*K, K.conjugate().T*Fp*J, K.conjugate().T*Fp*K
feedback = (I2-w*w*(I2-w*Ap).inv()*Bp*(s.eye(1)-w*Dp).inv()*Cp).det()
eq('TDP15 feedback factor', feedback, (1-w)**2/((1-w)**2-w*w*c*c*kappa*kappa))
eq('TDP15 full determinant', (I3-w*Fp).det(), (1-w)**3)
eq('TDP9 Schur resolvent', J.conjugate().T*(I3-w*Fp).inv()*J, (I2-w*Ap-w*w*Bp*(s.eye(1)-w*Dp).inv()*Cp).inv())
eq('TDP9 full factorization', (I3-w*Fp).det(), (s.eye(1)-w*Dp).det()*(I2-w*Ap).det()*feedback)
eq('TDP20 support defect', A-A*A, (Q*Pi*J).conjugate().T*(Q*Pi*J))
At = s.kronecker_product(A,A)
Pt, Qt = s.kronecker_product(P,P), s.eye(9)-s.kronecker_product(P,P)
Jt, Pit = s.kronecker_product(J,J), s.kronecker_product(Pi,Pi)
eq('TDP18 all mixed kernel sectors', Qt, s.kronecker_product(P,Q)+s.kronecker_product(Q,P)+s.kronecker_product(Q,Q))
eq('TDP20 tensor defect telescoping', At-At*At, s.kronecker_product(A-A*A,A)+s.kronecker_product(A*A,A-A*A))
eq('TDP20 tensor kernel square', At-At*At, (Qt*Pit*Jt).conjugate().T*(Qt*Pit*Jt))
eq('TDP21 tensor determinant', At.det(), A.det()**4)
Rt = s.kronecker_product(R,I3)+s.kronecker_product(I3,R)
eq('TDP23 nilpotent square', Rt**2, 2*s.kronecker_product(R,R))
eq('TDP23 nilpotent cube', Rt**3, s.zeros(9))
eq('TDP23 tensor exponential', s.eye(9)+c*Rt+c*c*Rt**2/2, s.kronecker_product(I3+c*R,I3+c*R))

# Full M includes a noncommuting Hermitian term, as in ST3.
Csource = s.Matrix([[1,s.I,2],[-s.I,3,1],[2,1,-1]])
M = Csource+R
H, B01, B10, DK = J.conjugate().T*M*J,J.conjugate().T*M*K,K.conjugate().T*M*J,K.conjugate().T*M*K
for n in range(1,5):
    first = J.conjugate().T*M**n*J
    recurrence = H*(J.conjugate().T*M**(n-1)*J)
    if n >= 2:
        recurrence += sum((B01*DK**j*B10*(J.conjugate().T*M**(n-2-j)*J) for j in range(n-1)), s.zeros(2))
    eq(f'TDP6 Taylor recurrence {n}', first, recurrence)
lam=s.Symbol('lam')
eq('TDP17 original rank-one secular factor', (lam*I3-M).det(), (lam*I3-Csource).det()*(1-epsilon*(e.conjugate().T*(lam*I3-Csource).inv()*f)[0]))
X = (2+s.I)*M+(1-3*s.I)*M**2
Xobs = J.conjugate().T*X*J
eq('TDP28 complete adjoint-product defect', J.conjugate().T*X.conjugate().T*X*J-Xobs.conjugate().T*Xobs, (Q*X*J).conjugate().T*(Q*X*J))

source = HERE/'TAU_DELiGNE_PRIME_MEMORY.tex'
receipt = {
    'status': 'PASS', 'groups': len(checks), 'entries':sum(c['entries'] for c in checks),
    'scope':'Independent exact complex-phase finite algebra checks; the full general proofs are in TDP1–28.',
    'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
    'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'sympy_version':s.__version__,
    'sample':{'a':str(a),'d':str(d),'r':str(r),'epsilon':str(epsilon),'kappa':str(kappa)},
    'checks':checks,
}
(HERE/'TAU_DELIGNE_PRIME_MEMORY_CHECK.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps({key:receipt[key] for key in ('status','groups','entries','source_sha256')}),flush=True)
