from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

base = Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans', 'font.size':12})
fig, axs = plt.subplots(1, 3, figsize=(16, 6))
for ax in axs:
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
blue, red, green = '#155e8d', '#ac304e', '#187b63'

def box(ax,x,y,text,w=.29,h=.11,color=blue):
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.01',
                              facecolor='#f6f8fb',edgecolor=color,lw=1.6))
    ax.text(x,y,text,ha='center',va='center',color=color)

ax=axs[0]
ax.text(.5,.96,'The retained four-state vector',ha='center',weight='bold',fontsize=14)
for x,y,txt,col in [(.27,.73,r'$\delta_{\varnothing}:\ +1$',blue),
                    (.73,.73,r'$\delta_{\{u\}}:\ -1$',red),
                    (.27,.53,r'$\delta_{\{v\}}:\ -1$',red),
                    (.73,.53,r'$\delta_{\{u,v\}}:\ +1$',blue)]:
    box(ax,x,y,txt,w=.39,color=col)
ax.text(.5,.34,r'$J_{\varnothing}(h)=J_u(h)=J_v(h)=0$',ha='center',color=green)
ax.text(.5,.23,r'$J_{\{u,v\}}(h)=1$',ha='center',fontsize=17,color=blue)
ax.text(.5,.07,'Marginals lose the vector.\nThe joint coefficient retains it.',ha='center',fontsize=11)

ax=axs[1]
ax.text(.5,.96,'Exact joint distribution',ha='center',weight='bold',fontsize=14)
ax.text(.5,.82,r'$\mathcal{V}_2(h)=W_u\otimes W_v+W_v\otimes W_u$',ha='center',fontsize=12)
ax.text(.5,.72,'Coefficient matrix in the labelled basis',ha='center',fontsize=10)
for i,labi in enumerate(['u','v']):
    for j,labj in enumerate(['u','v']):
        x=.35+.30*j; y=.57-.19*i
        box(ax,x,y,str(int(i!=j)),w=.23,h=.14,color=blue if i!=j else '#8795a5')
    ax.text(.15,.57-.19*i,r'$W_'+labi+'$',ha='center',va='center')
    ax.text(.35+.30*i,.69,r'$W_'+labi+'$',ha='center',va='center')
ax.text(.5,.21,r'$\mathcal{V}_2(h)(\psi_u\otimes\psi_v)=b_u b_v>0$',ha='center',fontsize=12)
ax.text(.5,.07,'Separate variables; no product of distributions\nat the same point. Decoder constants are retained.',ha='center',fontsize=10)

ax=axs[2]
ax.text(.5,.96,'Full additive support jet',ha='center',weight='bold',fontsize=14)
box(ax,.5,.77,r'$\mathbb{C}[\eta]/(\eta^2)$',w=.73,h=.13)
ax.text(.5,.65,r'Original action: $d_0\Pi+d_1R$',ha='center',fontsize=11)
for x,lab,col in [(.18,r'$\mathbb{C}\xi_{\varnothing}$',red),(.50,r'$\mathbb{C}\xi_{\{u\}}$',blue),(.82,r'$\mathbb{C}\xi_{\{v\}}$',blue)]:
    box(ax,x,.46,lab,w=.27,h=.13,color=col)
ax.text(.5,.31,r'$E_{\varnothing}+E_{\{u\}}+E_{\{v\}}=I-\Pi$',ha='center',fontsize=12)
ax.text(.5,.17,r'$\xi_{\varnothing}=h$',ha='center',fontsize=17,color=red)
ax.text(.5,.065,'The old scalar action specifies the sum.\nBoth individual branches miss this mixed factor.',ha='center',fontsize=10)

fig.suptitle('Mixed support recovered through its joint observation and exact algebra',fontsize=17,weight='bold',y=1.02)
fig.text(.5,-.015,'Proofs: FLC10–11; FSJ2–8; JMD1–14. Local distributions: Alain Connes; full support base: Split Support Geometry v11.',ha='center',fontsize=9)
fig.subplots_adjust(left=.025,right=.985,top=.94,bottom=.06,wspace=.18)
for suffix in ['png','svg']:
    fig.savefig(base/f'JOINT_SUPPORT_RECOVERY.{suffix}',dpi=180,bbox_inches='tight')
print('Rendered exact joint-support figure.')
