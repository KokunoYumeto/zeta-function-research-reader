"""Exact diagrams for the full-lattice recovery. No numerical geometry inferred."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle

base = Path(__file__).resolve().parent
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11})
fig, axes = plt.subplots(1, 3, figsize=(17, 6.4))
blue, red, green = '#155e8d', '#ae354b', '#187b63'
for ax in axes:
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')

def node(ax,x,y,txt,color=blue,w=.30,h=.12):
    ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=0.012',
                              facecolor='#f4f8fb',edgecolor=color,linewidth=1.5))
    ax.text(x,y,txt,ha='center',va='center',color=color)
def arrow(ax,x,y,u,v,color=blue,**kw):
    ax.annotate('',xy=(u,v),xytext=(x,y),arrowprops=dict(arrowstyle='->',color=color,lw=1.5,**kw))

ax=axes[0]
ax.text(.5,.97,'Full prime geometry',ha='center',va='top',weight='bold',fontsize=15)
ax.text(.5,.89,r'$L=\mathcal{P}(\{1,2\}),\quad R=\mathbb{Z}$',ha='center')
node(ax,.24,.73,r'$P_1=\{\tau,z_2\}$',w=.39)
node(ax,.76,.73,r'$P_2=\{\tau,z_1\}$',w=.39)
node(ax,.5,.46,r'$Q_{(0)}=Z_L$',w=.35)
arrow(ax,.27,.655,.47,.54); arrow(ax,.73,.655,.53,.54)
node(ax,.5,.20,r'$Q_{(p)}\quad(p\ \mathrm{prime})$',w=.65)
arrow(ax,.5,.385,.5,.275)
ax.text(.5,.025,'Arrows: strict specialization.\nEvery support branch meets the arithmetic stratum.',
        ha='center',va='bottom',fontsize=9.5)

ax=axes[1]
ax.text(.5,.97,'The original operator recovers a carrier',ha='center',va='top',weight='bold',fontsize=14)
ax.text(.5,.89,r'$q=(k+1)^2,\quad Q_k(0)\ne0$',ha='center')
for x,t in [(.1,'0'),(.34,'1'),(.9,r'$q-1$')]: node(ax,x,.70,t,w=.13,h=.10)
ax.text(.63,.70,r'$\cdots$',ha='center',va='center',fontsize=22)
arrow(ax,.18,.70,.25,.70); arrow(ax,.43,.70,.55,.70); arrow(ax,.70,.70,.81,.70)
arrow(ax,.90,.64,.10,.64,connectionstyle='arc3,rad=-.45')
ax.text(.5,.41,r'$A^*=\mathbf{1}_{q\times q}$',ha='center',fontsize=17,color=green)
ax.text(.5,.30,r'$\lambda_1=\cdots=\lambda_q=\lambda\in L$',ha='center',fontsize=14)
ax.text(.5,.18,r'$\mathcal{F}_p(v,\lambda)=(e^{i\log(p)M}v,\lambda)$',ha='center',fontsize=13)
ax.text(.5,.025,'Cycle shown with intermediate vertices omitted.\nThe entire lattice L survives; no branch is selected.',
        ha='center',va='bottom',fontsize=9.5)

ax=axes[2]
ax.text(.5,.97,'The mixed channel missed by marginals',ha='center',va='top',weight='bold',fontsize=14)
ax.text(.5,.88,r'$h=\delta_{\varnothing}-\delta_{\{1\}}-\delta_{\{2\}}+\delta_{\{1,2\}}$',ha='center',fontsize=13)
for x,y,lab,coeff in [(.29,.60,r'$\varnothing$',1),(.58,.60,r'$\{1\}$',-1),
                      (.29,.32,r'$\{2\}$',-1),(.58,.32,r'$\{1,2\}$',1)]:
    color=blue if coeff>0 else red
    ax.add_patch(Rectangle((x-.13,y-.13),.26,.26,facecolor='#f5f7f9',edgecolor=color,lw=1.5))
    ax.text(x,y+.065,lab,ha='center',fontsize=11)
    ax.text(x,y-.045,'+1' if coeff>0 else '-1',ha='center',fontsize=19,color=color,weight='bold')
for y in [.60,.32]: ax.text(.83,y,'= 0',ha='center',va='center',color=green,fontsize=14)
for x in [.29,.58]: ax.text(x,.115,'= 0',ha='center',va='center',color=green,fontsize=14)
ax.text(.5,.025,'Each row and column sums to zero.\nJoint support moments recover this nonzero vector.',
        ha='center',va='bottom',fontsize=9.5)

fig.suptitle('Full support, recovered prime evolution, and the remaining mixed channel',
             fontsize=18,weight='bold',y=1.02)
fig.text(.5,-.015,'Proofs: FLS2-3; CLM8-17; FLC6-11,20-21. Foundation: The Clankers, Split Support Geometry v11; Birkhoff lattice coordinates.',
         ha='center',fontsize=9)
fig.subplots_adjust(wspace=.18,top=.96,bottom=.07,left=.025,right=.985)
fig.savefig(base/'FULL_LATTICE_RECOVERY.png',dpi=175,bbox_inches='tight')
fig.savefig(base/'FULL_LATTICE_RECOVERY.svg',bbox_inches='tight')
print('Wrote reproducible full-lattice diagram.')
