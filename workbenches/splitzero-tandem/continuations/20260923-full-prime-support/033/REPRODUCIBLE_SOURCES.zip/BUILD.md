# Reproduce this continuation

Use Python with NumPy, Matplotlib and SymPy, and an ordinary LaTeX installation with pdflatex. Run make_continuation_figures.py, then build_continuation.py. The builder runs three passes and produces the complete single TeX and PDF. Run check_mixed_energy.py, check_full_weil.py and check_boundary_transport.py for the exact finite checks. The TeX contains the universal proofs. Optional render_review.py requires Poppler, Pillow and PyMuPDF and creates page PNGs for visual inspection.

The inputs directory contains the complete supplied 031/032 programme proof witnesses and unchanged foundational/Connes source witnesses. Reading coverage and authorship are stated in HUMAN_SOURCES.md; inclusion is not a claim of exhaustive reading. The local single-file 033 manuscript is complete for the new claims it states.
