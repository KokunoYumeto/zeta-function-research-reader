from pathlib import Path
import subprocess,re,json,hashlib

here=Path(__file__).resolve().parent
parts=['PRIME_DEGREE_MIXED_ADMISSIBLE_ENERGY.tex',
       'FULL_WEIL_POSITIVITY_THREE_PULSE.tex',
       'FULL_WEIL_JOINT_SUPPORT.tex',
       'SPECTRAL_BOUNDARY_TRANSPORT.tex']
header=r'''\documentclass[11pt]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{lmodern,amsmath,amssymb,amsthm,mathtools,mathrsfs,graphicx,xcolor}
\usepackage[a4paper,margin=24mm]{geometry}
\usepackage{microtype}
\usepackage[colorlinks=true,hypertexnames=false,linkcolor=blue!50!black,urlcolor=blue!50!black]{hyperref}
\setlength{\emergencystretch}{3em}
\allowdisplaybreaks
\title{Full Weil positivity and the surviving mixed-support trace\\
\large Exact prime energies and the original companion boundary}
\author{Programme continuation with explicit source provenance}
\date{23 September 2026 --- SZ-20260923-033}
\begin{document}
\maketitle

This continuation receives the actual degree-$p$ operator on the
relative principal parts and computes its action on the original
mixed-support tests. The resulting signed joint observation admits
both signs even on compact convolution squares satisfying both Weil
moments. We then evaluate the full Archimedean term and prove that
the entire three-pulse family has strictly positive complete Weil
form, with the exact lower bound $5981N/52500$. These tests are
therefore excluded as full-Weil counterexamples. Their mixed support
state remains nonzero; after retaining the common Archimedean term,
its joint trace is strictly negative at every tensor order at least
two. The complete maps and proofs of these assertions follow.

The companion calculation constructs the original off-critical
$q$-dimensional object as a recurrence subspace in the actual
local tensor operator's annulus distribution channel. It retains
every original cardinal label, phase, source metric, support label
and observation-kernel component. Evaluation at zero is its exact
inverse. Its exponential growth and its two finite boundary terms
are calculated without identifying that distribution subspace with
the global interior cohomology. No RH decision is claimed.

\paragraph{Human sources and programme inputs.}
The analytic convention is Alain Connes's original author TeX,
\href{https://arxiv.org/abs/2602.04022v1}{\emph{The Riemann Hypothesis:
Past, Present and a Letter Through Time}}, section
\texttt{sectweilpos}, equations \texttt{wp} and \texttt{arch},
which attributes the positivity criterion to Andr\'e Weil.
The source of the relative principal parts and local degree operator
is the supplied 031 proof, RP21--38, PD1--21 and IA1--9.
The full-lattice carrier, original companion coordinates and mixed
support diagonal are the supplied 032 proof, CLM8--17, CR1--41,
PDD1--15, JMD1--23 and TDP1--4. Their complete, exact-version TeX
sources accompany this paper in the reproducibility archive,
under \texttt{inputs/031\_SOURCE.tex} and
\texttt{inputs/032\_SOURCE.tex}; the source account records their
hashes. These supplied witnesses are identified as such, with no
unverified public-edition claim. The full local operator proofs and
all input definitions needed for the new assertions are included
again where used below.

The supported-zero prime chain is prior foundational work. The
user-provided origin attribution is Gemini 2.5 Pro; the first
\href{https://github.com/KokunoYumeto/zeta-function-research-reader/blob/d2f0020a7c446f429682925c1c682d99ba86a4cc/workbenches/splitzero-tandem/foundations/globalization-semiring/globalization_note.tex#L239}{globalization source, prime-ideal classification and dimension corollary},
has an empty author field, while the later full-lattice Version 11
has the byline The Clankers. These identities are not merged.
The general purity comparison belongs to Pierre Deligne,
\href{https://www.numdam.org/item/PMIHES_1980__52__137_0/}{\emph{La
conjecture de Weil. II}}, especially 3.3.6 for the image of compactly
supported cohomology in ordinary cohomology. No application of
that theorem to the constructed annulus space is assumed here.
The proofs below do not require an unverified transcription of
Deligne's theorem. Earlier ES--Fable provenance remains with its
original Levent Alp\"oge credit in the retained input collection;
no new ES result is asserted in this continuation.

\clearpage
\tableofcontents
\clearpage
\begin{figure}[p]
\centering
\includegraphics[width=\linewidth]{ADMISSIBLE_MIXED_TEST.png}
\caption{The actual three-pulse test for primes 2 and 3, in its original
logarithmic coordinate and amplitude. PME21--25 proves both Mellin
conditions and every prime evaluation; FWP1--24 proves the complete
Weil lower bound with Connes's full Archimedean term. FWJ1--8 proves
the simultaneously negative signed support trace, including that
same Archimedean term. The expanded pulse panels show the indicated
coordinate intervals without changing the pulse amplitudes.}
\end{figure}
\clearpage
'''
tail=r'''
\clearpage
\begin{figure}[p]
\centering
\includegraphics[width=\linewidth]{ANNULUS_BOUNDARY.png}
\caption{SBT5--10 constructs the actual annulus channel and its
original $E$-valued coefficient sequence. The arrows between
coefficients are $F_p^{-1}$; the spatial shift itself acts on $h_n$.
SBT18--20 proves the displayed boundary ratio and its nonzero
off-circle limits. The unit-circle curve is the separate comparison
explicitly defined after SBT15, not a modification of the original
off-critical polynomial. The inherited relative degree operator is
proved in PME1--5 and the supplied 031 PD1--21 source.}
\end{figure}
\end{document}
'''
contents=header+'\n\n'.join((here/p).read_text(encoding='utf-8') for p in parts)+tail
bad=[(i,ord(c)) for i,c in enumerate(contents) if ord(c)<32 and c not in '\n\r\t']
assert not bad,bad
tex=here/'MIXED_PRIME_ENERGY_AND_BOUNDARY.tex'
tex.write_text(contents,encoding='utf-8')
for n in range(3):
    r=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',tex.name],cwd=here,capture_output=True)
    (here/f'build_033_pass_{n+1}.txt').write_bytes(r.stdout+r.stderr)
    if r.returncode:
        print((r.stdout+r.stderr).decode(errors='replace')[-6000:]);raise SystemExit(r.returncode)
log=tex.with_suffix('.log').read_text(errors='replace')
warnings=[line for line in log.splitlines() if any(x in line for x in ['Overfull','undefined','multiply defined','destination with'])]
tags=re.findall(r'\\tag\{([^}]+)\}',contents)
assert len(tags)==len(set(tags))
receipt={'status':'PASS' if not warnings else 'LAYOUT_REVIEW_REQUIRED','warnings':warnings,
         'equation_tags':len(tags),'unique_equation_tags':len(set(tags)),
         'pdf_sha256':hashlib.sha256(tex.with_suffix('.pdf').read_bytes()).hexdigest(),
         'tex_sha256':hashlib.sha256(tex.read_bytes()).hexdigest(),
         'pages':re.findall(r'Output written on.*',log)}
(here/'BUILD_033.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
