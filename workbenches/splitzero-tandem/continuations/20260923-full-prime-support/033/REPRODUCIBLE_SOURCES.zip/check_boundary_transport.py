"""Exact finite checks of SBT's endpoints and unchanged nonorthogonal metric.

The universal proofs are in SPECTRAL_BOUNDARY_TRANSPORT.tex.
"""
from pathlib import Path
from hashlib import sha256
import json
import sympy as s

here=Path(__file__).resolve().parent
P=s.Matrix([[1,1],[s.I,2]])
C=P*s.diag(2*s.I,(1+s.I)/3)*P.inv()
G=s.Matrix([[3,1+s.I],[1-s.I,2]])
assert G.det()==4 and G[0,0]>0
v=s.Matrix([2-s.I,3+s.I])
zero=s.zeros(2,1)
checked=0
for H in range(5):
    sequence={n:C**(-n)*v for n in range(-H,H+1)}
    residual={n:s.simplify(sequence.get(n-1,zero)-C**(1-n)*v)
              for n in range(-H,H+1)}
    residual[H+1]=sequence[H]
    for n,x in residual.items():
        expected=C**(-H)*v if n==H+1 else (-C**(H+1)*v if n==-H else zero)
        assert s.simplify(x-expected)==zero
        checked+=1
    energy=s.simplify(sum((s.conjugate(x).T*G*x)[0] for x in residual.values()))
    target=s.simplify((s.conjugate(C**(-H)*v).T*G*(C**(-H)*v))[0]
                    +(s.conjugate(C**(H+1)*v).T*G*(C**(H+1)*v))[0])
    assert s.simplify(energy-target)==0
    coords=P.inv()*v
    card=s.conjugate(P).T*G*P
    omega=[2*s.I,(1+s.I)/3]
    direct=sum((s.conjugate(x).T*G*x)[0] for x in sequence.values())
    spectral=sum(s.conjugate(coords[i])*coords[j]*card[i,j]
                 *sum((s.conjugate(omega[i])*omega[j])**(-n) for n in range(-H,H+1))
                 for i in range(2) for j in range(2))
    assert s.simplify(direct-spectral)==0
receipt={'result':'PASS','endpoint_coordinates_checked':checked,
         'metrics':'One exact non-diagonal positive Hermitian metric; complex phases and nonorthogonal eigencoordinates retained.',
         'scope':'Finite identity checks; all-parameter proofs are SBT1–23.',
         'source_sha256':sha256((here/'SPECTRAL_BOUNDARY_TRANSPORT.tex').read_bytes()).hexdigest()}
(here/'BOUNDARY_CHECK.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt))
