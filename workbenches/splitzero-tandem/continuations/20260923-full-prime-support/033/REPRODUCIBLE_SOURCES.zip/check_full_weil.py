"""Exact transcription checks for the universal FWP proof, not an RH test."""
from pathlib import Path
from fractions import Fraction as F
from hashlib import sha256
from datetime import datetime, timezone
import json
import sympy as s

HERE = Path(__file__).resolve().parent
proof = HERE/'FULL_WEIL_POSITIVITY_THREE_PULSE.tex'
text = proof.read_text(encoding='utf-8')
controls = [(i, ord(c)) for i, c in enumerate(text) if ord(c)<32 and c not in '\n\r\t']
assert not controls, controls
assert 'qquad' not in text.replace('\\qquad','')
assert text.count('{') == text.count('}')

eps = s.symbols('epsilon', positive=True)
assert s.expand(6*eps**2+3*eps+6*(4*eps+s.Rational(1,7))
                -(27*eps+6*eps**2+s.Rational(6,7))) == 0
width_log_bound = F(1,6)-F(1,72)+F(1,648)
assert width_log_bound == F(25,162)
assert width_log_bound/16 < F(1,100)
log100_lower = 12*(F(1,3)+F(1,81)+F(1,1215))+F(4,9)
assert log100_lower == F(1864,405) > F(23,5)
H10 = sum((F(1,j) for j in range(1,11)), F(0))
assert H10 == F(7381,2520)
c_upper = H10+F(9,35)
assert c_upper == F(8029,2520)
epsilon_error = F(27,100)+F(6,10000)
assert epsilon_error == F(1353,5000)
constant = F(69,5)-3*c_upper-epsilon_error-F(6,7)-3
assert constant == F(5981,52500) > F(1,10)
assert constant-F(1,10) == F(731,52500)

x=s.symbols('x')
assert s.expand((x*x+1)*(x**6-4*x**5+5*x**4-4*x*x+4)-4
                -x**4*(1-x)**4) == 0
assert s.integrate(x**6-4*x**5+5*x**4-4*x*x+4,(x,0,1))==s.Rational(22,7)

b,a,c,y=s.symbols('b a c y', positive=True)
for r in range(2,11):
    difference=b**r-(b-a)**r-(b+c)**r+(b-a+c)**r
    integral=-r*(r-1)*s.integrate(s.integrate((b-x+y)**(r-2),(y,0,c)),(x,0,a))
    assert s.expand(difference-integral)==0

print("PASS: full-Weil constants and joint support finite differences.")
