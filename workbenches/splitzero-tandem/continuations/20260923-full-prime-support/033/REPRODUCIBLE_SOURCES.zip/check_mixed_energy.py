"""Independent exact arithmetic checks accompanying the PME proof.

The TeX contains the proofs for all parameters. These finite checks detect
coefficient and sign transcription errors; they do not prove RH or purity.
"""
from pathlib import Path
from fractions import Fraction
from hashlib import sha256
import json
from datetime import datetime, timezone
import sympy as s

HERE = Path(__file__).resolve().parent
BASE = HERE.parent

def digest(p):
    return sha256(p.read_bytes()).hexdigest()

ru, rv, su, sv, Nu, Nv = s.symbols('r_u r_v sigma tau N_u N_v', real=True)
first = 4*Nu*Nv*((1+su*ru)*(1+sv*rv)-(1+su*ru)-(1+sv*rv)+1)
assert s.expand(first - 4*su*sv*ru*rv*Nu*Nv) == 0
cross = 4*Nu*Nv*(1-1-1+1)
assert cross == 0

primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43]
checked_gaps = 0
for u in primes:
    for v in primes:
        if u == v:
            continue
        gap_ratio = Fraction(u*v+1, u*v)
        for n in range(2, 201):
            for ratio in (Fraction(n*v, u), Fraction(n*u, v)):
                assert ratio != 1
                distance_ratio = max(ratio, 1/ratio)
                assert distance_ratio > gap_ratio
                checked_gaps += 1
        assert max(Fraction(u, v), Fraction(v, u)) > gap_ratio

Au, Av = s.symbols('alpha_u alpha_v', positive=True)
assert s.expand((Au-Av)**2-Au**2-Av**2) == -2*Au*Av
for m in range(1, 17):
    for a, b in [(1, 1), (1, 3), (3, 1), (7, 11)]:
        assert (a-b)**(2*m)-a**(2*m)-b**(2*m) < 0
print("PASS: exact mixed energy, lag gaps, and even-order signs.")
