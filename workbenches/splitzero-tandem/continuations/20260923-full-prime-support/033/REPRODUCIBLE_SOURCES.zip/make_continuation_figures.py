"""Reproducible scientific figures for the exact PME/FWP/FWJ/SBT maps."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch

here=Path(__file__).resolve().parent
plt.rcParams.update({'font.size':11,'axes.titlesize':13,'figure.facecolor':'white',
                     'savefig.facecolor':'white','svg.fonttype':'none'})
u,v=2,3
eps=np.log((u*v+1)/(u*v))/16
def z(t):
    t=np.asarray(t); out=np.zeros_like(t)
    inside=np.abs(t)<eps
    x=t[inside]/eps; a=1-x*x; w=np.exp(-1/a)
    out[inside]=w*((-2/a**2-8*x*x/a**3+4*x*x/a**4)/eps**2-.25)
    return out

fig=plt.figure(figsize=(13,9))
grid=fig.add_gridspec(3,3,height_ratios=[1.35,1,1.1],hspace=.8,wspace=.35)
ax=fig.add_subplot(grid[0,:])
t=np.unique(np.r_[np.linspace(-.05,np.log(3)+.05,1400),
                   *(c+np.linspace(-eps,eps,501) for c in [0,np.log(2),np.log(3)])])
y=z(t)+z(t-np.log(2))-z(t-np.log(3))
ax.plot(t,y,color='#124b79',lw=1.5)
ax.axhline(0,color='0.6',lw=.7)
ax.set(xlabel=r'$t=\log x$',ylabel=r'$g(e^t)$',
       title=r'One exact admissible test: $u=2$, $v=3$, $\varepsilon=\frac{1}{16}\log(7/6)$')
for c,label in [(0,r'$z(t)$'),(np.log(2),r'$+z(t-\log2)$'),(np.log(3),r'$-z(t-\log3)$')]:
    ax.text(c,1.03*np.max(y),label,ha='center',va='bottom',fontsize=10)
ax.set_ylim(np.min(y)*1.3,np.max(y)*1.45)
ax.ticklabel_format(axis='y',style='sci',scilimits=(0,0))
for j,(c,sign,label) in enumerate([(0,1,'First pulse'),(np.log(2),1,'Prime 2 pulse'),(np.log(3),-1,'Prime 3 pulse')]):
    az=fig.add_subplot(grid[1,j]);tt=c+np.linspace(-eps,eps,701)
    az.plot(tt,sign*z(tt-c),color='#124b79' if sign>0 else '#a02a32')
    az.axhline(0,color='0.6',lw=.6)
    az.set(title=label,xlabel=r'$t$ (actual coordinate)')
    az.ticklabel_format(axis='y',style='sci',scilimits=(0,0))
    az.tick_params(labelsize=9)
az=fig.add_subplot(grid[2,:]);az.axis('off')
az.text(.01,.97,r'$\int g(e^t)e^{t/2}\,dt=\int g(e^t)e^{-t/2}\,dt=0$',fontsize=15,va='top')
az.text(.01,.63,r'$W_2(f)=\alpha_2>0,\quad W_3(f)=-\alpha_3<0,\quad W_p(f)=0\ (p\ne2,3)$',fontsize=14,va='top')
az.text(.01,.29,r'$Q(g)>N/10>0$',color='#216642',fontsize=17,va='top')
az.text(.40,.29,r'$\operatorname{Tr}[D_{\mathbf{h}}Q(f)^r]<0\quad(r\geq2)$',color='#a02a32',fontsize=17,va='top')
fig.text(.055,.01,'Exact test and moments: PME21–25. Full Weil lower bound: FWP. Full four-state trace: FWJ1–8. '
         'N is the unaltered integral of z²; αp = 2N(log p)/√p. The plots evaluate the stated formulas.',fontsize=9)
fig.savefig(here/'ADMISSIBLE_MIXED_TEST.png',dpi=165,bbox_inches='tight')
fig.savefig(here/'ADMISSIBLE_MIXED_TEST.svg',bbox_inches='tight')
plt.close(fig)

fig,axs=plt.subplots(2,1,figsize=(13,7),gridspec_kw={'height_ratios':[1,1.15]})
ax=axs[0];ax.axis('off')
xs=np.arange(7)
labels=[r'$F_p^{3}v$',r'$F_p^{2}v$',r'$F_p v$',r'$v$',r'$F_p^{-1}v$',r'$F_p^{-2}v$',r'$F_p^{-3}v$']
for i,(x,label) in enumerate(zip(xs,labels)):
    ax.text(x,.5,label,ha='center',va='center',fontsize=15,
            bbox={'boxstyle':'round,pad=.5','fc':'#edf3f8','ec':'#124b79'})
    ax.text(x,.0,rf'$n={i-3}$',ha='center',fontsize=11)
    if i<6:
        ax.add_patch(FancyArrowPatch((x+.32,.5),(x+.66,.5),arrowstyle='->',mutation_scale=12,color='#124b79'))
        ax.text(x+.49,.75,r'$F_p^{-1}$',ha='center',fontsize=10)
ax.set(xlim=(-.6,6.6),ylim=(-.2,1.05))
ax.set_title(r'Actual annulus channel: $h_n\otimes F_p^{-n}v$, with $\mathscr{T}_{p,k}h_n=p^{k/2}h_{n+1}$',pad=10)
ax=axs[1];H=np.arange(0,31)
p,k,delta=2,17,.1
for a,color in [(17,'#a02a32'),(0,'#124b79')]:
    r=p**((2*a-k)*delta)
    # This is precisely the dimensionless factor remaining in SBT19 after its displayed p^k.
    vals=np.array([(r**(-2*h)+r**(2*h+2))/sum(r**(-2*n) for n in range(-h,h+1)) for h in H])
    ax.plot(H,vals,color=color,label=rf'$a={a},\ r=2^{{{(2*a-k)*delta:g}}}$')
    ax.axhline(abs(r*r-1),color=color,ls=':',lw=1)
ax.plot(H,2/(2*H+1),color='#216642',label=r'$r=1$: separate unit-circle comparison')
ax.set_yscale('log')
ax.set(xlabel=r'Annulus cutoff $H$ (separate from source cutoff $N$)',
       ylabel=r'$\|B_{p,H}\ell\|^2\,/\,[p^k\|\mathcal{J}_{p,H}\ell\|^2]$',
       title=r'Exact boundary ratio: $p=2$, $k=17$, $\delta=1/10$; every original phase and metric cancels only in this ratio')
ax.legend(fontsize=10,loc='upper right');ax.grid(alpha=.2)
fig.tight_layout(rect=(0,.06,1,1))
fig.text(.055,.01,'SBT5–10 gives the actual annuli, distribution map and inverse evaluation. SBT18–20 proves the boundary formula and limits.\n'
         'The unit-circle curve is a separate rank-one comparison, not a change of the original off-critical companion polynomial.',fontsize=9)
fig.savefig(here/'ANNULUS_BOUNDARY.png',dpi=165,bbox_inches='tight')
fig.savefig(here/'ANNULUS_BOUNDARY.svg',bbox_inches='tight')
plt.close(fig)
print('Created two exact formula figures and their SVG sources.')
