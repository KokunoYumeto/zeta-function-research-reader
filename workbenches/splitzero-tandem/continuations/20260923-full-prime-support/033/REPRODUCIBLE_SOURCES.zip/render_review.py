from pathlib import Path
import subprocess,json,hashlib
from PIL import Image,ImageDraw
import fitz

here=Path(__file__).resolve().parent
qa=here/'qa_033';qa.mkdir(exist_ok=True)
pdf=here/'MIXED_PRIME_ENERGY_AND_BOUNDARY.pdf'
subprocess.run(['pdftoppm','-r','100','-png',str(pdf),str(qa/'page')],check=True,capture_output=True)
pages=sorted(qa.glob('page-*.png'))
for start in range(0,len(pages),4):
    ims=[Image.open(p).convert('RGB') for p in pages[start:start+4]]
    w,h=ims[0].size
    sheet=Image.new('RGB',(2*w,2*(h+28)),(224,226,230));draw=ImageDraw.Draw(sheet)
    for i,im in enumerate(ims):
        x=(i%2)*w;y=(i//2)*(h+28)
        sheet.paste(im,(x,y+28));draw.text((x+10,y+8),f'Page {start+i+1}',fill='black')
    sheet.save(qa/f'contact-{start//4+1}.png')
doc=fitz.open(pdf)
locators={}
for i,page in enumerate(doc):
    txt=page.get_text()
    for tag in ['PME17','FWP23','FWJ6','SBT17','SBT19','SBT23']:
        if '('+tag+')' in txt:locators[tag]=i+1
receipt={'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'pages':len(doc),
         'rendered_pages':len(pages),'selected_equation_pages':locators,'root_visual_review':'pending'}
(qa/'RENDER_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
