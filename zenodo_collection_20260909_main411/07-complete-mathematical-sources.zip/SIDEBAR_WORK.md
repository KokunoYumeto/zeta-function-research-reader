# Complete incoming sidebar mathematics

These are complete author-generated working texts, mirrored in distinct namespaces. Their source-authored claims, qualifications, citations and proofs are preserved; mirroring is not mathematical validation. No consolidation into the main reader is required.

Open `sidebar-work.tex` as the Overleaf main document to read the complete PDF collection. The original zeta main document remains `main.tex`.

## Exact fluid constructions and the Navier--Stokes question

[Complete reader (208 pages)](sidebar/fluid/reader.pdf)

Complete TeX entrypoint: `sidebar/fluid/tex/main.tex`. Replay files and source status: `sidebar/fluid/README.md` and the corresponding proof/check directories.

## Heat transport on the retained inverse-fibre cover

[Complete reader (120 pages)](sidebar/heat/reader.pdf)

Complete TeX entrypoint: `sidebar/heat/tex/main.tex`. Replay files and source status: `sidebar/heat/README.md` and the corresponding proof/check directories.

## Arithmetic trace quotient and exact heat transport

[Complete reader (82 pages)](sidebar/connes/reader.pdf)

Complete TeX entrypoint: `sidebar/connes/tex/main.tex`. Replay files and source status: `sidebar/connes/README.md` and the corresponding proof/check directories.

## Retained fibres, nonstandard Riemann hypotheses, and geometric complexity

[Complete reader (174 pages)](sidebar/gct/reader.pdf)

Complete TeX entrypoint: `sidebar/gct/tex/main.tex`. Replay files and source status: `sidebar/gct/README.md` and the corresponding proof/check directories.

## Vacuum hydrodynamics, gravity and thermodynamic structures

[Complete reader (37 pages)](sidebar/vacuum/reader.pdf)

Complete TeX entrypoint: `sidebar/vacuum/tex/main.tex`. The full authored
checkers and public mathematical records are included; see
`sidebar/vacuum/README.md` and `sidebar/vacuum/MANIFEST.json`.
