"""Finite independent coefficient regressions; full all-order proof is in29p.

No source-existence or Lean certification, remote action, or corpus rebuild.
Run with python -X utf8 certificates/rh_counterexample_20260908/verify_ns_finite_radial.py.
"""
from pathlib import Path
import hashlib
import json
import time
import sympy as s

start = time.perf_counter()
root = Path(__file__).resolve().parents[2]
eta, X = s.symbols('eta X')
h = s.Rational(1,113)
A, D, k = s.Rational(1,2)+h, s.Rational(1,2)-h, 1+h
b, c, e, C = -k, -A, -2*A, s.Integer(7)
L, d = 1-2*h*eta**2, 1-eta**2
checks = []

def check(name, actual, expected=0):
    residual = s.cancel(s.expand(actual-expected))
    assert residual == 0, (name, residual)
    checks.append({'id':name, 'passed':True})

def z(beta, f):
    return (2*beta*eta*f+d*s.diff(f,eta))/L

def t(beta, f):
    return (-beta*f+D*eta*s.diff(f,eta))/L

def Z(beta, f):
    return (2*beta*eta*f+d*s.diff(f,eta)-2*eta*X*s.diff(f,X))/L

def T(beta, f):
    return (-beta*f+D*eta*s.diff(f,eta)+X*s.diff(f,X))/L

def at(poly, m):
    return s.expand(poly).coeff(X,m)

# Distinct exact polynomials exercise all derivative/product indices.
def coeff(family,n,m):
    return ((family+1)*(n+2)+(m+1)**2)+(n+m+family+1)*eta+(family+2*m+1)*eta**2

N, M = 2, 3
ph = [sum(coeff(1,n,m)*X**m for m in range(M+3)) for n in range(N+1)]
uu = [sum(coeff(2,n,m)*X**m for m in range(M+3)) for n in range(N+1)]
pp = [sum(coeff(3,n,m)*X**m for m in range(M+3)) for n in range(N+1)]
vv = [sum(coeff(4,n,m)*X**(m+1) for m in range(M+3)) for n in range(N+1)]

for n in range(N+1):
    lam = 2*n*h
    angular = T(b+lam,ph[n])
    axial = T(c+lam,uu[n])+Z(e+lam,pp[n])
    omega = T(lam,vv[n])-2*X*s.diff(vv[n],X,2)
    if n:
        angular -= Z(b+2*(n-1)*h-D,Z(b+2*(n-1)*h,ph[n-1]))
        axial -= Z(c+2*(n-1)*h-D,Z(c+2*(n-1)*h,uu[n-1]))
        omega -= Z(2*(n-1)*h-D,Z(2*(n-1)*h,vv[n-1]))
    centrifugal = 0
    for i in range(n+1):
        j = n-i
        angular += vv[i]*(s.diff(ph[j],X)+ph[j]/X)+uu[i]*Z(b+2*j*h,ph[j])
        axial += vv[i]*s.diff(uu[j],X)+uu[i]*Z(c+2*j*h,uu[j])
        omega += vv[i]*(s.diff(vv[j],X)-vv[j]/(2*X))+uu[i]*Z(2*j*h,vv[j])
        centrifugal += ph[i]*ph[j]/C**2
    for m in range(M+1):
        ar=t(b+lam-m,at(ph[n],m))
        ur=t(c+lam-m,at(uu[n],m))+z(e+lam-m,at(pp[n],m))
        wr=t(lam-m-1,at(vv[n],m+1))-2*(m+2)*(m+1)*at(vv[n],m+2)
        pr=0
        if n:
            ar-=z(b+2*(n-1)*h-D-m,z(b+2*(n-1)*h-m,at(ph[n-1],m)))
            ur-=z(c+2*(n-1)*h-D-m,z(c+2*(n-1)*h-m,at(uu[n-1],m)))
            wr-=z(2*(n-1)*h-D-m-1,z(2*(n-1)*h-m-1,at(vv[n-1],m+1)))
        for i in range(n+1):
            j=n-i
            for aa in range(m+1):
                bb=m-aa
                vi, uj = at(vv[i],aa+1), at(uu[j],bb)
                ui, pj = at(uu[i],aa), at(ph[j],bb)
                vj = at(vv[j],bb+1)
                ar += (bb+1)*vi*pj+ui*z(b+2*j*h-bb,pj)
                ur += bb*vi*uj+ui*z(c+2*j*h-bb,uj)
                wr += (bb+s.Rational(1,2))*vi*vj+ui*z(2*j*h-bb-1,vj)
                pr += at(ph[i],aa)*pj/C**2
        check(f'angular.full.n{n}.m{m}',at(angular,m),ar)
        check(f'axial.full.n{n}.m{m}',at(axial,m),ur)
        check(f'omega.full.n{n}.m{m}',at(omega,m+1),wr)
        check(f'pressure.product.n{n}.m{m}',at(centrifugal,m),pr)
        check(f'angular.radial.factor.n{n}.m{m}',at(2*(X*s.diff(ph[n],X,2)+2*s.diff(ph[n],X)),m),2*(m+1)*(m+2)*at(ph[n],m+1))
        check(f'axial.radial.factor.n{n}.m{m}',at(2*(X*s.diff(uu[n],X,2)+s.diff(uu[n],X)),m),2*(m+1)**2*at(uu[n],m+1))

# Pressure boundary cancellation with every ordered Z operator kept.
for m in range(5):
    beta=c+2*m*h-m
    v=1+eta+(m+2)*eta**2
    unew=-z(beta-D,z(beta,v))/(2*(m+1)**2)
    vold=-z(beta,v)/(m+1)
    vnew=-z(c+2*(m+1)*h-m-1,unew)/(m+2)
    check(f'pressure.boundary.cancellation.m{m}',-2*(m+1)*(m+2)*vnew-z(2*m*h-D-m-1,z(2*m*h-m-1,vold)))

# Exact factorial recurrence, source exponents and viscosity scale.
hh, mm=s.symbols('h m')
DD=s.Rational(1,2)-hh
check('diagonal.exponent',2*mm*hh-mm,-2*DD*mm)
for j in range(1,13):
    swirl=(-1)**j/(s.Integer(2)**j*s.factorial(j)*s.factorial(j+1))
    axial=(-1)**j/(s.Integer(2)**j*s.factorial(j)**2)
    oldsw=(-1)**(j-1)/(s.Integer(2)**(j-1)*s.factorial(j-1)*s.factorial(j))
    oldax=(-1)**(j-1)/(s.Integer(2)**(j-1)*s.factorial(j-1)**2)
    check(f'diagonal.swirl.factor.j{j}',swirl,-oldsw/(2*j*(j+1)))
    check(f'diagonal.axial.factor.j{j}',axial,-oldax/(2*j*j))

# Source cutoff commutator: compute from the actual Stokes primitive.
q, nu, lam, rho, rhoq, eta_symbol, L_symbol, ucoeff, zcoeff=s.symbols('q nu lam rho rhoq eta L u z', positive=True)
for l in range(1,7):
    # S_l=nu^(3/2-l) q^(D+lam-l) rho*u/l. Axial chain rule gives the bracket below.
    physical=-nu**(1-l)*q**(lam-l)*(rho*zcoeff+2*eta_symbol*q*rhoq*ucoeff/L_symbol)/l
    proposed=nu**(1-l)*q**(lam-l)*(rho*(-zcoeff/l)-2*eta_symbol*q*rhoq*ucoeff/(L_symbol*l))
    check(f'cutoff.stokes.radial.l{l}',physical,proposed)
    sigma=s.symbols('sigma')
    check(f'flux.diffusion.factor.j{l}',s.expand(2*sigma*s.diff(sigma**(l+1),sigma,2)).coeff(sigma,l),2*l*(l+1))

proof=root/'tex/satellites/29p_ns_finite_radial_recursion.tex'
source=Path('[local]/Documents/math/output/dbn_ns_rh_20260908/sources/ns_public/navier_stokes_166.pdf')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt={'schema_version':1,'id':'NS-FINITE-RADIAL-20260909','status':'pass',
 'check_count':len(checks),'checks':checks,'script_sha256':sha(Path(__file__)),
 'proof_sha256':sha(proof),'source_sha256':sha(source),'sympy_version':s.__version__,
 'seconds':time.perf_counter()-start,
 'scope':'Exact finite coefficient regressions on specified polynomial inputs; full all-order standard proof in29p. Not source-existence or Lean certification.',
 'source_imported':True,'lean_used':False,'memory_policy':'noncritical 5000000000 bytes; small sequential symbolic polynomials'}
out=Path(__file__).with_name('ns_finite_radial_checks.json')
out.write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(f'NS_FINITE_RADIAL_OK checks={len(checks)} seconds={receipt["seconds"]:.2f} source_imported=true')
