"""Exact finite checks for the fully proved hidden-Mellin diffusion map."""
from pathlib import Path
import hashlib
import json
import time
import sympy as s

started=time.perf_counter()
root=Path(__file__).resolve().parents[2]
checks=[]
q=s.symbols('q',positive=True)  # exactly q=2**h, not a source normalization
x,w=s.symbols('x w')
def check(name, expr):
    value=s.simplify(s.expand(expr))
    assert value==0, (name,value)
    checks.append({'id':name,'passed':True})
def Wnegative(n):
    return s.zeta(-n)*(1-s.Rational(1,2)**(n+1))*(1-q*2**n)
kappa=(2*q-1)/16
d=7*(4*q-1)*s.zeta(3)/(32*s.pi**2)
check('kappa.factor',Wnegative(1)-kappa)
check('d.factor',(-s.zeta(3)/(4*s.pi**2))*s.Rational(7,8)*(1-4*q)-d)
check('kappa.over.d',kappa/d-2*s.pi**2*(2*q-1)/(7*(4*q-1)*s.zeta(3)))
for n in range(1,13):
    # Polynomial is the exact germ of the compact input chi*x**n.
    a=x**n
    psi=(1+q/2)*a-q*a.subs(x,2*x)-s.Rational(1,2)*a.subs(x,x/2)
    derivative=s.diff(psi,x,n).subs(x,0)
    check(f'dilation.jet.{n}',derivative-(1-s.Rational(1,2)**(n+1))*(1-q*2**n)*s.factorial(n))
    L=2*x*s.diff(a,x,2)
    if n>=2:
        check(f'radial.jet.{n}',s.diff(L,x,n-1).subs(x,0)-2*(n-1)*s.factorial(n))
    if n%2==0:
        check(f'even.trace.jet.{n}',Wnegative(n)*s.factorial(n))
        # W has simple zero: every regular term of Ma drops out of value.
        d0,d1,A0,H0=s.symbols('d0 d1 A0 H0')
        product=s.expand(w*(d0+d1*w)*(A0/w+H0))
        check(f'even.regular.value.{n}',product.subs(w,0)-d0*A0)
    else:
        A0,H0,V0,V1=s.symbols('A0 H0 V0 V1')
        product=s.expand((V0+V1*w)*(A0/w+H0))
        check(f'odd.residue.{n}',s.limit(w*product,w,0)-V0*A0)
check('flat.witness.image.jet',Wnegative(2)*2)
check('flat.witness.radial.nonzero.coefficient',kappa*s.diff(2*x*s.diff(x**2,x,2),x).subs(x,0)-4*kappa)
b1,b2,b3,p2,p3,q1,q2,f1,nu=s.symbols('b1 b2 b3 p2 p3 q1 q2 f1 nu')
B=b1*x+b2*x**2+b3*x**3
P=p2*x**2+p3*x**3
check('NS.radial.diffusion.coefficient',s.diff(2*x*s.diff(B,x,2),x).subs(x,0)-4*b2)
check('NS.radial.flux.coefficient',s.diff(P,x,2).subs(x,0)-2*p2)
MB,MP=s.symbols('MB MP')
check('NS.regular.value.balance',kappa*(4*nu*b2-2*p2)-(kappa/d)*(4*nu*MB-2*MP).subs({MB:d*b2,MP:d*p2}))
L0,L1,W1,W2=s.symbols('L0 L1 W1 W2')
check('zero.times.pole.limit',s.limit((d*w+W2*w**2)*(L0/w+L1),w,0)-d*L0)
check('shifted.pde.right.limit',s.limit((-2+w)*(kappa+W1*w)*(MP+2*nu*(-1+w)*MB),w,0)-2*kappa*(2*nu*MB-MP))
check('radial.mellin.residue',s.limit(w*2*(-1+w)*(-2+w)*(kappa+W1*w)*(b2/w+L1),w,0)-4*kappa*b2)
for n in range(1,13):
    beta,pi=s.symbols('beta pi')
    polynomial=2*nu*x*s.diff(beta*x**(n+1),x,2)-s.diff(pi*x**(n+1),x)
    check(f'full.hierarchy.coefficient.{n}',s.expand(polynomial).coeff(x,n)-(n+1)*(2*nu*n*beta-pi))
proof=root/'tex/satellites/29n_ns_diffusion_hidden_mellin.tex'
result={'schema_version':1,'status':'pass','check_count':len(checks),'checks':checks,
        'proof_sha256':hashlib.sha256(proof.read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'sympy_version':s.__version__,'elapsed_seconds':time.perf_counter()-started,
        'scope':'Finite exact coefficient and Laurent regressions supplement the complete analytic proof; they do not certify infinite summation, source existence or any RH endpoint.',
        'lean_run':False,'resource_class':'noncritical small sequential symbolic process'}
Path(__file__).with_name('ns_hidden_mellin_checks.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(f'NS_HIDDEN_MELLIN_CHECKS_PASS {len(checks)}')
