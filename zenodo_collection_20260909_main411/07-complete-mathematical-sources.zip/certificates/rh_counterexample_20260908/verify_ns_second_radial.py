"""Exact finite regressions; not a certificate of imported source existence."""
from pathlib import Path
import hashlib
import json
import time
import sympy as s

started = time.perf_counter()
root = Path(__file__).resolve().parents[2]
checks = []
eta, q, nu, C, j, lam, eps = s.symbols('eta q nu C j Lambda sigma_star', positive=True)
h = s.symbols('h', positive=True)
A, D, k = s.Rational(1, 2)+h, s.Rational(1, 2)-h, 1+h
d, L = 1-eta**2, 1-2*h*eta**2
U = 4*eta+j
Hs = D*eta+d*U
zs = -L*Hs/(Hs**2+eps**2)
phi = s.Function('phi')(eta)

def check(name, expression):
    value = s.simplify(s.expand(expression))
    assert value == 0, (name, value)
    checks.append({'id': name, 'passed': True})

def T(b, v):
    return (-b*v+D*eta*s.diff(v, eta))/L

def Z(b, v):
    return (2*b*eta*v+d*s.diff(v, eta))/L

def dt(v):
    return -s.diff(v, q)/L + D*eta*s.diff(v, eta)/(q*L)

def dz(v):
    return (2*eta*q**(1-D)*s.diff(v, q)+d*q**(-D)*s.diff(v, eta))/(s.sqrt(nu)*L)

tau, axial = q*d, s.sqrt(nu)*q**D*eta
check('coordinate.time.tau', dt(tau)+1)
check('coordinate.time.z', dt(axial))
check('coordinate.axial.tau', dz(tau))
check('coordinate.axial.z', dz(axial)-1)
check('coordinate.exponent.transport', A+D-1)
check('coordinate.exponent.axial.diffusion', -k-2*D-(-2+h))
check('coordinate.exponent.order1', -k-1+2*h-(-2+h))
for power in [-k, -A, -k-D]:
    check(f'operator.time.{power}', dt(q**power*phi)-q**(power-1)*T(power, phi))
    check(f'operator.axial.{power}', dz(q**power*phi)-q**(power-D)*Z(power, phi)/s.sqrt(nu))
H = T(-k, phi)+U*Z(-k, phi)-phi*Z(-A, U)
H_algebra = ((h-3-j*eta)*phi+Hs*s.diff(phi, eta))/L
check('H.full.algebra', H-H_algebra)
H_closed = phi*((h-3-j*eta)/L-lam*Hs**2/(Hs**2+eps**2))
check('H.exact.profile', H_algebra.subs(s.diff(phi, eta), lam*zs*phi)-H_closed)
V = -2*k*eta*phi+d*s.diff(phi, eta)
R = Z(-k-D, Z(-k, phi))
R_explicit = (2*(-k-D)*eta*V+d*s.diff(V, eta))/L**2-d*V*s.diff(L, eta)/L**3
check('R.full.operator.order', R-R_explicit)
check('R.inner.derivative', s.diff(V, eta)-(-2*k*phi-2*(k+1)*eta*s.diff(phi, eta)+d*s.diff(phi, eta, 2)))
S = j**2+eps**2
v = -lam*j/S
w = (lam*(4+D)*(j**2-eps**2)+lam**2*j**2)/S**2
check('phi.first.derivative', lam*zs.subs(eta,0)-v)
check('phi.second.derivative', (lam*s.diff(zs,eta)+lam**2*zs**2).subs(eta,0)-w)
jet = {phi.subs(eta,0):1, s.Subs(s.diff(phi,eta),eta,0):v,
       s.Subs(s.diff(phi,eta,2),eta,0):w}
K, R0 = h-3+j*v, w-2*k
check('H.origin', H.subs(eta,0).subs(jet)-K)
check('R.origin', R.subs(eta,0).subs(jet)-R0)
sigma = s.symbols('sigma')
aa, bb, az, ww, rf = s.symbols('a0 b0 w0_z w0 force_curl')
check('flux.radial.coefficient', 4*aa*bb-(-az*2*bb).subs(az,-2*aa))
b1t, b1z, b1zz, b1 = s.symbols('b1t b1z b1zz b1')
b2 = (b1t+ww*b1z-b1*az-nu*b1zz-rf)/(4*nu)
check('full.PDE.coefficient', b1t+2*(-az*b1)+(az*b1+ww*b1z)-nu*(4*b2+b1zz)-rf)
origin_b2 = (K*q**(-2-h)-R0*q**(-2+h))/(2*nu*C)-rf/(4*nu)
origin = {b1t:2*k*q**(-2-h)/C, ww:s.sqrt(nu)*j*q**(-A),
          b1z:2*v*q**(-k-D)/(C*s.sqrt(nu)), b1:2*q**(-k)/C,
          az:4/q, b1zz:2*R0*q**(-2+h)/(nu*C)}
check('full.PDE.origin', b2.subs(origin)-origin_b2)
cut = s.symbols('chi_c1q')
HH, RR = s.symbols('H R')
direct = (q**(-2-h)*HH-cut*q**(-2+h)*RR)/(2*nu*C)
via_PDE = (q**(-2-h)*HH-q**(-2+h)*RR)/(2*nu*C)-rf/(4*nu)
exact_rf = 2*(cut-1)*q**(-2+h)*RR/C
check('cutoff.force.exact', via_PDE.subs(rf,exact_rf)-direct)
check('cutoff.force.one', exact_rf.subs(cut,1))
for n in range(1,9):
    current = s.Function(f'phi{n}')(eta)*sigma
    # Full Z restricted to axis cannot revive a smooth O(X) term.
    def fullZ(b, f):
        return (2*b*eta*f+d*s.diff(f,eta)-2*eta*sigma*s.diff(f,sigma))/L
    twice = fullZ(-k+2*n*h-D, fullZ(-k+2*n*h,current))
    check(f'positive.axis.axial.vanish.{n}', twice.subs(sigma,0))
    check(f'positive.axis.radial.operator.{n}', (2*(sigma*s.diff(current,sigma,2)+2*s.diff(current,sigma))).subs(sigma,0)-4*s.Function(f'phi{n}')(eta))
z3, kap, dh, B2, MP, MB = s.symbols('zeta3 kappa d_h B2 MP MB')
dh_exact = 7*(2**(h+2)-1)*z3/(32*s.pi**2)
check('Mellin.d.constant', (-z3/(4*s.pi**2))*s.Rational(7,8)*(1-2**(h+2))-dh_exact)
local = s.symbols('local')
c0,c1,c2 = s.symbols('c0 c1 c2')
check('Mellin.regular.value', s.limit(local*(dh+c1*local)*(B2/local+c0+c2*local),local,0)-dh*B2)
arith_rhs = 4*nu*kap*origin_b2-2*kap*(-8*q**(-2-h)/C)
arith_expected = 2*kap*(5+h+j*v)*q**(-2-h)/C-2*kap*R0*q**(-2+h)/C-kap*rf
check('Mellin.full.balance.origin', arith_rhs-arith_expected)
proof = root/'tex/satellites/29o_ns_actual_second_radial.tex'
source = Path('[local]/Documents/math/output/dbn_ns_rh_20260908/sources/ns_public/navier_stokes_166.pdf')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(source)=='0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f'
result = {'schema_version':1,'status':'pass','check_count':len(checks),'checks':checks,
          'proof_sha256':sha(proof),'script_sha256':sha(Path(__file__)),
          'source_sha256':sha(source),'sympy_version':s.__version__,
          'elapsed_seconds':time.perf_counter()-started,'lean_run':False,
          'scope':'Finite coordinate, coefficient, cutoff and Laurent checks supplement the complete standard proof. Not certification of imported NS existence, uniform analytic estimates, or an RH counterexample.',
          'resource_class':'noncritical small sequential symbolic calculation; 5GB policy'}
Path(__file__).with_name('ns_second_radial_checks.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(f'NS_SECOND_RADIAL_CHECKS_PASS {len(checks)}')
