# Independent review: flow-translated Connes source quotient

Date: 2026-09-08. Reviewer: full_stress_review. Bounded independent mathematical review; no peer or parent TeX edited.

## Exact object and verdict

Target: [local]/Documents/math/output/connes_quotient_heat_transport_2026-09-08/tex/connes_quotient_heat_transport.tex

SHA-256 independently read before and after the main mathematical reading: b70272d1e23d49d2c5b7c9d407a01b151443a17ea93a7e6a3f4597e0e982f90a.

Complete sections 12 and 13, target lines 5557–6387, were read. Verdict: PASS at the manuscript's explicitly imported source scope. No correction to these sections was found. In particular the multiplicities, derivative sign, inverse heat operator, viscosity factors, changing material label, and the distinction between the original quotient and its information-preserving refinement are retained correctly.

The strongest unconditional nonvanishing conclusion proved here concerns the common refinement C_cap and the specified analytic quotient Q_I. In the original source quotient Q, the actual sample is exactly c_tau beta, beta=[Xi']; its vanishing is not decided by the spectral-set clause of the source. This is an exact computed source class, not a claim that the residue already descends to Q. The manuscript states this limitation correctly. Section 5 below records a further exact zero-or-divergence classification on this original source line.

This is not a complete independent certification of the 166-page Navier–Stokes existence construction, an audit of all preceding manuscript sections, a proof of a new nontrivial zeta zero, or an RH endpoint claim.

## Reading scope and primary evidence

Besides sections 12–13, the target's definitions and proofs read directly were lines 1–204 (source E,N,Q, original coordinate, growth topology and heat group), 380–508 (source kernel/cokernel, corrected division A_lambda, derivative/heat implications), 575–700 (entire division and the analytic ideal), 3305–3562 (actual Sobolev source and common-test morphism), 4764–4980 (original polynomial map, full inverse differential, real flow and profile derivatives), and 5321–5556 (actual viscosity-scaled sample, full source-profile identity, energy and terminal map). The necessary earlier portions were selected through their exact labels, not through routing summaries.

The source index and its private-path records were used only to locate primary mathematical content:

- Alain Connes, Caterina Consani, Henri Moscovici, Zeta zeros and prolate wave operators: Semilocal adelic operators. Actual author-proof p.19, especially lines 544–558, equation (3.22), and Proposition 3.6, was visually inspected. Its original arXiv v2 mathematical source clauses, lines 668–689, were also read in the retained primary-TeX excerpt. The proposition gives the zero set as a spectrum, not algebraic multiplicities. The local source PDF is [local]/Documents/Papors/used often/NCG/Zeta-zeros-and-prolateproofs-final-2024.pdf; 1,379,691 bytes, SHA-256 bc4ee754d7764ca61445a0c76fcf4cecee759a794c74abf9a4f60196eb3e4acd.
- Alain Connes and Matilde Marcolli, Noncommutative Geometry, Quantum Fields and Motives, Chapter 2, printed pp.378–381, Proposition 2.24 and its proof; pp.407–408, definitions 2.45–2.46 and Theorem 2.47; pp.416–420, annihilator proof and equations (2.447)–(2.449). The cited native primary text was read, with p.381 separately reread after an initially truncated tool display. Printed pp.408 and 420 were visually inspected to check the fraction and Jordan action. PDF: [local]/Documents/Papors/used often/NCG/Noncommutative Geometry, Quantum Fields and motives.pdf; 6,771,290 bytes, SHA-256 4154ad00fad638e06746f11cd476adb00d186d30cee11e9f531fd21c45aa71f7.
- Alain Connes, Trace Formula in Noncommutative Geometry and the Zeros of the Riemann Zeta Function. Actual author text, Section III pp.10–15 and Appendix I pp.62–67, was read; p.13 visually inspected. This supplies the original weighted norm, generator, strict multiplicity cutoff, and triangular log-monomial action. PDF: [local]/Documents/Papors/used often/Connes/selecta.ps-2 Trace Formula in Noncommutative Geometry and.pdf; 1,380,281 bytes, SHA-256 df24bd83e1653c4083061f478282badefa52653827cc21a8365d28f4923770cc.
- OpenAI, Finite time blowup for Navier–Stokes, retained 166-page release. Source p.121, Lemma 10.4 and its proof, and p.124, equations (10.20)–(10.23), were read directly again for this review. Earlier bounded source reads against the same hash are recorded in FULL_STRESS_REVIEW.md, ANGULAR_MELLIN_REVIEW.md, and AXIS_JET_REVIEW.md. PDF: [local]/Documents/math/output/navier_stokes_research_2026-09-08/downloaded_public_release/navier-stokes.pdf; 2,959,204 bytes, SHA-256 0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f. The complete existence theorem remains explicitly imported.

All four source PDF hashes above were independently recomputed in this review. No public source was uploaded. The inspected mathematical source texts are not reproduced in bulk here.

The bounded extract objects actually used have these bindings, relative to the Connes output directory:

- sources/topology_followup/ccm_v2_tex_mainc2m24fine_contexts.txt: 10,321 bytes; fa423b748f8526aa43572393aa045779a24f6a2e86efe58c42aea65cd992b871.
- sources/topology_followup/cm_book_proposition_context.txt: 12,524 bytes; b550d85dd0ae013b69179fa91fafd5ad9b366b7ddbed6de6148a347974f710ca.
- sources/source_sobolev_followup/cm_section9_excerpt.txt: 31,763 bytes; 5c0edcb57af1ef00dc6842434d53484dd45e38b75ca4e12b115baab1b1ca7d77.
- sources/source_sobolev_followup/connes_spectral_excerpt.txt: 25,280 bytes; 028da3ddbc892cc5874ac3644e4f68970a162070d708b7b11fbe08acfd536a0d.
- sources/flow_007/primary_closing_pages.txt: 28,269 bytes; ac5c67fbad62e2eb0c62a70c51c17c0588ec6041d327ce140219267dcfbff9d8.

These are reading locators, not substitute mathematical authors.

## 1. Original source and transported quotient

The reviewed E is the unchanged set of entire functions of order at most one. N is the original tau-closure of C[s] Xi; it has not been replaced by Xi E. The finite Hermite-image assertion in the primary source supports that generating span. The inspected source calls its ring topological but does not specify its topology there. Retaining tau instead of silently substituting gamma is therefore appropriate.

The growth seminorm proof of translation is correct: with b=c 2^(1-p),

|h(zeta+a)| exp(-c|zeta|^p) <= ||h||_(p,b) exp(c|a|^p).

Thus T_a and T_-a are gamma-homeomorphisms. Differentiation commutes with translation; gamma-convergence of the heat series allows the same commutation for U_theta. The actual full inverse is U_-theta T_-a.

The conjugate multiplication calculation has the right sign and factor:

V_(theta,a) s V_(theta,a)^(-1) = zeta+a-(theta/2)D_zeta.

Indeed [D^2,s]=2D and U_theta=exp(-theta D^2/4). This whole combination, rather than an isolated D term, preserves V_(theta,a)N. The quotient isomorphism and equality of continuous-inverse spectra follow by conjugating each two-sided inverse. At theta=0 the spectrum of multiplication by zeta is Spec(S)-a. No new spectral positions are created by this real translation.

Transporting the total fibre-family topology from C^2 x Q is legitimate and explicitly stated. It does not prove parameter continuity in the original untransported tau, and the text does not claim that.

The full time defect is D_j=v_j V Xi', with the original cancellation of -vartheta' D_zeta^2/4. Since Xi belongs to N, the moving profile itself has zero quotient class. Its derivative is an element of the exact multivalued derivative relation at zero, not a derivative assigned to the zero class by an assumed single-valued operator. The relation's kernel and ambiguity space are exactly as written.

## 2. Division, multiplicities and the common refinement

The earlier entire-division proof is sufficient for I=Xi E to be the stated closed analytic subspace. Its Jensen/Poisson estimate keeps a full denominator, does not rely on a false global minimum-modulus bound, and yields the displayed linear bound with b=a/(6*2^p). Division at zero locations is local Taylor division with every vanishing jet through multiplicity minus one. The gamma polynomial approximation then proves the claimed ideal closure.

For H_cap=N intersect I and the join topology, both continuous quotient maps C_cap -> Q and C_cap -> Q_I have the stated kernels N/H_cap and I/H_cap. The proof that the restrictions of the open quotient map identify these kernels topologically is correct: H_cap is contained in each subspace, which is exactly what makes q(A intersect O)=q(A) intersect q(O) true. The joint map is injective; no unjustified topological-embedding assertion is made.

At a zero lambda of multiplicity m, retaining Xi=(s-lambda)^m A_lambda gives

c Xi'/Xi = mc/(s-lambda) + c A_lambda'/A_lambda.

In particular Xi'(lambda) may itself vanish when m>1, but the residue remains mc. No simplification to a simple-zero argument occurs. The contour bound r sup|h|/min|Xi| is correct; its denominator is only a fixed small circle avoiding zeros. It proves gamma-continuity, hence continuity for the join topology, not continuity for tau.

R_lambda kills I and H_cap, so the common class beta_tilde has the exact continuous inverse coordinate R_tilde/m on its line. The projection Pi_lambda is genuinely idempotent. Its complement and direct-sum claims follow from the displayed scalar identity. This is an information-preserving refinement with an explicit inverse on the velocity line.

The full principal-part map has kernel exactly I: vanishing all negative Laurent coefficients gives an entire quotient, and the earlier division theorem supplies its unchanged order class. For nonzero theta the transported ideal is V I, not an ordinary ideal silently generated by T_a Z_theta. The inverse-heat factor in the transported residue is necessary and is correctly present.

## 3. Logarithmic connection and full physical inverse

At theta=0 the divisor lambda-a_j has its original multiplicity and imaginary coordinate. On its complement, omega=dPsi/Psi=(Xi'/Xi)(zeta+a)(d zeta+d a) has d omega=0. The connection is flat there, with its divisor explicitly excluded. The loop integral of the connection form divided by 2 pi i is m; this should not be confused with a nontrivial holonomy assertion, which the text does not make.

The time component has residue r_j=m v_j, equivalently -m times the zero's coordinate velocity. It is a meromorphic residue, not evaluation of a quotient at a singular point.

The unchanged polynomial map has det J=-1 and inverse columns [2W_1,W_2,W_3]. Hence r=mJu recovers all three components of u exactly. It does not require a globally injective polynomial target: the physical point and actual material flow remain in the data. The support constants M_K and N_K are valid on the fixed compact velocity support; X_t(K)=K follows from uniqueness both forward and backward.

The supremum comparison m||u||_infty/N_K <= sup|r| <= m M_K||u||_infty and the full L2 identity follow directly. Their constants retain the multiplicity factor. The spectral L2 comparison uses real translations, so the unchanged norm of Xi' is valid. No unproved terminal smooth inverse of the flow is used.

## 4. Actual source sample, signs, and compensation

The actual source p.124 gives the relative remainder O(tau^(2h)) after retaining the summation cutoffs and annular corrections. With its viscosity change x=sqrt(nu)y, the component is sqrt(nu) tau^(-1/2-h)(e_0+R_*(tau)). Its spatial L2 squared scale is nu^(5/2), as both the source and reviewed text retain.

Directly differentiating the original F at (r,0,0) gives precisely

J = ((0,0,1/2),(0,1,3r),(2,-3r^2,-r^3)).

Consequently u_2=v_2-6r v_1. The first two source shifts are zero, so the full entire-function identity for E_(nu,tau) is exact; it is not an approximation of Xi' by one of its values. Its residue is

m sqrt(nu) tau^(-1/2-h)(e_0+R_*(tau)).

The vector lower-bound denominator is sqrt(1+36r^2)=sqrt(1+72nu X_in tau), including the 2 in the similarity radius. The simultaneous energy upper bound m^2 M_nu^2 nu^(5/2)F_*(1)^2 agrees with source Lemma 10.4.

The changing-label calculation is essential and correct. Differentiating X_(1-tau)(q_tau)=x_tau gives A_tau q_tau'=x_tau'+u. The first two J rows kill x_tau'=r/(2tau)e_1, yielding grad_q a_j dot q_tau'=v_j. Thus along this sampling curve the full time-and-label differential is -v_j+v_j=0. The pullback of the connection at fixed spectral coordinate is zero on that curve even though its original partial-time residue grows. This is the explicit compensation; the text has not mistaken the Eulerian sampling path for one fixed material label.

For K, its source classes kappa and beta_K remain as given. The Xi divisor has not been assigned to the full K profile. The translated modular-double sign follows componentwise from conjugation and sector swap, and the conjugate source topology and relation are explicitly retained.

## 5. Exact consequence for the original source quotient

Write c_tau=sqrt(nu)tau^(-1/2-h)(e_0+R_*(tau)). The manuscript proves the exact source identity

[E_(nu,tau)]_Q = c_tau beta.

Its complete zero-or-growth classification is:

- If beta=0, every one of these original-source classes is exactly zero. The nonzero residue is retained in the comparison quotient, and need not descend to Q.
- If beta is nonzero, the map c -> c beta is a homeomorphism from ordinary C onto its line in Q, and c_tau beta leaves every bounded subset of Q as tau decreases to zero.

This last assertion needs neither a residue functional on all of Q nor local convexity of tau. Because N is closed, the original quotient is a Hausdorff topological vector space. The compact circle {c beta: |c|=1} omits zero, so choose a balanced zero-neighborhood U disjoint from it. If c beta belongs to U, balancedness implies |c|<1: otherwise dividing by |c| puts a member of the circle in U. Rescaling U proves continuity of the inverse scalar coordinate on the line. For any bounded B in Q, there is t>0 with B contained in tU. Therefore c beta in B implies |c|<t. Since |c_tau| tends to infinity by the source lower bound, the classes eventually leave B.

Similarly, the velocity-to-source-class map has exactly rank zero or rank three over C, with kernel J^(-1)(a_beta^3). There is no intermediate loss of only one physical component in this common-beta construction. The text computes the kernel and does not choose one of these alternatives without proving the membership question.

Thus there is genuine original-source information: the full actual class and its exact all-or-nothing kernel are computed, and its only possible boundedness behaviours are fixed. What is not proved is which of those two behaviours the unnamed source closure realizes. The common refinement solves the information-loss problem by an explicit map, not by silently declaring its nonzero class equal to a nonzero class in Q.

## 6. Frozen spectral data and the Sobolev comparison

The degree-one corrected division A_lambda gives the stated kernel and cokernel formulas on the actual N. In particular it cannot prove injectivity without the saturation equality. At zero, the imported source spectral theorem gives a continuous inverse because Xi(0) is nonzero. The formula

[f] -> [(f(s)-f(0)Xi(s)/Xi(0))/s]

is its exact representative formula: the numerator vanishes at zero, and changing a representative changes the numerator by an element of N intersect sE=sN. Continuity is supplied by the imported quotient inverse, not by an unproved continuity assertion about this lift.

The heat commutator P_(k+1)(X)=(t/2)X P_k(X)-P_k'(X) has degree k+1 with nonzero leading coefficient for t not zero. It therefore gives every derivative of U_t Xi in N under the stated one-sided inclusion. Taylor uniqueness and A_lambda then make every S-lambda algebraically onto. Surjectivity plus a nonzero eigenvector gives the full infinite independent preimage chain; all signs and factorials in the descended Weyl ladder agree.

Here a finite generalized eigenspace means the entire generalized eigenspace at that eigenvalue, not merely a finite invariant initial segment of an infinite Jordan chain. With that standard meaning the incompatibility is correct. The existence of such a finite full source root space is not supplied by the inspected CCM spectral-set clause.

For the specified Sobolev realization, the strict bound is a<(delta-1)/2. It is verified by the actual integral with power 2a-delta and gives the block size min(m,ceil((delta-1)/2)). The target correctly preserves the discrepancy between CM's printed Theorem 2.47 and its own proof; Connes's original Theorem 1 and the directly checked integral give the latter count. Transposing the left-translation representation gives eigenparameter it and the lowering coefficient a, exactly as written.

The earlier common-test morphism was checked with its actual Fourier sign: the character moment is i^a D^a Ff(-t), and T=-i partial_u intertwines with iD_1. The comparison maps have the two explicit kernels, not an assumed isomorphism. Finite Sobolev Jordan multiplicity therefore has not been imported into the unnamed entire-function quotient.

Finally the finite-support direct-sum spectral model is a valid model for exactly the spectral-set/Weyl-pair claim made. Its displayed finite geometric-series inverse is two-sided for mu outside Lambda, its backward shift is onto at a point of Lambda, and its generalized kernels have dimensions k. All linear maps are continuous in the stated finest locally convex topology. The principal-part realization has the correct derivative sign. It is not a realization of the actual source closure, and the manuscript explicitly does not identify it with Q.

## Operation receipt and limits

This review used bounded local text/PDF reads, existing source-page images, independent SHA-256 checks, and hand verification of the displayed identities. No numerical experiment, Lean invocation, TeX build, global index action, peer-source edit, or remote action was performed. One read-only PowerShell hash aggregation initially failed parsing because a foreach statement was piped without first collecting its result; the corrected read-only command completed and produced all recorded hashes. No state-changing operation occurred in that failed command.

The only created file is this review. It does not certify the unnamed topology by absence of a definition in a bounded source selection. It does not promote the imported full Navier–Stokes existence theorem to an independently checked theorem. It does not turn a growing logarithmic residue into an off-line zeta zero: the explicit divisor map leaves the imaginary coordinate unchanged.
