This preprint develops explicit maps connecting retained polynomial fibres, conductor defects, the nonstandard Riemann-hypothesis programme in geometric complexity theory, and concentration coordinates from the Navierâ€“Stokes manuscript made public on 8 September 2026. It includes complete proofs of the stated intermediate results and records the remaining gaps toward the large open problems motivating the investigation.

The concrete results include the original 1,260-dimensional GCT source representation and its integral presentation, exact Schur and nested Schur conductor maps, a finite negative coefficient along a specified concentration path, full differential-operator correspondences, and explicit failures of proposed positivity and tensor-symmetry constructions. The full integral braid now has a complete spectrum of 221 distinct eigenvalues and an exactly calculated conductor quotient of length 12,102 at q=1. Its infinitesimal double braid gives a positive operator with sharp bounds 316 and 556, an explicit flat logarithmic connection, and a phase-retaining square-root tangent on the concentration conic. The source-compatible sign, braid and coefficient bialgebras are connected by proved surjections. The material-tensor composition retains the physical Hamiltonian and its Hilbert adjoint: multiplying a state by a negative coefficient scales its positive spectral measure by the coefficient's squared modulus. The resulting statements do not establish a Millennium-problem resolution.

This was human-directed work with Codex. The human participant proposed the exploratory directions, including the suggestion to look for negativity at a finite endpoint. Codex generated calculations and proofs and used separate AI calculation routes for review. The manuscript records unsuccessful constructions and corrections as well as successful maps. These checks are not presented as external peer review or a complete formal verification. The original fibre/arithmetic work predates this task's introduction of the public Navierâ€“Stokes source on 8 September 2026; the subsequent bridge records both source revisions, precise formulas, attribution, and proof status. The external global Navierâ€“Stokes theorem was not independently verified in this preprint.

These are the public read-only workbenches where Codex worked. Readers are invited to audit the exploratory projects, including what was tried and what failed:

- [S6 Workbench](https://www.overleaf.com/read/rtmyqxyrzprn#fa24eb)
- [ErdÅ‘sâ€“Straus Workbench](https://www.overleaf.com/read/rnwvwkhfhztp#8f63da)
- [Navierâ€“Stokes Workbench](https://www.overleaf.com/read/hzthvczhdyxc#a60fc2)
- [Additional public workbench](https://www.overleaf.com/read/sybvppjwxmxw#b17484)

The fourth project label was not supplied with the link. The initial edition provides the readable manuscript and its complete mathematical source. Publication of the contributing transcripts, with profanity filtered and human suggestions retained in context, is a separately planned later stage.


## Building and checking

Install Python with SymPy and a TeX distribution providing pdfLaTeX and
BibTeX. Run `python reproduce.py` from this directory. It executes the 26
listed exact checkers sequentially and compiles the complete cumulative
proof. The checks supplement the written proofs; they do not replace
general arguments with finite experiments. The wider local research
replay is recorded in `validation_scope.json`. The archived `reader.pdf`
is the visually reviewed edition; rebuilding may change PDF metadata.
