"""Exact full-source braid spectrum and arithmetic order checks.

Default replay reads only this directory's portable source transcript. Optional
--observe-source ROOT additionally verifies every pinned original source hash.
No numerical floating-point calculations or third-party packages are used.
The finite checks supplement, and do not replace, the complete proof in
full_braid_spectrum.md / full_braid_spectrum.tex.
"""
from collections import Counter
from fractions import Fraction
from hashlib import sha256
from itertools import product
from pathlib import Path
import argparse
import json

HERE = Path(__file__).resolve().parent
CHECKS = Counter()


def check(test, group):
    if not test:
        raise AssertionError(group)
    CHECKS[group] += 1


def highest_classes():
    """Enumerate precisely the original source's column constraints."""
    ans = []
    for i3, i2, i1 in product(range(2), repeat=3):
        for A in range(4 - 2*i3):
            for B in range(4 - 2*i3 - A):
                C = 3 - 2*i3 - A - B
                for D in range(3 - 2*i2):
                    for E in range(3 - 2*i2 - D):
                        G, f = 2 - 2*i2 - D - E, 2 - 2*i1
                        if B*C or (D > 0 and C != 0) or (E > 0 and B > 1):
                            continue
                        if G > 1 or (G == 1 and f == 0) or B > f+E or C > f+D:
                            continue
                        k = 3*i3 + 2*i2 + i1
                        a = 2*A + 2*B + C + 2*D + E + G + f + k
                        b = 2*A + B + 2*C + D + 2*E + G + f + k
                        ans.append({'invariant_record': [0,i3,i2,i1],
                                    'columns_123_124_134_12_13_23_1': [A,B,C,D,E,G,f],
                                    'lambda': [a,15-a], 'mu': [b,15-b],
                                    'dimension': (2*a-14)*(2*b-14)})
    return ans


def exponent(m, p, n, u, r, s):
    check((m*n+p*u) % 2 == 0, 'integer full central exponent')
    return 225 + (m*n+p*u)//2 - r*(m+n-r+1) - s*(p+u-s+1)


def enumerate_spectrum(classes):
    mult = Counter((row['lambda'][0],row['mu'][0]) for row in classes)
    types = sorted(mult)
    spec, blocks = Counter(), []
    for ia, alpha in enumerate(types):
        a,b = alpha
        m,p = 2*a-15,2*b-15
        for beta in types[ia:]:
            c,d = beta
            n,u = 2*c-15,2*d-15
            pair_dimension = 0
            for r in range(min(m,n)+1):
                for s in range(min(p,u)+1):
                    e = exponent(m,p,n,u,r,s)
                    h,k = m+n-2*r,p+u-2*s
                    dimension = (h+1)*(k+1)
                    left_exp = 225+(m*n+p*u)//2-r*(2*m-r+1)-s*(2*p-s+1)
                    right_exp = 225+(m*n+p*u)//2-r*(2*n-r+1)-s*(2*u-s+1)
                    check(left_exp+right_exp == 2*e, 'exact monodromy exponent')
                    # The two factorial-ratio words cancel term by term.
                    # Use update/subtract: duplicate factorial arguments must add.
                    word = Counter([n,m-r,m,n-r,u,p-s,p,u-s])
                    word.subtract([n-r,m,m-r,n,u-s,p,p-s,u])
                    check(all(x == 0 for x in word.values()), 'exact factorial cancellation')
                    if alpha == beta:
                        eps = (-1)**(r+s)
                        g = mult[alpha]
                        plus = g*(g+eps)//2 * dimension
                        minus = g*(g-eps)//2 * dimension
                    else:
                        plus = minus = mult[alpha]*mult[beta]*dimension
                    spec[1,e] += plus
                    spec[-1,e] += minus
                    pair_dimension += plus+minus
                    blocks.append({'alpha': list(alpha), 'beta': list(beta),
                                   'ratio_weights': [m,p,n,u], 'channel': [r,s],
                                   'output_ratio_weights': [h,k], 'string_dimension': dimension,
                                   'exponent': e, 'positive_multiplicity': plus,
                                   'negative_multiplicity': minus})
            target = mult[alpha]*mult[beta]*(m+1)*(p+1)*(n+1)*(u+1)
            if alpha != beta:
                target *= 2
            check(pair_dimension == target, 'every unordered type pair dimension')
    return +spec, blocks, mult


def class_pair_count(classes):
    """A second aggregation at all 48 individual source copies, not 22 types."""
    answer = Counter()
    for ia, ca in enumerate(classes):
        m,p = ca['lambda'][0]-ca['lambda'][1],ca['mu'][0]-ca['mu'][1]
        for ib in range(ia, len(classes)):
            cb = classes[ib]
            n,u = cb['lambda'][0]-cb['lambda'][1],cb['mu'][0]-cb['mu'][1]
            for r in range(min(m,n)+1):
                for s in range(min(p,u)+1):
                    e = 225+(m*n+p*u)//2-r*(m+n-r+1)-s*(p+u-s+1)
                    dimension = (m+n-2*r+1)*(p+u-2*s+1)
                    if ia == ib:
                        answer[(-1)**(r+s),e] += dimension
                    else:
                        answer[1,e] += dimension
                        answer[-1,e] += dimension
    return +answer


def qinteger(n, q):
    return sum((q**(n-1-2*i) for i in range(n)), Fraction(0))


def exact_highest_checks():
    for q in map(Fraction, (2,3)):
        fac = [Fraction(1)]
        for j in range(1,20):
            fac.append(fac[-1]*qinteger(j,q))
        def choose(n,k):
            return fac[n]/fac[k]/fac[n-k]
        def highest(m,n,r,i):
            return ((-1)**i*q**(i*(n-2*r+i+1))*
                    fac[n-r+i]*fac[m-i]/fac[n-r]/fac[m])
        def beta(m,n,r):
            return ((-1)**r*q**((225+m*n)//2-r*(2*m-r+1))*
                    fac[n]*fac[m-r]/fac[n-r]/fac[m])
        for m,n in product((1,3,5,7,9), repeat=2):
            for r in range(min(m,n)+1):
                out = Counter()
                for i in range(r+1):
                    j = r-i
                    ai = highest(m,n,r,i)
                    for k in range(min(m-i,j)+1):
                        e = (225+(m-2*i)*(n-2*j))//2 + k*(k-1)//2
                        value = q**e*(q-q**-1)**k*fac[k]*choose(i+k,k)*choose(n-j+k,k)
                        out[j-k,i+k] += ai*value
                b = beta(m,n,r)
                for j in range(r+1):
                    check(out[j,r-j] == b*highest(n,m,r,j), 'direct finite R highest coefficients')
                e2 = 225+m*n-2*r*(m+n-r+1)
                check(b*beta(n,m,r) == q**e2, 'exact rational monodromy')
                e = e2//2
                x = b/q**e
                xp = beta(n,m,r)/q**e
                check(x*xp == 1, 'D-unit exchanged-block involution identity')


def arithmetic_checks(spec):
    counts = {s: sum(1 for ss,e in spec if ss == s) for s in (1,-1)}
    for (s,e),(ss,f) in product(spec, repeat=2):
        if (s,e) == (ss,f):
            continue
        # q=1 values, or exact first derivative at q=1 after their cancellation.
        if s == ss:
            check(e != f and s*(e-f) != 0, 'same-sign simple collision')
        else:
            check(s-ss in (2,-2), 'opposite-sign unit separation')
    lengths = [j for s in (1,-1) for j in range(1,counts[s])]
    check(counts == {1:112,-1:109}, 'distinct eigenvalue sign counts')
    check(sum(lengths) == 12102, 'Vandermonde quotient length')
    check(max(lengths) == 111, 'conductor maximum exponent')
    check(sum(counts.values())-2 == 219, 'specialization nilradical dimension')
    check(max(counts.values()) == 112, 'specialization nilpotence index')
    return {'positive_cluster_size':counts[1], 'negative_cluster_size':counts[-1],
            'quotient_elementary_divisor_exponents':lengths,
            'quotient_length':sum(lengths),
            'conductor_positive_exponent':counts[1]-1,
            'conductor_negative_exponent':counts[-1]-1,
            'specialization_nilradical_dimension':219,
            'specialization_nilpotence_index':112}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--observe-source', type=Path)
    args = parser.parse_args()
    data = json.loads((HERE/'source_transcript.json').read_text(encoding='utf8'))
    if args.observe_source is not None:
        for description, source in data['sources'].items():
            observed = args.observe_source/source['path']
            check(observed.is_file() and sha256(observed.read_bytes()).hexdigest() == source['sha256'],
                  'explicit original source observation')
    classes = highest_classes()
    check(classes == data['highest_classes'], 'all original highest class records')
    check(len(classes) == 48, 'highest class count')
    weight_counts = Counter()
    for row in classes:
        a,b = row['lambda'][0],row['mu'][0]
        for i in range(2*a-14):
            for j in range(2*b-14):
                weight_counts[a-i,15-a+i,b-j,15-b+j] += 1
    actual_weights = Counter()
    for i,row in enumerate(data['source_basis_weights']):
        check(row['index'] == i and sum(row['weight_V']) == sum(row['weight_W']) == 15,
              'every original source index and central degree')
        actual_weights[tuple(row['weight_V']+row['weight_W'])] += 1
    check(actual_weights == weight_counts, 'entire original 1260-basis weight character')
    check(sum(weight_counts.values()) == 1260, 'honest source dimension')
    spec, blocks, types = enumerate_spectrum(classes)
    check(spec == class_pair_count(classes), 'independent 48-copy versus 22-type aggregation')
    check(len(types) == 22 and len(blocks) == 4144, 'actual type and channel count')
    check(sum(spec.values()) == 1260**2 == 1587600, 'entire tensor dimension')
    check(sum(v for (s,e),v in spec.items() if s == 1) == 794430, 'positive specialization rank')
    check(sum(v for (s,e),v in spec.items() if s == -1) == 793170, 'negative specialization rank')
    check(len(spec) == 221, 'exact minimal polynomial degree')
    check({e for s,e in spec if s == 1} == {158,162,273,274,278} | set(range(164,271)),
          'complete positive exponent set')
    check({e for s,e in spec if s == -1} == {160,273,274} | set(range(164,266)) | set(range(267,271)),
          'complete negative exponent set')
    check(sum(e*v for (s,e),v in spec.items()) == 357210000, 'exact determinant exponent')
    check(sum(v for (s,e),v in spec.items() if s == -1) % 2 == 0, 'exact determinant sign')
    check(len({e for s,e in spec}) == 113, 'distinct monodromy exponent count')
    check(min(e for s,e in spec) == 158 and max(e for s,e in spec) == 278, 'spectral exponent extremes')
    check(spec[1,158] == 2 and spec[1,278] == 418, 'extremal multiplicities')
    exact_highest_checks()
    order = arithmetic_checks(spec)
    rows = [{'exponent':e,'positive_multiplicity':spec[1,e],'negative_multiplicity':spec[-1,e]}
            for e in sorted({e for s,e in spec})]
    result = {'status':'passed','coefficient_ring':'K=Q(q); all spectral endomorphisms regular over D=Q[q,q^-1]_(q-1)',
              'full_central_degrees_per_source_factor':[15,15],
              'source_rank':1260,'tensor_rank':1587600,'source_highest_classes':48,
              'nonzero_source_types':22,'unordered_type_channels':len(blocks),
              'distinct_generic_eigenvalues':len(spec),'minimal_polynomial_degree':len(spec),
              'positive_sign_rank':794430,'negative_sign_rank':793170,
              'spectrum':rows,'arithmetic_order':order,'channels':blocks}
    (HERE/'spectrum.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
    table = ['\\begin{longtable}{rrr}',
             '\\caption{Complete full-source spectrum. The columns are the multiplicities of $q^e$ and $-q^e$.}\\label{tab:full-braid-spectrum}\\\\',
             '\\toprule $e$ & $M_+(e)$ & $M_-(e)$\\\\ \\midrule \\endfirsthead',
             '\\toprule $e$ & $M_+(e)$ & $M_-(e)$\\\\ \\midrule \\endhead',
             '\\bottomrule \\endfoot']
    table.extend(f"{r['exponent']} & {r['positive_multiplicity']} & {r['negative_multiplicity']}\\\\" for r in rows)
    table.append('\\end{longtable}')
    (HERE/'spectrum_table.tex').write_text('\n'.join(table)+'\n',encoding='utf8')
    receipt = {'status':'passed','checks':dict(CHECKS),'total_checks':sum(CHECKS.values()),
               'input_sha256':sha256((HERE/'source_transcript.json').read_bytes()).hexdigest(),
               'checker_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
               'spectrum_sha256':sha256((HERE/'spectrum.json').read_bytes()).hexdigest(),
               'source_observed':args.observe_source is not None,
               'scope':'Exact complete source character and spectral aggregation; direct finite R/highest formula rational checks at q=2,3; exact collision and conductor arithmetic. General operator and D-regularity proofs are in the accompanying manuscript.'}
    (HERE/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8')
    print(json.dumps({k:v for k,v in receipt.items() if k != 'checks'},indent=2))


if __name__ == '__main__':
    main()
