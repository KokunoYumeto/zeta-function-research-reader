"""Standalone exact full-source braid spectrum audit (Python standard library).

The input constraints and source multiplicity table are transcribed independently
from the frozen source proof. No sibling script or machine-specific path is read.
Every output is written in this script's own directory.
"""
from collections import Counter
from itertools import product
from pathlib import Path
from math import comb
import hashlib
import json

HERE = Path(__file__).resolve().parent
CHECKS = Counter()


def verify(condition, family):
    if not condition:
        raise AssertionError(family)
    CHECKS[family] += 1


def highest_classes():
    classes = []
    for i3, i2, i1 in product((0, 1), repeat=3):
        n3, n2, f = 3 - 2*i3, 2 - 2*i2, 2 - 2*i1
        for A in range(n3 + 1):
            for B in range(n3 - A + 1):
                C = n3 - A - B
                for D in range(n2 + 1):
                    for E in range(n2 - D + 1):
                        G = n2 - D - E
                        if B*C or (D > 0 and C):
                            continue
                        if (E > 0 and B > 1) or G > 1:
                            continue
                        if (G == 1 and f == 0) or B > f+E or C > f+D:
                            continue
                        shift = 3*i3 + 2*i2 + i1
                        a = 2*A+2*B+C+2*D+E+G+f+shift
                        b = 2*A+B+2*C+D+2*E+G+f+shift
                        verify(8 <= a <= 12 and 8 <= b <= 12, 'dominant source weights')
                        classes.append({'invariants': [i3, i2, i1],
                                        'columns': [A, B, C, D, E, G, f],
                                        'lambda': [a, 15-a], 'mu': [b, 15-b]})
    return classes


def schur_weights_by_cell_recursion():
    """A cell recursion independent of the source class-constraint enumeration."""
    shape = (7, 5, 3)
    cells = [(i, j) for i, length in enumerate(shape) for j in range(length)]
    filling, result = {}, Counter()

    def visit(position):
        if position == len(cells):
            content = Counter(filling.values())
            result[content[1]+content[2], content[1]+content[3]] += 1
            return
        i, j = cells[position]
        minimum = max(filling.get((i, j-1), 1), filling.get((i-1, j), 0)+1)
        for value in range(minimum, 5):
            filling[i, j] = value
            visit(position + 1)
        filling.pop((i, j), None)

    visit(0)
    return result


def scalar_data(m, n, p, u, r, s):
    """Represent the exact braid scalar by sign, q exponent, and [j] powers.

    This deliberately retains the asymmetric forward coefficient, rather than
    replacing it with a square root of monodromy.
    """
    exponent = 225 + (m*n+p*u)//2-r*(2*m-r+1)-s*(2*p-s+1)
    factors = Counter()
    for top, low, sign in ((n, n-r, 1), (m, m-r, -1),
                           (u, u-s, 1), (p, p-s, -1)):
        for j in range(low+1, top+1):
            factors[j] += sign
    factors = {j: power for j, power in factors.items() if power}
    return (-1)**(r+s), exponent, factors


def main():
    classes = highest_classes()
    G = Counter((row['lambda'][0], row['mu'][0]) for row in classes)
    matrix = [[G[a, b] for b in range(12, 7, -1)] for a in range(12, 7, -1)]
    verify(matrix == [[0,0,1,1,1],[0,1,2,3,2],[1,2,4,4,3],
                      [1,3,4,4,2],[1,2,3,2,1]], 'independent transcribed source table')
    verify(len(classes) == 48 and len(G) == 22, 'source counts')
    character = Counter()
    for (a, b), multiplicity in G.items():
        for v in range(15-a, a+1):
            for w in range(15-b, b+1):
                character[v, w] += multiplicity
    tableaux = schur_weights_by_cell_recursion()
    verify(character == tableaux, 'entire Schur character by independent cell recursion')
    verify(sum(character.values()) == 1260, 'source dimension')
    for a, b in product(range(8, 13), repeat=2):
        finite_difference = tableaux[a,b]-tableaux[a+1,b]-tableaux[a,b+1]+tableaux[a+1,b+1]
        verify(finite_difference == G[a,b], 'inverse character highest multiplicity')

    spectrum, channels = Counter(), []
    types = sorted(G)
    for index, alpha in enumerate(types):
        a, b = alpha
        m, p = 2*a-15, 2*b-15
        for beta in types[index:]:
            c, d = beta
            n, u = 2*c-15, 2*d-15
            h_alpha, h_beta = G[alpha], G[beta]
            channel_dimension = 0
            for r in range(min(m, n)+1):
                for s in range(min(p, u)+1):
                    exponent = 225+(m*n+p*u)//2-r*(m+n-r+1)-s*(p+u-s+1)
                    length_V, length_W = m+n-2*r, p+u-2*s
                    irrep_dimension = (length_V+1)*(length_W+1)
                    sign, forward_exponent, forward_factors = scalar_data(m,n,p,u,r,s)
                    reverse_sign, reverse_exponent, reverse_factors = scalar_data(n,m,u,p,r,s)
                    verify(sign == reverse_sign, 'forward reverse scalar signs')
                    verify(forward_exponent+reverse_exponent == 2*exponent,
                           'exact monodromy q exponent')
                    verify(forward_exponent-exponent == r*(n-m)+s*(u-p),
                           'exact retained scalar ratio exponent')
                    for j in set(forward_factors) | set(reverse_factors):
                        verify(forward_factors.get(j,0)+reverse_factors.get(j,0) == 0,
                               'symbolic quantum factor cancellation')
                    verify(all(j > 0 for j in forward_factors), 'ratio denominators are D units')
                    if alpha == beta:
                        verify(forward_exponent == exponent and not forward_factors,
                               'equal type retains only multiplicity flip')
                        plus = irrep_dimension*h_alpha*(h_alpha+1)//2
                        minus = irrep_dimension*h_alpha*(h_alpha-1)//2
                        if plus:
                            spectrum[sign, exponent] += plus
                        if minus:
                            spectrum[-sign, exponent] += minus
                        channel_dimension += plus+minus
                        contributions = [{'sign': sign, 'multiplicity': plus},
                                         {'sign': -sign, 'multiplicity': minus}]
                    else:
                        multiplicity = irrep_dimension*h_alpha*h_beta
                        for eigen_sign in (-1, 1):
                            spectrum[eigen_sign, exponent] += multiplicity
                        channel_dimension += 2*multiplicity
                        contributions = [{'sign': 1, 'multiplicity': multiplicity},
                                         {'sign': -1, 'multiplicity': multiplicity}]
                    channels.append({'alpha': list(alpha), 'beta': list(beta),
                                     'r': r, 's': s, 'highest_ratios': [length_V,length_W],
                                     'exponent': exponent, 'irrep_dimension': irrep_dimension,
                                     'forward_scalar': {'sign': sign, 'q_exponent': forward_exponent,
                                                        'quantum_integer_powers': forward_factors},
                                     'eigenvalue_contributions': contributions})
            expected = (m+1)*(p+1)*(n+1)*(u+1)*h_alpha*h_beta
            if alpha != beta:
                expected *= 2
            verify(channel_dimension == expected, 'complete unordered type block dimension')

    # An independent enumeration regards the 48 original copies as separate.
    # Identical labelled copies have no exterior multiplicity; distinct copies
    # each contribute a two-way exchanged block, even when their types agree.
    labelled_spectrum = Counter()
    labels = [(row['lambda'][0], row['mu'][0]) for row in classes]
    for left, alpha in enumerate(labels):
        m, p = 2*alpha[0]-15, 2*alpha[1]-15
        for right in range(left, len(labels)):
            beta = labels[right]
            n, u = 2*beta[0]-15, 2*beta[1]-15
            for r in range(min(m,n)+1):
                for s in range(min(p,u)+1):
                    exponent = 225+(m*n+p*u)//2-r*(m+n-r+1)-s*(p+u-s+1)
                    dim = (m+n-2*r+1)*(p+u-2*s+1)
                    if left == right:
                        labelled_spectrum[(-1)**(r+s),exponent] += dim
                    else:
                        labelled_spectrum[1,exponent] += dim
                        labelled_spectrum[-1,exponent] += dim
    verify(spectrum == labelled_spectrum, 'labelled-copy and type-multiplicity enumerations agree')

    positive = sorted(e for (sign,e) in spectrum if sign == 1)
    negative = sorted(e for (sign,e) in spectrum if sign == -1)
    verify(positive == [158,162]+list(range(164,271))+[273,274,278], 'full positive exponent set')
    verify(negative == [160]+list(range(164,266))+[267,268,269,270,273,274], 'full negative exponent set')
    verify((len(positive),len(negative),len(spectrum)) == (112,109,221), 'distinct eigenvalue counts')
    verify(sum(spectrum.values()) == 1260**2, 'complete tensor-square dimension')
    plus_rank = sum(count for (sign,e),count in spectrum.items() if sign == 1)
    minus_rank = sum(count for (sign,e),count in spectrum.items() if sign == -1)
    verify(plus_rank == comb(1261,2) == 794430, 'symmetric specialization rank')
    verify(minus_rank == comb(1260,2) == 793170, 'alternating specialization rank')
    determinant_exponent = sum(exponent*count for (sign,exponent),count in spectrum.items())
    V1 = sum(v*count for (v,w),count in character.items())
    V2 = sum((15-v)*count for (v,w),count in character.items())
    W1 = sum(w*count for (v,w),count in character.items())
    W2 = sum((15-w)*count for (v,w),count in character.items())
    verify(determinant_exponent == V1*V1+V2*V2+W1*W1+W2*W2 == 357210000,
           'determinant independently from full original Cartan weights')
    verify(minus_rank % 2 == comb(1260,2) % 2 == 0, 'determinant flip sign')
    same_sign_pairs = comb(len(positive),2)+comb(len(negative),2)
    verify(same_sign_pairs == sum(range(112))+sum(range(109)) == 12102,
           'normalization quotient length two formulas')
    for exponents in (positive,negative):
        for i,e in enumerate(exponents):
            for f in exponents[i+1:]:
                verify(e-f != 0, 'same-sign difference has nonzero first Taylor coefficient')

    eigenvalues = [{'sign':sign,'exponent':exponent,'multiplicity':spectrum[sign,exponent]}
                   for sign in (1,-1) for exponent in sorted(e for s,e in spectrum if s == sign)]
    data = {'status':'passed', 'source_dimension':1260, 'tensor_square_dimension':1260**2,
            'highest_class_count':len(classes), 'nonzero_type_count':len(G),
            'unordered_type_channel_count':len(channels),
            'source_coordinate_order':[12,11,10,9,8], 'source_multiplicity_matrix':matrix,
            'spectrum':eigenvalues, 'minimal_polynomial_degree':len(eigenvalues),
            'positive_eigenvalue_count':len(positive), 'negative_eigenvalue_count':len(negative),
            'specialized_positive_rank':plus_rank, 'specialized_negative_rank':minus_rank,
            'determinant':{'sign':1,'q_exponent':determinant_exponent},
            'local_order':{'uniformizer':'q-1', 'conductor_positive_exponent':111,
                           'conductor_negative_exponent':108,
                           'quotient_smith_exponents':list(range(1,112))+list(range(1,109)),
                           'quotient_length':12102, 'specialization_nilradical_dimension':219,
                           'specialization_nilpotence_index':112},
            'checks':dict(CHECKS), 'total_assertions':sum(CHECKS.values()),
            'scope':'Exact enumeration and symbolic scalar/exponent audit, with complete proofs in AUDIT.md.'}
    (HERE/'spectrum.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
    (HERE/'channels.json').write_text(json.dumps(channels,indent=2)+'\n',encoding='utf-8')
    (HERE/'highest_classes.json').write_text(json.dumps(classes,indent=2)+'\n',encoding='utf-8')
    table = ['| exponent | multiplicity of +q^exponent | multiplicity of -q^exponent |',
             '|---:|---:|---:|']
    for exponent in sorted({e for sign,e in spectrum}):
        table.append(f'| {exponent} | {spectrum[1,exponent]} | {spectrum[-1,exponent]} |')
    (HERE/'SPECTRUM_TABLE.md').write_text('\n'.join(table)+'\n',encoding='utf-8')
    print(json.dumps({'status':'passed','assertions':sum(CHECKS.values()),
                      'eigenvalues':len(spectrum),'tensor_square_dimension':sum(spectrum.values()),
                      'local_order_length':same_sign_pairs},sort_keys=True))


if __name__ == '__main__':
    main()
