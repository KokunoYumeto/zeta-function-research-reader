"""Independent exact audit of the first jet and the infinitesimal connection.

The finite Laurent R matrices are built before differentiation.  No floating
point value or matrix supplied by the implementation under review is used.
Default replay requires only this file and input_transcript.json.  Optionally
--observe-source verifies the recorded root inputs without altering the test.
"""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
from hashlib import sha256
from itertools import product
import json
from math import comb, factorial
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
counts = Counter()


def check(condition, category, detail):
    if not condition:
        raise AssertionError((category, detail))
    counts[category] += 1


def add(a, b):
    c = dict(a)
    for i, v in b.items():
        c[i] = c.get(i, 0) + v
        if not c[i]:
            del c[i]
    return c


def scale(a, s):
    return {i: s * v for i, v in a.items() if s * v}


def pmul(a, b):
    c = {}
    for i, u in a.items():
        for j, v in b.items():
            c[i + j] = c.get(i + j, 0) + u * v
    return {i: v for i, v in c.items() if v}


def shift(a, e):
    return {i + e: v for i, v in a.items()}


@lru_cache(None)
def qi(n):
    return {n - 1 - 2 * i: 1 for i in range(n)}


@lru_cache(None)
def qfact(n):
    return {0: 1} if n == 0 else pmul(qfact(n - 1), qi(n))


@lru_cache(None)
def gaussian(n, k):
    # {n choose k}_{q^2}, from the polynomial Pascal recurrence.
    if k < 0 or k > n:
        return {}
    if k == 0 or k == n:
        return {0: 1}
    return add(gaussian(n - 1, k - 1), shift(gaussian(n - 1, k), 2 * k))


def qbinom(n, k):
    return shift(gaussian(n, k), -k * (n - k))


@lru_cache(None)
def delta_pow(k):
    return {0: 1} if k == 0 else pmul(delta_pow(k - 1), {1: 1, -1: -1})


def jet(p):
    # p(e^h) has coefficients sum a_j and sum j*a_j modulo h^2.
    return sum(p.values()), sum(e * a for e, a in p.items())


def braid_jets(m, n, d=15, e=15):
    out = []
    for i, j in product(range(m + 1), range(n + 1)):
        col0, col1 = {}, {}
        cartan_twice = d * e + (m - 2 * i) * (n - 2 * j)
        check(cartan_twice % 2 == 0, 'full_weight_integrality', (m, n, i, j))
        for k in range(min(m - i, j) + 1):
            poly = pmul(delta_pow(k), qfact(k))
            poly = pmul(poly, qbinom(i + k, k))
            poly = pmul(poly, qbinom(n - j + k, k))
            poly = shift(poly, cartan_twice // 2 + k * (k - 1) // 2)
            a, b = jet(poly)
            out_index = (j - k, i + k)
            if a:
                col0[out_index] = a
            if b:
                col1[out_index] = b
            if k >= 2:
                check((a, b) == (0, 0), 'higher_nilpotent_jet', (m, n, i, j, k))
        out.append(((i, j), (col0, col1)))
    return dict(out)


def compose_col(columns, vector):
    ans = {}
    for i, a in vector.items():
        ans = add(ans, scale(columns[i], a))
    return ans


def omega_pair(m, n, i, j, d=15, e=15):
    ans = {(i, j): d * e + (m - 2 * i) * (n - 2 * j)}
    if i and j < n:
        ans[(i - 1, j + 1)] = 2 * (m - i + 1) * (j + 1)
    if i < m and j:
        ans[(i + 1, j - 1)] = 2 * (i + 1) * (n - j + 1)
    return {t: a for t, a in ans.items() if a}


def delta_f(m, n, v):
    ans = {}
    for (i, j), a in v.items():
        if i < m:
            ans = add(ans, {(i + 1, j): a * (i + 1)})
        if j < n:
            ans = add(ans, {(i, j + 1): a * (j + 1)})
    return ans


def run_pair(m, n):
    jets_mn, jets_nm = braid_jets(m, n), braid_jets(n, m)
    reverse0 = {i: c[0] for i, c in jets_nm.items()}
    reverse1 = {i: c[1] for i, c in jets_nm.items()}
    omega = {}
    for (i, j), (c0, c1) in jets_mn.items():
        check(c0 == {(j, i): 1}, 'braid_specialization', (m, n, i, j))
        expected_r = {(j, i): F(225 + (m - 2 * i) * (n - 2 * j), 2)}
        if i < m and j:
            expected_r[(j - 1, i + 1)] = 2 * (i + 1) * (n - j + 1)
        check(c1 == expected_r, 'braid_first_jet', (m, n, i, j))
        derivative_square = add(compose_col(reverse0, c1), compose_col(reverse1, c0))
        omega[(i, j)] = omega_pair(m, n, i, j)
        check(derivative_square == omega[(i, j)], 'literal_monodromy_first_jet', (m, n, i, j))
    full_basis_size = 0
    for r in range(min(m, n) + 1):
        highest = {(i, r - i): (-1) ** i * F(factorial(n - r + i) * factorial(m - i), factorial(n - r) * factorial(m)) for i in range(r + 1)}
        ell = m + n - 2 * r
        eigenvalue = 225 + m * n - 2 * r * (m + n - r + 1)
        casimir_value = 225 + F(ell * (ell + 2) - m * (m + 2) - n * (n + 2), 2)
        check(eigenvalue == casimir_value, 'casimir_scalar_identity', (m, n, r))
        v = highest
        for s in range(ell + 1):
            check(bool(v), 'nonzero_clebsch_descendant', (m, n, r, s))
            check(compose_col(omega, v) == scale(v, eigenvalue), 'complete_clebsch_eigenvectors', (m, n, r, s))
            full_basis_size += 1
            v = scale(delta_f(m, n, v), F(1, s + 1))
        check(not v, 'clebsch_lowering_boundary', (m, n, r))
    check(full_basis_size == (m + 1) * (n + 1), 'clebsch_dimension', (m, n))
    for i, j in product(range(m + 1), range(n + 1)):
        wi = comb(m, i) * comb(n, j)
        for target, a in omega[(i, j)].items():
            wt = comb(m, target[0]) * comb(n, target[1])
            check(wt * a == wi * omega[target].get((i, j), 0), 'omega_weighted_adjoint', (m, n, i, j, target))


def local_string(m):
    # Column matrices in the original divided-power order.
    E = {i: ({i - 1: m - i + 1} if i else {}) for i in range(m + 1)}
    FF = {i: ({i + 1: i + 1} if i < m else {}) for i in range(m + 1)}
    H = {i: ({i: m - 2 * i} if m != 2 * i else {}) for i in range(m + 1)}
    return E, FF, H


def matrix_sum(a, b):
    return {i: add(a[i], b[i]) for i in a}


def matrix_compose(a, b):
    return {i: compose_col(a, b[i]) for i in b}


def comm(a, b):
    ab, ba = matrix_compose(a, b), matrix_compose(b, a)
    return {i: add(ab[i], scale(ba[i], -1)) for i in a}


def run_classical(m):
    E, FF, H = local_string(m)
    check(comm(E, FF) == H, 'classical_commutator', m)
    check(comm(H, E) == {i: scale(v, 2) for i, v in E.items()}, 'classical_commutator', ('HE', m))
    check(comm(H, FF) == {i: scale(v, -2) for i, v in FF.items()}, 'classical_commutator', ('HF', m))
    C = matrix_sum(matrix_compose(H, H), {i: scale(v, 2) for i, v in matrix_sum(matrix_compose(E, FF), matrix_compose(FF, E)).items()})
    check(C == {i: ({i: m * (m + 2)} if m else {}) for i in range(m + 1)}, 'full_casimir_matrix', m)
    for action in (E, FF, H):
        check(all(not v for v in comm(C, action).values()), 'casimir_commutator', m)
    for i in range(m + 1):
        check(comb(m, i) > 0, 'positive_divided_power_metric', (m, i))
        for j in range(m + 1):
            check(comb(m, i) * E[j].get(i, 0) == comb(m, j) * FF[i].get(j, 0), 'exact_E_adjoint_F', (m, i, j))


def omega_slots(types, first, second, state):
    # Each slot is (V-index,W-index), both original full degrees are 15.
    ans = {state: 450}
    for colour in (0, 1):
        a, b = types[first][colour], types[second][colour]
        i, j = state[2 * first + colour], state[2 * second + colour]
        ans = add(ans, {state: (a - 2 * i) * (b - 2 * j)})
        if i and j < b:
            t = list(state)
            t[2 * first + colour] -= 1
            t[2 * second + colour] += 1
            ans = add(ans, {tuple(t): 2 * (a - i + 1) * (j + 1)})
        if i < a and j:
            t = list(state)
            t[2 * first + colour] += 1
            t[2 * second + colour] -= 1
            ans = add(ans, {tuple(t): 2 * (i + 1) * (b - j + 1)})
    return ans


def run_kohno(types):
    states = list(product(*(range(m + 1) for typ in types for m in typ)))
    A = {s: omega_slots(types, 0, 1, s) for s in states}
    B = {s: omega_slots(types, 0, 2, s) for s in states}
    C = {s: omega_slots(types, 1, 2, s) for s in states}
    AB, AC, BC = comm(A, B), comm(A, C), comm(B, C)
    for state in states:
        check(add(AB[state], AC[state]) == {}, 'full_two_colour_kohno_12', (types, state))
        check(add(scale(AB[state], -1), BC[state]) == {}, 'full_two_colour_kohno_13', (types, state))
        # The curvature coefficients are T,-T,T in lexicographic pair order.
        check(AC[state] == scale(AB[state], -1) and BC[state] == AB[state], 'curvature_commutator_orientation', (types, state))


def run_arnold():
    # Linear denominator/numerator vectors are in the order (x,y).
    den = [(1, 0), (1, 1), (0, 1)]
    num = [(1, 0), (1, 1), (0, 1)]  # d x, d(x+y), d y
    coefficients = [0, 0]
    for a, b, sign in ((0, 1, 1), (0, 2, -1), (1, 2, 1)):
        wedge = num[a][0] * num[b][1] - num[a][1] * num[b][0]
        remaining = 3 - a - b
        for variable in range(2):
            coefficients[variable] += sign * wedge * den[remaining][variable]
    check(coefficients == [0, 0], 'arnold_symbolic_numerator', coefficients)
    for a in num:
        check(a[0] * a[1] - a[1] * a[0] == 0, 'log_form_closedness', a)


def run_source_spectrum(transcript):
    matrix = transcript['multiplicities_descending_12_to_8']
    types = [(2 * (12 - i) - 15, 2 * (12 - j) - 15, h) for i, row in enumerate(matrix) for j, h in enumerate(row) if h]
    check(sum(h for m, p, h in types) == 48, 'actual_source_highest_count', types)
    dim = sum((m + 1) * (p + 1) * h for m, p, h in types)
    check(dim == 1260, 'actual_source_dimension', dim)
    spectrum = Counter()
    extremes = {}
    for m, p, h in types:
        for n, u, k in types:
            for r, s in product(range(min(m, n) + 1), range(min(p, u) + 1)):
                exponent = 450 + m * n + p * u - 2 * r * (m + n - r + 1) - 2 * s * (p + u - s + 1)
                spectrum[exponent] += h * k * (m + n - 2 * r + 1) * (p + u - 2 * s + 1)
                extremes.setdefault(exponent, (m, p, n, u, r, s))
                check(exponent >= 252, 'proved_uniform_source_bound', (m, p, n, u, r, s))
    check(sum(spectrum.values()) == 1260 ** 2, 'full_actual_tensor_dimension', sum(spectrum.values()))
    check((min(spectrum), max(spectrum)) == (316, 556), 'actual_extremal_eigenvalues', (min(spectrum), max(spectrum)))
    return {'dimension': 1260 ** 2, 'min': min(spectrum), 'max': max(spectrum), 'minimum_witness': extremes[min(spectrum)], 'maximum_witness': extremes[max(spectrum)], 'multiplicities': dict(sorted(spectrum.items()))}


def main():
    start = time.time()
    parser = argparse.ArgumentParser()
    parser.add_argument('--observe-source', action='store_true')
    args = parser.parse_args()
    transcript = json.loads((HERE / 'input_transcript.json').read_text(encoding='utf-8'))
    if args.observe_source:
        root = HERE.parent.parent
        for source in transcript['sources'].values():
            data = (root / source['path']).read_bytes()
            check(sha256(data).hexdigest() == source['sha256'], 'observed_source_hash', source['path'])
    for m in range(10):
        run_classical(m)
    for m, n in product((1, 3, 5, 7, 9), repeat=2):
        run_pair(m, n)
    for types in (((1, 1),) * 3, ((1, 3), (3, 1), (3, 3)), ((9, 3), (1, 1), (1, 1)), ((5, 9), (1, 1), (1, 1))):
        run_kohno(types)
    run_arnold()
    spectrum = run_source_spectrum(transcript)
    receipt = {'status': 'passed', 'arithmetic': 'exact integers and fractions; full Laurent polynomials differentiated by their integer exponents', 'audited_proof_sha256': transcript['sources']['infinitesimal_proof']['sha256'], 'checker_sha256': sha256(Path(__file__).read_bytes()).hexdigest(), 'input_transcript_sha256': sha256((HERE / 'input_transcript.json').read_bytes()).hexdigest(), 'checks': sum(counts.values()), 'categories': dict(sorted(counts.items())), 'seconds': round(time.time() - start, 3), 'source_spectrum': spectrum, 'limitations': ['Finite computations supplement the complete arbitrary-N paper proof.', 'No analytic monodromy equivalence at finite q is asserted.', 'The original 1260-by-1260 source-matrix derivative is audited separately by root.']}
    (HERE / 'verification.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': receipt['status'], 'checks': receipt['checks'], 'seconds': receipt['seconds'], 'min_omega': spectrum['min'], 'max_omega': spectrum['max']}))


if __name__ == '__main__':
    main()
