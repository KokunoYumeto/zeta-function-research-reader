# Full-source standard braiding in the retained coproduct convention

This is the next research continuation, written only in Markdown while the preceding publication checkpoint is frozen. No Python, TeX, root artifact or upload is changed by this task. The derivations use the original full source matrices and proved string maps as named dependencies. They have not yet been integrated into the cumulative reader.

## Assignment and scope

The parent requested the strongest exact full-source braided tensor map for the original coproduct, retaining all forty-eight highest strings, the original source isomorphism, both degree-fifteen central characters, the integral lattice, specialization at \(q=1\), all actions, and all braid relations. It requested actual calculation of highest-string coefficients and comparison with the previously constructed involution \(J\) and sector Hecke repair. This file is the durable record of that bounded continuation. The complete session provenance remains in the parent's logbook.

The mathematical proofs below are complete; final independent audit is recorded at the end. The scope is the standard quantum-subgroup braiding on the actual nonstandard source representation. No canonical-basis, Frobenius or complexity conclusion is assumed.

## 1. Original objects and the integral formula

Put
\[
 A=\mathbb Z[q,q^{-1}],\quad K_0=\mathbb Q(q),\quad
 \delta=q-q^{-1},\quad [j]=q^{j-1}+q^{j-3}+\cdots+q^{1-j},
 \quad [k]!=\prod_{j=1}^k[j],\quad[0]!=1.
\]
Let \(X_A\) be the original 1260-dimensional honest source lattice with its unchanged ordered basis \(b_i\), four full Chevalley matrices and all divided powers. For either colour \(V,W\), retain
\[
 \Delta K=K\otimes K,\qquad
 \Delta E=E\otimes K^{-1}+1\otimes E,\qquad
 \Delta F=F\otimes1+K\otimes F. \tag{1}
\]
The relations are \(KEK^{-1}=q^2E\), \(KFK^{-1}=q^{-2}F\), and
\([E,F]=(K-K^{-1})/\delta\). The two colours commute.

Each source basis vector has the full integer weights
\(\lambda_i^V=(\lambda_{i1}^V,\lambda_{i2}^V)\) and
\(\lambda_i^W=(\lambda_{i1}^W,\lambda_{i2}^W)\), each summing to fifteen.
Define
\[
 Q_{X,X}(b_i\otimes b_j)
 =q^{\lambda_i^V\cdot\lambda_j^V+\lambda_i^W\cdot\lambda_j^W}
 b_i\otimes b_j. \tag{2}
\]
All exponents in (2) are integers. Define the actual finite matrices
\[
 \Theta^c_{X,X}=\sum_{k=0}^{9}
 q^{k(k-1)/2}\delta^k[k]!\,F_c^{(k)}\otimes E_c^{(k)}
 \quad(c=V,W),                                      \tag{3}
\]
\[
 R_{X,X}=\Theta^V_{X,X}\Theta^W_{X,X}Q_{X,X},
 \qquad c_{X,X}=\tau_{X,X}R_{X,X},
 \quad \tau(x\otimes y)=y\otimes x.                  \tag{4}
\]
The Cartan factor acts first. The upper bound nine follows from the
proved highest ratio weights \(1,3,5,7,9\) of all forty-eight source
strings. Thus the tenth raising and lowering divided powers vanish.
Every matrix in (2)–(4) is over the original \(A\). No integer, quantum
integer, hook length or source determinant is inverted. There are at
most one hundred nilpotent summands for the two colours together.

On arbitrary finite tensor powers use the same formula with a nilpotence
bound for those powers and their actual integer weight pairs. Such a
bound exists because weights are bounded and each root application moves
one weight. The Gaussian coproduct calculation in Section 4 proves that
the divided powers preserve these tensor lattices. We will prove all
identities first over \(K_0\); since the final maps are integral and all
lattices are free, equality descends to \(A\).

## 2. Fundamental convention check

On \(L_1\) take \(Fe_0=e_1\), \(Ee_1=e_0\), and the other boundary actions
zero, with full weights \((1,0),(0,1)\). In the order
\((00,01,10,11)\),
\[
 Q=\operatorname{diag}(q,1,1,q),\qquad
 (F\otimes E)(01)=10,\qquad (F\otimes E)(10)=0.
\]
Thus
\[
 c=\tau(1+\delta F\otimes E)Q
 =\begin{pmatrix}
 q&0&0&0\\0&\delta&1&0\\0&1&0&0\\0&0&0&q
 \end{pmatrix}.                                    \tag{5}
\]
In particular \(c(01)=\delta01+10\) and \(c(10)=01\). Since
\(\Delta F(00)=10+q01\),
\[
 c\Delta F(00)=(1+q\delta)01+q10
 =q^2 01+q10=\Delta F c(00).
\]
Also \(\Delta E(11)=q01+10\), giving the same direct intertwining check.
This is exactly the earlier sector Hecke matrix. The parent independently
checked (5) by symbolic matrix arithmetic. An initial review concern
had interchanged \(F\otimes E\) and \(E\otimes F\); it was corrected by
the explicit columns above, and is not a defect in (4).

## 3. Intertwining every original generator

For one colour, the Cartan operator on full weight pairs is
\(Q(x_\lambda\otimes y_\mu)=q^{\lambda\cdot\mu}x_\lambda\otimes y_\mu\).
A root changes its weight by \((1,-1)\) or \((-1,1)\), hence
\[
 Q(E\otimes1)Q^{-1}=E\otimes K,\quad
 Q(1\otimes E)Q^{-1}=K\otimes E,
\]
\[
 Q(F\otimes1)Q^{-1}=F\otimes K^{-1},\quad
 Q(1\otimes F)Q^{-1}=K^{-1}\otimes F.                 \tag{6}
\]
Put
\[
 t_k=q^{k(k-1)/2}\delta^k/[k]!,\qquad
 \Theta=\sum_{k\ge0}t_k F^k\otimes E^k.
\]
This is (3), since \(F^k=[k]!F^{(k)}\) and similarly for \(E\).

Repeated commutation gives
\[
 [E,F^k]=\frac{[k]}{\delta}F^{k-1}
 (q^{1-k}K-q^{k-1}K^{-1}),\qquad
 [E^k,F]=\frac{[k]}{\delta}E^{k-1}
 (q^{k-1}K-q^{1-k}K^{-1}).                           \tag{7}
\]
Here is the induction. For the first formula expand
\([E,F^{k+1}]=[E,F^k]F+F^k[E,F]\). Moving the last \(F\) left of
the Cartan factors reduces the two coefficients to
\([k]q^{-k-1}+1=[k+1]q^{-k}\) and
\([k]q^{k+1}+1=[k+1]q^k\). Both follow by adding their finite Laurent
sums. The \(k=1\) case is the defining commutator. For the second formula
expand \([E^{k+1},F]=E[E^k,F]+[E,F]E^k\), move the Cartan factors right
of \(E^k\), and use the same Laurent identities.

Using (6), \(R\Delta E=\Delta^{\rm op}E R\) is equivalent to
\[
 \Theta(E\otimes1+K\otimes E)
 =(E\otimes1+K^{-1}\otimes E)\Theta.                 \tag{8}
\]
By (7), the coefficient in the difference at \(F^{k-1}\otimes E^k\) is
\[
 -t_k\frac{[k]}{\delta}(q^{1-k}K-q^{k-1}K^{-1})
 +t_{k-1}(K-q^{2k-2}K^{-1}),
\]
which vanishes because the explicitly retained coefficients satisfy
\[
 t_k[k]q^{1-k}=\delta t_{k-1}.                        \tag{9}
\]
For \(F\), (6) reduces the intertwining to
\[
 \Theta(F\otimes K^{-1}+1\otimes F)
 =(1\otimes F+F\otimes K)\Theta.                     \tag{10}
\]
At \(F^k\otimes E^{k-1}\), its difference is
\[
 t_k\frac{[k]}{\delta}(q^{k-1}K-q^{1-k}K^{-1})
 +t_{k-1}(K^{-1}-q^{2k-2}K),
\]
again zero by (9). Nilpotence removes all boundary terms. Every term
\(F^k\otimes E^k\) preserves the total Cartan weights, and both full
central degrees are retained. The same argument applies to each colour.
It proves intertwining for all original generators. Taking powers and
dividing over \(K_0\) proves the divided-power identities, which descend
to the integral matrices. After the final flip,
\(c_{X,X}\Delta(u)=\Delta(u)c_{X,X}\), with both degree-thirty central
characters on the tensor square.

## 4. Gaussian identities, tensor integrality and the explicit inverse

If \(UV=q^2VU\), expansion in the order \(U^iV^j\) gives
\[
 (U+V)^n=\sum_{i+j=n}
 q^{-ij}\frac{[n]!}{[i]![j]!}U^iV^j.                 \tag{11}
\]
To prove it, multiply by \(U+V\). Moving the new \(U\) left of \(V^j\)
contributes \(q^{-2j}\), giving the Gaussian Pascal recurrence, with
the initial coefficient one. Equivalently its coefficient is the
Gaussian polynomial \({n\brack i}_{q^{-2}}\); substitution of
\([a]=q^{a-1}(1-q^{-2a})/(1-q^{-2})\) gives the expression in (11).
This proves cancellation of its formal denominators. The identity
\[
 t_{i+j}q^{-ij}\frac{[i+j]!}{[i]![j]!}=t_it_j         \tag{12}
\]
follows by expanding \((i+j)(i+j-1)/2-ij\).

In particular use \(U=F\otimes1\), \(V=K\otimes F\) in (11) and
divide by \([n]!\) over \(K_0\). Each term becomes a power of \(q\)
times \(F^{(i)}K^j\otimes F^{(j)}\). This proves preservation of the
tensor lattice by \(\Delta F^{(n)}\). For \(E\), use
\(U=1\otimes E\), \(V=E\otimes K^{-1}\), which also satisfy
\(UV=q^2VU\); each term after division is a power of \(q\) times a
product of \(E^{(i)},E^{(j)}\) and a Cartan power. Iterate by
coassociativity. These are the promised integral tensor-power actions.

The exact inverse nilpotent factor is
\[
 \Theta^{-1}=\sum_{k\ge0}
 \frac{(-\delta)^k q^{-k(k-1)/2}}{[k]!}F^k\otimes E^k
 =\sum_{k\ge0}(-\delta)^k q^{-k(k-1)/2}[k]!
 F^{(k)}\otimes E^{(k)}.                             \tag{13}
\]
Both factors are polynomials in the same nilpotent \(F\otimes E\).
At degree \(n>0\), their product has coefficient
\[
 \frac{\delta^n q^{n(n-1)/2}}{[n]!}
 \sum_{j=0}^{n}(-1)^j q^{-j(n-1)}
 {n\brack j}_{\rm sym},
 \qquad {n\brack j}_{\rm sym}=\frac{[n]!}{[j]![n-j]!}.
\]
The finite product identity
\[
 \sum_{j=0}^{n}(-1)^j q^{-j(n-1)}{n\brack j}_{\rm sym}
 =\prod_{j=0}^{n-1}(1-q^{-2j})=0                     \tag{14}
\]
follows by expanding the product with Gaussian Pascal's recurrence:
use \({n\brack j}_{q^{-2}}=q^{-j(n-j)}{n\brack j}_{\rm sym}\).
The right side contains \(1-1\). The coefficient at degree zero is one.
This proves both inverse compositions in (13), with integral matrices.
Consequently
\[
 c_{X,X}^{-1}=Q_{X,X}^{-1}(\Theta^W_{X,X})^{-1}
 (\Theta^V_{X,X})^{-1}\tau_{X,X}.                    \tag{15}
\]
No localization or inverse determinant is needed.

## 5. Both hexagons and all braid relations

For one colour, integer weights add, so
\[
 (\Delta\otimes1)Q=Q_{13}Q_{23},\qquad
 (1\otimes\Delta)Q=Q_{13}Q_{12}.                     \tag{16}
\]
In \((\Delta\otimes1)\Theta\) take \(U=F_1\), \(V=K_1F_2\).
They satisfy \(UV=q^2VU\), and (11)–(12) give
\[
 (\Delta\otimes1)\Theta
 =\sum_{i,j\ge0}t_it_j F_1^iK_1^jF_2^j E_3^{i+j}.   \tag{17}
\]
But \(Q_{13}E_3^jQ_{13}^{-1}=K_1^jE_3^j\), so expansion of
\[
 R_{13}R_{23}
 =\Theta_{13}(Q_{13}\Theta_{23}Q_{13}^{-1})Q_{13}Q_{23}
\]
has exactly the nilpotent part (17), in the same factor order. Hence
\[
 (\Delta\otimes1)R=R_{13}R_{23}.                     \tag{18}
\]

For the other identity use the ordered summands \(U=E_3\),
\(V=E_2K_3^{-1}\) of \(\Delta E\). They again satisfy \(UV=q^2VU\).
The same expansion is
\[
 (1\otimes\Delta)\Theta
 =\sum_{i,j\ge0}t_it_j F_1^{i+j}E_2^jE_3^iK_3^{-j}. \tag{19}
\]
Conjugating \(F_1^j\) by \(Q_{13}\) multiplies it by \(K_3^{-j}\).
Thus expansion of
\(R_{13}R_{12}=\Theta_{13}(Q_{13}\Theta_{12}Q_{13}^{-1})Q_{13}Q_{12}\)
is exactly (19), proving
\[
 (1\otimes\Delta)R=R_{13}R_{12}.                     \tag{20}
\]
All sums are finite on each module. The proof also establishes
naturality: a map preserving the full integer weight spaces and
commuting with \(E,F\) commutes term by term with \(Q,\Theta\).

Intertwining on the first two tensor factors applies to each term of
\((\Delta\otimes1)R\), since these terms are coproducts of powers of
the same root generators and functions of the total integer weights.
Using (18),
\[
 R_{12}R_{13}R_{23}
 =R_{12}(\Delta\otimes1)R
 =(\Delta^{\rm op}\otimes1)R\,R_{12}
 =R_{23}R_{13}R_{12}.                               \tag{21}
\]
The full central weight factor obeys the same identity by bilinearity
in (16); it was not omitted. Every \(V\) operator commutes with every
\(W\) operator even on overlapping tensor slots, so regrouping applies
(21) twice and proves it for the full two-colour \(R\). Inserting the
flips converts it into
\[
 (c\otimes1)(1\otimes c)(c\otimes1)
 =(1\otimes c)(c\otimes1)(1\otimes c).                \tag{22}
\]
On \(X_A^{\otimes N}\) put
\(b_i=1^{\otimes(i-1)}\otimes c_{X,X}\otimes
1^{\otimes(N-i-1)}\). Equation (15) proves invertibility, (22) gives
the adjacent braid relations, and disjoint-slot maps commute. These
are every defining relation of \(B_N\), proving its action on the
original integral tensor lattice. Coassociativity and the proved
intertwining show that each \(b_i\) commutes with the full iterated
source action and both degree-\(15N\) central characters.

At \(q=1\), \(Q=1\) and each positive-index term of (3) vanishes
because it contains \(\delta^k\). Therefore \(c|_{q=1}=\tau\).
The entire action specializes to the ordinary permutation action,
factoring through \(S_N\). Over \(\mathbb Q\) the existing
\(\sigma^{\otimes N}\), with inverse \((\sigma^{-1})^{\otimes N}\),
identifies it with tensor permutations on
\(S_{(7,5,3)}(V\otimes W)^{\otimes N}\). This is an actual specialized
map, not a generic identification with ordinary Schur operations.

## 6. Calculated highest-string coefficients

Let \(L_m,L_n\) have divided bases \(e_i,f_j\), with
\(Ke_i=q^{m-2i}e_i\), \(Fe_i=[i+1]e_{i+1}\),
\(Ee_i=[m-i+1]e_{i-1}\), and the analogous formulas for \(f_j\).
Supply their full highest weights as
\(((d+m)/2,(d-m)/2)\), \(((e+n)/2,(e-n)/2)\), respectively.
Thus \(d\equiv m\pmod2\), \(e\equiv n\pmod2\).

The existing, proved normalized highest tensor vector is
\[
 z_{mnr}=\sum_{i=0}^r a_i(m,n,r)e_i\otimes f_{r-i},
 \qquad 0\le r\le\min(m,n),
\]
\[
 a_i(m,n,r)=(-1)^i q^{i(n-2r+i+1)}
 \prod_{j=0}^{i-1}\frac{[n-r+j+1]}{[m-j]}.            \tag{23}
\]
All denominators are units of
\(D=\mathbb Q[q,q^{-1}]_{(q-1)}\). The vectors
\(w_{mnr,s}=\Delta F^{(s)}z_{mnr}\), \(0\le s\le m+n-2r\), give
the already proved full tensor basis, with its explicit inverse.

The map (4) has the following exact matrix on the original tensor bases:
\[
 c_{m,n}^{d,e}(e_i\otimes f_j)=
 \sum_{k=0}^{\min(m-i,j)}
 q^{(de+(m-2i)(n-2j))/2+k(k-1)/2}\delta^k[k]!
 {i+k\brack k}_{\rm sym}{n-j+k\brack k}_{\rm sym}
 f_{j-k}\otimes e_{i+k}.                             \tag{24}
\]
Indeed \(F^{(k)}e_i={i+k\brack k}_{\rm sym}e_{i+k}\) and
\(E^{(k)}f_j={n-j+k\brack k}_{\rm sym}f_{j-k}\), by multiplying
the displayed string coefficients. The Cartan exponent is exactly
the dot product of the full integer weight pairs, so it is integral.
Every Gaussian factor is a Laurent polynomial by (11).

Because the map intertwines, its value on \(z_{mnr}\) is a scalar
\(\beta_{mnr}^{d,e}z_{nmr}\); the relevant highest weight has multiplicity
one in this two-string tensor product by the existing complete
Clebsch–Gordan basis. To calculate the scalar, inspect
\(f_r\otimes e_0\). The second index in (24) is \(i+k\), so only
\(i=k=0\) can contribute. Its coefficient is exactly
\(q^{(de+m(n-2r))/2}\), because \(a_0=1\). The coefficient of that
same output vector in \(z_{nmr}\) is
\[
 a_r(n,m,r)=(-1)^r q^{r(m-r+1)}
 \frac{[m]![n-r]!}{[m-r]![n]!}.
\]
Division gives the fully calculated scalar
\[
 \boxed{\displaystyle
 \beta_{mnr}^{d,e}=(-1)^r
 q^{(de+mn)/2-r(2m-r+1)}
 \frac{[n]![m-r]!}{[n-r]![m]!}.}                     \tag{25}
\]
This derives its asymmetric exponent and quantum-factorial ratio
from the actual normalization. No classical coefficient is substituted.
Commutation with the lowering divided powers proves
\[
 c_{m,n}^{d,e}(w_{mnr,s})=\beta_{mnr}^{d,e}w_{nmr,s}. \tag{26}
\]
For a pure ratio-weight expression one may introduce \(v\) with
\(q=v^2\) and remove the factor \(q^{de/2}\). The full integer-weight
formula (25), which is the one used on the source, needs no such
extension. At \(q=1\), it evaluates to the original
\(\gamma_{mnr}=(-1)^r n!(m-r)!/((n-r)!m!)\).

## 7. All forty-eight actual source strings and comparison with J

Retain exactly the existing map
\[
 \Phi_D:\bigoplus_{a,b=8}^{12}
 L_{(a,15-a)}\otimes L_{(b,15-b)}\otimes H_{ab,D}
 \longrightarrow X_D,\qquad
 e_i\otimes f_j\otimes z\longmapsto F_V^{(i)}F_W^{(j)}z. \tag{27}
\]
The actual simultaneous highest spaces \(H_{ab,D}\) have total dimension
forty-eight; they are extracted by the original projectors and raising
inverse, not by a chosen replacement module. The inverse identities
and both original central degrees are part of the proved source map.

For a pair of summands \((a,b),(c,d)\), put
\(m=2a-15,n=2c-15,p=2b-15,u=2d-15\). Regroup the two colours and
multiplicity spaces, apply (26) in each colour with central degrees
fifteen, flip the multiplicity spaces, then undo the regrouping.
On the \((r,s)\) highest tensor string the coefficient is
\[
 \beta_{mnr}^{15,15}\beta_{pus}^{15,15}
 =(-1)^{r+s}q^{225+(mn+pu)/2-r(2m-r+1)-s(2p-s+1)}
 \frac{[n]![m-r]!}{[n-r]![m]!}
 \frac{[u]![p-s]!}{[u-s]![p]!}.                      \tag{28}
\]
Conjugating by \(\Phi_D\otimes\Phi_D\) gives exactly (4), because
\(\Phi_D\) intertwines every full weight operator and every root power
in that formula. This proves the matrix correspondence in both
directions and includes all forty-eight strings. It does not assume
that the localized map \(\Phi_D\) extends to an isomorphism over \(A\).

The old \(J_X\) has coefficient \(\gamma_{mnr}\gamma_{pus}\) on the
same string basis. Define the diagonal string operator \(S\) by the
quotient of (28) by that nonzero classical coefficient. Then
\[
 c_{X,X}=J_XS\quad\hbox{over }D.                     \tag{29}
\]
The entire scalar of \(S\) is specified by (28), including the
quantum-factorial ratios. It specializes to one but is generically
nontrivial. Thus the coherence repair changes the old calculated
string scalars; it does not reinterpret \(J\)'s already proved defect.

Two successive one-colour braids have scalar
\[
 \beta_{mnr}^{d,e}\beta_{nmr}^{e,d}
 =q^{de+mn-2r(m+n-r+1)}.                             \tag{30}
\]
The signs and factorial ratios cancel explicitly. For
\(h=m+n-2r\), expanding \(h(h+2)\) rewrites its exponent as
\(de+\{h(h+2)-m(m+2)-n(n+2)\}/2\).
This Casimir expression is derived from (25), not assumed in its place.
The full source monodromy exponent is
\[
 450+mn+pu-2r(m+n-r+1)-2s(p+u-s+1).                 \tag{31}
\]
The braid is therefore generally not an involution.

For later sign projectors one can divide (25) by the pure \(q\)-power
square root of (30). Its exponent is even because \(de+mn\) is even.
The resulting coefficient is
\[
 \overline\beta_{mnr}=(-1)^r q^{r(n-m)}
 \frac{[n]![m-r]!}{[n-r]![m]!}.                      \tag{32}
\]
Use the product of (32) for the two colours and the multiplicity flip.
The reversed coefficients multiply to one, so this defines an
equivariant sign commutor with square one over \(D\), specializing to
the flip. Its projectors are \((1\pm\overline c)/2\).
For \(m\ne n\), (32) generally differs from the prior \(\gamma\).
This is the precise comparison, not an implicit identification.
On identical fundamental strings it agrees with the old \(J\);
there the earlier braid defect persists. No braid identity is
claimed for this sign commutor.

## 8. The previous Hecke sector and a quadratic obstruction

The actual \(g_{8,8}=1\) source summand has full highest weights
\((8,7)\) in each colour and ratio weights one. In one colour,
(25) gives eigenvalues \(q^{113},-q^{111}\), hence the checked
matrix is \(q^{112}B\), where \(B\) is precisely (5).
For both colours the full checked map is \(q^{224}B_VB_W\) after
the specified regrouping.

On the slice with a \(W\) highest vector in each tensor position,
\(B_W\) acts by \(q\). Therefore the full source braid restricts to
\[
 c_{X,X}=q^{225}B_V.                                \tag{33}
\]
Removing exactly this displayed scalar gives the old sector repair.
It is now the restriction of a proved full braid. The normalization
on tensor blocks \(X^{\otimes r},X^{\otimes s}\) is \(q^{-225rs}\).
Its bilinearity verifies both hexagons, so the normalization is
coherent and changes no central action or degree.

On the entire tensor square of this four-dimensional source summand,
the three eigenvalues are
\[
 q^{226},\qquad -q^{224},\qquad q^{222},              \tag{34}
\]
with multiplicities \(9,6,1\). The two top strings have dimension
\(3\cdot3\), the mixed pairs have total dimension \(3\cdot1+1\cdot3\),
and the two trivial strings have dimension one. All are nonzero and
the three scalars are distinct over \(K_0\). Thus the minimal polynomial
on this actual sixteen-dimensional source submodule is exactly
\[
 (Z-q^{226})(Z+q^{224})(Z-q^{222}).                  \tag{35}
\]
No quadratic Hecke relation can therefore hold on the entire
\(X\otimes X\) braid. This proves a precise obstruction to treating
the full braid as a Hecke action, while retaining its genuine
higher-degree braid action. Computing the full minimal polynomial
from all forty-eight strings and swapped blocks is the next bounded
spectral calculation; it is not needed for the completed coherence
proof or the present quadratic obstruction.

There is a second exact three-eigenvalue witness using the original
retained vector \(T\). Its simultaneous highest weights \((12,3;9,6)\)
give the actual generated submodule with ratio labels \(L_9\otimes L_3\)
and both central degrees fifteen. The source string theorem proves this
submodule and its injection; (4) preserves its tensor square because it
uses only its own original generators and weights. For \(0\le r\le9\),
\(0\le s\le3\), the identical-pair formula (28) has scalar
\[
 (-1)^{r+s}q^{270-r(19-r)-s(7-s)}.
\]
The factorial ratios cancel only because each colour's two labels here
are identical. The choices \((r,s)=(0,0),(0,1),(0,2)\) give
\(q^{270},-q^{264},q^{260}\), respectively, on nonzero highest strings.
A scalar polynomial of degree at most two cannot vanish at these three
distinct elements of \(K_0\) unless it is the zero polynomial: division
by each monic linear factor successively proves that their product
would have to divide it. Thus a nonzero scalar rescaling of the full
braid cannot create a quadratic Hecke relation either. This independent
witness keeps the exact source vector carrying the retained coefficient.

## 9. The original coefficient in a composed full-source matrix entry

Use the unchanged source vectors \(T=b_{126}\), \(Q=b_{144}\), and
\[
 C(q)=(F_V^{(2)})_{144,126}
 =q^{10}-q^4-q^{-4}+q^{-10}.
\]
The full source calculation proves that \(T\) is highest in both
colours with weights \((12,3;9,6)\). Let \(y=F_V^{(2)}T\), of weights
\((10,5;9,6)\). The \(W\) raising operators kill \(y\), since the
two colours commute. Equation (2) on this input is
\[
 q^{12\cdot10+3\cdot5+9\cdot9+6\cdot6}=q^{252}.
\]
To produce \(Q\otimes T\) before the flip, only the \(V\) term \(k=2\)
in (3) can contribute: \(k=0,1\) has the wrong first weight, and
\(k>2\) kills the second factor. Only \(k_W=0\) contributes.
The actual highest string gives
\(E_V^{(2)}F_V^{(2)}T={9\brack2}_{\rm sym}T\).
Hence the coefficient of \(T\otimes Q\) in the full source vector
\(c_{X,X}(T\otimes F_V^{(2)}T)\) is
\[
 \boxed{q^{253}\delta^2[2]!{9\brack2}_{\rm sym}C(q).} \tag{36}
\]
The second input factor is the specified source vector, not a
single honest basis vector. Its complete expansion is the already
computed original divided-square column.
Equivalently, with \(\pi_T,\pi_Q\) the original coordinate projections,
the scalar in (36) is
\[
 (\pi_T\otimes\pi_Q)c_{X,X}(1\otimes F_V^{(2)})(T\otimes T).
\]
Thus it is an original-basis matrix entry of the explicitly composed
operator \(c_{X,X}\circ(1\otimes F_V^{(2)})\), not an original-basis
matrix entry of \(c_{X,X}\) alone.

The parent independently read the current full-generator matrices:
the coefficient of \(Q\) in \(F_V^2T\) is
\[
 q^{11}+q^9-q^5-q^3-q^{-3}-q^{-5}+q^{-9}+q^{-11}.
\]
Division by the retained \([2]=q+q^{-1}\) gives exactly \(C(q)\).
The parent also verified both stated weight pairs directly from
the original indices 126 and 144. Thus (36) uses the full source
path calculation, not merely the four-vector quotient.

Retain all factors in (36); the additional identity
\([2]!{9\brack2}_{\rm sym}=[9][8]\) gives its orders conveniently.
At \(q=1\) the order is four, with leading coefficient
\(4\cdot2\cdot36\cdot84=24192\).
In characteristic three, the finite Frobenius identity gives
\([9]=\delta^8\) while \([8](1)=2\), and \(C\) has order four and
leading coefficient one. Thus (36) has order fourteen and lead two.
In characteristic seven, \([9](1)=2,[8](1)=1\), and \(C\) has
order eight and lead five. Its resulting order is ten and lead
\(4\cdot2\cdot1\cdot5=5\) modulo seven. These are orders in the
specified residue-field Laurent rings at \(q=1\), not vertical
prime valuations.

The exact original path phase can also be retained. Set
\(q=e^{i\theta}\), \(0<\theta<\pi/9\), and
\(\tau=2\sin^2\theta\). Then \(\delta^2=-2\tau\). Write the retained
coefficient as \(C(q)=\tau B(\tau)\), using the direct substitution
\(\delta^2=-2\tau\) in \(C=\delta^2[7][3]\).
The exact retained identities are \([3]=3+\delta^2=3-2\tau\) and
\([7]=7+14\delta^2+7\delta^4+\delta^6
=7-28\tau+28\tau^2-8\tau^3\).
The latter follows by writing \(x=q^2+q^{-2}=\delta^2+2\) and expanding
\([7]=x^3+x^2-2x-1\). Consequently the actual polynomial is
\[
 B(\tau)=-2(7-28\tau+28\tau^2-8\tau^3)(3-2\tau),
 \qquad B(0)=-42.                                   \tag{38}
\]
The phase-retaining entry (36) is exactly
\[
 A_\tau=-2\tau^2 e^{253i\theta}[9]_{e^{i\theta}}
 [8]_{e^{i\theta}}B(\tau).                           \tag{39}
\]
For \(0<\theta<\pi/9\), the finite identity
\([j]_{e^{i\theta}}=\sin(j\theta)/\sin\theta\) makes
\([3],[7],[8],[9]\) strictly positive, so \(B=-2[7][3]<0\).
Thus the explicitly phase-adjusted entry \(q^{-253}A_\tau\) is
positive. The original entry retains the full complex phase
\(e^{253i\theta}\). Its limit is
\[
 \lim_{\tau\downarrow0}A_\tau/\tau^2
 =-2\cdot9\cdot8\cdot(-42)=6048.                     \tag{40}
\]
The phase tends to one; no phase was silently removed. This is a
precise cancellation of the scalar negative \(C\) by the additional
negative \(\delta^2\) in an actual braided source entry. It is not
an eigenvalue or Hermitian-sign assertion.

The braid does not automatically descend to the old negative-Borel
interval: it contains raising operators, whereas that interval
admits no full raising action by the established trace obstruction.
Equation (36) is instead the exact full-source bridge.

## 10. Exact coordinate map and the nonstandard programme

The operators (4) are the standard
\(U_q(\mathfrak{gl}_2)\otimes U_q(\mathfrak{gl}_2)\) braiding on the
actual original source module. The restriction of action is explicit:
the source has the given standard subgroup generators, and (4) is
a polynomial expression in their full matrices and integer weights.
No larger nonstandard coaction or canonical basis is inferred.

A concrete coordinate map remains available. Over \(D\), take
\(P^+=(1+\overline c)/2\) from the calculated sign commutor (32).
Let \(t=(t^i_j)\) be the standard quantum-subgroup matrix coefficients
on \(X_D\). Concretely \(t^i_j(u)\) is the \((i,j)\) entry of the
original representation matrix of \(u\). These functions lie in the
finite dual over \(K_0\); take the \(D\)-algebra they generate there,
with multiplication induced by the original coproduct. Matrix
multiplication gives
\(t^i_j(uv)=\sum_k t^i_k(u)t^k_j(v)\), so their coproduct is the finite
sum \(\sum_k t^i_k\otimes t^k_j\), which retains this \(D\)-algebra.
Its counit is evaluation at the identity element. This specifies the
coefficient bialgebra used here. Since \(\overline c\) intertwines,
its coordinate equation is
\[
 P^+(t\otimes t)=(t\otimes t)P^+.                    \tag{41}
\]
The free matrix algebra on \(u^i_j\) therefore maps by
\(u^i_j\mapsto t^i_j\) to the original matrix-coefficient algebra,
and (41) proves that the ideal generated by the entries of
\(P^+(u\otimes u)-(u\otimes u)P^+\) lies in its kernel.
The quotient map is onto the algebra generated by these matrix
coefficients, by its specified images.

The relation ideal is a biideal for matrix comultiplication
\(\Delta u^i_j=\sum_k u^i_k\otimes u^k_j\). Indeed two matrix tensors
\(U\otimes U\), \(V\otimes V\) satisfying the relation have a product
also commuting with \(P^+\); their coefficient-algebra factors commute
in the tensor product. This is exactly preservation under matrix
comultiplication. The identity counit matrix commutes as well.
Thus the quotient and the indicated map are bialgebra objects/maps.

This is the precise sign-projector matrix construction in the existing
GCT-VII bridge, now supplied with the actual full-source standard
braiding and its calculated sign commutor. The source \(X\) here is
reducible as a standard-subgroup representation, so this quotient
construction is proved for that actual object; it does not import
additional source theorems whose hypotheses require an irreducible
plethysm input. Nor does the construction prove that this new
sign-projector bialgebra is the original nonstandard GCT-IV algebra
acting on the same underlying vector space.

The full braiding supplies a coherent integral tensor construction
and the coordinate map (41). It does not prove canonical-basis
positivity, a finite-field Frobenius model, reciprocity, effectivity,
an asymptotic class-variety obstruction or a complexity separation.
Those remain the continuing goal's mathematical tasks.

## 11. Verification and continuation

The independent Markdown-only formula audit is in FORMULA_AUDIT.md.
It independently derives
\(R^-=Q^{-1}\sum_{k\ge0}(-\delta)^kq^{-k(k-1)/2}
 E^k\otimes F^k/[k]!\),
proves both generator recurrences and both hexagons, and obtains (4)
as its opposite inverse. It independently calculates the highest
scalar (25); the extremal-coordinate calculation above is a second
direct derivation. The parent independently checked the fundamental
matrix, the full original retained coefficient, its weight exponent,
and the stated characteristic-zero/three/seven jets.

The completed independent audit proves both orientations, both hexagons,
integral divided-power tensor closure, and the full original-basis
two-colour sum. Its frozen file FORMULA_AUDIT.md has SHA-256
9fbdff4099157cec50cd349eace620e19c01fa933b015e584059c0c5075115ea.
The exact checks comprise 2,205 intertwiner/inverse columns, 2,000 typed
braid columns, and 6,111 further highest-scalar and formula checks,
for 10,316 checks in total. They were run inline; no Python or TeX file
was authored. The parent separately reviewed the hexagon coefficient
orders and the integral divided-power coproducts without finding an
error. The independent source-generator check is recorded in Section 9.

The parent further expanded the complete scalar (36) as an ordinary
polynomial in q: its nonzero exponents range from 226 to 280, with
eight positive and eight negative nonzero coefficients. Its independent
binomial expansion at q=1 confirmed all three orders and leading
coefficients stated in Section 9. These source/jet review results are
durable in ROOT_REVIEW.md. The mixed signs of this polynomial have
not been replaced by its sign on a particular parameter path.

No fresh whole-repository replay or updated reader is claimed here.
After the checkpoint freeze is released, convert the proof to cumulative
TeX, add exact representative higher-string and retained-entry checks,
and inspect the rendered pages. The next spectral task is the full
minimal polynomial from all forty-eight strings and swapped blocks;
the already proved three-eigenvalue submodule rules out a quadratic
Hecke relation without needing that larger calculation.
