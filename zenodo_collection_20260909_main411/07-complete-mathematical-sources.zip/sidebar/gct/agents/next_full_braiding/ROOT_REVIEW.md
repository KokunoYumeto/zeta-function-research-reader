# Root independent review — next full braiding

A preliminary hand review incorrectly reversed F tensor E and E tensor F and flagged the candidate orientation. The explicit symbolic matrix calculation corrected that review concern; it was not a mathematical flaw in the candidate.

In basis00,01,10,11 with E e1=e0,F e0=e1,K=diag(q,q^-1), Q=diag(q,1,1,q), the actual candidate c=tau (I+(q-q^-1)F tensor E)Q is

```
[q,0,0,0]
[0,q-q^-1,1,0]
[0,1,0,0]
[0,0,0,q]
```

Direct symbolic multiplication gives c Delta(F)-Delta(F)c=0 for Delta(F)=F tensor1+K tensorF. This agrees with the previously proved sector Hecke map. General highest weights, full integral source, and hexagon proof are under the separate bounded audit; the fundamental calculation alone does not certify them.


## Direct full-source retained-entry check

Read full_generators.json and basis_1260.json directly. The original T index126 has V weight(12,3), W weight(9,6), and Q index144 has V weight(10,5), W weight(9,6). The full FV² coefficient at Q is q^11+q^9−q^5−q^3−q^-3−q^-5+q^-9+q^-11. Direct symbolic division by[2]=q+q^-1 gives C(q) exactly. This retains every intermediate FV component and confirms the divided-power endpoint assignment and fullweight dot252.


## Three actual source eigenvalues and the quadratic obstruction

Work over Q(q), retaining both degree15 central characters. The actual T has highest differences9 and3. Its cyclic submodule Y has the40 independent vectors F_V^(i)F_W^(j)T, 0<=i<=9,0<=j<=3: they have distinct full weight pairs, and applying E_V^(i)E_W^(j) returns the nonzero scalar [9 choose i][3 choose j]T. The earlier complete source string proof supplies stability and the zero endpoint actions, so this is the actual embedded L9 tensor L3 submodule, with its original central characters.

The displayed candidate full braid operator restricts to Y tensor Y because each of its divided-power operators and its full-weight diagonal preserve this subspace. Apply the independently proved equal-factor scalar formula to each colour. The two central factors together contribute q^225. For rV=0..9 and rW=0..3 the corresponding highest-vector eigenvalue is

lambda(rV,rW)=(-1)^(rV+rW) q^(270-rV(19-rV)-rW(7-rW)).

The three nonzero vectors with rV=0 and rW=0,1,2 therefore have eigenvalues q^270,-q^264,q^260. They are distinct in Q(q): their pairwise differences are respectively q^264(q^6+1), q^260(q^10-1), and -q^260(q^4+1), all nonzero Laurent polynomials.

If a scalar polynomial p in Q(q)[x] annihilated the full operator, applying it to these vectors would give p(q^270)=p(-q^264)=p(q^260)=0. Successive division by the three distinct linear factors proves that a nonzero such p has degree at least3. In particular the full operator cannot obey a scalar quadratic Hecke relation. Multiplication of the operator by a nonzero scalar function preserves distinctness, so cannot repair this quadratic obstruction. At q=1 two of the displayed eigenvalues coincide; that specialization does not contradict the generic calculation.

This argument uses the completed pairwise intertwiner/scalar calculation. Coherence of the candidate across all tensor powers remains in the separate full proof audit until its hexagons have been completely written and checked. It does not identify a scalar quadratic Hecke algebra with a more general braid centralizer or supply a canonical nonstandard GCT basis.


## Independent exact retained-entry jets

An inline symbolic expansion of the full unchanged Laurent product yielded:

```json
{
  "original_entry": "q^253(q-q^-1)^2[9]_q[8]_q C(q)",
  "minimum_q_exponent": 226,
  "maximum_q_exponent": 280,
  "positive_laurent_coefficients": 8,
  "negative_laurent_coefficients": 8,
  "ordinary_q_minus_one_order": 4,
  "ordinary_lead": 24192,
  "residual_orders": {
    "3": 14,
    "7": 10
  },
  "residual_leads": {
    "3": 2,
    "7": 5
  }
}
```

The full binomial expansion at q=1 was reduced coefficient by coefficient in characteristics3 and7. This verifies the displayed orders and leads, without rescaling the original source map. A first receipt-formatting attempt used SymPy Boolean values in a Python sum; converting the comparisons to ordinary booleans repaired the receipt code without changing the calculated polynomial.
