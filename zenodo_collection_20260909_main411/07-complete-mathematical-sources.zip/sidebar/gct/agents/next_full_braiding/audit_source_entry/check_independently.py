"""Independent dense-Laurent/source-path audit; no author imports or shelf reads."""
from fractions import Fraction
from pathlib import Path
from collections import Counter
import hashlib
import json

HERE = Path(__file__).resolve().parent
BRAID = HERE.parent
SOURCE = BRAID.parent / 'full_source_generators'
PINNED = {
    'full_generators.json': 'e26086722e2910dc9ffff7d57314a25e80b79bb00bfb1808a42bf97761377253',
    'source_basis/basis_1260.json': '77233bf1fb129fd3dd7077987f1ae2ea62619aaff1ff178432a342fa2f15b767',
}
COUNTS = Counter()


def require(category, condition):
    if not condition:
        raise AssertionError(category)
    COUNTS[category] += 1


class Laurent:
    """Dense coefficients with an exponent offset, normalized only internally."""
    def __init__(self, coefficients=(), offset=0):
        c = list(coefficients)
        while c and not c[-1]:
            c.pop()
        while c and not c[0]:
            c.pop(0)
            offset += 1
        self.c, self.lo = tuple(c), offset if c else 0

    def __bool__(self):
        return bool(self.c)

    def __eq__(self, other):
        return self.c == other.c and self.lo == other.lo

    def __add__(self, other):
        if not self:
            return other
        if not other:
            return self
        lo = min(self.lo, other.lo)
        c = [0] * (max(self.lo + len(self.c), other.lo + len(other.c)) - lo)
        for p in (self, other):
            for i, value in enumerate(p.c):
                c[i + p.lo - lo] += value
        return Laurent(c, lo)

    def __mul__(self, other):
        if not self or not other:
            return ZERO
        c = [0] * (len(self.c) + len(other.c) - 1)
        for i, x in enumerate(self.c):
            for j, y in enumerate(other.c):
                c[i+j] += x*y
        return Laurent(c, self.lo + other.lo)

    def exact_divide(self, other):
        if not other:
            raise ZeroDivisionError
        if not self:
            return ZERO
        r = list(self.c)
        quotient = [0] * max(0, len(r) - len(other.c) + 1)
        while r and len(r) >= len(other.c):
            degree = len(r) - len(other.c)
            value = Fraction(r[-1], other.c[-1])
            quotient[degree] = value
            for j, coefficient in enumerate(other.c):
                r[degree+j] -= value * coefficient
            while r and not r[-1]:
                r.pop()
        if r:
            raise ArithmeticError('Nonzero Laurent-division remainder')
        return Laurent(quotient, self.lo - other.lo)

    def serial(self):
        if any(Fraction(c).denominator != 1 for c in self.c):
            raise ArithmeticError('Nonintegral output coefficient')
        return [[i+self.lo, int(c)] for i, c in enumerate(self.c) if c]


ZERO, ONE = Laurent(), Laurent([1])


def monomial(exponent, coefficient=1):
    return Laurent([coefficient], exponent)


def from_pairs(pairs):
    p = ZERO
    for exponent, coefficient in pairs:
        p = p + monomial(exponent, coefficient)
    return p


def qinteger(n):
    return Laurent([1 if k % 2 == 0 else 0 for k in range(2*n-1)], 1-n)


def apply(matrix, vector):
    result = {}
    for i, scalar in vector.items():
        for j, coefficient in matrix[i]:
            result[j] = result.get(j, ZERO) + coefficient * scalar
    return {j: c for j, c in result.items() if c}


def divide_vector(vector, polynomial):
    return {i: c.exact_divide(polynomial) for i, c in vector.items()}


def root_order(poly, prime=None):
    """Repeated synthetic division at 1; q^lo is a unit with value one."""
    c = [int(v) for v in poly.c]
    if prime:
        c = [v % prime for v in c]
    order = 0
    while c:
        residue = sum(c)
        if prime:
            residue %= prime
        if residue:
            return order, residue
        if len(c) == 1:
            break
        quotient = [0] * (len(c)-1)
        quotient[-1] = c[-1]
        for i in range(len(c)-2, 0, -1):
            quotient[i-1] = c[i] + quotient[i]
        c = [x % prime for x in quotient] if prime else quotient
        while c and not c[-1]:
            c.pop()
        order += 1
    raise ArithmeticError('Zero polynomial has no finite root order')


def main():
    data = {}
    for relative, expected_hash in PINNED.items():
        blob = (SOURCE / relative).read_bytes()
        require('frozen_input_hash', hashlib.sha256(blob).hexdigest() == expected_hash)
        data[relative] = json.loads(blob)
    basis = data['source_basis/basis_1260.json']['basis']
    raw = data['full_generators.json']['matrices']
    matrices = {name: [[(j, from_pairs(c)) for j, c in col] for col in mat]
                for name, mat in raw.items()}
    require('original_dimension', len(basis) == 1260)
    T, Q = 126, 144
    require('original_T_label', basis[T]['columns'] == ['123','123','124','12','12','1','1'])
    require('original_Q_label', basis[Q]['columns'] == ['123','123','124','12','13','4','1'])
    require('original_T_scaling', (basis[T]['sign'], basis[T]['p_power']) == (1, 0))
    require('original_Q_scaling', (basis[Q]['sign'], basis[Q]['p_power']) == (-1, -1))
    wt = lambda i: basis[i]['weight_V'] + basis[i]['weight_W']
    require('T_weight', wt(T) == [12,3,9,6])
    require('Q_weight', wt(Q) == [10,5,9,6])
    require('full_weight_dot', sum(x*y for x,y in zip(wt(T),wt(Q))) == 252)
    t = {T: ONE}
    f1 = apply(matrices['FV'], t)
    f2 = apply(matrices['FV'], f1)
    paths = []
    for i in f1:
        coefficient = dict(matrices['FV'][i]).get(Q, ZERO)
        if coefficient:
            paths.append((i, f1[i]*coefficient))
    require('complete_two_step_paths', [i for i,c in paths] == [8,146])
    combined = ZERO
    for i, c in paths:
        combined = combined + c
    require('path_sum_equals_full_action', combined == f2[Q])
    square = from_pairs([(11,1),(9,1),(5,-1),(3,-1),(-3,-1),(-5,-1),(-9,1),(-11,1)])
    require('original_square', f2[Q] == square)
    y = divide_vector(f2, qinteger(2))
    require('full_y_support', len(y) == 8)
    C = from_pairs([(10,1),(4,-1),(-4,-1),(-10,1)])
    require('retained_C_from_full_original_paths', y[Q] == C)
    for name in ('EV','EW'):
        require('T_highest', not apply(matrices[name], t))
    require('actual_W_raising_cancellation', not apply(matrices['EW'], y))
    e2y = apply(matrices['EV'], apply(matrices['EV'], y))
    require('actual_raised_square', e2y == {T: qinteger(9)*qinteger(8)})
    require('actual_third_raise_zero', not apply(matrices['EV'], e2y))

    # Ordinary powers, divided by a single [k]!, are independent of the
    # author's recursive tensor divided-power implementation. W terms vanish.
    first, second, factorial, delta_power = t, y, ONE, ONE
    delta = from_pairs([(1,1),(-1,-1)])
    out = {}
    contributing_powers = []
    for k in range(4):
        if not second:
            require('braid_termination_at_three', k == 3)
            break
        contributing_powers.append(k)
        multiplier = monomial(252+k*(k-1)//2)*delta_power
        for i, a in first.items():
            for j, b in second.items():
                coefficient = (multiplier*a*b).exact_divide(factorial)
                out[j,i] = out.get((j,i), ZERO) + coefficient
        first = apply(matrices['FV'], first)
        second = apply(matrices['EV'], second)
        factorial = factorial*qinteger(k+1)
        delta_power = delta_power*delta
    out = {pair:c for pair,c in out.items() if c}
    require('ordinary_power_braid_terms', contributing_powers == [0,1,2])
    require('complete_braid_column_support', len(out) == 32)
    for c in out.values():
        require('integral_braid_output_coordinate', all(Fraction(x).denominator == 1 for x in c.c))
    entry = out[T,Q]
    expected = monomial(253)*delta*delta*qinteger(9)*qinteger(8)*C
    require('composed_entry_from_full_contractions', entry == expected)
    require('entry_exponent_interval', (entry.lo,entry.lo+len(entry.c)-1) == (226,280))
    require('entry_signed_coefficient_counts', (sum(x>0 for x in entry.c),sum(x<0 for x in entry.c)) == (8,8))
    q1 = {pair: sum(c.c) for pair,c in out.items() if sum(c.c)}
    q1_flip = {(j,T): sum(c.c) for j,c in y.items() if sum(c.c)}
    require('complete_column_q1_flip', q1 == q1_flip)
    orders = {}
    for prime, c_expected, a_expected in [(None,(2,84),(4,24192)),(3,(4,1),(14,2)),(7,(8,5),(10,5))]:
        c_result, a_result = root_order(C,prime), root_order(entry,prime)
        require('synthetic_division_C_order_and_lead', c_result == c_expected)
        require('synthetic_division_entry_order_and_lead', a_result == a_expected)
        orders[str(prime or 0)] = {'C': c_result,'composed_entry': a_result}
    tau = monomial(0,Fraction(-1,2))*delta*delta
    B = monomial(0,-2)*qinteger(7)*qinteger(3)
    require('retained_phase_polynomial', C == tau*B)
    require('original_phase_entry', entry == monomial(253,-2)*tau*tau*qinteger(9)*qinteger(8)*B)
    require('phase_B_at_zero', sum(B.c) == -42)
    require('unadjusted_limit', sum(entry.exact_divide(tau*tau).c) == 6048)
    for n in (3,7,8,9):
        require('circle_identity_without_approximation', delta*qinteger(n) == from_pairs([(n,1),(-n,-1)]))
    reviewed = ['check_full_source_entry.py','RESEARCH.md','ROOT_REVIEW.md']
    hashes = {name:hashlib.sha256((BRAID/name).read_bytes()).hexdigest() for name in reviewed}
    hashes['audit_source_entry/check_independently.py'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return {'status':'pass','checks':sum(COUNTS.values()),'categories':dict(COUNTS),
            'input_hashes':PINNED,'reviewed_hashes':hashes,
            'source_paths':[{'via':i,'polynomial':c.serial()} for i,c in paths],
            'full_source_divided_square_support':len(y),'full_braided_column_support':len(out),
            'full_source_divided_square':{str(i):c.serial() for i,c in y.items()},
            'composed_entry':entry.serial(),'synthetic_division_orders':orders,
            'scope':'Independent exact full original source paths, ordinary-power composed braid column, integrality, q=1 flip, prime root orders and phase identity. Does not certify all tensor columns, global intertwining or hexagons.',
            'findings':[]}


if __name__ == '__main__':
    try:
        result = main()
    except Exception as exc:
        (HERE/'independent_verification.json').write_text(json.dumps({'status':'fail','error':repr(exc)},indent=2)+'\n',encoding='utf-8')
        raise
    (HERE/'independent_verification.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ['status','checks','categories']}))
