#!/usr/bin/env python3
"""Portable finite exact checks for the two audited braiding orientations.

Run with Python 3.10+ and no third-party packages.  The report is written beside
this file as braid_verification.json.  No source-module data are read.

All checked equalities use Fraction or integer Laurent polynomials.  In
particular each hexagon constructs its compound module from the literal
coproduct generators and computes powers there; its left side is not assembled
from the two pair operators appearing on its right side.

This executable checks the documented finite ranges.  The Markdown proofs,
not this finite sample, establish the unrestricted identities.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from hashlib import sha256
from itertools import product
import json
from pathlib import Path
import time
import traceback


F = Fraction
Vector = dict[int, F]
Columns = tuple[Vector, ...]
Laurent = dict[int, int]
COUNTS: Counter[str] = Counter()


def equal(category: str, actual, expected, context) -> None:
    """Count exactly one executed equality, and fail immediately on mismatch."""
    if actual != expected:
        raise AssertionError(
            f"{category}: {context!r}\nactual={actual!r}\nexpected={expected!r}"
        )
    COUNTS[category] += 1


def add(target: dict, index, coefficient) -> None:
    if coefficient:
        target[index] = target.get(index, 0) + coefficient
        if not target[index]:
            del target[index]


def scale(vector: dict, coefficient) -> dict:
    return {i: coefficient * a for i, a in vector.items() if coefficient * a}


def apply(columns: Columns, vector: Vector) -> Vector:
    result: Vector = {}
    for j, a in vector.items():
        for i, b in columns[j].items():
            add(result, i, a * b)
    return result


@dataclass
class Module:
    key: tuple
    # Each entry is the actual full gl2 weight pair, not its ratio alone.
    weights: tuple[tuple[int, int], ...]
    E: Columns
    F: Columns
    height: int

    @property
    def dim(self) -> int:
        return len(self.weights)

    def ratio(self, index: int) -> int:
        a, b = self.weights[index]
        return a - b


class Context:
    def __init__(self, v: int):
        self.v = F(v)
        self.q = self.v**2
        self.delta = self.q - 1 / self.q
        self.modules: dict[tuple, Module] = {}
        self.power_cache: dict[tuple, Columns] = {}
        self.r_cache: dict[tuple, Columns] = {}
        self.c_cache: dict[tuple, Columns] = {}

    @lru_cache(None)
    def qi(self, n: int) -> F:
        if self.q == 1:
            return F(n)
        return (self.q**n - self.q**(-n)) / self.delta

    @lru_cache(None)
    def factorial(self, n: int) -> F:
        result = F(1)
        for j in range(1, n + 1):
            result *= self.qi(j)
        return result

    def irrep(self, m: int, degree: int | None = None) -> Module:
        if degree is None:
            degree = m
        if m < 0 or (degree - m) % 2:
            raise ValueError("The highest weight and central degree must match.")
        key = ("irrep", m, degree)
        if key not in self.modules:
            E, FF, weights = [], [], []
            for i in range(m + 1):
                alpha = m - 2 * i
                weights.append(((degree + alpha) // 2, (degree - alpha) // 2))
                E.append({i - 1: self.qi(m - i + 1)} if i else {})
                FF.append({i + 1: self.qi(i + 1)} if i < m else {})
            self.modules[key] = Module(key, tuple(weights), tuple(E), tuple(FF), m)
        return self.modules[key]

    def tensor(self, left: Module, right: Module) -> Module:
        key = ("tensor", left.key, right.key)
        if key not in self.modules:
            E, FF, weights = [], [], []
            for i, lam in enumerate(left.weights):
                for j, mu in enumerate(right.weights):
                    weights.append((lam[0] + mu[0], lam[1] + mu[1]))
                    ec, fc = {}, {}
                    # Literal Delta E = E x K^-1 + 1 x E.
                    for ii, value in left.E[i].items():
                        add(ec, ii * right.dim + j, value * self.q**(-right.ratio(j)))
                    for jj, value in right.E[j].items():
                        add(ec, i * right.dim + jj, value)
                    # Literal Delta F = F x 1 + K x F.
                    for ii, value in left.F[i].items():
                        add(fc, ii * right.dim + j, value)
                    for jj, value in right.F[j].items():
                        add(fc, i * right.dim + jj, value * self.q**left.ratio(i))
                    E.append(ec)
                    FF.append(fc)
            self.modules[key] = Module(
                key, tuple(weights), tuple(E), tuple(FF), left.height + right.height
            )
        return self.modules[key]

    def powers(self, module: Module, generator: str, k: int) -> Columns:
        key = (module.key, generator, k)
        if key not in self.power_cache:
            if k == 0:
                answer = tuple({i: F(1)} for i in range(module.dim))
            else:
                previous = self.powers(module, generator, k - 1)
                action = getattr(module, generator)
                answer = tuple(apply(action, column) for column in previous)
            self.power_cache[key] = answer
        return self.power_cache[key]

    def cartan(
        self, left: Module, right: Module, i: int, j: int, kind: str, sign: int
    ) -> F:
        if kind == "gl2":
            lam, mu = left.weights[i], right.weights[j]
            return self.q ** (sign * (lam[0] * mu[0] + lam[1] * mu[1]))
        if kind == "sl2":
            # q=v^2, so q^(alpha*beta/2)=v^(alpha*beta) exactly.
            return self.v ** (sign * left.ratio(i) * right.ratio(j))
        raise ValueError(kind)

    def R(
        self, left: Module, right: Module, positive: bool, kind: str = "gl2"
    ) -> Columns:
        key = (left.key, right.key, positive, kind)
        if key not in self.r_cache:
            answer = [dict() for _ in range(left.dim * right.dim)]
            for k in range(min(left.height, right.height) + 1):
                if positive:
                    coefficient = (
                        self.delta**k * self.q ** (k * (k - 1) // 2)
                        / self.factorial(k)
                    )
                    lop, rop = "F", "E"
                else:
                    coefficient = (
                        (-self.delta)**k * self.q ** (-k * (k - 1) // 2)
                        / self.factorial(k)
                    )
                    lop, rop = "E", "F"
                if not coefficient:
                    continue
                lp, rp = self.powers(left, lop, k), self.powers(right, rop, k)
                for i in range(left.dim):
                    for j in range(right.dim):
                        column = answer[i * right.dim + j]
                        for ii, a in lp[i].items():
                            for jj, b in rp[j].items():
                                # Positive Q is on the RIGHT (input weight).
                                # Negative Q^-1 is on the LEFT (output weight).
                                cartan = self.cartan(
                                    left, right, i if positive else ii,
                                    j if positive else jj, kind,
                                    1 if positive else -1
                                )
                                add(column, ii * right.dim + jj, coefficient*a*b*cartan)
            self.r_cache[key] = tuple(answer)
        return self.r_cache[key]

    def checked(
        self, left: Module, right: Module, positive: bool, kind: str = "gl2"
    ) -> Columns:
        key = (left.key, right.key, positive, kind)
        if key not in self.c_cache:
            answer = []
            for column in self.R(left, right, positive, kind):
                flipped = {}
                for index, coefficient in column.items():
                    i, j = divmod(index, right.dim)
                    flipped[j * left.dim + i] = coefficient
                answer.append(flipped)
            self.c_cache[key] = tuple(answer)
        return self.c_cache[key]


def flat_triple(vector: dict[tuple[int, int, int], F], modules) -> Vector:
    _, n, p = (module.dim for module in modules)
    return {(i * n + j) * p + k: c for (i, j, k), c in vector.items()}


def unflat_triple(vector: Vector, modules) -> dict[tuple[int, int, int], F]:
    _, n, p = (module.dim for module in modules)
    answer = {}
    for index, c in vector.items():
        ij, k = divmod(index, p)
        i, j = divmod(ij, n)
        answer[i, j, k] = c
    return answer


def place_R(ctx, vector: dict, modules, first, second, positive, kind="gl2"):
    """Apply an unflipped R on explicitly selected ordered tensor positions."""
    left, right = modules[first], modules[second]
    matrix = ctx.R(left, right, positive, kind)
    out = {}
    for indices, coefficient in vector.items():
        column = matrix[indices[first] * right.dim + indices[second]]
        for index, value in column.items():
            ii, jj = divmod(index, right.dim)
            dest = list(indices)
            dest[first], dest[second] = ii, jj
            add(out, tuple(dest), coefficient * value)
    return out


def adjacent_checked(ctx, vector, modules, slot, positive):
    left, right = modules[slot:slot + 2]
    matrix = ctx.checked(left, right, positive)
    out = {}
    for indices, coefficient in vector.items():
        for index, value in matrix[indices[slot] * right.dim + indices[slot+1]].items():
            jj, ii = divmod(index, left.dim)
            dest = list(indices)
            dest[slot:slot+2] = (jj, ii)
            add(out, tuple(dest), coefficient * value)
    labels = list(modules)
    labels[slot:slot+2] = (right, left)
    return out, tuple(labels)


def check_pairs(ctx: Context, highest_range, degree_offset=(0, 0)) -> None:
    for m, n in product(highest_range, repeat=2):
        left = ctx.irrep(m, m + degree_offset[0])
        right = ctx.irrep(n, n + degree_offset[1])
        source, target = ctx.tensor(left, right), ctx.tensor(right, left)
        for positive in (True, False):
            name = "positive" if positive else "negative"
            matrix = ctx.checked(left, right, positive)
            reverse = ctx.checked(right, left, not positive)
            for i in range(source.dim):
                datum = (str(ctx.q), m, n, degree_offset, i)
                for generator in ("E", "F"):
                    equal(
                        f"intertwining_{name}_{generator}",
                        apply(matrix, getattr(source, generator)[i]),
                        apply(getattr(target, generator), matrix[i]),
                        datum,
                    )
                equal(f"opposite_inverse_{name}", apply(reverse, matrix[i]), {i: F(1)}, datum)
                central_factor = ctx.v ** (
                    (1 if positive else -1)
                    * (m + degree_offset[0]) * (n + degree_offset[1])
                )
                equal(
                    f"gl2_central_factor_{name}",
                    matrix[i],
                    scale(ctx.checked(left, right, positive, "sl2")[i], central_factor),
                    datum,
                )


def check_triples(ctx: Context, highest_range) -> None:
    for m, n, p in product(highest_range, repeat=3):
        modules = tuple(ctx.irrep(a) for a in (m, n, p))
        left, middle, right = modules
        compound_left = ctx.tensor(left, middle)
        compound_right = ctx.tensor(middle, right)
        for positive in (True, False):
            name = "positive" if positive else "negative"
            # These left-hand operators use literal compound generator powers.
            first_hexagon = ctx.R(compound_left, right, positive)
            second_hexagon = ctx.R(left, compound_right, positive)
            for indices in product(*(range(a.dim) for a in modules)):
                vector = {indices: F(1)}
                flat = next(iter(flat_triple(vector, modules)))
                datum = (str(ctx.q), (m, n, p), indices)
                rhs1 = place_R(ctx, vector, modules, 1, 2, positive)
                rhs1 = place_R(ctx, rhs1, modules, 0, 2, positive)
                equal(
                    f"hexagon_delta_first_{name}",
                    unflat_triple(first_hexagon[flat], modules), rhs1, datum,
                )
                rhs2 = place_R(ctx, vector, modules, 0, 1, positive)
                rhs2 = place_R(ctx, rhs2, modules, 0, 2, positive)
                equal(
                    f"hexagon_delta_second_{name}",
                    unflat_triple(second_hexagon[flat], modules), rhs2, datum,
                )
                lhs, labels_l = vector, modules
                rhs, labels_r = vector, modules
                for slot in (0, 1, 0):
                    lhs, labels_l = adjacent_checked(ctx, lhs, labels_l, slot, positive)
                for slot in (1, 0, 1):
                    rhs, labels_r = adjacent_checked(ctx, rhs, labels_r, slot, positive)
                equal(
                    f"typed_braid_{name}",
                    (tuple(a.key for a in labels_l), lhs),
                    (tuple(a.key for a in labels_r), rhs), datum,
                )


def highest_vector(ctx, m, n, r) -> Vector:
    coefficients = {(r): F(1)}  # index of e_0 x f_r
    a = F(1)
    for i in range(r):
        a *= -ctx.q**(n - 2*r + 2*i + 2) * ctx.qi(n-r+i+1) / ctx.qi(m-i)
        coefficients[(i+1)*(n+1) + r-i-1] = a
    return coefficients


def beta(ctx, m, n, r, d, e, positive):
    if (d*e + m*n) % 2:
        raise AssertionError("Nonintegral full gl2 highest Cartan exponent.")
    exponent = (
        (d*e + m*n)//2 - r*(2*m-r+1)
        if positive else -(d*e + m*n)//2 + r*(2*n-r+1)
    )
    return (
        (-1)**r * ctx.q**exponent
        * ctx.factorial(n)*ctx.factorial(m-r)
        / (ctx.factorial(n-r)*ctx.factorial(m))
    )


def check_strings(ctx: Context, pairs: list[tuple[int, int, int, int]]) -> None:
    for m, n, d, e in pairs:
        left, right = ctx.irrep(m, d), ctx.irrep(n, e)
        source, target = ctx.tensor(left, right), ctx.tensor(right, left)
        for r in range(min(m, n)+1):
            z, zz = highest_vector(ctx, m, n, r), highest_vector(ctx, n, m, r)
            equal("highest_vector_kernel", apply(source.E, z), {}, (str(ctx.q), m, n, r, d, e))
            for positive in (True, False):
                name = "positive" if positive else "negative"
                coefficient = beta(ctx, m, n, r, d, e, positive)
                # Ordinary powers divided by [s]! form the actual descendants.
                for s in range(m+n-2*r+1):
                    w = scale(apply(ctx.powers(source, "F", s), z), 1/ctx.factorial(s))
                    ww = scale(apply(ctx.powers(target, "F", s), zz), 1/ctx.factorial(s))
                    equal(
                        f"highest_string_beta_{name}",
                        apply(ctx.checked(left, right, positive), w),
                        scale(ww, coefficient),
                        (str(ctx.q), m, n, r, s, d, e),
                    )


def lp_add(left: Laurent, right: Laurent) -> Laurent:
    result = dict(left)
    for degree, coefficient in right.items():
        add(result, degree, coefficient)
    return result


def lp_shift(poly: Laurent, shift: int, scalar: int = 1) -> Laurent:
    return {degree+shift: scalar*value for degree, value in poly.items() if scalar*value}


def lp_mul(left: Laurent, right: Laurent) -> Laurent:
    result: Laurent = {}
    for i, a in left.items():
        for j, b in right.items():
            add(result, i+j, a*b)
    return result


@lru_cache(None)
def lp_factorial(n: int) -> Laurent:
    result = {0: 1}
    for j in range(1, n+1):
        result = lp_mul(result, {i: 1 for i in range(1-j, j, 2)})
    return result


@lru_cache(None)
def lp_gaussian(n: int, k: int) -> Laurent:
    if k < 0 or k > n:
        return {}
    if n == 0:
        return {0: 1}
    return lp_add(
        lp_shift(lp_gaussian(n-1, k), -k),
        lp_shift(lp_gaussian(n-1, k-1), n-k),
    )


def lp_eval(poly: Laurent, q: F) -> F:
    return sum((coefficient*q**degree for degree, coefficient in poly.items()), F(0))


def integral_column(m, n, d, e, i, j, positive):
    """Independent integer-Laurent formula in the divided-power string bases."""
    out = {}
    bound = min(m-i, j) if positive else min(i, n-j)
    delta_power = {0: 1}
    for k in range(bound+1):
        if positive:
            ii, jj = i+k, j-k
            alpha, beta_weight = m-2*i, n-2*j
            g1, g2 = lp_gaussian(i+k, k), lp_gaussian(n-j+k, k)
            shift = (d*e + alpha*beta_weight)//2 + k*(k-1)//2
            sign = 1
        else:
            ii, jj = i-k, j+k
            alpha, beta_weight = m-2*ii, n-2*jj
            g1, g2 = lp_gaussian(m-i+k, k), lp_gaussian(j+k, k)
            shift = -(d*e + alpha*beta_weight)//2 - k*(k-1)//2
            sign = (-1)**k
        if (d*e + alpha*beta_weight) % 2:
            raise AssertionError("Parity failure in integral column.")
        value = lp_mul(lp_mul(lp_mul(delta_power, lp_factorial(k)), g1), g2)
        value = lp_shift(value, shift, sign)
        out[jj*(m+1)+ii] = value  # checked output f_jj x e_ii
        delta_power = lp_mul(delta_power, {1: 1, -1: -1})
    return out


def check_integrality(ctx):
    for n in range(11):
        for k in range(n+1):
            equal(
                "symbolic_gaussian_denominator_cancellation",
                lp_mul(lp_mul(lp_gaussian(n, k), lp_factorial(k)), lp_factorial(n-k)),
                lp_factorial(n), (n, k),
            )
    pairs = [(m, n, m, n) for m, n in product(range(5), repeat=2)]
    pairs += [(m, n, 15, 15) for m, n in product((1, 3, 5), repeat=2)]
    for m, n, d, e in pairs:
        left, right = ctx.irrep(m, d), ctx.irrep(n, e)
        for i, j in product(range(m+1), range(n+1)):
            lam, mu = left.weights[i], right.weights[j]
            equal(
                "gl2_weight_dot_product_parity",
                2*(lam[0]*mu[0]+lam[1]*mu[1]),
                d*e+(m-2*i)*(n-2*j), (m, n, d, e, i, j),
            )
            for positive in (True, False):
                name = "positive" if positive else "negative"
                polynomial = integral_column(m, n, d, e, i, j, positive)
                evaluated = {}
                for index, entry in polynomial.items():
                    if any(not isinstance(a, int) for a in entry.values()):
                        raise AssertionError("Laurent coefficient is not an integer.")
                    add(evaluated, index, lp_eval(entry, ctx.q))
                equal(
                    f"integer_laurent_braid_column_{name}",
                    evaluated, ctx.checked(left, right, positive)[i*(n+1)+j],
                    (m, n, d, e, i, j),
                )


def block_flip(vector):
    return {(j, b, i, a): c for (i, a, j, b), c in vector.items()}


def two_colour(ctx, vector, modules, positive, reverse_order=False):
    """Separate commuting colour actions, then one flip of the whole blocks."""
    slots = ((1, 3), (0, 2)) if reverse_order else ((0, 2), (1, 3))
    out = vector
    for first, second in slots:
        out = place_R(ctx, out, modules, first, second, positive)
    return block_flip(out)


def check_two_colour(ctx):
    # Four factors are V_m,W_p,V_n,W_u; every central degree is exactly 15.
    for m, p, n, u in product((1, 3), repeat=4):
        modules = tuple(ctx.irrep(a, 15) for a in (m, p, n, u))
        for indices in product(*(range(a.dim) for a in modules)):
            vector = {indices: F(1)}
            for positive in (True, False):
                name = "positive" if positive else "negative"
                result = two_colour(ctx, vector, modules, positive)
                equal(
                    f"two_colour_commutation_{name}", result,
                    two_colour(ctx, vector, modules, positive, True),
                    ((m, p, n, u), indices),
                )
                swapped = (modules[2], modules[3], modules[0], modules[1])
                equal(
                    f"two_colour_opposite_inverse_{name}",
                    two_colour(ctx, result, swapped, not positive), vector,
                    ((m, p, n, u), indices),
                )
        for r, s in product(range(min(m, n)+1), range(min(p, u)+1)):
            zV, zW = highest_vector(ctx, m, n, r), highest_vector(ctx, p, u, s)
            targetV, targetW = highest_vector(ctx, n, m, r), highest_vector(ctx, u, p, s)
            source, target = {}, {}
            for iv, cv in zV.items():
                i, j = divmod(iv, n+1)
                for iw, cw in zW.items():
                    a, b = divmod(iw, u+1)
                    add(source, (i, a, j, b), cv*cw)
            for iv, cv in targetV.items():
                j, i = divmod(iv, m+1)
                for iw, cw in targetW.items():
                    b, a = divmod(iw, p+1)
                    add(target, (j, b, i, a), cv*cw)
            for positive in (True, False):
                name = "positive" if positive else "negative"
                coefficient = beta(ctx, m, n, r, 15, 15, positive)*beta(ctx, p, u, s, 15, 15, positive)
                equal(
                    f"two_colour_highest_beta_{name}",
                    two_colour(ctx, source, modules, positive),
                    scale(target, coefficient), (m, p, n, u, r, s),
                )


def check_q_one():
    ctx = Context(1)  # Calls the same qi, R and checked constructors at q=1.
    pairs = [(m, n, m, n) for m, n in product(range(6), repeat=2)]
    pairs += [(m, n, 15, 15) for m, n in product((1, 3, 5), repeat=2)]
    for m, n, d, e in pairs:
        left, right = ctx.irrep(m, d), ctx.irrep(n, e)
        for i, j in product(range(m+1), range(n+1)):
            for positive in (True, False):
                name = "positive" if positive else "negative"
                equal(
                    f"q_one_ordinary_flip_{name}",
                    ctx.checked(left, right, positive)[i*(n+1)+j],
                    {j*(m+1)+i: F(1)}, (m, n, d, e, i, j),
                )
    for m, p, n, u in product((1, 3), repeat=4):
        modules = tuple(ctx.irrep(a, 15) for a in (m, p, n, u))
        for indices in product(*(range(a.dim) for a in modules)):
            vector = {indices: F(1)}
            for positive in (True, False):
                name = "positive" if positive else "negative"
                equal(
                    f"q_one_two_colour_block_flip_{name}",
                    two_colour(ctx, vector, modules, positive),
                    block_flip(vector), ((m, p, n, u), indices),
                )


PARAMETERS = {
    "pair_intertwining_inverse_and_central_factor": [
        {"q": 4, "m_n": [0, 1, 2, 3, 4, 5], "degrees": ["m+2", "n+4"]},
        {"q": 9, "m_n": [0, 1, 2, 3, 4], "degrees": ["m", "n"]},
    ],
    "typed_braid_and_both_direct_compound_hexagons": [
        {"q": 4, "m_n_p": [0, 1, 2, 3], "degrees": ["m", "n", "p"]},
        {"q": 9, "m_n_p": [0, 1, 2], "degrees": ["m", "n", "p"]},
    ],
    "complete_highest_strings_all_descendants": [
        {"q": 4, "m_n": [0, 1, 2, 3, 4, 5], "degrees": ["m", "n"]},
        {"q": 9, "m_n": [0, 1, 2, 3, 4], "degrees": ["m", "n"]},
        {"q": 4, "m_n": [1, 3, 5, 7, 9], "degrees": [15, 15]},
    ],
    "symbolic_gaussian_identity": {"n": list(range(11)), "k": "0..n"},
    "integer_laurent_columns_and_weight_parity": [
        {"q_for_rational_comparison": 4, "m_n": list(range(5)), "degrees": ["m", "n"]},
        {"q_for_rational_comparison": 4, "m_n": [1, 3, 5], "degrees": [15, 15]},
    ],
    "two_commuting_colours_all_columns_and_highest_pairs": {
        "q": 4, "m_p_n_u": [1, 3], "all_four_degrees": 15
    },
    "q_one_actual_constructor_flip": [
        {"m_n": list(range(6)), "degrees": ["m", "n"]},
        {"m_n": [1, 3, 5], "degrees": [15, 15]},
    ],
    "q_one_two_colour_actual_constructor_block_flip": {
        "m_p_n_u": [1, 3], "all_four_degrees": 15
    },
    "orientation": "Both positive and negative in every applicable category.",
    "coverage": "All parameter tuples and all basis columns in the stated Cartesian ranges.",
}


def run():
    q4, q9 = Context(2), Context(3)
    check_pairs(q4, range(6), (2, 4))
    check_pairs(q9, range(5))
    check_triples(q4, range(4))
    check_triples(q9, range(3))
    check_strings(q4, [(m, n, m, n) for m, n in product(range(6), repeat=2)])
    check_strings(q9, [(m, n, m, n) for m, n in product(range(5), repeat=2)])
    check_strings(q4, [(m, n, 15, 15) for m, n in product((1, 3, 5, 7, 9), repeat=2)])
    check_integrality(q4)
    check_two_colour(q4)
    check_q_one()


def main() -> int:
    started = time.perf_counter()
    report = {
        "schema_version": 1,
        "checker": Path(__file__).name,
        "checker_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
        "arithmetic": "Python standard-library Fraction and integer Laurent dictionaries; no floats in identities.",
        "coproduct": {
            "E": "E tensor K^-1 + 1 tensor E",
            "F": "F tensor 1 + K tensor F",
        },
        "positive_operator_order": "(sum b_k F^k tensor E^k) Q; Q acts on input.",
        "negative_operator_order": "Q^-1 (sum a_k E^k tensor F^k); Q^-1 acts on output.",
        "parameter_ranges": PARAMETERS,
        "scope": "Finite exact model checks; no original 1260-dimensional source matrix is read or certified here.",
    }
    exit_code = 0
    try:
        run()
        report["status"] = "passed"
    except Exception as error:
        exit_code = 1
        report["status"] = "failed"
        report["error"] = str(error)
        report["traceback"] = traceback.format_exc()
    report["checks_by_category"] = dict(sorted(COUNTS.items()))
    report["total_checked_equalities"] = sum(COUNTS.values())
    elapsed_seconds = round(time.perf_counter()-started, 6)
    output = Path(__file__).with_name("braid_verification.json")
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": report["status"],
        "total_checked_equalities": report["total_checked_equalities"],
        "checks_by_category": report["checks_by_category"],
        "report": output.name,
        "elapsed_seconds": elapsed_seconds,
    }))
    if exit_code:
        print(report["traceback"])
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
