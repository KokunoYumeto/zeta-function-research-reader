# Independent full material coefficient audit

Status: **PASS**. The original-polynomial Jacobians, all entries of (102), its inverse, the full tensor and endpoint, and the exact constants in (104)–(105) agree. No coefficient correction is required.

This audit binds the unchanged archived manuscript `provisional_publication_20260908/FABEL_TENSOR_TRANSFER.md`, SHA-256 `c0bdfe683d3f620858a74654406e30c02b3242d0b6cfb012432cac173d98d9fc`, through the compact `input_transcript.json`. That checked-in transcript records the exact input equations, their literal source excerpts, domains, source locator and hash; its SHA-256 is `b16b6edbaa83af244ec4b6bf075f73fa45d23833c3b4a80ab4a378c1e5a6f7ab`. Default replay requires neither the full private manuscript nor a `source/` folder. The scope is the exact finite-regulator material coefficient calculation and cubic Gram identity. It does not assert the source's remaining interacting spectral limit or a mass-gap or complexity consequence.

## Original derivative and exact inverse

The original real spatial variables are \((x,y,w)\). For writing the differentiated entries only, denote their unchanged polynomial \(1+xy\) by \(t\); this is an abbreviation, not a change of coordinates. The original map is

\[
F=\begin{pmatrix}
t^3w+y^2t(4+3xy)\\
y+3xt^2w+3xy^2(4+3xy)\\
2x-3x^2y-x^3w
\end{pmatrix},\qquad t=1+xy.
\]

Direct differentiation, retaining every summand, gives

\[
DF=\begin{pmatrix}
3wyt^2+3y^3t+y^3(3xy+4)&
3wxt^2+3xy^2t+xy^2(3xy+4)+2yt(3xy+4)&t^3\\
6wxyt+3wt^2+9xy^3+3y^2(3xy+4)&
6wx^2t+9x^2y^2+6xy(3xy+4)+1&3xt^2\\
-3wx^2-6xy+2&-3x^2&-x^3
\end{pmatrix}.
\]

The cofactor polynomial
\[
J_{11}(J_{22}J_{33}-J_{23}J_{32})
-J_{12}(J_{21}J_{33}-J_{23}J_{31})
+J_{13}(J_{21}J_{32}-J_{22}J_{31})
\]
is exactly \(-2\) after substituting these entries and \(t=1+xy\); the checker expands this identity over \(\mathbb Q[x,y,w]\), with zero residual. In particular no exclusion in the original real spatial domain is needed to invert \(DF\).

At \(q_0=(1,-3/2,13/2)\) and
\(\gamma=(z^{-1},-3z/2,13z^2/2)\), for the retained real domain \(z>0\), substitution gives exactly

\[
J_0=\begin{pmatrix}
-9/16&-3/8&-1/8\\3/8&25/4&3/4\\-17/2&-3&-1
\end{pmatrix},\qquad
J_\gamma=\begin{pmatrix}
-9z^3/16&-3z/8&-1/8\\3z^2/8&25/4&3/(4z)\\-17/2&-3/z^2&-1/z^3
\end{pmatrix}.
\]

Let \(\tau=(1-z^2)/8\) and \(B=I+6\tau E_{23}\). Since \(E_{23}^2=0\), its inverse is \(I-6\tau E_{23}\), and both determinants are one. Multiplication of the original factors gives all nine entries

\[
C=J_0^{-1}B^{-1}J_\gamma=
\begin{pmatrix}
(17-9z^3)/8&(3-3z^3)/(4z^2)&(1-z^3)/(4z^3)\\
(51-24z^2-27z^3)/16&(9+8z^2-9z^3)/(8z^2)&(3-3z^3)/(8z^3)\\
(-153+36z^2+117z^3)/8&(-27-12z^2+39z^3)/(4z^2)&(-9+13z^3)/(4z^3)
\end{pmatrix}.
\]

The inverse in the same original coordinates is

\[
A=J_\gamma^{-1}BJ_0=
\begin{pmatrix}
(17z^3-9)/(8z^3)&(3z^3-3)/(4z^3)&(z^3-1)/(4z^3)\\
(51z^3-24z-27)/(16z)&(9z^3+8z-9)/(8z)&(3z^3-3)/(8z)\\
(-153z^3+36z+117)/8&(-27z^3-12z+39)/4&(13-9z^3)/4
\end{pmatrix}.
\]

Each of the eighteen scalar entries in \(AC=CA=I\) was checked as an exact rational-function identity. Independently the original factorization proves those compositions by adjacent inverse cancellation, with all factors invertible on \(z>0\). The determinant factorization gives
\(\det C=(-2)^{-1}\cdot1\cdot(-2)=1\), and similarly \(\det A=1\). At \(z=1\), \(\tau=0\), \(\gamma=q_0\), and both complete matrices equal \(I\), as also checked entry by entry.

## Every tensor entry and the endpoint

To record all of \(K=CC^{\mathsf T}\) compactly and exactly, define the following nine polynomials without discarding any term:

\[
M=16z^3C=
\begin{pmatrix}
-18z^6+34z^3&-12z^4+12z&4-4z^3\\
-27z^6-24z^5+51z^3&-18z^4+16z^3+18z&6-6z^3\\
234z^6+72z^5-306z^3&156z^4-48z^3-108z&52z^3-36
\end{pmatrix}.
\]

Writing its three unchanged rows as \(a=(a_1,a_2,a_3)\), \(b=(b_1,b_2,b_3)\), and \(c=(c_1,c_2,c_3)\), the six independent entries, including every cross term, are

\[
K={1\over256z^6}
\begin{pmatrix}
a_1^2+a_2^2+a_3^2&a_1b_1+a_2b_2+a_3b_3&a_1c_1+a_2c_2+a_3c_3\\
a_1b_1+a_2b_2+a_3b_3&b_1^2+b_2^2+b_3^2&b_1c_1+b_2c_2+b_3c_3\\
a_1c_1+a_2c_2+a_3c_3&b_1c_1+b_2c_2+b_3c_3&c_1^2+c_2^2+c_3^2
\end{pmatrix}.
\]

The receipt additionally stores the fully expanded nine numerator entries and all three exact rational functions \(w_j(K)\). This full tensor is symmetric, has determinant \((\det C)^2=1\), and satisfies \(K(1)=I\). For every real \(v\ne0\),
\[
v^{\mathsf T}Kv=(C^{\mathsf T}v)^{\mathsf T}(C^{\mathsf T}v)>0,
\]
because \(C^{\mathsf T}\) is invertible. Thus negative off-diagonal entries do not produce a negative quadratic form in this material tensor.

Evaluation of the polynomial matrix at zero gives
\[
M(0)=\begin{pmatrix}0&0&4\\0&0&6\\0&0&-36\end{pmatrix}
=16\eta e_3^{\mathsf T},\qquad
\eta=(1/4,3/8,-9/4)^{\mathsf T}.
\]
Consequently, with the exact endpoint direction retained,
\[
\lim_{z\downarrow0}z^3C=\eta e_3^{\mathsf T},\qquad
\lim_{z\downarrow0}z^6K
=\eta\eta^{\mathsf T}
=S_*={1\over64}\begin{pmatrix}4&6&-36\\6&9&-54\\-36&-54&324\end{pmatrix}.
\]
All eighteen scalar endpoint entries were independently computed from the original matrices. The matrix \(S_*\) has rank one because \(\eta\ne0\), and \(v^{\mathsf T}S_*v=(\eta^{\mathsf T}v)^2\ge0\). Its positive eigenvalue is \(\eta^{\mathsf T}\eta=337/64\); the other two eigenvalues are zero. This is a degenerate positive endpoint.

The unchanged affine covector \(\zeta=C^{\mathsf T}e_3\) has squared length \(Q=K_{33}\). Its full three-summand expression and \(\lim z^6Q=81/16\) were also verified. This additional check binds the quadratic tensor to the preceding affine-covector calculation without replacing either object.

## Cubic Gram coefficients and exact constants

The independent proof in `weight_identity/REVIEW.md` determines every cubic-invariant Hermitian Gram form in the original basis
\[
E_{11},E_{22},E_{33},E_{12}+E_{21},E_{13}+E_{31},E_{23}+E_{32}.
\]
It is exactly \(((d-h)I_3+h\mathbf1\mathbf1^{\mathsf T})\oplus oI_3\), with real \(d,h,o\). Reflections kill all diagonal/off-diagonal cross terms and all cross terms between distinct off-diagonal pairs; permutations equate the surviving entries and make \(h\) real. Hence for an arbitrary symmetric \(S\), the form equals
\[
d\sum_iS_{ii}^2+2h\sum_{i<j}S_{ii}S_{jj}
+o\sum_{i<j}S_{ij}^2.
\]
The seed matrices \(I\), \(E_{11}-E_{22}\), and \(E_{12}+E_{21}\) have values \(3d+6h\), \(2(d-h)\), and \(o\). Expanding the squared diagonal deviations then gives precisely
\[
w_0(S)={ (\operatorname{tr}S)^2\over9},\qquad
w_{\rm d}(S)={1\over2}\sum_i(S_{ii}-\operatorname{tr}S/3)^2,
\qquad w_{\rm o}(S)=\sum_{i<j}S_{ij}^2.
\]
The factor two in the off-diagonal seed polynomial \(2m_1m_2\) is retained by this basis. No seed norm is divided out. Applying this form to the spectral Gram form proves (104), also when one or more seed measures vanish.

For the actual endpoint, \(\operatorname{tr}S_*=337/64\), and its three diagonal deviations are \((-325,-310,635)/192\). Therefore
\[
\begin{aligned}
w_0(S_*)&={337^2\over9\cdot64^2}={113569\over36864},\\
w_{\rm d}(S_*)&={325^2+310^2+635^2\over2\cdot192^2}
={100825\over12288},\\
w_{\rm o}(S_*)&={6^2+(-36)^2+(-54)^2\over64^2}
={531\over512}.
\end{aligned}
\]
Each polynomial weight is homogeneous of degree two, so
\(z^{12}w_j(K)=w_j(z^6K)\to w_j(S_*)\). The checker also takes these limits directly on the exact full rational functions before endpoint substitution. This verifies both the power \(z^{12}\) and every constant in (105).

At each fixed regulator, the difference of the three-measure combinations is bounded in total variation by
\[
\sum_{j\in\{0,\mathrm d,\mathrm o\}}
|z^{12}w_j(K)-w_j(S_*)|\,\nu_j((0,\infty)).
\]
It tends to zero because there are exactly three finite seed measures. Replacing their masses by their finite first or second moments proves the asserted corresponding moment convergence. This argument does not exchange the material endpoint with a regulator limit.

## Replay and receipts

Run `python check_coefficients.py` for standalone equation-transcript replay. Optional `--observe-source --source-path <archived-source-path>` checks the complete original manuscript hash and all ten exact equation excerpts; the path must be supplied explicitly and no machine-specific location is embedded in the checker. The original 155 exact scalar identities remain, and 52 additional identities bind the calculation to every recorded polynomial, point, displayed matrix, parameter, endpoint vector, matrix and weight. `verification.json` records every identity label, the complete original derivative, both full matrices, the full tensor numerator, the full weights, and their endpoint values.

The independent standard-library rational checker in `weight_identity/check.py` passed 3,096 checks, including all 48 signed permutations, the complete Gram polynomial, seed values, and endpoint fractions. Together these checks verify the stated finite calculation. The reviews delimit their mathematical scope; their passing status is not evidence for an uncomputed interacting spectral limit.
