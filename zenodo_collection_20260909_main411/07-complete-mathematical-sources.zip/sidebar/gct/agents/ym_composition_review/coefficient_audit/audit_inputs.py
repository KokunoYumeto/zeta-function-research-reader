"""Load the small equation transcript; original-source observation is optional."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TRANSCRIPT = ROOT / "input_transcript.json"
TRANSCRIPT_SHA = "b16b6edbaa83af244ec4b6bf075f73fa45d23833c3b4a80ab4a378c1e5a6f7ab"
SOURCE_SHA = "c0bdfe683d3f620858a74654406e30c02b3242d0b6cfb012432cac173d98d9fc"


def load_inputs(observe_source=False, source_path=None):
    if observe_source and source_path is None:
        raise ValueError("--observe-source requires an explicit --source-path")
    raw = TRANSCRIPT.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == TRANSCRIPT_SHA, "audited input transcript changed"
    inputs = json.loads(raw)
    assert inputs["schema_version"] == 1
    assert inputs["original_source_sha256"] == SOURCE_SHA
    excerpts = inputs["source_equation_excerpts"]
    assert len(excerpts) == 10 and all(item["exact_text"] for item in excerpts)
    if observe_source:
        source_raw = Path(source_path).read_bytes()
        assert hashlib.sha256(source_raw).hexdigest() == SOURCE_SHA, "original source hash changed"
        source_text = source_raw.decode("utf-8")
        for item in excerpts:
            assert item["exact_text"] in source_text, ("original equation excerpt changed", item["locator"])
    return inputs
