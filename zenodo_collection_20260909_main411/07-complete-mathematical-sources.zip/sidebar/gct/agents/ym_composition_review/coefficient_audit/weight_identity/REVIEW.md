# Independent cubic-weight audit

Status: PASS. No correction to (104) or the three constants in (105) is required.

This proprietary local audit covers only the cubic-invariant Gram identity and substitution of the given endpoint matrix. It does not audit the derivatives producing that matrix, the interacting Hamiltonian construction, or any regulator limit.

Source locator: `provisional_publication_20260908/FABEL_TENSOR_TRANSFER.md`.

Audited source SHA-256: `c0bdfe683d3f620858a74654406e30c02b3242d0b6cfb012432cac173d98d9fc`.

A later live source version has SHA-256 `895f7149cb80d87425c5c4c4326cdc3437eb360561f7237a15ba1d68b58e470a`. A read-only line comparison of its lines 194–265 against the original audited version found no differences. This range includes definition (103), all three seed states, theorem (104), its complete Gram proof, and the endpoint through (105) with the convergence justification. This review remains pinned to the original c0bd version, retained at the source locator above; the later live version is not the default replay input.

Standalone replay reads the pinned equation transcript at `../input_transcript.json` through `../audit_inputs.py`; it does not require a source folder or access an original source path. The loader verifies the transcript hash. The checker asserts the three exact formula strings, reads all six endpoint coordinates and the three claimed endpoint weights from that transcript, and independently tests them. Optional `python check.py --observe-source --source-path PATH` additionally asks the loader to verify the full original source hash and exact source excerpts at the explicitly supplied path. That path is not written to the receipt. The previous `source_observation.json` is a historical private snapshot-comparison record from the superseded replay mechanism; current replay evidence is `receipt.json`.

## Exact derivation in the original matrix coordinates

Let V be the complexification of the real vector space of symmetric 3-by-3 matrices, with the unchanged ordered basis

\[
A_1=E_{11},\quad A_2=E_{22},\quad A_3=E_{33},\quad
B_{12}=E_{12}+E_{21},\quad B_{13}=E_{13}+E_{31},\quad
B_{23}=E_{23}+E_{32}.
\]

The signed permutation group acts by \(S\mapsto RSR^{\mathsf T}\). Let H be any invariant positive semidefinite Hermitian form on V, antilinear in its first argument. Positive definite forms are included; semidefinite forms are necessary for the source's spectral measures, which can vanish.

A coordinate reflection fixes every \(A_i\), and acts on \(B_{jk}\) by the product of the two relevant coordinate signs. For every pair \(A_i,B_{jk}\), reflecting coordinate j negates precisely the second vector. Invariance therefore gives \(H(A_i,B_{jk})=-H(A_i,B_{jk})=0\). For two different off-diagonal pairs, a coordinate belonging to exactly one pair negates precisely one vector, proving \(H(B_{ij},B_{kl})=0\). Permutations make \(H(B_{ij},B_{ij})=c\) independent of the pair. Permutations similarly give a common value d for \(H(A_i,A_i)\) and a common value h for \(H(A_i,A_j)\), \(i\ne j\). The permutation exchanging i and j gives \(H(A_i,A_j)=H(A_j,A_i)\), and Hermitian symmetry makes h real. Thus the complete Gram matrix, with no basis rescaling, is

\[
G=((d-h)I_3+hJ_3)\oplus cI_3,
\qquad d,h,c\in\mathbb R.
\]

Conversely, this matrix is invariant under every signed permutation: permutations preserve the first block and permute the final three coordinates, while reflections only change signs in the final diagonal block. Its eigenvalues are \(d+2h\) on \((1,1,1)\), \(d-h\) on the diagonal trace-zero plane, and c on the off-diagonal subspace. Consequently positivity is exactly

\[
d+2h\ge0,\qquad d-h\ge0,\qquad c\ge0.
\]

For the actual real symmetric matrix S, put \(s_i=S_{ii}\), \(t=\operatorname{tr}S\), and keep its original off-diagonal entries \(S_{ij}\). Then

\[
\begin{aligned}
H(S,S)
&=d\sum_i s_i^2+2h\sum_{i<j}s_is_j+c\sum_{i<j}S_{ij}^2\\
&=(d-h)\sum_i(s_i-t/3)^2+(d+2h)t^2/3
  +c\sum_{i<j}S_{ij}^2.
\end{aligned}
\]

Here the second equality follows by expanding \(\sum_i(s_i-t/3)^2=\sum_i s_i^2-t^2/3\), with \(t^2=\sum_i s_i^2+2\sum_{i<j}s_is_j\). The source's unmodified seed matrices are

\[
I=A_1+A_2+A_3,\quad D=A_1-A_2,\quad O=B_{12}.
\]

Their exact quadratic values are

\[
H(I,I)=3d+6h,\quad H(D,D)=2(d-h),\quad H(O,O)=c.
\]

Substitution, without dividing by any seed norm, proves

\[
\boxed{H(S,S)=\frac{t^2}{9}H(I,I)
+\frac12\sum_i(s_i-t/3)^2H(D,D)
+\sum_{i<j}S_{ij}^2H(O,O).}
\]

For a Borel set B in the positive energy axis, apply this identity to
\(H_B(S,T)=\langle\Xi_{f_S},1_B(\mathcal A)\Xi_{f_T}\rangle\).
The source's equivariance and commuting spectral projections make this a cubic-invariant positive semidefinite Hermitian form. The seed polynomials are exactly \(m_1^2+m_2^2+m_3^2\), \(m_1^2-m_2^2\), and \(2m_1m_2\). Therefore the boxed identity is precisely (104), with the stated off-diagonal factors. No assumption that a seed state is nonzero occurs in the derivation.

## Exact endpoint constants

For the supplied matrix

\[
S_*={1\over64}
\begin{pmatrix}4&6&-36\\6&9&-54\\-36&-54&324\end{pmatrix},
\]

the trace is \(337/64\), and the three diagonal deviations from one third of the trace are \((-325,-310,635)/192\). Hence

\[
\begin{aligned}
w_0(S_*)&={337^2\over9\cdot64^2}={113569\over36864},\\
w_{\rm d}(S_*)&={325^2+310^2+635^2\over2\cdot192^2}
={604950\over73728}={100825\over12288},\\
w_{\rm o}(S_*)&={6^2+(-36)^2+(-54)^2\over64^2}
={4248\over4096}={531\over512}.
\end{aligned}
\]

All three are strictly positive. Each weight is a continuous polynomial homogeneous of degree two in the original entries. Thus the stated matrix endpoint \(z^6K_\tau\to S_*\) gives \(z^{12}w_j(K_\tau)=w_j(z^6K_\tau)\to w_j(S_*)\), proving precisely the coefficients and power of z in (105). At a fixed regulator the finite sum of the three fixed finite seed measures converges in total variation: its error is at most \(\sum_j|w_j(z^6K_\tau)-w_j(S_*)|\nu_j((0,\infty))\). The same estimate with finite first or second moments proves the corresponding moment assertion. This step uses only the stated endpoint and fixed-regulator finiteness; it does not verify that endpoint independently.

## Exact computational cross-check

`check.py` uses only Python's standard library and rational arithmetic. It checks the general Gram quadratic identity for all 21 monomial positions and all three independent parameters, verifies the three Gram-parameter matrices under all 48 signed permutations, and checks the three endpoint fractions and all three original seed values. `receipt.json` binds the review and checker to the pinned transcript hash and the original source identity. Optional original observation leaves that deterministic replay receipt unchanged and reports the observation in command output. The proof above establishes necessity of the Gram form; the finite computation independently verifies sufficiency and the exact coefficients.
