# Independent domain and composition audit

Status: PASS. The complete author fragment was read and the domain clarifications listed below were checked in its final text. No unresolved finding remains. `final_review_receipt.json` binds the reviewed fragment and proof dependencies by SHA-256.

## Exact assignment and ownership

The delegated task is to audit `agents/ym_composition_review/ym_composition.tex` independently, including the original Fabel parameter, the NS sheet, the fixed Wilson Hilbert space, complex spectral weights, and the external quantum-module tensor map. All audit writes stay in this `domain_audit` directory. The original Fabel and NS source files are read only. No numerical value of a coordinate is identified with an energy or a quantum deformation parameter without its displayed map.

## Parameter maps and excluded loci

Let the original Fabel material time be \(t_F=(1-z_F^2)/8\), and retain its root-chart coordinates \(r=-z_F/2\), \(s=-z_F^2/8\), \(b=c=0\). The positive NS path has \(s=\tau\), \(r=i\sqrt{2\tau}\), \(0<\tau<2\), and \(p=\sqrt{4-2\tau}>0\). Composing the two root maps gives exactly

\[
z_F=-i\sqrt{8\tau},\qquad z_F^2=-8\tau,\qquad t_F=1/8+\tau.
\]

Thus this is evaluation of the original rational Fabel matrix on a complex path. The positive real Fabel material path ended at \(t_F=1/8\); it is not being identified with a real trajectory beyond that endpoint. The original rational matrix is defined at every \(z_F\ne0\). Its denominators remain the displayed powers of \(z_F\). The arithmetic connection also excludes \(m=0\) and \(n=m+4=0\), which on this path are \(\tau=0\) and \(\tau=2\). Endpoint limits of the rational tensors and coefficient polynomials do not extend the localized connection across those branch points.

For a common coefficient ring use \(w=\sqrt\tau\), \(\mathscr O=\mathbb C\{w\}\), and its meromorphic fraction field \(\mathscr M\). The convergent square-root germ with value one at zero gives

\[
q(w)=\sqrt{1-w^2/2}+iw/\sqrt2,\quad q(w)^{-1}=\sqrt{1-w^2/2}-iw/\sqrt2,\quad q-q^{-1}=i\sqrt2w.
\]

Their product is one. The map \(D=\mathbb Q[q,q^{-1}]_{(q-1)}\to\mathscr O\) is defined because every denominator has nonzero value at \(q=1\), hence its substituted germ is a unit. It is injective: \(q(w)\) is nonconstant since its derivative at zero is \(i/\sqrt2\); a nonzero polynomial over \(\mathbb Q\) has finitely many complex roots, while a nonconstant holomorphic germ has infinite image. Clearing Laurent powers proves the same for Laurent polynomials and hence for the localization. This is a germ map. There is no simultaneous evaluation of all elements of \(D\) at every point of \(0<\tau<2\), because regularity at \(q=1\) does not exclude poles at other points of the unit circle.

## Hilbert space and complex-linear observable map

Fix the original integer \(L\ge2\) and real \(a,g>0\). The configuration space is \(\mathcal Q=\mathrm{SU}(2)^{\mathsf E_L}\) with product Haar probability measure. The original operator on complex \(L^2(\mathcal Q,\lambda)\) is

\[
H=\kappa\sum_eE_e+b_{\rm YM}\sum_p(2-W_p),\quad \kappa=2g^2/a,\quad b_{\rm YM}=1/(2g^2a),\quad E_e=-\sum_{a=1}^3X_{e,a}^2.
\]

The notation \(b_{\rm YM}\) identifies the source's positive coupling coefficient and avoids confusing it with the arithmetic coordinate \(b=0\). It does not change its value. The domain remains \(H^2(\mathcal Q)\), the form domain remains \(H^1(\mathcal Q)\), and the positive smooth unit vacuum remains the original \(\psi\). Inner products are conjugate-linear in their first argument. Put \(\mathcal A=H-E_0\).

For a complex edge weight \(f\), define the differential expression on smooth functions by

\[
f_p=\tfrac14\sum_{e\in\partial p}f_e,\quad D_f=\kappa\sum_ef_eE_e+\sum_pf_p b_{\rm YM}(2-W_p),\quad \Xi_f=D_f\psi-\langle\psi,D_f\psi\rangle\psi.
\]

All sums retain boundary edges and faces. Both terms are complex-linear in \(f\), so \(\Xi_f\) is complex-linear. It is smooth, gauge invariant, and vacuum orthogonal. Smoothness places it in every power domain of the fixed elliptic \(H\). For complex weights \(D_f\) need not be self-adjoint; its use on the smooth core suffices here. In particular the real same-\(D_f\) double-commutator energy formula must not be continued as if it were a positive complex quadratic form. The identities \(\mathcal A\Xi_f=[H,D_f]\psi\) and the spectral-projection definition below remain valid.

For \(S\in\operatorname{Sym}_3(\mathbb C)\), define \(f_S(e)=m(e)^TSm(e)\) with original dimensionless edge midpoints and \(\mathfrak M(S)=\Xi_{f_S}\). This is a map from complex symmetric matrices; it does not change the kinetic tensor or metric in \(H\). Its image lies in the span of the six fixed smooth physical states \(u_i=\Xi_{m_i^2}\), \(v_{ij}=\Xi_{2m_im_j}\), \(i<j\). No independence or nonvanishing of these six states is required for the map.

For a signed coordinate permutation \(R\), the source's real unitary \(\mathsf T_R\) acts complex-linearly and satisfies \(\mathsf T_R\mathfrak M(S)=\mathfrak M(RSR^T)\). The midpoint identity \(m(e')=Rm(e)\) proves the matrix action. It preserves \(H\), \(\psi\), and each spectral projection \(\mathbf1_B(\mathcal A)\).

The spectral Gram matrix of the \(u_i\) has diagonal \(d(B)\) and real off-diagonal \(h(B)\); the latter is real because an index swap identifies each off-diagonal entry with its conjugate. Reflections annihilate all diagonal/off-diagonal cross terms and cross terms between distinct \(v_{ij}\). For complex \(s_i=S_{ii}\), the diagonal Gram expression is

\[
(d-h)\sum_i|s_i-\overline s|^2+\frac{d+2h}{3}\left|\sum_i s_i\right|^2,\qquad \overline s=\tfrac13\sum_i s_i,
\]

where \(\overline s\) denotes the mean, not complex conjugation. Using \(\nu_0=3d+6h\), \(\nu_{\rm d}=2(d-h)\), and the common off-diagonal measure \(\nu_{\rm o}\), the exact positive measure is

\[
\nu_{\mathfrak M(S)}=\frac{|\operatorname{tr}S|^2}{9}\nu_0+\frac12\sum_i|S_{ii}-\operatorname{tr}S/3|^2\nu_{\rm d}+\sum_{i<j}|S_{ij}|^2\nu_{\rm o}.
\]

The measures use the fixed self-adjoint \(\mathcal A\), so they remain positive for complex \(S\). This formula does not assert a holomorphic spectral measure: it contains squared complex moduli. Every raw moment is finite. Physical midpoints \(a m(e)\), if chosen instead, multiply every state by \(a^2\) and every raw spectral measure by \(a^4\).

## The phase and endpoint topology

The rational continuation keeps \(K(z_F)=C(z_F)C(z_F)^T\), with ordinary transpose. Replacing it by \(CC^*\) would change the original rational object. Although \(K\) is complex symmetric on the NS path, it is a valid input to \(\mathfrak M\).

The source limit \(z_F^6K(z_F)\to S_*=\eta\eta^T\), \(\eta=(1/4,3/8,-9/4)^T\), is the leading term of an actual rational matrix and therefore holds along this complex path. Since \((-i)^6=-1\),

\[
\tau^3\mathfrak M(K)\longrightarrow-\mathfrak M(S_*)/512.
\]

The original GCT coefficient is \(C(q)=\tau B(\tau)\) with \(B(0)=-42\). Consequently

\[
\tau^2 C(q)\mathfrak M(K)=B(\tau)\tau^3\mathfrak M(K)\longrightarrow21\mathfrak M(S_*)/256.
\]

These are vector limits in every Sobolev norm at fixed \(L,a,g\), since all vectors lie in a fixed finite span of smooth states and their six coefficients converge. The spectral limits therefore contain factors \(1/512^2\) and \((21/256)^2\), respectively, not the signed vector factors. The spectral Gram formula also directly proves total-variation convergence and convergence of every fixed moment: bound the difference by the sum of the three coefficient errors times the corresponding finite seed moment.

The three weights of \(S_*\) are strictly positive: \(113569/36864\), \(100825/12288\), and \(531/512\). Their continued scaled counterparts remain strictly positive for sufficiently small positive \(\tau\). In that neighborhood, the support of the resulting measure is exactly the union of the supports of the nonzero seed measures. Scalar multiplication by nonzero \(C(q)\) changes masses by \(|C(q)|^2\) and leaves supports and raw Rayleigh quotients unchanged. If the seed mass sum is zero, all six states in this family vanish and no quotient is defined. Otherwise the positive limiting weighted mass proves nonvanishing for sufficiently small \(\tau\), and the raw quotient tends to the stated weighted seed-moment ratio. None of these fixed-regulator statements implies a continuum or infinite-volume spectral limit.

## Exact external quantum-module typing

Put \(X_{\mathscr M}=\mathscr M\otimes_D X_D\). Extend the six-state map by scalars to

\[
\mathfrak M_{\mathscr M}:\operatorname{Sym}_3(\mathscr M)\longrightarrow\mathscr M\otimes_{\mathbb C}\mathcal H_{\rm sm}.
\]

The tensor product on the right is algebraic: its elements are finite sums of meromorphic scalar germs times fixed smooth physical states. No completion or meromorphic Hamiltonian is used. Then

\[
\mathrm{id}_{X_{\mathscr M}}\otimes\mathfrak M_{\mathscr M}:X_{\mathscr M}\otimes_{\mathscr M}\operatorname{Sym}_3(\mathscr M)\longrightarrow X_{\mathscr M}\otimes_{\mathscr M}(\mathscr M\otimes_{\mathbb C}\mathcal H_{\rm sm})
\]

is an exact intertwiner for the original base-changed quantum action on \(X_{\mathscr M}\), acting trivially via the counit on every second factor. Indeed, for each original generator \(u\) and each pure tensor, both orders yield \(u x\otimes\mathfrak M_{\mathscr M}(S)\); linearity proves the identity on every vector. Both original central labels stay on \(X\). The map gives no action of the quantum generators on the physical Hilbert factor and no map from \(X\) alone to that factor. It does not intertwine a quantum involution with Hilbert adjunction or intertwine the material generator with \(H\). Such assertions would require additional maps absent from this composition.

## Source observations

Read the complete `FABEL_TENSOR_TRANSFER.md`, the original-operator opening of `extensive_quantum_blocking.tex`, `FABEL_JACOBI_TO_YM_COORDINATE_AUDIT.md`, the current `agents/ns_scaling_bridge/ns_scaling_bridge.tex`, and the current `tex/quantum_tensor_symmetry.tex`. The first three are in the original local YM task and were not edited. The final composition review below is bound in `final_review_receipt.json`.

## Complete author-fragment review

The complete `agents/ym_composition_review/ym_composition.tex` was read. It restates the original finite interacting operator, its actual vacuum, the full matrix, all scalar/conic maps, the complex state map and its proof, and the external quantum-module map. The argument preserves the original lattice, all face terms, the inner-product convention, the distinction between arithmetic and physical spacing, and the distinction between a continued tensor and the unchanged self-adjoint Hamiltonian.

The author's coefficient field is equivalently \(\mathcal R=\mathbb C\{z_F\}[z_F^{-1}]\). The linear change \(z_F=-i\sqrt8w\) is a local analytic coordinate isomorphism between this field and the \(\mathscr M\) used above. Every nonzero one-variable convergent germ is a power of its coordinate times an analytic unit, so this localization is precisely the meromorphic germ field. The author's branch \(p(0)=2\) and \(q=(p-z_F/2)/2\) gives the same composed NS sheet. Its denominator statement correctly applies only to germs.

The derivative calculation was checked on all generators. For \(s=-z_F^2/8\), the derivation is \(\nabla_s=-4z_F^{-1}\partial_{z_F}\). It gives \(\nabla_s r=2/z_F=-1/r\), \(\nabla_s p=-1/p\), and, from \(q'=-q/(2p)\), \(\nabla_s q=-q/(rp)\). The product rule gives exactly \(-\nabla_s^2/4=-4z_F^{-2}\partial_{z_F}^2+4z_F^{-3}\partial_{z_F}\). This maps the meromorphic germ field to itself and commutes with the fixed finite-span complex-linear state map. No differentiation on an unlocalized arithmetic quotient or equality with the physical Hamiltonian is asserted. The displayed polynomial acting on the original \(\widehat S\) agrees with the already proved conic arithmetic formula in `tex/conic_arithmetic_bridge.tex`.

The author's added kernel formula is exact. The three matrix channels have dimensions one, two, and three. On each channel its coefficient quadratic form is strictly positive away from zero. Since the three seed masses are nonnegative and the physical state is orthogonal to the full zero eigenspace, a vector is killed exactly when its components belong to channels with zero seed mass. Hence the stated sum of kernel channels and rank formula follow with no nonvanishing assumption. The extended external kernel follows by a complex vector-space complement to the finite-dimensional kernel, extending both the injection on that complement and its inverse on its image. Tensoring with the free original source preserves that decomposition. The natural embedding of the written \(X_{\mathcal R}\otimes_{\mathbb C}\ker\mathfrak M\) is \(x\otimes S\mapsto x\otimes(1\otimes S)\).

The original source's quantum generator matrices, divided powers, and central labels act on the external \(X\) factor. The given source coproduct acts only there when the second factor has its counit action. The exact source splitting and tensor-square idempotents already live over \(D\), so their formulas and inverse identities extend by the stated ring homomorphism. The author makes no quantum-module claim about the Hilbert factor, no star correspondence, and no canonical-basis or complexity-separation inference.

Four requested clarifications were checked in the live text: \(L\) is an integer; the gauge group and endpoint action are explicitly defined; exponential spectral integration is restricted to \(u\ge0\); and \(\mathcal A\Xi_f=[H,D_f]\psi\) is displayed to identify the squared-current moment on the common smooth domain. The \(u\ge0\) restriction matters because smooth vectors need not have finite positive exponential spectral moments. All four are resolved.

The independent local checker verifies all 48 signed coordinate permutations, every entry of the entire six-state cubic spectral Gram projection, the full complex modulus-square formula, and the germ/phase identities: 143 exact checks. The independent Hilbert audit derives the full operator-domain and sesquilinear statements, and its separate standard-library checker corroborates the complex Gram identities with 8,003 exact checks. These checks support the written proofs and do not replace them.

## Reproducibility repair

The default `check_domains_independently.py` replay reads only its own complete equations, the local reviewed composition and audit, and `input_provenance.json` in this directory. That small portable input contains only the two relative source locators and their previously observed SHA-256 hashes. It runs every one of the same 143 mathematical checks. Default replay does not reopen the external sources or read the private machine-path provenance record. Optional observation is invoked with `--observe-source --source-root <GCT-root>`; omitting the explicit source root is an argument error. It joins that supplied root with the two known relative NS and quantum paths and requires exact SHA-256 equality. A missing file raises an error and a changed hash fails the assertion; there is no fallback or skip in this observation mode. Its receipt is `source_observation.json`, preserving the default `verification.json`, and it contains no machine-specific source root. The final audit receipt lists the relative source observations separately from current required artifact hashes. It requires neither a full Fabel snapshot, external source TeX, nor the private `source_provenance.json` to seal the authored proof. This repair changes no mathematical formula, proof claim, or reviewed composition hash.
