from pathlib import Path
import json,subprocess,sys
root=Path(__file__).resolve().parent
checks=['scripts/check_quantum_tensor_symmetry.py', 'agents/quantum_tensor_audit/small_braid/check_small_braid.py', 'agents/plethysm_transport_exact/basis/check_integral_schur_basis.py', 'agents/plethysm_transport_exact/check_plethysm_transport.py', 'agents/plethysm_transport_exact/audit/check_independently.py', 'agents/plethysm_transport_exact/audit/mixed_prime/check_mixed_prime.py', 'agents/ns_scaling_bridge/check_ns_scaling_bridge.py', 'agents/ns_scaling_bridge/source_audit/check_bridge_independently.py', 'agents/positive_source_geometry_obstruction/ns_bridge_audit/check_conic_connection.py', 'agents/positive_source_geometry_obstruction/ns_bridge_audit/profile_review/check_profiles.py', 'scripts/check_ns_schur_path.py', 'agents/ns_schur_path_audit/check_endpoint_germ.py', 'agents/ns_schur_path_audit/tableau_audit/check_tableaux.py', 'agents/ns_schur_path_audit/tableau_audit/check_path_algebra.py', 'agents/ym_composition_review/check_composition.py', 'agents/ym_composition_review/coefficient_audit/check_coefficients.py', 'agents/ym_composition_review/domain_audit/check_domains_independently.py', 'agents/ym_composition_review/domain_audit/hilbert_complexification/cubic_check/check_cubic_weights.py', 'agents/ym_composition_review/coefficient_audit/weight_identity/check.py', 'agents/next_full_braiding/check_braid_identities.py', 'agents/next_full_braiding/check_full_source_entry.py', 'agents/next_full_braiding/audit_source_entry/check_independently.py', 'agents/full_braid_spectrum/check_spectrum.py', 'agents/full_braid_spectrum/independent_audit/check_spectrum.py', 'scripts/check_infinitesimal_braid.py', 'agents/infinitesimal_braid_audit/check_infinitesimal.py']
runs=[]
for name in checks:
 p=subprocess.run([sys.executable,'-X','utf8',str(root/name)],cwd=(root/name).parent,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 runs.append({'script':name,'exit_code':p.returncode,'output':p.stdout.decode('utf-8',errors='replace')})
 if p.returncode: print(runs[-1]['output']);raise SystemExit(p.returncode)
for command in [['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],['bibtex','main'],['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex'],['pdflatex','-interaction=nonstopmode','-halt-on-error','main.tex']]:
 p=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 if p.returncode: print(p.stdout.decode('utf-8',errors='replace'));raise SystemExit(p.returncode)
(root/'public_replay.json').write_text(json.dumps({'status':'passed','runs':runs},indent=2),encoding='utf-8')
print(json.dumps({'status':'passed','checks':len(runs)}))
