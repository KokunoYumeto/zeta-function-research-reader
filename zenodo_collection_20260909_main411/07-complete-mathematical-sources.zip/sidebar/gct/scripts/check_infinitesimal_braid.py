"""Exact original-coordinate checks for the proved infinitesimal braid map."""
from pathlib import Path
from collections import defaultdict
from itertools import product
import hashlib,json,random
ROOT=Path(__file__).resolve().parents[1]
MP=ROOT/'agents/full_source_generators/full_generators.json'
BP=ROOT/'agents/full_source_generators/source_basis/basis_1260.json'
assert hashlib.sha256(MP.read_bytes()).hexdigest()=='e26086722e2910dc9ffff7d57314a25e80b79bb00bfb1808a42bf97761377253'
assert hashlib.sha256(BP.read_bytes()).hexdigest()=='77233bf1fb129fd3dd7077987f1ae2ea62619aaff1ff178432a342fa2f15b767'
basis=json.loads(BP.read_text())['basis']; source=json.loads(MP.read_text())['matrices']
M={name:[{target:sum(c for e,c in poly) for target,poly in col if sum(c for e,c in poly)} for col in cols] for name,cols in source.items()}
H={c:[b['weight_'+c][0]-b['weight_'+c][1] for b in basis] for c in ('V','W')}
counts=defaultdict(int)
def clean(v):return {i:a for i,a in v.items() if a}
def add(*terms):
 out=defaultdict(int)
 for a,v in terms:
  for i,b in v.items():out[i]+=a*b
 return clean(out)
def apply(mat,v):
 out=defaultdict(int)
 for j,a in v.items():
  for i,b in mat[j].items():out[i]+=a*b
 return clean(out)
def ck(value,category):
 assert value,category
 counts[category]+=1
C={}
for colour in ('V','W'):
 E,F=M['E'+colour],M['F'+colour]; h=H[colour]
 C[colour]=[add((h[j]**2,{j:1}),(2,apply(E,F[j])),(2,apply(F,E[j]))) for j in range(1260)]
 for j in range(1260):
  ck(add((1,apply(E,F[j])),(-1,apply(F,E[j])))==clean({j:h[j]}),'original classical commutator')
  for name in ('E'+colour,'F'+colour):
   ck(apply(C[colour],M[name][j])==apply(M[name],C[colour][j]),'actual Casimir commutation')
def factor(v,position,mat):
 out=defaultdict(int)
 for key,a in v.items():
  for target,b in mat[key[position]].items():
   new=list(key);new[position]=target;out[tuple(new)]+=a*b
 return clean(out)
def pair(v,i,j):
 out={}
 for key,a in v.items():
  diagonal=450+sum(H[c][key[i]]*H[c][key[j]] for c in ('V','W'))
  out=add((1,out),(a*diagonal,{key:1}))
 for c in ('V','W'):
  out=add((1,out),(2,factor(factor(v,j,M['F'+c]),i,M['E'+c])),(2,factor(factor(v,j,M['E'+c]),i,M['F'+c])))
 return out
def total(v,mat):return add(*[(1,factor(v,i,mat)) for i in range(len(next(iter(v))))]) if v else {}
def dtcas(v,c):
 n=len(next(iter(v))); assert n==2
 hv={key:a*sum(H[c][key[i]] for i in range(n))**2 for key,a in v.items()}
 return add((1,hv),(2,total(total(v,M['F'+c]),M['E'+c])),(2,total(total(v,M['E'+c]),M['F'+c])))
rng=random.Random(260908)
pairs=[(126,126),(126,144),(144,126),(8,146),(0,1259)]+[(rng.randrange(1260),rng.randrange(1260)) for _ in range(55)]
for a,b in pairs:
 v={(a,b):1}; rhs=add((900,v))
 for c in ('V','W'):
  rhs=add((1,rhs),(1,dtcas(v,c)),(-1,factor(v,0,C[c])),(-1,factor(v,1,C[c])))
 ck(add((2,pair(v,0,1)))==rhs,'actual two-colour Casimir identity')
 for name in ('EV','FV','EW','FW'):
  ck(pair(total(v,M[name]),0,1)==total(pair(v,0,1),M[name]),'actual pair invariance')
ck(pair({(126,126):1},0,1)=={(126,126):540},'retained highest tensor exact central eigenvalue')
triples=[(126,126,126),(126,144,8),(1259,0,146)]+[tuple(rng.randrange(1260) for _ in range(3)) for _ in range(15)]
for key in triples:
 v={key:1}
 lhs=pair(add((1,pair(v,0,2)),(1,pair(v,1,2))),0,1)
 rhs=add((1,pair(pair(v,0,1),0,2)),(1,pair(pair(v,0,1),1,2)))
 ck(lhs==rhs,'actual three-position infinitesimal braid relation')
for m,n in product((1,3,5,7,9),repeat=2):
 for r in range(min(m,n)+1):
  l=m+n-2*r; value=m*n-2*r*(m+n-r+1)
  ck(2*value==l*(l+2)-m*(m+2)-n*(n+2),'all allowed one-colour Casimir exponents')
  ck(value>=-99,'uniform one-colour lower bound')
receipt={'status':'passed','checks':sum(counts.values()),'categories':dict(counts),'source_matrices_sha256':hashlib.sha256(MP.read_bytes()).hexdigest(),'source_basis_sha256':hashlib.sha256(BP.read_bytes()).hexdigest(),'proof':'tex/infinitesimal_braid.tex','proof_sha256':hashlib.sha256((ROOT/'tex/infinitesimal_braid.tex').read_bytes()).hexdigest(),'scope':'Full proof supplemented by all original-column Casimir checks,60 exact source-pair identities,18 actual sparse triple tests and every allowed one-colour eigenvalue. Tests do not enumerate the1260^3 tensor basis.'}
(ROOT/'checks/infinitesimal_braid.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps({'status':'passed','checks':receipt['checks'],'categories':receipt['categories']}))
