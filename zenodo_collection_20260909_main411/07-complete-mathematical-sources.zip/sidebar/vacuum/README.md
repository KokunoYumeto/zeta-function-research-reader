# Geometric and thermodynamic images of the actual forced construction

The complete mathematical reader is `reader.pdf`; its source is `tex/main.tex` and the five included TeX sections. The reader preserves the released construction's cutoff sums, viscosity, pressure, force, time, source constants, and parameter domains.

The local proofs calculate the full actual axis jet; the Rindler metric, stress, and normal momentum flux; an invertible curved-boundary representation of the entire force; horizon shear, normal-connection curvature, and the forced area and entropy balance; the complete stereographic forced equation on a round sphere; and an explicitly calibrated arithmetic thermometric state with Hamiltonian and modular-time maps.

The existence and all-order correction scheme of the released Navier–Stokes construction are identified source imports. The reader proves its local maps and identities. It does not claim independent certification of the entire released proof, a nonlinear forced vacuum completion absent from the cited source, or terminal convergence of the gravitational expansion. Source-internal sign and coefficient discrepancies are recorded where direct calculation encounters them.

## Reproduction

Use Python with SymPy and a TeX installation providing pdfLaTeX, Latin Modern, AMS packages, `mathtools`, `mathrsfs`, `microtype`, `xurl`, and `hyperref`.

Run each `scripts/check_*.py` checker once, sequentially, then run `python scripts/build_reader.py`. The finite symbolic checks supplement the written proofs; they are not a verification of the external existence theorem. No Lean, network access, credentials, or upload is required to rebuild the reader.

`records/` holds the source identities, exact source locations, map and claim records, and check receipts. The local `sources/` and `private/` directories are excluded from the public payload. They are not needed to build the TeX. Copyrighted source papers and private session messages are not redistributed. Primary-source links are given in the reader and source records.

The `public_payload/` directory is the publication-safe copy for the existing parent mirror lane. It contains the readable PDF, complete authored TeX, bounded verification scripts, and sanitized records. It is not an independent upload or release.
