"""Rebuild the complete readable proof artifact; no source downloads or uploads."""
from pathlib import Path
import subprocess, shutil, json, hashlib, re

root=Path(__file__).resolve().parents[1]
tex=root/'tex'
for run in (1,2):
 proc=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',
                      '-file-line-error','main.tex'],cwd=tex,capture_output=True)
 (tex/f'build_{run}.txt').write_bytes(proc.stdout+proc.stderr)
 if proc.returncode:
  raise SystemExit(f'LaTeX failed; see tex/build_{run}.txt')
log=(tex/'main.log').read_text(encoding='utf-8',errors='replace')
issues=re.findall(r'Overfull[^\n]*|LaTeX Warning: (?:Reference|Citation)[^\n]*|[^\n]*undefined references[^\n]*',log)
if issues:
 print('\n'.join(issues));raise SystemExit('Resolve typesetting and references before delivery')
out=root/'reader.pdf';shutil.copyfile(tex/'main.pdf',out)
record={'status':'passed','runs':2,'output':'reader.pdf',
        'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
        'bytes':out.stat().st_size,'overfull_boxes':0,'undefined_references':0,
        'visual_QA':'separate rendered-page inspection record'}
(root/'records/build.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(record,indent=2))
