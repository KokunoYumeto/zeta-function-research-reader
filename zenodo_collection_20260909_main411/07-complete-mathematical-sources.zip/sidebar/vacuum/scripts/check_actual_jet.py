"""Bounded exact algebra checks for the written actual-axis derivation.

This does not verify the source manuscript's existence proof or profiles.
All original constants are free symbolic values; no numerical normalization.
"""
from pathlib import Path
import hashlib
import json
import sympy as sp

ROOT = Path(__file__).resolve().parents[1]
tau, q, nu, C, h, j0, Lam, sig = sp.symbols(
    'tau q nu C h j0 Lambda sigma_star', positive=True)
eta = sp.symbols('eta', real=True)
A, D = sp.Rational(1, 2) + h, sp.Rational(1, 2) - h
d, L = 1 - eta**2, 1 - 2*h*eta**2
b = C**-1 * tau**(-1-h)
G = sp.Matrix([[-2/tau, -b, 0], [b, -2/tau, 0], [0, 0, 4/tau]])
S, Om = (G + G.T)/2, (G - G.T)/2
omega = sp.Matrix([G[2, 1]-G[1, 2], G[0, 2]-G[2, 0], G[1, 0]-G[0, 1]])
checks = []

def check(name, actual, expected):
    delta = actual - expected
    if isinstance(delta, sp.MatrixBase):
        ok = all(sp.simplify(v) == 0 for v in delta)
    else:
        ok = sp.simplify(delta) == 0
    if not ok:
        raise AssertionError((name, actual, expected, delta))
    checks.append({'name': name, 'status': 'exact_zero',
                   'actual': sp.sstr(actual), 'expected': sp.sstr(expected)})

qz, etaz = 2*eta*q**(1-D)/L, d/(q**D*L)
qt, etat = -1/L, D*eta/(q*L)
check('z derivative of tau relation', qz*d - 2*q*eta*etaz, 0)
check('z derivative of z relation', D*q**(D-1)*eta*qz + q**D*etaz, 1)
check('t derivative of tau relation', qt*d - 2*q*eta*etat, -1)
check('t derivative of z relation', D*q**(D-1)*eta*qt + q**D*etat, 0)
w = q**(-A)*(4*eta+j0)
k = q**-1/L*(4*d - 2*A*eta*(4*eta+j0))
check('full axis axial derivative', sp.diff(w,q)*qz + sp.diff(w,eta)*etaz, k)
check('origin axial derivative', k.subs({eta:0, q:tau}), 4/tau)
check('source radial coefficient equals minus half axial derivative',
      (2*eta*(4*eta+j0) - 2*D*eta*(4*eta+j0) - 4*d)/(2*q*L), -k/2)
check('viscosity spatial derivative multiplier', sp.sqrt(nu)/sp.sqrt(nu), 1)
check('strain tensor', S, sp.diag(-2/tau, -2/tau, 4/tau))
check('trace strain', sp.trace(S), 0)
check('vorticity vector', omega, sp.Matrix([0,0,2*b]))
check('strain squared', sp.trace(S*S.T), 24/tau**2)
check('rotation squared', sp.trace(Om*Om.T), 2/C**2*tau**(-2-2*h))
check('vorticity squared', omega.dot(omega), 4/C**2*tau**(-2-2*h))
check('full gradient squared', sp.trace(G*G.T), 24/tau**2+2/C**2*tau**(-2-2*h))
check('symmetrized derivative squared', sp.trace((G+G.T)*(G+G.T).T), 96/tau**2)
check('trace gradient squared', sp.trace(G**2), 24/tau**2-2/C**2*tau**(-2-2*h))
check('gradient determinant', G.det(), 4/tau*(4/tau**2+C**-2*tau**(-2-2*h)))
check('strain acts on vorticity', S*omega, 4/tau*omega)
check('local viscous dissipation', 2*nu*sp.trace(S*S.T), 48*nu/tau**2)
Hstar = D*eta+d*(4*eta+j0)
zeta_star = -L*Hstar/(Hstar**2+sig**2)
phi_prime_0 = Lam*zeta_star.subs(eta,0)
check('original phi axis derivative', phi_prime_0, -Lam*j0/(j0**2+sig**2))
oz_z = 2/(C*sp.sqrt(nu))*tau**(-1-h-D)*phi_prime_0
check('axial vorticity derivative exponent', oz_z,
      2/(C*sp.sqrt(nu))*tau**sp.Rational(-3,2)*phi_prime_0)
dt_oz = -sp.diff(2*b, tau)
adv_oz = sp.sqrt(nu)*j0*tau**(-A)*oz_z
stretch_oz = 4/tau*(2*b)
check('fixed point vorticity derivative', dt_oz, 2/C*(1+h)*tau**(-2-h))
check('material advection term retained', adv_oz,
      2/C*j0*phi_prime_0*tau**(-2-h))
check('exact vorticity diffusion plus actual force curl', dt_oz+adv_oz-stretch_oz,
      2/C*(h-3-Lam*j0**2/(j0**2+sig**2))*tau**(-2-h))
check('force norm viscosity factor', sp.sqrt(nu)*nu**sp.Rational(3,4), nu**sp.Rational(5,4))
check('energy viscosity factor', nu*nu**sp.Rational(3,2), nu**sp.Rational(5,2))
check('Helmholtz potential viscosity factor', nu**sp.Rational(-1,2)*nu**sp.Rational(3,2), nu)

payload = {
    'schema_version': 1,
    'scope': 'Exact finite-dimensional algebra checks; source existence not verified.',
    'check_count': len(checks),
    'status': 'passed',
    'source_pdf_sha256': '0e779481c4da40bd28d1e642e1d8ca57447d129610df28dfa5a11e9af8ae228f',
    'tex_sha256': hashlib.sha256((ROOT/'tex/actual_jet.tex').read_bytes()).hexdigest(),
    'checks': checks,
}
out = ROOT/'records/actual_jet_checks.json'
out.write_text(json.dumps(payload, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'status':'passed','check_count':len(checks),'receipt':str(out)}))
