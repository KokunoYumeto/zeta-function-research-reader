"""Exact linear curvature check for the retained 5D BKLS metric.

One SymPy process, three symbolic axis gradient entries; no numerical grid.
The perturbation parameter d represents hydrodynamic weight two at a point.
"""
from pathlib import Path
import sympy as s
import json

T,r,x,y,z=s.symbols('T r x y z', real=True)
rc=s.symbols('r_c', positive=True)
a,b,c=s.symbols('a b c', real=True)
q=[T,r,x,y,z]; n=5
g=s.zeros(n);g[0,0]=-r;g[0,1]=g[1,0]=1
for i in range(2,n):g[i,i]=1
gi=g.inv()
v=[a*x-b*y,b*x+a*y,c*z]
h=s.zeros(n)
for i in range(3):
 h[0,i+2]=h[i+2,0]=-(1-r/rc)*v[i]
 h[1,i+2]=h[i+2,1]=-v[i]/rc
hi=-gi*h*gi
def gamma(inv,met):
 return [[[s.expand(sum(inv[A,D]*(s.diff(met[D,C],q[B])+s.diff(met[D,B],q[C])-s.diff(met[B,C],q[D]))/2 for D in range(n))) for C in range(n)]for B in range(n)]for A in range(n)]
G0=gamma(gi,g); t1=gamma(gi,h); t2=gamma(hi,g)
G1=[[[s.expand(t1[A][B][C]+t2[A][B][C])for C in range(n)]for B in range(n)]for A in range(n)]
R={}
for A in range(n):
 for B in range(n):
  for C in range(n):
   for D in range(n):
    if C==D:continue
    v0=s.diff(G1[A][D][B],q[C])-s.diff(G1[A][C][B],q[D])
    v0+=sum(G0[A][C][E]*G1[E][D][B]+G1[A][C][E]*G0[E][D][B]-G0[A][D][E]*G1[E][C][B]-G1[A][D][E]*G0[E][C][B] for E in range(n))
    v0=s.expand(v0).subs({x:0,y:0,z:0})
    if v0!=0:R[A,B,C,D]=v0
Rl={}
for A in range(n):
 for B in range(n):
  for C in range(n):
   for D in range(n):
    val=s.expand(sum(g[A,E]*R.get((E,B,C,D),0) for E in range(n)))
    if val!=0:Rl[A,B,C,D]=val
nonzero_inv={A:[(B,gi[A,B])for B in range(n)if gi[A,B]!=0]for A in range(n)}
K=0
for (A,B,C,D),val in Rl.items():
 for E,ae in nonzero_inv[A]:
  for F,bf in nonzero_inv[B]:
   for H,ch in nonzero_inv[C]:
    for I,di in nonzero_inv[D]:K+=val*ae*bf*ch*di*Rl.get((E,F,H,I),0)
K=s.factor(K)
checks={
 'leading_riemann_square': str(K),
 'expected_riemann_square':str(-12*b**2/rc**2),
 'riemann_square_check':s.expand(K+12*b**2/rc**2)==0,
 'nonzero_riemann_lowered_components':len(Rl),
 'axis_strain_trace':str(2*a+c),
 'axis_strain_squared':str(2*a*a+c*c),
 'all_curvature_components':{','.join(map(str,k)):str(val)for k,val in Rl.items()},
 'scope':'Exact coefficient for metric first jet of hydrodynamic weight two. Does not solve forced vacuum Einstein equations or bound a terminal remainder.'
}
out=Path(__file__).resolve().parents[1]/'records/curvature_check.json'
out.write_text(json.dumps(checks,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in checks.items()if k!='all_curvature_components'},indent=2))
assert checks['riemann_square_check']
