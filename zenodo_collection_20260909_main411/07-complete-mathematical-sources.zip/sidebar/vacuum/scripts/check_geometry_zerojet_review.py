"""Independent finite symbolic zero-jet check, retaining viscosity and pressure.

By an orthogonal spatial coordinate change a constant velocity is aligned
with z; the two perpendicular directions are flat product factors. This
3 by 3 calculation therefore checks every component in the five-dimensional
constant-velocity/pressure sector through hydrodynamic weight two.
"""
import json
from pathlib import Path
import sympy as s

T, r, z = s.symbols('T r z', real=True)
nu = s.symbols('nu', positive=True)
w, p = s.symbols('w p', real=True)
q = (T, r, z)
n = len(q)
g0 = s.Matrix([[-r, 1, 0], [1, 0, 0], [0, 0, 1]])
g1 = s.zeros(n)
g1[0,2] = g1[2,0] = -(1-r/nu)*w
g1[1,2] = g1[2,1] = -w/nu
g2 = s.zeros(n)
g2[0,0] = (1-r/nu)*(w*w+2*p)
g2[0,1] = g2[1,0] = (w*w+2*p)/(2*nu)
g2[2,2] = (1-r/nu)*w*w/nu
iv0 = g0.inv()
iv1 = -iv0*g1*iv0
iv2 = iv0*g1*iv0*g1*iv0-iv0*g2*iv0
gs=(g0,g1,g2)
ivs=(iv0,iv1,iv2)
Gam=[]
for k in range(3):
    Gam.append([[[s.factor(sum(
        ivs[j][a,d]*(s.diff(gs[k-j][d,c],q[b])
                    +s.diff(gs[k-j][d,b],q[c])
                    -s.diff(gs[k-j][b,c],q[d]))/2
        for j in range(k+1) for d in range(n)))
        for c in range(n)] for b in range(n)] for a in range(n)])
nonzero={}
for k in range(3):
    for a in range(n):
        for b in range(n):
            for c in range(n):
                for d in range(n):
                    val=s.diff(Gam[k][a][d][b],q[c])-s.diff(Gam[k][a][c][b],q[d])
                    val+=sum(Gam[j][a][c][e]*Gam[k-j][e][d][b]
                             -Gam[j][a][d][e]*Gam[k-j][e][c][b]
                             for j in range(k+1) for e in range(n))
                    val=s.factor(val)
                    if val != 0:
                        nonzero[','.join(map(str,(k,a,b,c,d)))]=str(val)
result={
    'method':'Exact rational-symbolic coefficient calculation; v=epsilon*w*e_z and P=epsilon^2*p; nu preserved.',
    'nonzero_riemann_components_weights_0_1_2':nonzero,
    'zerojet_flat_through_weight_two':not nonzero,
    'scope':'Constant v and P only; orthogonal spatial covariance restores arbitrary constant vector. No assertion about higher orders or a terminal bound.'
}
out=Path(__file__).resolve().parents[1]/'records/geometry_zerojet_review.json'
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
assert not nonzero
