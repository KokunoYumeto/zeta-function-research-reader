"""Replay the 21 exact membrane checks with SymPy and the authored TeX only.

Run from any directory: python scripts/check_membrane.py
The receipt is written to records/membrane_checks.json beside this project.
"""
from pathlib import Path
import hashlib
import json
import re

import sympy as s


root = Path(__file__).resolve().parents[1]
proof = root / "tex/membrane.tex"
tau, C, h, eps, nu, k, a = s.symbols(
    "tau C h epsilon nu kappa0 a_H", positive=True
)
b = 1 / (C * tau ** (1 + h))
G = s.Matrix([[-2 / tau, -b, 0], [b, -2 / tau, 0], [0, 0, 4 / tau]])
S = (G + G.T) / 2
omega = s.Matrix([G[2, 1] - G[1, 2], G[0, 2] - G[2, 0], G[1, 0] - G[0, 1]])
checks = []


def check(name, expr):
    result = s.expand(expr)
    if result != 0:
        result = s.factor(result)
    if result != 0:
        raise AssertionError((name, result))
    checks.append({"id": name, "passed": True, "exact_zero_residual": str(result)})


check("axis_incompressibility", s.trace(G))
check("axis_strain_square", s.trace(S.T * S) - 24 / tau**2)
check("axis_vorticity_square", (omega.T * omega)[0] - 4 / (C**2 * tau ** (2 + 2 * h)))
check("axis_full_gradient_square", s.trace(G.T * G) - 24 / tau**2 - 2 / (C**2 * tau ** (2 + 2 * h)))
check("epsilon_shear_square", s.trace((eps**2 * S).T * (eps**2 * S)) - 24 * eps**4 / tau**2)
F = k * eps**2 * (G - G.T)
check("normal_connection_square", s.trace(F.T * F) / a**4 - 8 * k**2 * eps**4 / (a**4 * C**2 * tau ** (2 + 2 * h)))
check("viscosity_focusing_factor", (24 * eps**4 / (k * tau**2)).subs(k, 1 / (2 * nu)) - 48 * nu * eps**4 / tau**2)
v1, v2, v3 = s.symbols("v1 v2 v3")
d1, d2, d3 = s.symbols("d1 d2 d3")
check("velocity_square_cancellation", k * (v1 * d1 + v2 * d2 + v3 * d3) - k * (2 * v1 * d1 + 2 * v2 * d2 + 2 * v3 * d3) / 2)
Q, J1, J2, J3, z, X1, X2, X3 = s.symbols("Q J1 J2 J3 z X1 X2 X3")
metric = s.Matrix([[0, 1, 0, 0, 0], [1, 0, 0, 0, 0], [0, 0, 1, 0, 0], [0, 0, 0, 1, 0], [0, 0, 0, 0, 1]])
kvec = s.Matrix([1, -z * z * (X1 * X1 + X2 * X2 + X3 * X3) / 2, z * X1, z * X2, z * X3])
check("null_variation_is_exactly_null", (kvec.T * metric * kvec)[0])
T = s.zeros(5)
T[0, 0] = Q
for i, J in enumerate([J1, J2, J3], 2):
    T[0, i] = T[i, 0] = J
check("tensor_section_nn", T[0, 0] - Q)
for i, J in enumerate([J1, J2, J3], 2):
    check(f"tensor_section_ne_{i - 1}", T[0, i] - J)
check("null_energy_linear_term", s.diff((kvec.T * T * kvec)[0], z).subs(z, 0) - 2 * (J1 * X1 + J2 * X2 + J3 * X3))
ell = s.Matrix([1, -(J1**2 + J2**2 + J3**2) / (2 * Q**2), J1 / Q, J2 / Q, J3 / Q])
check("null_dust_covector", (ell.T * metric * ell)[0])
Td = Q * ell * ell.T
Jnorm = J1**2 + J2**2 + J3**2
check("null_dust_complement_nm", Td[0, 1] + Jnorm / (2 * Q))
check("null_dust_complement_me1", Td[1, 2] + Jnorm * J1 / (2 * Q**2))
check("null_dust_complement_mm", Td[1, 1] - Jnorm**2 / (4 * Q**3))
check("null_dust_screen_e1e2", Td[2, 3] - J1 * J2 / Q)
xi, kap, dt, dxi = s.symbols("xi kappa dt dxi", positive=True)
check("rindler_ef_metric", -kap**2 * xi**2 * (dt - dxi / (kap * xi))**2 + dxi**2 - (-kap**2 * xi**2 * dt**2 + 2 * kap * xi * dt * dxi))

text = proof.read_text(encoding="utf-8")
labels = re.findall(r"\\label\{([^}]+)\}", text)
assert len(labels) == len(set(labels)), "Duplicate TeX labels"
assert all(label.startswith("mf:") for label in labels), "Unexpected TeX label namespace"
assert "=mathcal" not in text and r"\([," not in text, "Known TeX typo"
stack = []
for kind, name in re.findall(r"\\(begin|end)\{([^}]+)\}", text):
    if kind == "begin":
        stack.append(name)
    else:
        assert stack and stack.pop() == name, (kind, name)
assert not stack, "Unclosed TeX environment"
checks.append({"id": "tex_unique_prefixed_labels_and_balanced_environments", "passed": True, "label_count": len(labels)})
assert len(checks) == 21


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


receipt = {
    "schema_version": 1,
    "command": "python scripts/check_membrane.py",
    "checker": {"path": "scripts/check_membrane.py", "sha256": sha(Path(__file__))},
    "inputs": [{"path": "tex/membrane.tex", "sha256": sha(proof)}],
    "dependencies": {"python": "standard library", "sympy_version": s.__version__},
    "check_count": len(checks),
    "passed": all(item["passed"] for item in checks),
    "checks": checks,
    "scope": "Exact authored tensor and coordinate identities plus TeX label/environment structure; no independent certification of source existence or bulk completion.",
}
destination = root / "records/membrane_checks.json"
destination.parent.mkdir(exist_ok=True)
destination.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"checks_passed": len(checks), "receipt": "records/membrane_checks.json", "sha256": sha(destination)}))
