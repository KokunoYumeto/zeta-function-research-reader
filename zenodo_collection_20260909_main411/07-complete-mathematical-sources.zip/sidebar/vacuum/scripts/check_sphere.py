"""Bounded exact checks, distinct from the human-readable sphere proofs."""
from pathlib import Path
import hashlib
import json
import time
import sympy as S

start = time.time()
root = Path(__file__).resolve().parents[1]
checks = []

def check(name, expressions):
    values = [S.factor(S.trigsimp(x)) for x in expressions]
    assert all(x == 0 for x in values), (name, values)
    checks.append({"name": name, "scalar_identities": len(values), "passed": True})

L = S.symbols('L', positive=True)
y = S.symbols('y0:3', real=True)
r2 = sum(x*x for x in y)
D = L*L+r2
O = 2*L*L/D
a = O**-3
q = [S.diff(O,x)/O for x in y]
Phi = S.Matrix([O*x for x in y]+[L*(r2-L*L)/D])
JP = Phi.jacobian(y)
check('chart radius and full pullback metric', [Phi.dot(Phi)-L*L]+list(JP.T*JP-O**2*S.eye(3)))
check('chart inverse composition', [L*Phi[i]/(L-Phi[3])-y[i] for i in range(3)])

def Gam(i,j,k):
    return int(i==j)*q[k]+int(i==k)*q[j]-int(j==k)*q[i]

# Check a nontrivial polynomial curl, constant offsets and linear shear.
A = S.Matrix([y[0]*y[1]**2+y[2]**3,
              y[1]*y[2]**2+y[0]**3,
              y[2]*y[0]**2+y[1]**3])
u = S.Matrix([S.diff(A[2],y[1])-S.diff(A[1],y[2])+1-2*y[0]-3*y[1],
              S.diff(A[0],y[2])-S.diff(A[2],y[0])+2+3*y[0]-2*y[1],
              S.diff(A[1],y[0])-S.diff(A[0],y[1])+3+4*y[2]])
check('test vector is divergence free', [sum(S.diff(u[i],y[i]) for i in range(3))])
v = a*u
dv = S.Matrix(3,3,lambda i,j:S.diff(v[i],y[j])+sum(Gam(i,j,k)*v[k] for k in range(3)))
check('flux divergence', [S.trace(dv)])
rough = S.Matrix([sum(S.diff(dv[i,j],y[j])+
      sum(Gam(i,j,k)*dv[k,j]-Gam(k,j,j)*dv[i,k] for k in range(3))
      for j in range(3))/O**2 for i in range(3)])
lapu = S.Matrix([sum(S.diff(u[i],z,2) for z in y) for i in range(3)])
qu = sum(q[i]*u[i] for i in range(3))
qq = sum(x*x for x in q)
dq = sum(S.diff(q[i],y[i]) for i in range(3))
explicit = S.Matrix([O**-5*(lapu[i]-3*sum(q[j]*S.diff(u[i],y[j]) for j in range(3))
      +2*sum(q[j]*S.diff(u[j],y[i]) for j in range(3))
      +(-2*dq+qq+2*O**2/L**2)*u[i]-q[i]*qu) for i in range(3)])
check('full Christoffel Laplacian plus Ricci against explicit force operator', list(rough+2*v/L**2-explicit))
conv = dv*v
conv2 = a*a*(u.jacobian(y)*u-qu*u-S.Matrix(q)*u.dot(u))
check('full convective derivative', list(conv-conv2))
vlow = O**2*v
dlow = S.Matrix(3,3,lambda i,j:S.diff(vlow[j],y[i])-
                           sum(Gam(k,i,j)*vlow[k] for k in range(3)))
strain = (dlow+dlow.T)/2
strain2 = S.Matrix(3,3,lambda i,j:O**-1*((S.diff(u[j],y[i])+S.diff(u[i],y[j]))/2
      -S.Rational(3,2)*(q[i]*u[j]+q[j]*u[i])+int(i==j)*qu))
check('full covariant strain', list(strain-strain2))
omega = S.Matrix(3,3,lambda i,j:S.diff(vlow[j],y[i])-S.diff(vlow[i],y[j]))
omega2 = S.Matrix(3,3,lambda i,j:O**-1*(S.diff(u[j],y[i])-S.diff(u[i],y[j])-q[i]*u[j]+q[j]*u[i]))
check('exterior vorticity', list(omega-omega2))

nu = S.symbols('nu', positive=True)
f = S.Matrix(S.symbols('f0:3'))
dp = S.Matrix(S.symbols('p0:3'))
ut = f-u.jacobian(y)*u-dp+nu*lapu
residual = a*ut+conv+O**-2*dp-nu*explicit
formula = a*f+(a*a-a)*(u.jacobian(y)*u)+(O**-2-a)*dp+nu*a*lapu-nu*explicit-a*a*(qu*u+S.Matrix(q)*u.dot(u))
check('forced PDE residual including original f and pressure', list(residual-formula))

tau,C,h = S.symbols('tau C h',positive=True)
b = C**-1*tau**(-1-h)
B = S.Matrix([[-2/tau,-b,0],[b,-2/tau,0],[0,0,4/tau]])
axisS=(B+B.T)/2
axisF=B.T-B
check('actual axis invariant strain and two-form',[
      S.trace(axisS.T*axisS)/64-S.Rational(3,8)/tau**2,
      S.trace(axisF.T*axisF)/128-b*b/16])

chi=S.symbols('chi', positive=True)
green=-((S.pi-chi)*S.cot(chi)-S.Rational(1,2))/(4*S.pi**2*L)
check('Green radial Laplacian away from source',[(S.diff(green,chi,2)+2*S.cot(chi)*S.diff(green,chi))/L**2+1/(2*S.pi**2*L**3)])
check('Green unit source flux',[S.limit(4*S.pi*L*S.sin(chi)**2*S.diff(green,chi),chi,0)-1])

alpha,m=S.symbols('alpha m',positive=True)
Aa=1+alpha/(2*m*m)
lam=m*m*Aa**2*(1-Aa**-2)/(3-2*Aa**-2)**2
check('lambda exact inverse polynomial',[lam*(3*Aa**2-2)**2-m*m*Aa**4*(Aa**2-1)])
check('lambda derivative at zero',[S.limit(lam/alpha,alpha,0)-1])
check('lambda second coefficient fixing source boundary sign',[
      S.limit((lam-alpha)/alpha**2,alpha,0)+S.Rational(15,4)/m**2])
gss=-(m/alpha)**2*(1-Aa**-2)
check('exact Schwarzschild boundary temporal coefficient',[
      S.limit(gss+1/lam,alpha,0)-S.Rational(9,2)/m**2])
r=S.symbols('r',positive=True)
rstar=r+m*S.log((r-2*m)/(r+2*m))
check('Schwarzschild tortoise derivative',[S.diff(rstar,r)-1/(1-(2*m/r)**2)])

source_path=root/'sources/1106.3084v1/sphere.tex'
source_sha256='ef92194e5b952466573956311acc5782f1c70f694a66ea742526a3616e76c48e'
source_available=source_path.is_file()
source_verified=None
if source_available:
    source_verified=hashlib.sha256(source_path.read_bytes()).hexdigest()==source_sha256
    assert source_verified, 'Local optional source does not match the pinned edition'
report={
 'schema_version':1,'status':'passed','checks':checks,
 'total_scalar_identities':sum(c['scalar_identities'] for c in checks),
 'seconds':round(time.time()-start,3),'python_role':'non-critical exact algebra; no Lean',
 'source_tex_sha256':source_sha256,
 'optional_local_source_available':source_available,
 'optional_local_source_hash_verified':source_verified,
 'proof_sha256':hashlib.sha256((root/'tex/sphere.tex').read_bytes()).hexdigest(),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'independent_review':'check_conformal independently corrected two draft Laplacian coefficients; corrections incorporated before final checks',
}
try:
    import psutil
    memory=psutil.Process().memory_info()
    report['process_peak_working_set_bytes']=getattr(memory,'peak_wset',memory.rss)
    assert report['process_peak_working_set_bytes'] < 5_000_000_000
except ImportError:
    report['process_peak_working_set_bytes']=None
(root/'records/sphere_checks.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':report['status'],'scalar_identities':report['total_scalar_identities'],'seconds':report['seconds']}))
