"""Replayable exact regressions for thermal.tex; all inputs are authored package files."""
from pathlib import Path
from fractions import Fraction
from math import gcd
import hashlib
import json
import sympy as s

ROOT = Path(__file__).resolve().parents[1]
checks = []

def record(name, n, ok):
    assert ok, name
    checks.append({"name": name, "exact_cases": n, "passed": True})

def monomial(n, r, m, k):
    if k % m:
        return None
    j = k // m
    return (n*j, (j*r) % 1)

count = 0
for n in range(1,4):
 for m in range(1,4):
  for a in range(1,4):
   for b in range(1,4):
    d = gcd(m,a)
    for r in [Fraction(0),Fraction(1,2),Fraction(1,3)]:
     for q in [Fraction(0),Fraction(1,2),Fraction(1,3)]:
      for k in range(1,13):
       right = monomial(a,q,b,k)
       lhs = None
       if right is not None:
           left = monomial(n,r,m,right[0])
           if left is not None:
               lhs = (left[0], (left[1]+right[1]) % 1)
       rhs = monomial(n*a//d, Fraction(a,d)*r+Fraction(m,d)*q, b*m//d,k)
       assert lhs == rhs, (n,m,a,b,r,q,k,lhs,rhs)
       count += 1
record("BC monomial product including divisibility and root-of-unity phase",count,True)

count = 0
for n in range(1,9):
 for m in range(1,9):
  p_n,p_m = Fraction(1,n*n),Fraction(1,m*m)
  record_ok = p_n * Fraction(m,n)**(-2) == p_m
  assert record_ok
  count += 1
record("KMS matrix-unit boundary with positive Hamiltonian convention",count,True)

x,y,z,t=s.symbols("x y z t", real=True)
v=s.Function("a")(x*x+y*y,z,t)
w=s.Function("b")(x*x+y*y,z,t)
u=s.Matrix([v*x-w*y,w*x+v*y,s.Function("d")(x*x+y*y,z,t)])
curl=s.Matrix([s.diff(u[2],y)-s.diff(u[1],z),
               s.diff(u[0],z)-s.diff(u[2],x),
               s.diff(u[1],x)-s.diff(u[0],y)])
axis=curl.subs({x:0,y:0,z:0})
record("smooth actual-axis curl including radial and axial terms",3,
       axis==s.Matrix([0,0,2*s.Function("b")(0,0,t)]))

I,C,tf,h,E,kB,hbar,lf,rhof=s.symbols("I C tf h E kB hbar lf rhof", positive=True)
tau=s.symbols("tau", positive=True)
eps=2*I/(C**2*tf**2)*(1-t)**(-2-2*h)
expected=2*I*(2+2*h)/(C**2*tf**2)*(1-t)**(-3-2*h)
record("actual sensor derivative retains C,h,inertia and time unit",1,
       s.simplify(s.diff(eps,t)-expected)==0)
heat_scale=rhof*(lf**2/tf)*lf**3*tf/tf**2
record("physical heat conversion factor",1,
       s.simplify(heat_scale-rhof*lf**5/tf**2)==0)

bt=s.Function("b")(t)
t0=s.symbols("t0",real=True)
spt=E*tf*(t-t0)/(hbar*bt)
record("pointwise modular clock full product derivative",1,
       s.simplify(s.diff(bt*spt,t)-E*tf/hbar)==0)
sl=s.Function("s")(t)
record("varying-state modular clock chain rule",1,
       s.expand(s.diff(bt*sl,t)-(bt*s.diff(sl,t)+sl*s.diff(bt,t)))==0)

bb,V,ell,ep=s.symbols("bb V ell ep", positive=True)
bp=-ep/(E*V)
record("calibrated entropy derivative equals dEnergy/temperature",1,
       s.simplify((-kB*bb*V)*bp-ep/(E/(kB*bb)))==0)
record("positive physical heat capacity expression",1,
       s.simplify((-E*V)/(-E/(kB*bb**2))-kB*bb**2*V)==0)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

receipt = {
    "schema_version": 1,
    "scope": "Mathematical regressions replayable without private or protected source files",
    "proof_artifact": {"path": "tex/thermal.tex", "sha256": sha(ROOT / "tex/thermal.tex")},
    "checker": {"path": "scripts/check_thermal.py", "sha256": sha(Path(__file__))},
    "replay_command": "python scripts/check_thermal.py",
    "dependencies": {"python": ">=3.10", "sympy": s.__version__},
    "groups": checks,
    "exact_cases": sum(c["exact_cases"] for c in checks),
    "all_passed": True,
    "source_intake_replayed": False,
    "source_intake_scope": "Earlier private source-byte verification remains recorded separately in thermal.json; this checker does not read external literature files."
}
(ROOT / "records").mkdir(exist_ok=True)
(ROOT / "records/thermal_checks.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"passed": True, "exact_cases": receipt["exact_cases"],
                  "groups": len(checks), "proof_sha256": receipt["proof_artifact"]["sha256"]}))
